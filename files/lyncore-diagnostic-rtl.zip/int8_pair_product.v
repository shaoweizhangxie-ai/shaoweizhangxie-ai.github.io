// 两个有符号INT8权重共享一个有符号INT8输入。
// 用本器件可接受的25x8乘法，不照搬DSP48实例。
// A = w1*2^17 + unsigned(w0)，P=A*x。
// 低乘积采用17bit保护区；借位修正高乘积，低乘积补回w0符号。
module int8_pair_product(input wire signed [7:0] x,w0,w1,
 output wire signed [15:0] p0,p1);
 wire signed [24:0] packed_weights=$signed({w1,9'd0,w0});
 wire signed [32:0] full_product /* synthesis syn_dspstyle = "block_mult" */ =packed_weights*x;
 wire signed [15:0] sign_correction=w0[7]?$signed({x,8'd0}):16'sd0;
 assign p0=$signed(full_product[15:0])-sign_correction;
 assign p1=$signed(full_product[32:17])+$signed({15'd0,full_product[16]});
endmodule
