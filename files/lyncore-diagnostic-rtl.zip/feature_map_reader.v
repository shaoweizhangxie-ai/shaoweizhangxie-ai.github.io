`timescale 1ns/1ps

// 响应 Conv Engine 的一次 ifm_request，从特征图缓存重放一个四通道组。
// 请求地址和输入像素分别按各自 ready/valid 推进，不依赖 RAM 固定等待拍数。
// 与缓存一起形成可综合的层间供数路径；外部负责决定源 Bank 和启动下一层。
module feature_map_reader (
    input  wire clk,
    input  wire rst_n,
    input  wire frame_start,
    output wire frame_ready,
    input  wire frame_bank,
    input  wire [15:0] frame_ci_group,
    input  wire source_valid,
    input  wire [31:0] source_pixels,
    input  wire [15:0] source_channels,
    input  wire abort,
    output wire busy,
    output reg  frame_done,
    output reg  error,
    output wire request_valid,
    input  wire request_ready,
    output wire request_bank,
    output wire [15:0] request_ci_group,
    output wire [31:0] request_index,
    input  wire response_valid,
    output wire response_ready,
    input  wire response_bank,
    input  wire [15:0] response_ci_group,
    input  wire [31:0] response_index,
    input  wire [31:0] response_pixel,
    input  wire response_error,
    output wire out_valid,
    input  wire out_ready,
    output wire [31:0] out_pixel
);
    reg active,preparing,cfg_source_valid;
    reg [16:0] cfg_groups;
    reg cfg_bank;
    reg [15:0] cfg_ci_group;
    reg [31:0] cfg_pixels;
    reg [31:0] next_request;
    reg [31:0] next_output;
    wire [16:0] source_groups = ({1'b0, source_channels} + 17'd3) >> 2;
    assign frame_ready = !active && !preparing && !response_valid;
    assign busy = active || preparing || response_valid;
    // 空闲时选择外部 Bank，便于从缓存读出该 Bank 的配置后启动。
    assign request_bank = (active || preparing) ? cfg_bank : frame_bank;
    assign request_ci_group = cfg_ci_group;
    assign request_index = next_request;
    assign request_valid = active && !abort && (next_request < cfg_pixels);
    wire response_matches = (response_bank == cfg_bank) &&
                            (response_ci_group == cfg_ci_group) &&
                            (response_index == next_output);
    assign out_valid = active && !abort && response_valid && response_matches;
    assign out_pixel = response_pixel;
    // 出错/中止后丢弃残留响应，防止上一帧事务堵住下一次启动。
    assign response_ready = !active || abort || !response_matches || out_ready;

    always @(posedge clk or negedge rst_n) begin
        if (!rst_n) begin
            active <= 1'b0;
            preparing <= 1'b0;cfg_source_valid <= 1'b0;cfg_groups <= 0;
            cfg_bank <= 1'b0;
            cfg_ci_group <= 16'd0;
            cfg_pixels <= 32'd0;
            next_request <= 32'd0;
            next_output <= 32'd0;
            frame_done <= 1'b0;
            error <= 1'b0;
        end else begin
            frame_done <= 1'b0;
            error <= 1'b0;
            if(preparing)begin
                preparing <= 1'b0;
                if(!cfg_source_valid || cfg_pixels==0 || {1'b0,cfg_ci_group}>=cfg_groups)
                    error <= 1'b1;
                else active <= 1'b1;
            end
            if (frame_start) begin
                if(!frame_ready)error <= 1'b1;
                else begin
                    preparing <= 1'b1;
                    cfg_source_valid <= source_valid;cfg_groups <= source_groups;
                    cfg_bank <= frame_bank;cfg_ci_group <= frame_ci_group;cfg_pixels <= source_pixels;
                    next_request <= 32'd0;next_output <= 32'd0;
                end
            end
            if (request_valid && request_ready) next_request <= next_request + 32'd1;
            if (out_valid && out_ready) begin
                next_output <= next_output + 32'd1;
                if (next_output == cfg_pixels - 32'd1) begin
                    active <= 1'b0;
                    frame_done <= 1'b1;
                end
            end
            if (active && (response_error || (response_valid && !response_matches))) begin
                active <= 1'b0;
                frame_done <= 1'b0;
                error <= 1'b1;
            end
            if (abort) begin
                active <= 1'b0;
                preparing <= 1'b0;
                frame_done <= 1'b0;
            end
        end
    end
endmodule
