`timescale 1ns/1ps
// Common asynchronous assertion, two local-clock edges before release.
module lyncore_reset_release(input wire clk,async_n,output wire release_n);
 (* syn_preserve=1 *) reg meta;
 (* syn_preserve=1 *) reg sync;
 always @(posedge clk or negedge async_n)
  if(!async_n)begin meta<=0;sync<=0;end
  else begin meta<=1;sync<=meta;end
 assign release_n=sync;
endmodule
