`timescale 1ns/1ps

// 保存一个输入通道组 × 输出通道组的权重，并向 PE 并行提供全部权重。
// 默认 PCIN=4、PCOUT=8，与当前 pe_array 的总线布局一致。
module weight_buffer #(
    parameter integer PCIN = 4,
    parameter integer PCOUT = 8,
    parameter integer STATIC_WRITE_DECODE = 1,
    parameter integer K1_WIDE_ENABLE = 0
) (
    input  wire                         clk,
    input  wire                         rst_n,
    input  wire                         load_start,
    input wire wide_mode,
    input wire [2:0] wide_subgroup,
    input  wire                         kernel_1x1,
    input  wire                         load_valid,
    output wire                         load_ready,
    input  wire [31:0]                  load_word,
    output wire                         load_busy,
    output reg                          load_done,
    output reg                          tile_valid,
    output reg  [PCIN*PCOUT*9*8-1:0]    weight_bus
);

    // Verilog-2001 常量函数：索引至少占一位，避免出现负数位宽。
    function integer index_width;
        input integer count;
        integer value;
        begin
            value = count - 1;
            index_width = 0;
            while (value > 0) begin
                index_width = index_width + 1;
                value = value >> 1;
            end
            if (index_width == 0)
                index_width = 1;
        end
    endfunction

    localparam integer WEIGHTS_3X3 = PCIN * PCOUT * 9;
    localparam integer WEIGHTS_1X1 = PCIN * PCOUT;
    localparam integer WORDS_3X3 = (WEIGHTS_3X3 + 3) / 4;
    localparam integer WORDS_1X1 = (WEIGHTS_1X1 + 3) / 4;
    localparam integer INDEX_WIDTH =
        index_width(WORDS_3X3);

    reg                     loading;
    reg                     active_kernel_1x1;
    reg [INDEX_WIDTH-1:0]   word_index;
    integer lane;

    assign load_ready = loading;
    assign load_busy  = loading;

    // 控制器只在 load_ready 为 1 时发送 32 位数据。
    // 一个 3×3 tile 默认接收 72 个字；一个 1×1 tile 默认接收 8 个字。
    always @(posedge clk or negedge rst_n) begin
        if (!rst_n) begin
            loading           <= 1'b0;
            active_kernel_1x1 <= 1'b0;
            word_index        <= {INDEX_WIDTH{1'b0}};
            load_done         <= 1'b0;
            tile_valid        <= 1'b0;
        end else begin
            load_done <= 1'b0;
            if (!loading && load_start) begin
                loading           <= 1'b1;
                active_kernel_1x1 <= kernel_1x1;
                word_index        <= {INDEX_WIDTH{1'b0}};
                tile_valid        <= 1'b0;
            end else if (loading && load_valid) begin
                if (active_kernel_1x1 ?
                    (word_index == WORDS_1X1-1) :
                    (word_index == WORDS_3X3-1)) begin
                    loading    <= 1'b0;
                    tile_valid <= 1'b1;
                    load_done  <= 1'b1;
                end else begin
                    word_index <= word_index + 1'b1;
                end
            end
        end
    end

    // 新 tile 开始时清空旧权重。RAM 不适合同时输出全部权重，
    // 因此这里用寄存器保存一个 tile，后续需结合目标器件评估资源。
    // 3×3：按 co、ci、k 的顺序连续写入 8 位权重。
    // 1×1：按 co、ci 的顺序输入，仅写每组九个位置中的 k=0。

    // 每个目的字节的写使能静态解码，避免动态2304位写选择器。
    generate if(STATIC_WRITE_DECODE!=0 && PCIN==4) begin : g_static_write
      genvar b;
      for(b=0;b<WEIGHTS_3X3;b=b+1)begin : g_byte
        localparam integer CO=b/(PCIN*9), CI=(b/9)%PCIN, K=b%9;
        wire wide=K1_WIDE_ENABLE!=0 && wide_mode;
        wire put_k3=!active_kernel_1x1 && word_index==b/4;
        wire put_k1=active_kernel_1x1 && !wide && K==0 && word_index==(CO*PCIN+CI)/4;
        wire put_wide=active_kernel_1x1 && wide && K<8 && word_index==CO && wide_subgroup==CI*2+K/4;
        wire [7:0] data_byte=!active_kernel_1x1?load_word[(b%4)*8 +: 8]:
             (wide?load_word[(K%4)*8 +: 8]:load_word[((CO*PCIN+CI)%4)*8 +: 8]);
        always @(posedge clk) if(rst_n)begin
          if(!loading && load_start)begin
            if(!wide || wide_subgroup==0)weight_bus[b*8 +: 8]<=0;
          end else if(loading && load_valid && (put_k3 || put_k1 || put_wide))
            weight_bus[b*8 +: 8]<=data_byte;
        end
      end
    end else begin : g_legacy_write
    always @(posedge clk) begin
        if (rst_n) begin
            if (!loading && load_start) begin
                if (K1_WIDE_ENABLE==0 || !wide_mode || wide_subgroup==0)
                    weight_bus <= {(PCIN*PCOUT*9*8){1'b0}};
            end else if (loading && load_valid) begin
                for (lane = 0; lane < 4; lane = lane + 1) begin
                    if (active_kernel_1x1) begin
                        if (word_index*4 + lane < WEIGHTS_1X1)
                            if (K1_WIDE_ENABLE!=0 && wide_mode)
                                // 外部每个字仍是co的四个ci权重，八次ci4装载重排到32通道。
                                // K1每次严格8字，显式3位索引避免PDS展开无效的高位选择空间。
                                weight_bus[(word_index[2:0]*36+wide_subgroup[2:1]*9+wide_subgroup[0]*4+lane)*8 +: 8] <= load_word[lane*8 +: 8];
                            else weight_bus[((word_index*4 + lane)*9)*8 +: 8] <= load_word[lane*8 +: 8];
                    end else begin
                        if (word_index*4 + lane < WEIGHTS_3X3)
                            weight_bus[(word_index*4 + lane)*8 +: 8] <=
                                load_word[lane*8 +: 8];
                    end
                end
            end
        end
    end

    end endgenerate
endmodule
