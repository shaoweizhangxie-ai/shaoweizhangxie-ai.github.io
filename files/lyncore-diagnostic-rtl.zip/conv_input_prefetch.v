`timescale 1ns/1ps

// 两个输入 Bank 的预取管理器。只管理搬运和标签，不改变卷积/Psum 数学语义。
// 每个 Bank 保存一个 Tile+Halo 的 group8，Reader 每次选择低/高 group4。
// 正在读取的 Bank 不得被覆盖；标签仅在 DMA 和缓存均完整提交后发布。
module conv_input_prefetch #(
    parameter [31:0] DDR_WINDOW_BASE=32'h20000000,
    parameter [63:0] DDR_BYTES=64'h40000000,
    parameter integer DDR_READ_PIPELINE=0,
    parameter integer FEATURE_RESIDENCY=0, FEATURE_CACHE_WORDS=8192, K1_WIDE_ENABLE=0
) (
    input wire clk,rst_n,clear,invalidate,
    input wire [31:0] frame_base,
    input wire [15:0] frame_width,frame_height,frame_channels,
    input wire [1:0] step,pad,
    input wire demand_valid,
    input wire [31:0] demand_tile,
    input wire [15:0] demand_group,demand_width,demand_height,
    output wire demand_hit,demand_bank,
    input wire hint_valid,
    input wire [31:0] hint_tile,
    input wire [15:0] hint_group,hint_width,hint_height,
    input wire protect_valid,protect_bank,
    output wire busy,
    output reg error,
    output wire cache_write_start,
    input wire cache_write_ready,
    output wire cache_write_bank,
    output wire [15:0] cache_width,cache_height,cache_channels,
    output wire cache_write_valid,
    input wire cache_data_ready,cache_write_allow,
    output wire [15:0] cache_co,
    output wire [31:0] cache_index,
    output wire [63:0] cache_data,
    output wire cache_write_end,
    input wire cache_write_done,cache_error,
    output wire read_request_valid,
    input wire read_request_ready,
    output wire [31:0] read_request_address,
    input wire read_response_valid,
    output wire read_response_ready,
    input wire [31:0] read_response_address,read_response_data,
    input wire read_response_error,
    input wire wide_mode,
    input wire [31:0] wide_tile_y,
    input wire [15:0] wide_width,wide_height,wide_group8_base,
    output wire [3:0] wide_group_valid,
    input wire wide_request,
    input wire [31:0] wide_index,
    output wire wide_ready,wide_response_valid,
    output wire [255:0] wide_data
);
    localparam IDLE=0,OPEN=1,LAUNCH=2,TRANSFER=3,COMMIT=4,ABORT=5,PREPARE_SOURCE=6;
    reg [2:0] state;
    reg [1:0] valid;
    reg [31:0] tag_tile[0:1];
    reg [15:0] tag_group[0:1],tag_width[0:1],tag_height[0:1];
    reg target_bank,replacement;
    reg [31:0] target_tile;
    reg [15:0] target_group,target_width,target_height,target_channels;
    wire demand0=valid[0] && tag_tile[0]==demand_tile && tag_group[0]==demand_group &&
        tag_width[0]==demand_width && tag_height[0]==demand_height;
    wire demand1=valid[1] && tag_tile[1]==demand_tile && tag_group[1]==demand_group &&
        tag_width[1]==demand_width && tag_height[1]==demand_height;
    wire hint0=valid[0] && tag_tile[0]==hint_tile && tag_group[0]==hint_group &&
        tag_width[0]==hint_width && tag_height[0]==hint_height;
    wire hint1=valid[1] && tag_tile[1]==hint_tile && tag_group[1]==hint_group &&
        tag_width[1]==hint_width && tag_height[1]==hint_height;
    assign demand_hit=(demand0 || demand1) && !clear && !invalidate;
    assign demand_bank=!demand0 && demand1;
    wire use_demand=demand_valid && !demand_hit;
    wire want=use_demand || (hint_valid && !(hint0 || hint1));
    wire [31:0] selected_tile=use_demand?demand_tile:hint_tile;
    wire [15:0] selected_group=use_demand?demand_group:hint_group;
    wire [15:0] selected_width=use_demand?demand_width:hint_width;
    wire [15:0] selected_height=use_demand?demand_height:hint_height;
    // Reader 活跃时只能写另一 Bank；没有读者时优先填空 Bank。
    wire selected_bank=protect_valid?~protect_bank:(!valid[0]?1'b0:(!valid[1]?1'b1:replacement));
    wire [18:0] channel_start={selected_group,3'd0};
    wire [18:0] remaining={3'd0,frame_channels}-channel_start;
    wire [15:0] selected_channels=remaining>=8?16'd8:remaining[15:0];
    wire dma_ready,dma_busy,dma_done,dma_error,dma_cancelled,dma_valid;
    // 驻留缓存只减少跨 co 的 DDR 重读，仍通过原 inactive Bank 完整提交。
    wire resident_geometry_ready;
    wire resident_eligible,resident_hit,resident_valid,resident_done,resident_busy;
    wire [31:0] resident_index;
    wire [63:0] resident_data;
    wire [15:0] dma_co;
    wire [31:0] dma_index;
    wire [63:0] dma_data;
    reg use_resident;
    reg resident_hit_q,resident_eligible_q;
    wire source_ready=resident_hit_q || dma_ready;
    wire source_valid=use_resident?resident_valid:dma_valid;
    wire source_done=use_resident?resident_done:dma_done;
    wire source_accept=state==TRANSFER && cache_data_ready && cache_write_allow && !clear;
    assign cache_co=use_resident?16'd0:dma_co;
    assign cache_index=use_resident?resident_index:dma_index;
    assign cache_data=use_resident?resident_data:dma_data;
    // 仿真可观察的事件，不放硬件累计计数器。
    wire feature_cache_hit=state==LAUNCH && source_ready && resident_hit_q && !clear;
    wire feature_cache_miss=state==LAUNCH && source_ready && resident_eligible_q && !resident_hit_q && !clear;
    wire feature_cache_bypass=state==LAUNCH && source_ready && !resident_eligible_q && !clear;
    generate if(FEATURE_RESIDENCY!=0)begin:g_feature_residency
        feature_residency_cache #(.CACHE_WORDS(FEATURE_CACHE_WORDS),.K1_WIDE_ENABLE(K1_WIDE_ENABLE),.PIPELINE_GEOMETRY(1)) cache(
            .clk(clk),.rst_n(rst_n),.clear(clear || state==ABORT || cache_error || dma_error || dma_cancelled),.invalidate(invalidate),
            .frame_base(frame_base),.tile_y(target_tile),.frame_width(frame_width),.frame_height(frame_height),
            .frame_channels(frame_channels),.region_width(target_width),.region_height(target_height),.group8(target_group),.step(step),.pad(pad),
            .begin_request(state==LAUNCH && source_ready && !clear),.eligible(resident_eligible),.hit(resident_hit),.geometry_ready(resident_geometry_ready),
            .fill_valid(!use_resident && source_accept && dma_valid),.fill_index(dma_index),.fill_data(dma_data),
            .fill_commit(state==COMMIT && cache_write_done),
            .replay_valid(resident_valid),.replay_ready(use_resident && source_accept),.replay_index(resident_index),
            .replay_data(resident_data),.replay_done(resident_done),.replay_busy(resident_busy),
            .wide_mode(wide_mode),.wide_tile_y(wide_tile_y),.wide_width(wide_width),.wide_height(wide_height),
            .wide_group8_base(wide_group8_base),.wide_group_valid(wide_group_valid),.wide_request(wide_request),
            .wide_index(wide_index),.wide_ready(wide_ready),.wide_response_valid(wide_response_valid),.wide_data(wide_data));
    end else begin:g_no_feature_residency
        assign resident_geometry_ready=1;assign resident_eligible=0;assign resident_hit=0;assign resident_valid=0;assign resident_done=0;
        assign resident_busy=0;assign resident_index=0;assign resident_data=0;
        assign wide_group_valid=0;assign wide_ready=0;assign wide_response_valid=0;assign wide_data=0;
    end endgenerate
    assign busy=state!=IDLE;
    assign cache_write_start=state==OPEN && cache_write_ready && !clear;
    assign cache_write_bank=target_bank;
    assign cache_width=target_width;
    assign cache_height=target_height;
    assign cache_channels=target_channels;
    assign cache_write_valid=state==TRANSFER && source_valid && cache_write_allow && !clear;
    assign cache_write_end=state==TRANSFER && source_done && !clear;
    generate if(DDR_READ_PIPELINE!=0) begin: g_pipeline
    feature_map_ddr_read_pipeline #(.DDR_WINDOW_BASE(DDR_WINDOW_BASE),.DDR_BYTES(DDR_BYTES)) prefetch_dma (
        .clk(clk),.rst_n(rst_n),.clear(clear || state==ABORT),
        .start(state==LAUNCH && dma_ready && !resident_hit_q && !clear),.ready(dma_ready),.busy(dma_busy),
        .done(dma_done),.error(dma_error),.cancelled(dma_cancelled),.download(1'b1),
        .frame_base(frame_base),.frame_width(frame_width),.frame_height(frame_height),.frame_channels(frame_channels),
        .region_x(-$signed({30'd0,pad})),
        .region_y($signed(target_tile*step)-$signed({30'd0,pad})),
        .region_width(target_width),.region_height(target_height),.co_base(target_group),.co_groups(16'd1),
        .source_slot(3'd0),.source_config_slot(),.source_config_valid(1'b0),
        .source_width(16'd0),.source_height(16'd0),.source_channels(16'd0),
        .source_request_valid(),.source_request_ready(1'b0),.source_request_slot(),.source_request_ci_group(),.source_request_index(),
        .source_response_valid(1'b0),.source_response_ready(),.source_response_slot(3'd0),
        .source_response_ci_group(16'd0),.source_response_index(32'd0),.source_response_pixel(32'd0),.source_response_error(1'b0),
        .transfer_width(),.transfer_height(),.transfer_channels(),
        // 取消时仍接收已经呈现的 DMA 字并丢弃，避免 EMIT 等 ready 导致死锁。
        .out_valid(dma_valid),.out_ready(clear || state==ABORT || (!use_resident && state==TRANSFER && cache_data_ready && cache_write_allow)),
        .out_co_group(dma_co),.out_index(dma_index),.out_data(dma_data),.out_last(),
        .read_request_valid(read_request_valid),.read_request_ready(read_request_ready),.read_request_address(read_request_address),
        .read_response_valid(read_response_valid),.read_response_ready(read_response_ready),
        .read_response_address(read_response_address),.read_response_data(read_response_data),.read_response_error(read_response_error),
        .write_request_valid(),.write_request_ready(1'b0),.write_request_address(),.write_request_data(),.write_request_strobe(),
        .write_response_valid(1'b0),.write_response_ready(),.write_response_address(32'd0),.write_response_error(1'b0)
    );
    end else begin: g_serial
    feature_map_ddr_dma #(.DDR_WINDOW_BASE(DDR_WINDOW_BASE),.DDR_BYTES(DDR_BYTES)) prefetch_dma (
        .clk(clk),.rst_n(rst_n),.clear(clear || state==ABORT),
        .start(state==LAUNCH && dma_ready && !resident_hit_q && !clear),.ready(dma_ready),.busy(dma_busy),
        .done(dma_done),.error(dma_error),.cancelled(dma_cancelled),.download(1'b1),
        .frame_base(frame_base),.frame_width(frame_width),.frame_height(frame_height),.frame_channels(frame_channels),
        .region_x(-$signed({30'd0,pad})),
        .region_y($signed(target_tile*step)-$signed({30'd0,pad})),
        .region_width(target_width),.region_height(target_height),.co_base(target_group),.co_groups(16'd1),
        .source_slot(3'd0),.source_config_slot(),.source_config_valid(1'b0),
        .source_width(16'd0),.source_height(16'd0),.source_channels(16'd0),
        .source_request_valid(),.source_request_ready(1'b0),.source_request_slot(),.source_request_ci_group(),.source_request_index(),
        .source_response_valid(1'b0),.source_response_ready(),.source_response_slot(3'd0),
        .source_response_ci_group(16'd0),.source_response_index(32'd0),.source_response_pixel(32'd0),.source_response_error(1'b0),
        .transfer_width(),.transfer_height(),.transfer_channels(),
        // 取消时仍接收已经呈现的 DMA 字并丢弃，避免 EMIT 等 ready 导致死锁。
        .out_valid(dma_valid),.out_ready(clear || state==ABORT || (!use_resident && state==TRANSFER && cache_data_ready && cache_write_allow)),
        .out_co_group(dma_co),.out_index(dma_index),.out_data(dma_data),.out_last(),
        .read_request_valid(read_request_valid),.read_request_ready(read_request_ready),.read_request_address(read_request_address),
        .read_response_valid(read_response_valid),.read_response_ready(read_response_ready),
        .read_response_address(read_response_address),.read_response_data(read_response_data),.read_response_error(read_response_error),
        .write_request_valid(),.write_request_ready(1'b0),.write_request_address(),.write_request_data(),.write_request_strobe(),
        .write_response_valid(1'b0),.write_response_ready(),.write_response_address(32'd0),.write_response_error(1'b0)
    );
    end endgenerate
    integer bank;
    always @(posedge clk or negedge rst_n) begin
        if(!rst_n) begin
            state<=IDLE;valid<=0;replacement<=0;target_bank<=0;target_tile<=0;
            target_group<=0;target_width<=0;target_height<=0;target_channels<=0;error<=0;use_resident<=0;
            resident_hit_q<=0;resident_eligible_q<=0;
            for(bank=0;bank<2;bank=bank+1) begin
                tag_tile[bank]<=0;tag_group[bank]<=0;tag_width[bank]<=0;tag_height[bank]<=0;
            end
        end else begin
            error<=0;
            case(state)
                IDLE: if(want && !clear && !invalidate) begin
                    target_bank<=selected_bank;target_tile<=selected_tile;target_group<=selected_group;
                    target_width<=selected_width;target_height<=selected_height;target_channels<=selected_channels;
                    valid[selected_bank]<=0;replacement<=~selected_bank;state<=OPEN;
                end
                OPEN: if(cache_write_ready) state<=PREPARE_SOURCE;
                PREPARE_SOURCE: if(resident_geometry_ready)begin
                    resident_hit_q<=resident_hit;resident_eligible_q<=resident_eligible;state<=LAUNCH;
                end
                LAUNCH: if(source_ready) begin use_resident<=resident_hit_q;state<=TRANSFER;end
                TRANSFER: if(source_done) state<=COMMIT;
                COMMIT: if(cache_write_done) begin
                    valid[target_bank]<=1;tag_tile[target_bank]<=target_tile;tag_group[target_bank]<=target_group;
                    tag_width[target_bank]<=target_width;tag_height[target_bank]<=target_height;state<=IDLE;
                end
                ABORT: if(!dma_busy) state<=IDLE;
                default: begin error<=1;valid<=0;state<=ABORT;end
            endcase
            if(invalidate) valid<=0;
            if(clear || (state!=IDLE && state!=ABORT && (cache_error || dma_error || dma_cancelled))) begin
                valid<=0;
                if(!clear)error<=1;
                // 上层在整个 ABORT 期间持续 clear；不能反复覆盖排空后的 IDLE。
                if(state!=IDLE && state!=ABORT)state<=ABORT;
            end
        end
    end
endmodule
