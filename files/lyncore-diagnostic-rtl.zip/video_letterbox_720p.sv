`timescale 1ns/1ps
// Fixed 1280x720 -> 320x180 + 70 gray rows above/below. This preserves the
// supplied candidate's INTER_LINEAR pixel-center rule: downscale by four
// averages source (4*x+1,4*y+1)..(4*x+2,4*y+2). No runtime mul/div/mod.
// RGB/INT8 equivalence to this candidate is not model calibration evidence.
module video_letterbox_720p #(parameter SOURCE_RGB565=0)(
 input wire clk,rst_n,clear,start,input wire [31:0] source_base,source_capacity,frame_id,
 output wire ready,busy,output reg done,error,cancelled,
 output wire read_request_valid,input wire read_request_ready,output wire [31:0] read_request_address,
 input wire read_response_valid,output wire read_response_ready,
 input wire [31:0] read_response_address,read_response_data,input wire read_response_error,
 output wire out_valid,input wire out_ready,output wire [63:0] out_data,
 output wire [23:0] out_rgb,output wire [31:0] out_index,out_frame_id,output wire out_last,
 output wire [15:0] resized_width,resized_height,pad_left,pad_top
);
 localparam [2:0] IDLE=0,MAP=1,REQUEST=2,WAIT_READ=3,CALC=4,EMIT=5;
 localparam [31:0] SOURCE_BYTES=SOURCE_RGB565 ? 32'd1843200:32'd7372800;
 localparam [31:0] FIRST_SAMPLE=SOURCE_RGB565 ? 32'd2560:32'd10248;
 localparam [31:0] SOURCE_ROW=SOURCE_RGB565 ? 32'd2560:32'd10240;
 localparam [31:0] PIXEL_STEP=SOURCE_RGB565 ? 32'd8:32'd32;
 reg [2:0] state;
 reg [8:0] x,y;reg [16:0] index;
 reg [31:0] row_address,pixel_address,identity;
 reg [1:0] sample;reg aborted;
 reg [23:0] pixels[0:3],result_rgb;reg [63:0] result_word;
 wire content_row=y>=70 && y<250;
 wire [31:0] sample_offset=sample==0?32'd0:sample==1?(SOURCE_RGB565 ? 32'd4:32'd8):
  sample==2?SOURCE_ROW:SOURCE_ROW+(SOURCE_RGB565 ? 32'd4:32'd8);
 wire [15:0] packed_pixel=sample[0]?read_response_data[15:0]:read_response_data[31:16];
 wire [23:0] expanded_pixel={{packed_pixel[4:0],packed_pixel[4:2]},
  {packed_pixel[10:5],packed_pixel[10:9]},{packed_pixel[15:11],packed_pixel[15:13]}};
 assign resized_width=16'd320;assign resized_height=16'd180;assign pad_left=0;assign pad_top=16'd70;
 assign ready=state==IDLE;assign busy=!ready;
 assign read_request_valid=rst_n && state==REQUEST;
 assign read_request_address=pixel_address+sample_offset;
 assign read_response_ready=state==WAIT_READ;
 assign out_valid=rst_n && state==EMIT && !aborted && !clear;
 assign out_data=result_word;assign out_rgb=result_rgb;
 assign out_index={15'd0,index};assign out_frame_id=identity;
 assign out_last=index==17'd102399;
 function automatic [7:0] average4(input [7:0] a,b,c,d);
  reg [9:0] sum;
  begin sum={2'b0,a}+{2'b0,b}+{2'b0,c}+{2'b0,d}+10'd2;average4=sum[9:2];end
 endfunction
 integer channel;reg [7:0] value;
 always @(posedge clk or negedge rst_n)begin
  if(!rst_n)begin
   state<=IDLE;x<=0;y<=0;index<=0;row_address<=0;pixel_address<=0;identity<=0;
   sample<=0;aborted<=0;result_rgb<=0;result_word<=0;done<=0;error<=0;cancelled<=0;
   for(channel=0;channel<4;channel=channel+1)pixels[channel]<=0;
  end else begin
   done<=0;error<=0;cancelled<=0;
   if(clear && state!=IDLE)aborted<=1;
   case(state)
    IDLE:if(start && !clear)begin
     if(source_base[2:0]!=0 || source_capacity<SOURCE_BYTES ||
       {32'd0,source_base}+{32'd0,SOURCE_BYTES}>64'h100000000)error<=1;
     else begin
      row_address<=source_base+FIRST_SAMPLE;pixel_address<=source_base+FIRST_SAMPLE;
      identity<=frame_id;x<=0;y<=0;index<=0;aborted<=0;state<=MAP;
     end
    end
    MAP:if(aborted || clear)begin state<=IDLE;cancelled<=1;end
     else if(!content_row)begin result_rgb<=24'h727272;result_word<=64'h0000000000393939;state<=EMIT;end
     else begin sample<=0;state<=REQUEST;end
    REQUEST:if(read_request_ready)state<=WAIT_READ;
    WAIT_READ:if(read_response_valid)begin
     if(read_response_error || read_response_address!=read_request_address)begin error<=1;aborted<=1;state<=IDLE;end
     else if(aborted || clear)begin state<=IDLE;cancelled<=1;end
     else begin
      pixels[sample]<=SOURCE_RGB565 ? expanded_pixel:read_response_data[23:0];
      if(sample==3)state<=CALC;else begin sample<=sample+1'b1;state<=REQUEST;end
     end
    end
    CALC:begin
     result_word<=0;
     for(channel=0;channel<3;channel=channel+1)begin
      value=average4(pixels[0][channel*8+:8],pixels[1][channel*8+:8],pixels[2][channel*8+:8],pixels[3][channel*8+:8]);
      result_rgb[channel*8+:8]<=value;
      // For every uint8 p, floor((127*p+127)/255) == p>>1.
      result_word[channel*8+:8]<={1'b0,value[7:1]};
     end
     state<=EMIT;
    end
    EMIT:if(aborted || clear)begin state<=IDLE;cancelled<=1;end
     else if(out_ready)begin
      if(out_last)begin state<=IDLE;done<=1;end
      else begin
       index<=index+1'b1;state<=MAP;
       if(x==319)begin
        x<=0;y<=y+1'b1;
        if(content_row)begin row_address<=row_address+(SOURCE_ROW<<2);pixel_address<=row_address+(SOURCE_ROW<<2);end
        else pixel_address<=row_address;
       end else begin x<=x+1'b1;if(content_row)pixel_address<=pixel_address+PIXEL_STEP;end
      end
     end
    default:state<=IDLE;
   endcase
  end
 end
endmodule
