`timescale 1ns/1ps

// YOLOv5 SPPF 的有符号 INT8 最大池化：K=5、stride=1、padding=2。
// 每帧处理一个八通道组，输入/输出均按 y -> x 顺序；不同组通过 frame_co_group 区分。
// 先求水平方向五点最大值，再经四行缓存求竖直五点最大值，等价于完整 5x5。
// padding 必须为 -128，不能为零，否则全负数窗口会得到错误结果。
module maxpool5x5 #(
    parameter MAX_WIDTH = 640
) (
    input wire clk,
    input wire rst_n,
    input wire clear,
    input wire frame_start,
    output wire frame_ready,
    input wire [15:0] frame_width,
    input wire [15:0] frame_height,
    input wire [15:0] frame_co_group,
    output reg busy,
    output reg frame_done,
    output reg error,
    input wire in_valid,
    output wire in_ready,
    input wire [63:0] in_data,
    output wire out_valid,
    input wire out_ready,
    output reg [63:0] out_data,
    output reg [15:0] out_co_group,
    output reg [31:0] out_index
);
    localparam [63:0] PAD = 64'h8080808080808080;
    localparam ROW_DEPTH = MAX_WIDTH + 4;
    reg [15:0] cfg_width, cfg_height, cfg_co;
    reg [16:0] scan_x, scan_y;
    reg scan_active;
    // 四个循环行 Bank 不复位。新帧先写满四行，a_y>=4 才允许输出。
    reg [63:0] row0 [0:ROW_DEPTH-1];
    reg [63:0] row1 [0:ROW_DEPTH-1];
    reg [63:0] row2 [0:ROW_DEPTH-1];
    reg [63:0] row3 [0:ROW_DEPTH-1];
    reg [63:0] previous0, previous1, previous2, previous3;
    reg a_valid;
    reg [16:0] a_x, a_y;
    reg [63:0] a0, a1, a2, a3, a4;
    reg out_last;
    reg result_valid;

    function [63:0] max_word;
        input [63:0] left, right;
        integer lane;
        begin
            for (lane = 0; lane < 8; lane = lane + 1)
                max_word[lane*8 +: 8] = $signed(left[lane*8 +: 8]) > $signed(right[lane*8 +: 8]) ?
                    left[lane*8 +: 8] : right[lane*8 +: 8];
        end
    endfunction

    wire advance = !result_valid || out_ready;
    wire in_image = scan_x >= 2 && scan_x < {1'b0,cfg_width}+17'd2 &&
                    scan_y >= 2 && scan_y < {1'b0,cfg_height}+17'd2;
    wire scan_accept = scan_active && advance && (!in_image || in_valid);
    wire [63:0] pixel = in_image ? in_data : PAD;
    wire [63:0] horizontal = max_word(max_word(pixel, scan_x >= 1 ? previous0 : PAD),
        max_word(max_word(scan_x >= 2 ? previous1 : PAD, scan_x >= 3 ? previous2 : PAD),
                 scan_x >= 4 ? previous3 : PAD));
    wire [63:0] vertical = max_word(max_word(a0, a1), max_word(max_word(a2, a3), a4));
    wire emit = a_valid && a_x >= 4 && a_y >= 4;
    assign frame_ready = rst_n && !clear && !busy;
    assign in_ready = rst_n && !clear && busy && scan_active && in_image && advance;
    assign out_valid = result_valid && rst_n && !clear;

    // RAM 访问使用独立的同步时钟块，避免异步复位过程将行存储展开成寄存器。
    // a_valid 和坐标在下面复位；数据寄存器仅在对应 valid 为一时使用。
    always @(posedge clk) begin
        if (rst_n && !clear && scan_accept) begin
            a0 <= row0[scan_x]; a1 <= row1[scan_x];
            a2 <= row2[scan_x]; a3 <= row3[scan_x];
            a4 <= horizontal;
            // 最大值与行的排列无关；循环覆盖最老一行，避免 RAM 之间整行搬移。
            // 非阻塞赋值保证 a0..a3 获取覆盖前的数据，即过去四行。
            case (scan_y[1:0])
                2'd0: row0[scan_x] <= horizontal;
                2'd1: row1[scan_x] <= horizontal;
                2'd2: row2[scan_x] <= horizontal;
                2'd3: row3[scan_x] <= horizontal;
            endcase
            previous3 <= previous2; previous2 <= previous1;
            previous1 <= previous0; previous0 <= pixel;
        end
    end

    always @(posedge clk or negedge rst_n) begin
        if (!rst_n) begin
            busy <= 0; scan_active <= 0; a_valid <= 0; result_valid <= 0;
            frame_done <= 0; error <= 0; out_last <= 0;
            cfg_width <= 0; cfg_height <= 0; cfg_co <= 0;
            scan_x <= 0; scan_y <= 0; a_x <= 0; a_y <= 0;
            out_co_group <= 0; out_index <= 0;
        end else begin
            frame_done <= 0; error <= 0;
            if (clear) begin
                busy <= 0; scan_active <= 0; a_valid <= 0; result_valid <= 0; out_last <= 0;
            end else begin
                if (frame_start && !frame_ready) error <= 1;
                if (frame_start && frame_ready) begin
                    if (frame_width == 0 || frame_height == 0 || frame_width > MAX_WIDTH) error <= 1;
                    else begin
                        cfg_width <= frame_width; cfg_height <= frame_height; cfg_co <= frame_co_group;
                        scan_x <= 0; scan_y <= 0; scan_active <= 1; busy <= 1;
                        a_valid <= 0; result_valid <= 0; out_last <= 0;
                    end
                end else if (advance) begin
                    // 输出暂停时，坐标、RAM 更新、水平历史和两级有效标志一起冻结。
                    result_valid <= emit;
                    if (emit) begin
                        out_data <= vertical; out_co_group <= cfg_co;
                        out_index <= (a_y-17'd4)*cfg_width + (a_x-17'd4);
                        out_last <= a_x == {1'b0,cfg_width}+17'd3 && a_y == {1'b0,cfg_height}+17'd3;
                    end
                    a_valid <= scan_accept;
                    if (scan_accept) begin
                        // 每个地址同步读取过去四行的水平最大值，并将当前行写入。
                        a_x <= scan_x; a_y <= scan_y;
                        if (scan_x == {1'b0,cfg_width}+17'd3) begin
                            scan_x <= 0;
                            if (scan_y == {1'b0,cfg_height}+17'd3) scan_active <= 0;
                            else scan_y <= scan_y + 1'b1;
                        end else scan_x <= scan_x + 1'b1;
                    end
                    // 完成由最后一笔输出的真实握手决定，不能用固定排空拍数。
                    if (out_valid && out_ready && out_last) begin
                        frame_done <= 1; busy <= 0; out_last <= 0;
                    end
                end
            end
        end
    end
endmodule
