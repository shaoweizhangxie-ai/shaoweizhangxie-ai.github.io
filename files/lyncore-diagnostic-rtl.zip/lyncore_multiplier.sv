`timescale 1ns/1ps
// Frequency-oriented control: four registered 16x16 products, same CPU interface.
module lyncore_multiplier (
    input logic clk,rst,enable,
    input logic [1:0] op,
    input logic [31:0] a,b,
    output logic [31:0] result,low_result
);
    logic [31:0] p00,p01,p10,p11,saved_a,saved_b;
    logic [1:0] operation;
    logic negative_a,negative_b;
    wire [32:0] cross_product={1'b0,p01}+{1'b0,p10};
    wire [47:0] upper_product={p11,16'b0}+{15'b0,cross_product}+{32'b0,p00[31:16]};
    wire [15:0] low_sum=p00[31:16]^p01[15:0]^p10[15:0];
    wire [15:0] low_carry=((p00[31:16]&p01[15:0])|(p00[31:16]&p10[15:0])|(p01[15:0]&p10[15:0]))<<1;
    wire [15:0] low_upper=low_sum+low_carry;
    assign low_result={low_upper,p00[15:0]};
    assign result=operation==0 ? low_result : upper_product[47:16]-
        (negative_a ? saved_b : 32'b0)-(negative_b ? saved_a : 32'b0);
    always_ff @(posedge clk) begin
        if(rst) begin
            p00<=0;p01<=0;p10<=0;p11<=0;saved_a<=0;saved_b<=0;
            operation<=0;negative_a<=0;negative_b<=0;
        end else if(enable) begin
            p00<=a[15:0]*b[15:0];p01<=a[15:0]*b[31:16];
            p10<=a[31:16]*b[15:0];p11<=a[31:16]*b[31:16];
            saved_a<=a;saved_b<=b;operation<=op;
            negative_a<=(op==1 || op==2) && a[31];
            negative_b<=op==1 && b[31];
        end
    end
endmodule
