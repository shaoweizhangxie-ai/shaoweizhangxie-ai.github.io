`timescale 1ns/1ps
// Exact configuration-time threshold, not a quantization approximation.
// round_away((x+bias)*grid_m / 2^grid_s) >= 512 iff
// x >= ceil((grid_s ? 1023*2^(grid_s-1) : 512)/grid_m)-bias.
// One shared restoring divider serves all eight lanes while cfg is stalled.
// Inputs must remain stable from start until done; the layer's parameter RAM
// supplies them. Values above the possible signed-33 biased input clamp to an
// unreachable positive sentinel. No DSP multiplier or runtime divider is used.
module postprocess_thresholds(
 input wire clk,rst_n,start,output wire ready,busy,output reg done,
 input wire [255:0] bias_bus,input wire [247:0] grid_multiplier_bus,
 input wire [47:0] grid_shift_bus,output reg [271:0] positive_input_threshold_bus
);
 localparam [1:0] IDLE=0,LOAD=1,DIVIDE=2,STORE=3;
 reg [1:0] state;reg [2:0] lane;
 reg [72:0] dividend;reg [30:0] divisor;reg [31:0] remainder,quotient;
 reg [6:0] remaining;reg overflow;reg signed [31:0] bias;
 wire [31:0] trial={remainder[30:0],dividend[72]};
 wire quotient_bit=trial>={1'b0,divisor};
 wire [31:0] next_remainder=quotient_bit?trial-{1'b0,divisor}:trial;
 wire [31:0] next_quotient={quotient[30:0],quotient_bit};
 wire next_overflow=overflow||(quotient_bit&&remaining>32);
 wire [32:0] rounded_quotient={1'b0,quotient}+(remainder!=0?33'd1:33'd0);
 wire [32:0] threshold=overflow?33'h100000000:rounded_quotient;
 wire [5:0] selected_shift=grid_shift_bus[lane*6+:6];
 wire [30:0] selected_divisor=grid_multiplier_bus[lane*31+:31];
 wire signed [31:0] selected_bias=bias_bus[lane*32+:32];
 assign ready=state==IDLE;assign busy=state!=IDLE;
 always @(posedge clk or negedge rst_n)begin
  if(!rst_n)begin state<=IDLE;lane<=0;dividend<=0;divisor<=0;remainder<=0;
   quotient<=0;remaining<=0;overflow<=0;bias<=0;done<=0;positive_input_threshold_bus<=0;end
  else begin
   done<=0;
   case(state)
    IDLE:if(start)begin state<=LOAD;lane<=0;end
    LOAD:begin
     if(selected_divisor==0)begin
      positive_input_threshold_bus[lane*34+:34]<=34'sh100000000-$signed({{2{selected_bias[31]}},selected_bias});
      if(lane==7)begin state<=IDLE;done<=1;end else lane<=lane+1'b1;
     end else begin
      dividend<=selected_shift==0?(73'd512<<63):(73'd1023<<63);
      divisor<=selected_divisor;bias<=selected_bias;remainder<=0;quotient<=0;
      overflow<=0;remaining<=selected_shift==0?7'd10:{1'b0,selected_shift}+7'd9;state<=DIVIDE;
     end
    end
    DIVIDE:begin
     dividend<=dividend<<1;remainder<=next_remainder;quotient<=next_quotient;
     overflow<=next_overflow;remaining<=remaining-1'b1;
     if(remaining==1)state<=STORE;
    end
    STORE:begin
     positive_input_threshold_bus[lane*34+:34]<=$signed({1'b0,threshold})-$signed({{2{bias[31]}},bias});
     if(lane==7)begin state<=IDLE;done<=1;end else begin lane<=lane+1'b1;state<=LOAD;end
    end
    default:state<=IDLE;
   endcase
  end
 end
endmodule
