`timescale 1ns/1ps
// 自主 DDR 网络控制器：只需启动一次，逐个取描述、预留目标、运行、提交和释放。
// 模型/任务描述只读；Feature DMA 唯一拥有者是当前 Conv 或 Aux 包装器。
// Slot 管理器只管理 generation/refcount/valid，不驱动任何 DMA。
module network_task_executor #(
    parameter integer FORWARD_GEOMETRY_PIPELINE=1, // Candidate-only rollback switch.
    parameter integer K1_WIDE_ENABLE=0,
    parameter integer MAX_WIDTH=324,PSUM_DEPTH=1024,TILE_ROWS=6,
    INPUT_CACHE_DEPTH=4096,OUTPUT_CACHE_DEPTH=8192,MAX_CO_GROUPS=32,
    INPUT_PING_PONG=0,DDR_READ_PIPELINE=0,WRITE_COMBINE=0,
    WEIGHT_RESIDENCY=0,WEIGHT_CACHE_WORDS=16384,
    FEATURE_RESIDENCY=0,FEATURE_CACHE_WORDS=8192,
    // 三条静态驻留策略均默认关闭；共享原 RAM，保留 DDR 镜像及旧参数顺序。
    FEATURE_FORWARD_P3=0,FORWARD_CACHE_WORDS=6400,FEATURE_FORWARD_P1=0,FEATURE_FORWARD_P2=0,
    // Phase8.8 局部实验：默认关闭，只有真实 task84 上传可使用四字 FIFO。
    TASK84_UPLOAD_PIPELINE_TEST=0,
    // 扩展实验：按真实 task_id 选择 Conv 上传。全零保留旧入口；FIFO仍共享同一四字存储。
    parameter [86:0] UPLOAD_PIPELINE_TASK_MASK=87'd0,
    // 默认关闭。原型默认只允许 task49，K3 扩展由独立验证入口显式选择。
    parameter integer WEIGHT_PREFETCH_ENABLE=0,
    parameter [86:0] WEIGHT_PREFETCH_TASK_MASK=(87'd1<<49),
    parameter integer AUX_PIPELINE_ENABLE=0
)(
    input wire clk,rst_n,clear,start,ddr_ready,
    output wire ready,busy,
    output reg done,error,cancelled,
    input wire [31:0] descriptor_base,image_base,image_bytes,program_offset,directory_offset,
    input wire [15:0] model_task_count,execute_task_count,
    input wire [31:0] seed_base,seed_capacity,
    input wire [15:0] seed_width,seed_height,seed_channels,seed_consumers,
    input wire input_allow,input_write_allow,
    output reg job_started,job_finished,
    output reg [15:0] task_id,
    output wire [511:0] active_descriptor,
    output wire raw_valid,
    output wire [15:0] raw_co_group,
    output wire [31:0] raw_index,
    output wire [255:0] raw_data,
    output wire out_valid,
    output wire [15:0] out_co_group,
    output wire [31:0] out_index,
    output wire [63:0] out_data,
    // 整网结束后 CPU 查询已保留头的 Slot 元数据。
    input wire [2:0] inspect_slot,
    output wire inspect_valid,
    output wire [31:0] inspect_base,
    output wire [15:0] inspect_generation,inspect_consumers,
    output wire read_request_valid,
    input wire read_request_ready,
    output wire [31:0] read_request_address,
    input wire read_response_valid,
    output wire read_response_ready,
    input wire [31:0] read_response_address,read_response_data,
    input wire read_response_error,
    output wire write_request_valid,
    input wire write_request_ready,
    output wire [31:0] write_request_address,write_request_data,
    output wire [3:0] write_request_strobe,
    input wire write_response_valid,
    output wire write_response_ready,
    input wire [31:0] write_response_address,
    input wire write_response_error
);
    localparam IDLE=0,CONFIG=1,SEED_CFG=2,SEED_BEGIN=3,SEED_GEN=4,SEED_COMMIT=5,
        FETCH=6,FETCH_WAIT=7,CHECK_L=8,CHECK_R=9,ALLOC=10,BEGIN_JOB=11,TARGET_GEN=12,
        LAUNCH=13,EXEC=14,COMMIT=15,PUBLISHED=16,RELEASE_L=17,RELEASE_R=18,
        NEXT=19,FINISH=20,ABORT=21,FAILED=22,WRITE_FENCE=23,WAIT_FENCE=24,FORWARD_GEO_INIT=25,FORWARD_GEO_COUNT=26;
    reg [511:0] d;
    wire [15:0] iw=d[31:16],ih=d[47:32],ow=d[63:48],oh=d[79:64],lc=d[95:80],rc=d[111:96],oc=d[127:112];
    reg [4:0] state;
    reg [31:0] forward_plan_rows,forward_plan_pixels;
    // Bounded once per descriptor; no division in the reserve/capture enable cone.
    wire [32:0] forward_next_pixels={1'b0,forward_plan_pixels}+{17'd0,ow};
    wire forward_can_add=forward_plan_rows<TILE_ROWS && forward_next_pixels<=PSUM_DEPTH;

    reg [4:0] fence_return;
    reg [31:0] table_addr,im_base,im_bytes,im_program,im_directory,s_base,s_capacity;
    reg [15:0] m_count,e_count,s_width,s_height,s_channels,s_refs,target_generation;
    reg stop_error,stop_cancel,abort_issued;
    wire [2:0] op=d[2:0],lhs=d[5:3],rhs=d[8:6],dst=d[11:9];
    wire is_conv=op==0 || op==5;
    wire binary=op==1 || op==2;
    wire [31:0] lb=d[287:256],rb=d[319:288],ob=d[351:320],capacity=d[383:352];
    wire [15:0] refs=d[399:384];
    assign active_descriptor=d;
    assign ready=state==IDLE && !clear && ddr_ready;
    assign busy=state!=IDLE;
    wire stopping=state==ABORT;
    // 下游取消必须是脉冲；持续 Clear 会反复覆盖加载器 ABORT -> FINISH。
    // 第一个 ABORT 周期发取消，此后仅等待各所有者接收已在途的应答。
    wire halt=clear || (stopping && !abort_issued);
    // 4 客户的物理应答路由始终由已有共享仲裁器维护。
    wire [3:0] rqv,rqr,rsv,rsr,rse,wqv,wqr,wsv,wsr,wse;
    wire [127:0] rqa,rsa,rsd,wqa,wqd,wsa;
    wire [15:0] wqs;
    wire arbiter_fault,arbiter_busy;
    generate if(DDR_READ_PIPELINE!=0) begin: g_read_pipeline
    ddr_read_pipeline_arbiter #(.CLIENTS(4)) arbiter(
        .clk(clk),.rst_n(rst_n),.clear(1'b0),.enable(ddr_ready),.busy(arbiter_busy),.protocol_fault(arbiter_fault),
        .client_read_request_valid(rqv),.client_read_request_ready(rqr),.client_read_request_address(rqa),
        .client_read_response_valid(rsv),.client_read_response_ready(rsr),.client_read_response_address(rsa),
        .client_read_response_data(rsd),.client_read_response_error(rse),
        .client_write_request_valid(wqv),.client_write_request_ready(wqr),.client_write_request_address(wqa),
        .client_write_request_data(wqd),.client_write_request_strobe(wqs),.client_write_response_valid(wsv),
        .client_write_response_ready(wsr),.client_write_response_address(wsa),.client_write_response_error(wse),
        .read_request_valid(read_request_valid),.read_request_ready(read_request_ready),.read_request_address(read_request_address),
        .read_response_valid(read_response_valid),.read_response_ready(read_response_ready),.read_response_address(read_response_address),
        .read_response_data(read_response_data),.read_response_error(read_response_error),
        .write_request_valid(write_request_valid),.write_request_ready(write_request_ready),.write_request_address(write_request_address),
        .write_request_data(write_request_data),.write_request_strobe(write_request_strobe),.write_response_valid(write_response_valid),
        .write_response_ready(write_response_ready),.write_response_address(write_response_address),.write_response_error(write_response_error));
    end else begin: g_serial
    ddr_request_arbiter #(.CLIENTS(4)) arbiter(
        .clk(clk),.rst_n(rst_n),.clear(1'b0),.enable(ddr_ready),.busy(arbiter_busy),.protocol_fault(arbiter_fault),
        .client_read_request_valid(rqv),.client_read_request_ready(rqr),.client_read_request_address(rqa),
        .client_read_response_valid(rsv),.client_read_response_ready(rsr),.client_read_response_address(rsa),
        .client_read_response_data(rsd),.client_read_response_error(rse),
        .client_write_request_valid(wqv),.client_write_request_ready(wqr),.client_write_request_address(wqa),
        .client_write_request_data(wqd),.client_write_request_strobe(wqs),.client_write_response_valid(wsv),
        .client_write_response_ready(wsr),.client_write_response_address(wsa),.client_write_response_error(wse),
        .read_request_valid(read_request_valid),.read_request_ready(read_request_ready),.read_request_address(read_request_address),
        .read_response_valid(read_response_valid),.read_response_ready(read_response_ready),.read_response_address(read_response_address),
        .read_response_data(read_response_data),.read_response_error(read_response_error),
        .write_request_valid(write_request_valid),.write_request_ready(write_request_ready),.write_request_address(write_request_address),
        .write_request_data(write_request_data),.write_request_strobe(write_request_strobe),.write_response_valid(write_response_valid),
        .write_response_ready(write_response_ready),.write_response_address(write_response_address),.write_response_error(write_response_error));
    end endgenerate
    // 客户0平时只读模型，空闲时承担提交/取消屏障。零mask仅在新模式为FENCE。
    assign wqv[0]=WRITE_COMBINE!=0 && state==WRITE_FENCE && !clear;assign wqv[3]=1'b0;assign wqa[31:0]=32'd0;assign wqa[127:96]=32'd0;
    assign wqd[31:0]=32'd0;assign wqd[127:96]=32'd0;assign wqs[3:0]=4'd0;assign wqs[15:12]=4'd0;assign wsr[0]=state==WAIT_FENCE || stopping;assign wsr[3]=1'b0;
    wire desc_ready,desc_valid,desc_error,desc_busy;
    wire [15:0] desc_index;
    wire [511:0] desc_data;
    task_descriptor_reader descriptors(.clk(clk),.rst_n(rst_n),.clear(halt),
        .request_valid(state==FETCH && !clear),.request_ready(desc_ready),.table_base(table_addr),.request_index(task_id),.task_count(m_count),
        .response_valid(desc_valid),.response_ready(state==FETCH_WAIT || stopping),.response_index(desc_index),.response_descriptor(desc_data),.response_error(desc_error),.busy(desc_busy),
        .read_request_valid(rqv[3]),.read_request_ready(rqr[3]),.read_request_address(rqa[127:96]),
        .read_response_valid(rsv[3]),.read_response_ready(rsr[3]),.read_response_address(rsa[127:96]),.read_response_data(rsd[127:96]),.read_response_error(rse[3]));
    wire mrq,mrqr,mrv,mrr,mre,model_ready,model_error,configured,model_busy;
    wire [1:0] mk,mrk;
    wire [15:0] mt,mrt;
    wire [31:0] ma,mra;
    wire [847:0] md;
    model_memory_adapter #(.MAX_TASKS(256)) model(.clk(clk),.rst_n(rst_n),.clear(halt),
        .cfg_valid(state==CONFIG && model_ready && !clear),.cfg_ready(model_ready),.cfg_image_base(im_base),.cfg_image_bytes(im_bytes),
        .cfg_program_offset(im_program),.cfg_directory_offset(im_directory),.cfg_task_count(m_count),.cfg_error(model_error),.configured(configured),.configured_task_count(),.busy(model_busy),
        .program_request_valid(1'b0),.program_request_ready(),.program_request_index(16'd0),.program_response_valid(),.program_response_ready(1'b1),
        .program_response_index(),.program_response_data(),.program_response_error(),
        .memory_request_valid(mrq),.memory_request_ready(mrqr),.memory_request_kind(mk),.memory_request_task(mt),.memory_request_address(ma),
        .memory_response_valid(mrv),.memory_response_ready(mrr),.memory_response_kind(mrk),.memory_response_task(mrt),.memory_response_address(mra),.memory_response_data(md),.memory_response_error(mre),
        .read_request_valid(rqv[0]),.read_request_ready(rqr[0]),.read_request_address(rqa[31:0]),
        .read_response_valid(rsv[0]),.read_response_ready(rsr[0]),.read_response_address(rsa[31:0]),.read_response_data(rsd[31:0]),.read_response_error(rse[0]));
    wire loader_ready,loader_busy,loader_done,loader_error,loader_cancelled;
    wire region_start,region_clear,region_ready,region_busy,region_done,region_error,region_cancelled,region_result;
    wire cfg_we,cfg_ready,lut_start,lut_valid,lut_ready,weight_request,weight_ready,weight_valid;
    wire [15:0] cfg_co,ci,co;
    wire [255:0] bias;
    wire [247:0] multiplier,grid_multiplier;
    wire [47:0] shift,grid_shift;
    wire [7:0] lut_data;
    wire [31:0] weight_word;
    wire lrq,lrqr,lrv,lrr;
    (* syn_maxfan = 64 *) wire lre;
    wire [1:0] lk,lrk;
    wire [15:0] lt,lrt;
    wire [31:0] la,lra;
    wire [847:0] ld;
    wire future_weight_valid;
    wire [15:0] future_weight_ci,future_weight_co,request_weight_ci,request_weight_co;
    wire weight_cache_hit,weight_cache_miss,weight_cache_bypass,weight_cache_fill_busy;
    generate if(WEIGHT_RESIDENCY!=0) begin:residency
        weight_residency_cache #(.CACHE_WORDS(WEIGHT_CACHE_WORDS)) cache(
            .clk(clk),.rst_n(rst_n),.clear(halt || (state==CONFIG)),
            .layer_start(state==LAUNCH && is_conv && loader_ready && !clear),
            .layer_id(task_id),.cin_groups(op==5?16'd3:((lc+16'd3)>>2)),.cout_groups((oc+16'd7)>>3),
            .kernel_1x1(d[12]),.request_co_group(request_weight_co),.request_ci_group(request_weight_ci),
            .request_valid(lrq),.request_ready(lrqr),.request_kind(lk),.request_task(lt),.request_address(la),
            .response_valid(lrv),.response_ready(lrr),.response_kind(lrk),.response_task(lrt),.response_address(lra),.response_data(ld),.response_error(lre),
            .memory_request_valid(mrq),.memory_request_ready(mrqr),.memory_request_kind(mk),.memory_request_task(mt),.memory_request_address(ma),
            .memory_response_valid(mrv),.memory_response_ready(mrr),.memory_response_kind(mrk),.memory_response_task(mrt),.memory_response_address(mra),.memory_response_data(md),.memory_response_error(mre),
            .cache_hit(weight_cache_hit),.cache_miss(weight_cache_miss),.cache_bypass(weight_cache_bypass),.cache_fill_busy(weight_cache_fill_busy));
    end else begin:no_residency
        assign mrq=lrq;assign lrqr=mrqr;assign mk=lk;assign mt=lt;assign ma=la;
        assign lrv=mrv;assign mrr=lrr;assign lrk=mrk;assign lrt=mrt;assign lra=mra;assign ld=md;assign lre=mre;
        assign weight_cache_hit=1'b0;
        assign weight_cache_miss=lrq && lrqr && lk==2;
        assign weight_cache_bypass=weight_cache_miss;
        assign weight_cache_fill_busy=1'b0;
    end endgenerate
    conv_region_model_loader #(.WEIGHT_PREFETCH_ENABLE(WEIGHT_PREFETCH_ENABLE)) loader(.clk(clk),.rst_n(rst_n),.clear(halt),.start(state==LAUNCH && is_conv && loader_ready && !clear),
        .ready(loader_ready),.busy(loader_busy),.done(loader_done),.error(loader_error),.cancelled(loader_cancelled),
        .model_task(task_id),.cin_groups(op==5?16'd3:((lc+16'd3)>>2)),.cout_groups((oc+16'd7)>>3),.kernel_1x1(d[12]),.silu_enable(d[15]),
        .region_start(region_start),.region_clear(region_clear),.region_ready(region_ready),.region_busy(region_busy),.region_done(region_done),
        .region_error(region_error),.region_cancelled(region_cancelled),.region_result_valid(region_result),
        .cfg_we(cfg_we),.cfg_ready(cfg_ready),.cfg_co_group(cfg_co),.cfg_bias_bus(bias),.cfg_multiplier_bus(multiplier),.cfg_grid_multiplier_bus(grid_multiplier),
        .cfg_shift_bus(shift),.cfg_grid_shift_bus(grid_shift),.lut_load_start(lut_start),.lut_load_valid(lut_valid),.lut_load_ready(lut_ready),.lut_load_data(lut_data),
        .weight_request(weight_request),.weight_ready(weight_ready),.weight_valid(weight_valid),.weight_word(weight_word),.current_ci_group(ci),.current_co_group(co),
        .prefetch_enable(is_conv && task_id<16'd87 && WEIGHT_PREFETCH_TASK_MASK[task_id]),
        .future_weight_valid(future_weight_valid),.future_weight_ci(future_weight_ci),.future_weight_co(future_weight_co),
        .memory_request_co_group(request_weight_co),.memory_request_ci_group(request_weight_ci),
        .memory_request_valid(lrq),.memory_request_ready(lrqr),.memory_request_kind(lk),.memory_request_task(lt),.memory_request_address(la),
        .memory_response_valid(lrv),.memory_response_ready(lrr),.memory_response_kind(lrk),.memory_response_task(lrt),.memory_response_address(lra),.memory_response_data(ld),.memory_response_error(lre));
    wire cv;
    wire [15:0] cco;
    wire [31:0] cindex;
    wire [63:0] cdata;
    wire conv_rqv,conv_rqr,conv_rsv,conv_rsr,conv_rse;
    wire [31:0] conv_rqa,conv_rsa,conv_rsd;
    conv_region_ddr_top #(.K1_WIDE_ENABLE(K1_WIDE_ENABLE),.MAX_WIDTH(MAX_WIDTH),.PSUM_DEPTH(PSUM_DEPTH),.TILE_ROWS(TILE_ROWS),
        .UPLOAD_FIFO_WORDS(TASK84_UPLOAD_PIPELINE_TEST!=0 || UPLOAD_PIPELINE_TASK_MASK!=0 ? 4 : 0),
        .INPUT_CACHE_DEPTH(INPUT_CACHE_DEPTH),.OUTPUT_CACHE_DEPTH(OUTPUT_CACHE_DEPTH),.MAX_CO_GROUPS(MAX_CO_GROUPS),
        .FEATURE_RESIDENCY(FEATURE_RESIDENCY),.FEATURE_CACHE_WORDS(FEATURE_CACHE_WORDS),.TILE_AWARE(1),.GROUP8_BATCH(1),.INPUT_PING_PONG(INPUT_PING_PONG),.DDR_READ_PIPELINE(DDR_READ_PIPELINE),.WRITE_COMBINE(WRITE_COMBINE),.SUPPORT_SILU(1),.SUPPORT_STEM(1)) region(
        .clk(clk),.rst_n(rst_n),.clear(region_clear),.start(region_start),.ready(region_ready),.busy(region_busy),
        .upload_pipeline_enable((TASK84_UPLOAD_PIPELINE_TEST!=0 && task_id==16'd84) ||
            (is_conv && task_id<16'd87 && UPLOAD_PIPELINE_TASK_MASK[task_id])),
        .done(region_done),.error(region_error),.cancelled(region_cancelled),.result_valid(region_result),
        .input_base(lb),.output_base(ob),.width(iw),.height(ih),.channels_in(lc),.channels_out(oc),
        .kernel_1x1(d[12]),.stride_2(d[13]),.padding_1(d[14]),.kernel_6x6(op==5),
        .cfg_we(cfg_we),.cfg_ready(cfg_ready),.cfg_co_group(cfg_co),.cfg_bias_bus(bias),.cfg_multiplier_bus(multiplier),.cfg_shift_bus(shift),
        .silu_enable(d[15]),.cfg_grid_multiplier_bus(grid_multiplier),.cfg_grid_shift_bus(grid_shift),
        .lut_load_start(lut_start),.lut_load_valid(lut_valid),.lut_load_ready(lut_ready),.lut_valid(),.lut_load_data(lut_data),
        .weight_request(weight_request),.weight_ready(weight_ready),.weight_valid(weight_valid),.weight_word(weight_word),
        .current_ci_group(ci),.current_co_group(co),.current_tile_y(),.raw_valid(raw_valid),.raw_co_group(raw_co_group),.raw_index(raw_index),.raw_data(raw_data),
        .future_weight_valid(future_weight_valid),.future_weight_ci(future_weight_ci),.future_weight_co(future_weight_co),
        .out_valid(cv),.out_co_group(cco),.out_index(cindex),.out_data(cdata),.input_allow(input_allow),.input_write_allow(input_write_allow),
        .read_request_valid(conv_rqv),.read_request_ready(conv_rqr),.read_request_address(conv_rqa),
        .read_response_valid(conv_rsv),.read_response_ready(conv_rsr),.read_response_address(conv_rsa),.read_response_data(conv_rsd),.read_response_error(conv_rse),
        .write_request_valid(wqv[1]),.write_request_ready(wqr[1]),.write_request_address(wqa[63:32]),.write_request_data(wqd[63:32]),.write_request_strobe(wqs[7:4]),
        .write_response_valid(wsv[1]),.write_response_ready(wsr[1]),.write_response_address(wsa[63:32]),.write_response_error(wse[1]));
    wire av,aux_ready,aux_busy,aux_done,aux_error,aux_cancelled;
    wire [15:0] aco;
    wire [31:0] aindex;
    wire [63:0] adata;
    wire aux_rqv,aux_rqr,aux_rsv,aux_rsr,aux_rse;
    wire [31:0] aux_rqa,aux_rsa,aux_rsd;
    // 先声明 Slot 查询信号，避免实例端口连接提前引用时产生隐式网络。
    wire cfg_slot_ready,release_ready,write_ready,commit_ready,slot_error,slot_valid,slot_allocated;
    wire [31:0] slot_base;
    wire [15:0] slot_w,slot_h,slot_c,slot_gen;
    wire forward_hit,forward_pending,forward_entry_valid,forward_complete,forward_fault;
    wire [31:0] forward_captured_words;
    // 显式前向声明：Questa/PDS不能依赖后文声明推断过程块中的信号。
    // 比较表达式仍在Slot查询定义后赋值，逻辑与原版一致。
    wire bad_left,bad_right;
    reg [15:0] forward_source_generation,forward_left_generation;
    always @(posedge clk or negedge rst_n)begin
        if(!rst_n)begin forward_source_generation<=0;forward_left_generation<=0;end
        else if(state==CONFIG)begin forward_source_generation<=0;forward_left_generation<=0;end
        else begin
            if(state==CHECK_R && !bad_right)forward_source_generation<=slot_gen;
            if(state==CHECK_L && !bad_left)forward_left_generation<=slot_gen;
        end
    end
    generate if(FEATURE_FORWARD_P3!=0 || FEATURE_FORWARD_P1!=0 || FEATURE_FORWARD_P2!=0)begin:g_p3_forward
        wire local_ready,local_valid,local_error;
        wire [31:0] local_address,local_data;
        wire local_rqv,local_rsr;
        wire [31:0] local_rqa;
        wire controller_busy,reservation_ready;
        wire p1_producer=FEATURE_FORWARD_P1!=0 && task_id==10;
        wire p2_producer=FEATURE_FORWARD_P2!=0 && task_id==33;
        wire p3_producer=FEATURE_FORWARD_P3!=0 && task_id==65;
        wire p1_consumer=FEATURE_FORWARD_P1!=0 && (task_id==11 || task_id==13);
        wire p2_conv_consumer=FEATURE_FORWARD_P2!=0 && task_id==34;
        wire p2_concat_consumer=FEATURE_FORWARD_P2!=0 && task_id==52;
        wire p3_consumer=FEATURE_FORWARD_P3!=0 && task_id==66;
        wire forward_producer=p1_producer || p2_producer || p3_producer;
        wire conv_consumer=op==0 && ((p1_consumer && task_id==11) || p2_conv_consumer);
        wire aux_consumer=(p1_consumer && task_id==13 && op==1) ||
            ((p3_consumer || p2_concat_consumer) && op==2);
        // Conv 及 P1 Add 从左源读取；P2/P3 Concat 驻留的是右源。
        // generation 必须与同一侧的 base/shape 配套，不能使用消费者目标 Slot。
        wire right_source=p3_consumer || p2_concat_consumer;
        wire [15:0] source_generation=right_source?forward_source_generation:forward_left_generation;
        wire [15:0] configured_consumer=p1_producer?16'd11:p2_producer?16'd34:16'd66;
        wire [15:0] configured_consumer2=p2_producer?16'd52:16'd13;
        wire [15:0] configured_refs=(p1_producer || p2_producer)?16'd2:16'd1;
        wire capture_start=state==LAUNCH && op==0 && forward_producer &&
            refs==configured_refs && loader_ready && !clear;
        reg capture_admitted;
        // 预留被拒绝时继续 DDR，不阻塞网络，也不向仍驻留的旧表项发送 capture/publish。
        always @(posedge clk or negedge rst_n)begin
            if(!rst_n)capture_admitted<=0;
            else if(halt || state==CONFIG)capture_admitted<=0;
            else if(state==LAUNCH && is_conv && loader_ready)
                capture_admitted<=capture_start && reservation_ready;
        end
        // 普通 Conv 行带尺寸与 region 的 PLAN 相同；三条 producer 均不是 RGB Stem。
        wire [31:0] limit_rows=PSUM_DEPTH/{16'd0,ow};
        wire [31:0] capture_rows=FORWARD_GEOMETRY_PIPELINE!=0 ? forward_plan_rows : (limit_rows<TILE_ROWS?limit_rows:TILE_ROWS);
        // 任意策略启用均使用引用释放；P3 配置一个消费者，P1/P2 配置两个。
        feature_residency_controller #(.CACHE_WORDS(FORWARD_CACHE_WORDS),.MULTI_CONSUMER(1)) controller(
            .clk(clk),.rst_n(rst_n),.clear(halt || state==CONFIG),
            .capture_begin(capture_start),
            .publish(state==PUBLISHED && forward_producer && capture_admitted && slot_valid && !clear),
            .retire(1'b0),
            .cfg_producer(task_id),.cfg_consumer(configured_consumer),.cfg_generation(target_generation),
            .cfg_consumer2(configured_consumer2),.cfg_consumer_count(configured_refs),
            // 完整消费任务提交后才释放一个引用；task34 后保留 task52 的引用。
            .release_valid(state==PUBLISHED && (conv_consumer || aux_consumer) && slot_valid && !clear),
            .release_cancelled(1'b0),.release_task(task_id),
            .release_generation(source_generation),
            .cfg_base(ob),.cfg_channels(oc),.cfg_height(oh),.cfg_width(ow),.cfg_tile_rows(capture_rows[15:0]),
            .capture_valid(cv && forward_producer && capture_admitted),.capture_co_group(cco),.capture_index(cindex),.capture_data(cdata),
            .consumer_enable(state==EXEC && (conv_consumer || aux_consumer) && !halt),
            .consumer_task(task_id),.consumer_generation(source_generation),
            .consumer_base(right_source?rb:lb),.consumer_channels(right_source?rc:lc),.consumer_height(ih),.consumer_width(iw),
            .read_request_valid(local_rqv),.read_request_ready(local_ready),.read_hit(forward_hit),
            .read_request_address(local_rqa),.read_response_valid(local_valid),.read_response_ready(local_rsr),
            .read_response_address(local_address),.read_response_data(local_data),.read_response_error(local_error),
            .entry_valid(forward_entry_valid),.capture_complete(forward_complete),.capture_fault(forward_fault),
            .producer_task(),.consumer_task_id(),.generation(),.channels(),.height(),.width(),.base_address(),.word_count(),
            .consumer_count(),.remaining_consumers(),.consumer_task2(),.consumer_bitmap(),.cancelled_bitmap(),.release_state(),.reservation_ready(reservation_ready),.reservation_reject(),
            .captured_words(forward_captured_words),.busy(controller_busy));
        if(FEATURE_FORWARD_P1!=0 || FEATURE_FORWARD_P2!=0)begin:g_refcount_routes
            wire crq,crqr,crr,arq,arqr,arr,cbusy,abusy,cfault,afault;
            wire [31:0] cra,ara;
            reg response_owner_conv;
            wire select_conv=conv_consumer;
            assign local_rqv=crq || arq;
            assign local_rqa=select_conv?conv_rqa:aux_rqa;
            assign crqr=local_ready;assign arqr=local_ready && !crq;
            assign local_rsr=response_owner_conv?crr:arr;
            assign forward_pending=controller_busy || cbusy || abusy;
            always @(posedge clk or negedge rst_n)begin
                if(!rst_n)response_owner_conv<=0;
                else if(local_rqv && local_ready)response_owner_conv<=crq;
            end
            feature_forward_read_mux conv_mux(
                .clk(clk),.rst_n(rst_n && state!=CONFIG),.clear(halt),.enable(state==EXEC && select_conv),
                .request_valid(conv_rqv),.request_ready(conv_rqr),.request_address(conv_rqa),
                .response_valid(conv_rsv),.response_ready(conv_rsr),.response_address(conv_rsa),.response_data(conv_rsd),.response_error(conv_rse),
                .local_hit(forward_hit && select_conv),.local_request_valid(crq),.local_request_ready(crqr),.local_request_address(cra),
                .local_response_valid(local_valid && response_owner_conv),.local_response_ready(crr),
                .local_response_address(local_address),.local_response_data(local_data),.local_response_error(local_error),
                .ddr_request_valid(rqv[1]),.ddr_request_ready(rqr[1]),.ddr_request_address(rqa[63:32]),
                .ddr_response_valid(rsv[1]),.ddr_response_ready(rsr[1]),.ddr_response_address(rsa[63:32]),.ddr_response_data(rsd[63:32]),.ddr_response_error(rse[1]),
                .busy(cbusy),.protocol_fault(cfault),.pending_count());
            feature_forward_read_mux aux_mux(
                .clk(clk),.rst_n(rst_n && state!=CONFIG),.clear(halt),.enable(state==EXEC && aux_consumer),
                .request_valid(aux_rqv),.request_ready(aux_rqr),.request_address(aux_rqa),
                .response_valid(aux_rsv),.response_ready(aux_rsr),.response_address(aux_rsa),.response_data(aux_rsd),.response_error(aux_rse),
                .local_hit(forward_hit && !select_conv),.local_request_valid(arq),.local_request_ready(arqr),.local_request_address(ara),
                .local_response_valid(local_valid && !response_owner_conv),.local_response_ready(arr),
                .local_response_address(local_address),.local_response_data(local_data),.local_response_error(local_error),
                .ddr_request_valid(rqv[2]),.ddr_request_ready(rqr[2]),.ddr_request_address(rqa[95:64]),
                .ddr_response_valid(rsv[2]),.ddr_response_ready(rsr[2]),.ddr_response_address(rsa[95:64]),.ddr_response_data(rsd[95:64]),.ddr_response_error(rse[2]),
                .busy(abusy),.protocol_fault(afault),.pending_count());
        end else begin:g_single_routes
        assign local_rqv=aux_rqv;assign local_rqa=aux_rqa;assign local_rsr=aux_rsr;
        assign forward_pending=controller_busy;
        assign rqv[1]=conv_rqv;assign conv_rqr=rqr[1];assign rqa[63:32]=conv_rqa;
        assign conv_rsv=rsv[1];assign rsr[1]=conv_rsr;assign conv_rsa=rsa[63:32];
        assign conv_rsd=rsd[63:32];assign conv_rse=rse[1];
        // Aux 只有一笔读取在途。本地应答占用期间禁止发送下一笔 DDR 请求。
        // 同一 Aux request 只由一条路径接受，地址协议及写路径均保持原样。
        assign rqv[2]=aux_rqv && !forward_hit && !forward_pending;
        assign rqa[95:64]=aux_rqa;
        assign aux_rqr=forward_hit?local_ready:(rqr[2] && !forward_pending);
        assign aux_rsv=local_valid || rsv[2];
        assign aux_rsa=local_valid?local_address:rsa[95:64];
        assign aux_rsd=local_valid?local_data:rsd[95:64];
        assign aux_rse=local_valid?local_error:rse[2];
        assign rsr[2]=aux_rsr && !local_valid;
        end
    end else begin:g_no_p3_forward
        assign rqv[1]=conv_rqv;assign conv_rqr=rqr[1];assign rqa[63:32]=conv_rqa;
        assign conv_rsv=rsv[1];assign rsr[1]=conv_rsr;assign conv_rsa=rsa[63:32];
        assign conv_rsd=rsd[63:32];assign conv_rse=rse[1];
        assign rqv[2]=aux_rqv;assign aux_rqr=rqr[2];assign rqa[95:64]=aux_rqa;
        assign aux_rsv=rsv[2];assign rsr[2]=aux_rsr;assign aux_rsa=rsa[95:64];
        assign aux_rsd=rsd[95:64];assign aux_rse=rse[2];
        assign forward_hit=1'b0;assign forward_pending=1'b0;assign forward_entry_valid=1'b0;
        assign forward_complete=1'b0;assign forward_fault=1'b0;assign forward_captured_words=32'd0;
    end endgenerate
    aux_ddr_top #(.MAX_WIDTH(MAX_WIDTH),.IO_PIPELINE(AUX_PIPELINE_ENABLE)) aux(.clk(clk),.rst_n(rst_n),.clear(halt),
        .start(state==LAUNCH && !is_conv && aux_ready && !clear),.ready(aux_ready),.busy(aux_busy),.done(aux_done),.error(aux_error),.cancelled(aux_cancelled),
        .descriptor(d[255:0]),.left_base(lb),.right_base(rb),.output_base(ob),.out_valid(av),.out_co_group(aco),.out_index(aindex),.out_data(adata),
        .read_request_valid(aux_rqv),.read_request_ready(aux_rqr),.read_request_address(aux_rqa),
        .read_response_valid(aux_rsv),.read_response_ready(aux_rsr),.read_response_address(aux_rsa),.read_response_data(aux_rsd),.read_response_error(aux_rse),
        .write_request_valid(wqv[2]),.write_request_ready(wqr[2]),.write_request_address(wqa[95:64]),.write_request_data(wqd[95:64]),.write_request_strobe(wqs[11:8]),
        .write_response_valid(wsv[2]),.write_response_ready(wsr[2]),.write_response_address(wsa[95:64]),.write_response_error(wse[2]));
    assign out_valid=is_conv?cv:av;assign out_co_group=is_conv?cco:aco;
    assign out_index=is_conv?cindex:aindex;assign out_data=is_conv?cdata:adata;
    wire seed_mode=state>=SEED_CFG && state<=SEED_COMMIT;
    wire [2:0] query_slot=state==CHECK_L || state==RELEASE_L?lhs:state==CHECK_R || state==RELEASE_R?rhs:
        seed_mode?3'd0:(state==IDLE || state==FINISH?inspect_slot:dst);
    assign inspect_valid=slot_valid;assign inspect_base=slot_base;
    assign inspect_generation=slot_gen;
    ddr_slot_manager #(.EXTERNAL_COMMIT(1)) slots(
        // 每次新网络开始先清空旧 Slot 元数据；DDR 本体和已排空的桥不复位。
        .clk(clk),.rst_n(rst_n && state!=CONFIG),.clear(stopping),
        .cfg_valid((state==SEED_CFG || state==ALLOC) && !clear),.cfg_ready(cfg_slot_ready),.cfg_slot(seed_mode?3'd0:dst),
        .cfg_base(seed_mode?s_base:ob),.cfg_capacity(seed_mode?s_capacity:capacity),
        .cfg_width(seed_mode?s_width:ow),.cfg_height(seed_mode?s_height:oh),.cfg_channels(seed_mode?s_channels:oc),
        .cfg_tile_width(seed_mode?s_width:ow),.cfg_tile_height(16'd6),.cfg_tile_groups(16'd1),.cfg_consumers(seed_mode?s_refs:refs),
        // DDR 源 Slot 也用 CHECK_L/CHECK_R 保存的源 generation，与本地引用释放一致。
        .release_valid((state==RELEASE_L || state==RELEASE_R) && !clear),.release_ready(release_ready),.release_slot(query_slot),
        .release_generation(state==RELEASE_R?forward_source_generation:forward_left_generation),
        .write_begin((state==SEED_BEGIN || state==BEGIN_JOB) && !clear),.write_ready(write_ready),.write_slot(seed_mode?3'd0:dst),.write_job(seed_mode?16'hffff:task_id),
        .external_busy(loader_busy || aux_busy),.commit_valid((state==SEED_COMMIT || state==COMMIT) && !clear),.commit_ready(commit_ready),
        .commit_slot(seed_mode?3'd0:dst),.commit_generation(target_generation),.commit_job(seed_mode?16'hffff:task_id),.commit_success(1'b1),
        .upload_start(1'b0),.upload_ready(),.upload_source_slot(3'd0),.download_start(1'b0),.download_ready(),.download_slot(3'd0),
        .download_x(32'sd0),.download_y(32'sd0),.download_width(16'd0),.download_height(16'd0),.download_co_base(16'd0),.download_co_groups(16'd0),
        .busy(),.write_active(),.region_done(),.write_done(),.download_done(),.error(slot_error),.cancelled(),
        .query_slot(query_slot),.query_allocated(slot_allocated),.query_valid(slot_valid),.query_writing(),.query_base(slot_base),.query_capacity(),
        .query_width(slot_w),.query_height(slot_h),.query_channels(slot_c),.query_consumers(inspect_consumers),.query_generation(slot_gen),
        .next_valid(),.next_slot(),.next_x(),.next_y(),.next_width(),.next_height(),.next_co_base(),.next_co_groups(),.next_channels(),.next_generation(),
        .dma_start(),.dma_ready(1'b0),.dma_busy(1'b0),.dma_done(1'b0),.dma_error(1'b0),.dma_cancelled(1'b0),
        .dma_download(),.dma_frame_base(),.dma_frame_width(),.dma_frame_height(),.dma_frame_channels(),
        .dma_region_x(),.dma_region_y(),.dma_region_width(),.dma_region_height(),.dma_co_base(),.dma_co_groups(),.dma_source_slot());
    assign bad_left=!slot_valid || slot_base!=lb || slot_w!=iw || slot_h!=ih || slot_c!=lc;
    assign bad_right=!slot_valid || slot_base!=rb || slot_w!=iw || slot_h!=ih || slot_c!=rc;
    wire [16:0] kw=d[12]?17'd1:17'd3;
    wire [16:0] pw={1'b0,iw}+(d[14]?17'd2:0),ph={1'b0,ih}+(d[14]?17'd2:0);
    wire [16:0] expected_w=((pw-kw)>>(d[13]?1:0))+1,expected_h=((ph-kw)>>(d[13]?1:0))+1;
    wire bad_d=op>5 || d[415:400]!=task_id || refs==0 || dst==lhs || dst==rhs ||
        iw==0 || ih==0 || ow==0 || oh==0 || lc==0 || rc==0 || oc==0 || iw>MAX_WIDTH ||
        d[159] || d[191] || d[199:198]!=0 || d[207:206]!=0 || d[255:208]!=0 ||
        (op==0 && (pw<kw || ph<kw || ow!=expected_w || oh!=expected_h)) ||
        (op==5 && (lc!=3 || iw[0] || ih[0] || iw<2 || ih<2 || ow!=(iw>>1) || oh!=(ih>>1) || d[12] || !d[13] || d[14])) ||
        (op==1 && (lc!=rc || oc!=lc || ow!=iw || oh!=ih)) ||
        (op==2 && ({1'b0,lc}+rc!=oc || ow!=iw || oh!=ih)) ||
        (op==3 && (lc!=oc || ow!=iw || oh!=ih)) ||
        (op==4 && (lc!=oc || {1'b0,ow}!={iw,1'b0} || {1'b0,oh}!={ih,1'b0})) || (!is_conv && d[15:12]!=0);
    always @(posedge clk or negedge rst_n) begin
        if(!rst_n) begin state<=IDLE;fence_return<=IDLE;d<=0;task_id<=0;done<=0;error<=0;cancelled<=0;job_started<=0;job_finished<=0;
            table_addr<=0;im_base<=0;im_bytes<=0;im_program<=0;im_directory<=0;m_count<=0;e_count<=0;
            s_base<=0;s_capacity<=0;s_width<=0;s_height<=0;s_channels<=0;s_refs<=0;target_generation<=0;stop_error<=0;stop_cancel<=0;abort_issued<=0;forward_plan_rows<=0;forward_plan_pixels<=0;end
        else begin
            done<=0;error<=0;cancelled<=0;job_started<=0;job_finished<=0;
            abort_issued<=stopping;
            case(state)
                IDLE: if(start && ready) begin
                    table_addr<=descriptor_base;im_base<=image_base;im_bytes<=image_bytes;im_program<=program_offset;im_directory<=directory_offset;
                    m_count<=model_task_count;e_count<=execute_task_count;s_base<=seed_base;s_capacity<=seed_capacity;
                    s_width<=seed_width;s_height<=seed_height;s_channels<=seed_channels;s_refs<=seed_consumers;
                    task_id<=0;stop_error<=0;stop_cancel<=0;state<=CONFIG;
                    if(execute_task_count==0 || execute_task_count>model_task_count) begin stop_error<=1;state<=FAILED;end
                end
                CONFIG: if(model_ready) state<=SEED_CFG;
                SEED_CFG: if(cfg_slot_ready) state<=SEED_BEGIN;
                SEED_BEGIN: if(write_ready) state<=SEED_GEN;
                SEED_GEN: begin target_generation<=slot_gen;fence_return<=SEED_COMMIT;state<=WRITE_COMBINE!=0?WRITE_FENCE:SEED_COMMIT;end
                SEED_COMMIT: if(commit_ready) state<=FETCH;
                FETCH: if(desc_ready) state<=FETCH_WAIT;
                FETCH_WAIT: if(desc_valid) begin
                    if(desc_error || desc_index!=task_id) begin stop_error<=1;state<=ABORT;end
                    else begin d<=desc_data;state<=FORWARD_GEOMETRY_PIPELINE!=0 ? FORWARD_GEO_INIT : CHECK_L;end
                end
                FORWARD_GEO_INIT: begin forward_plan_rows<=0;forward_plan_pixels<=0;state<=FORWARD_GEO_COUNT;end
                FORWARD_GEO_COUNT: if(forward_can_add)begin
                    forward_plan_rows<=forward_plan_rows+1;forward_plan_pixels<=forward_next_pixels[31:0];
                end else state<=CHECK_L;
                CHECK_L: if(bad_d || bad_left) begin stop_error<=1;state<=ABORT;end else state<=binary?CHECK_R:ALLOC;
                CHECK_R: if(bad_right) begin stop_error<=1;state<=ABORT;end else state<=ALLOC;
                ALLOC: if(cfg_slot_ready) state<=BEGIN_JOB;
                BEGIN_JOB: if(write_ready) state<=TARGET_GEN;
                TARGET_GEN: begin target_generation<=slot_gen;state<=LAUNCH;end
                LAUNCH: if(is_conv?loader_ready:aux_ready) begin state<=EXEC;job_started<=1;end
                EXEC: if(is_conv?loader_done:aux_done)begin fence_return<=COMMIT;state<=WRITE_COMBINE!=0?WRITE_FENCE:COMMIT;end
                COMMIT: if(commit_ready) state<=PUBLISHED;
                PUBLISHED: if(!slot_valid) begin stop_error<=1;state<=ABORT;end else begin job_finished<=1;state<=RELEASE_L;end
                RELEASE_L: if(release_ready) state<=binary && rhs!=lhs?RELEASE_R:NEXT;
                RELEASE_R: if(release_ready) state<=NEXT;
                NEXT: if(task_id+1==e_count) state<=FINISH;else begin task_id<=task_id+1;state<=FETCH;end
                FINISH: begin done<=1;state<=IDLE;end
                ABORT: if(!loader_busy && !aux_busy && !desc_busy && !model_busy && !arbiter_busy && !forward_pending)begin
                    fence_return<=FAILED;state<=WRITE_COMBINE!=0?WRITE_FENCE:FAILED;
                end
                WRITE_FENCE: if(wqv[0] && wqr[0])state<=WAIT_FENCE;
                WAIT_FENCE: if(wsv[0] && wsr[0])begin
                    if(wse[0] || wsa[31:0]!=0)begin stop_error<=1;state<=FAILED;end
                    else state<=fence_return;
                end
                FAILED: begin error<=stop_error;cancelled<=stop_cancel;state<=IDLE;end
                default: begin stop_error<=1;state<=ABORT;end
            endcase
            if(state!=IDLE && state!=ABORT && state!=FAILED && state!=FINISH &&
               (clear || slot_error || model_error || loader_error || aux_error || loader_cancelled || aux_cancelled || arbiter_fault)) begin
                stop_error<=!clear;stop_cancel<=clear;state<=ABORT;
            end
        end
    end
endmodule
