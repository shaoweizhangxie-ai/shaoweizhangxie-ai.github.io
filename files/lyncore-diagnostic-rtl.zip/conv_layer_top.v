`timescale 1ns/1ps

// 在已有 INT32 Conv Engine 外包一层，输出可供下一层使用的 INT8 特征。
// 参数按输出通道组存放；外部在启动前装好偏置、缩放系数和本层 SiLU 表。
module conv_layer_top #(
    parameter integer MAX_WIDTH = 640,
    parameter integer PSUM_DEPTH = 256,
    parameter integer MAX_CO_GROUPS = 128,
    parameter integer PE_LATENCY = 10,
    parameter integer SINGLE_GROUP_STREAM = 0,
    parameter integer GROUP_INPUT_HANDSHAKE = 0,
    parameter integer K1_WIDE_ENABLE = 0
) (
    input  wire          clk,
    input  wire          rst_n,
    input  wire          layer_start,
    input  wire [15:0]   frame_width,
    input  wire [15:0]   frame_height,
    input  wire [15:0]   cin_groups,
    input  wire [15:0]   cout_groups,
    input  wire          kernel_1x1,
    input  wire          stride_2,
    input  wire          padding_1,
    input  wire          silu_enable,
    output wire          layer_ready,
    output wire          layer_busy,
    output reg           layer_done,
    output wire          layer_error,
    // cfg_we && cfg_ready 时装载一个输出组的八通道参数。
    input  wire          cfg_we,
    output wire          cfg_ready,
    input  wire [15:0]   cfg_co_group,
    input  wire [255:0]  cfg_bias_bus,
    input  wire [247:0]  cfg_linear_multiplier_bus,
    input  wire [47:0]   cfg_linear_shift_bus,
    input  wire [247:0]  cfg_grid_multiplier_bus,
    input  wire [47:0]   cfg_grid_shift_bus,
    // 空闲时发 load_start，再按 ready/valid 顺序送 1024 个字节。
    input  wire          lut_load_start,
    input  wire          lut_load_valid,
    output wire          lut_load_ready,
    input  wire [7:0]    lut_load_data,
    output reg           lut_valid,
    output wire          weight_request,
    output wire          weight_ready,
    input  wire          weight_valid,
    input  wire [31:0]   weight_word,
    output wire          ifm_request,
    output wire          input_group_request,
    input  wire          input_group_ready,
    output wire          ifm_ready,
    input  wire          ifm_valid,
    input  wire [31:0]   ifm_pixel,
    input wire k1_wide_mode,
    input wire [255:0] ifm_wide_pixel,
    output wire [15:0]   current_ci_group,
    output wire         future_weight_valid,
    output wire [15:0]  future_weight_ci, future_weight_co,
    output wire [15:0]   current_co_group,
    output wire [31:0]   current_tile_base,
    output wire          out_valid,
    output wire [15:0]   out_co_group,
    output wire [31:0]   out_index,
    output wire [63:0]   out_data,
    // 可选联调端口：原始整数卷积输出，未使用时允许不连接。
    output wire          raw_valid,
    output wire [15:0]   raw_co_group,
    output wire [31:0]   raw_index,
    output wire [255:0]  raw_data
);
    reg [255:0] bias_mem [0:MAX_CO_GROUPS-1];
    reg [247:0] linear_multiplier_mem [0:MAX_CO_GROUPS-1];
    reg [47:0] linear_shift_mem [0:MAX_CO_GROUPS-1];
    reg [247:0] grid_multiplier_mem [0:MAX_CO_GROUPS-1];
    reg [47:0] grid_shift_mem [0:MAX_CO_GROUPS-1];
    reg [MAX_CO_GROUPS-1:0] parameter_valid;
    reg lut_loading;
    reg [9:0] lut_count;
    reg active;
    reg configured_activation;
    reg raw_done_seen;
    reg config_error;
    wire raw_ready;
    wire raw_done;
    wire raw_error;
    wire post_busy;
    reg [271:0] positive_input_threshold_mem [0:MAX_CO_GROUPS-1];
    reg [15:0] threshold_group;
    wire threshold_busy,threshold_done;
    wire [271:0] computed_threshold;
    postprocess_thresholds threshold_calculator(
        .clk(clk),.rst_n(rst_n),.start(cfg_we && cfg_ready && cfg_co_group < MAX_CO_GROUPS),
        .ready(),.busy(threshold_busy),.done(threshold_done),
        .bias_bus(bias_mem[threshold_group]),
        .grid_multiplier_bus(grid_multiplier_mem[threshold_group]),
        .grid_shift_bus(grid_shift_mem[threshold_group]),
        .positive_input_threshold_bus(computed_threshold));
    always @(posedge clk or negedge rst_n)
        if(!rst_n) threshold_group<=0;
        else if(cfg_we && cfg_ready && cfg_co_group < MAX_CO_GROUPS) threshold_group<=cfg_co_group;
    always @(posedge clk)
        if(threshold_done) positive_input_threshold_mem[threshold_group]<=computed_threshold;

    assign layer_ready = raw_ready && !active && !lut_loading && !threshold_busy && !threshold_done;
    assign cfg_ready = layer_ready;
    assign layer_busy = active;
    assign layer_error = raw_error || config_error;
    assign lut_load_ready = lut_loading;
    wire table_write = lut_load_ready && lut_load_valid;

    // 只有本层要用到的组需要有效；复位只清有效标记，不复位整块参数存储。
    reg missing_parameters;
    integer check_group;
    always @* begin
        missing_parameters = (cout_groups == 0) || (cout_groups > MAX_CO_GROUPS);
        for (check_group = 0; check_group < MAX_CO_GROUPS;
             check_group = check_group + 1)
            if (check_group < cout_groups && !parameter_valid[check_group])
                missing_parameters = 1'b1;
    end
    wire bad_post_config = missing_parameters || (silu_enable && !lut_valid);
    wire accepted_start = layer_start && layer_ready && !lut_load_start && !bad_post_config;

    always @(posedge clk or negedge rst_n) begin
        if (!rst_n) begin
            parameter_valid <= {MAX_CO_GROUPS{1'b0}};
            lut_loading <= 1'b0;
            lut_count <= 10'd0;
            lut_valid <= 1'b0;
            active <= 1'b0;
            configured_activation <= 1'b0;
            raw_done_seen <= 1'b0;
            layer_done <= 1'b0;
            config_error <= 1'b0;
        end else begin
            layer_done <= 1'b0;
            config_error <= 1'b0;
            if (cfg_we && cfg_ready) begin
                if (cfg_co_group < MAX_CO_GROUPS)
                    parameter_valid[cfg_co_group] <= 1'b1;
                else
                    config_error <= 1'b1;
            end
            if (lut_load_start && layer_ready) begin
                lut_loading <= 1'b1;
                lut_count <= 10'd0;
                lut_valid <= 1'b0;
            end else if (table_write) begin
                if (lut_count == 10'd1023) begin
                    lut_loading <= 1'b0;
                    lut_valid <= 1'b1;
                end else
                    lut_count <= lut_count + 10'd1;
            end
            if (layer_start && layer_ready && !lut_load_start) begin
                if (bad_post_config)
                    config_error <= 1'b1;
                else begin
                    active <= 1'b1;
                    configured_activation <= silu_enable;
                    raw_done_seen <= 1'b0;
                end
            end
            if (raw_error) begin
                active <= 1'b0;
                raw_done_seen <= 1'b0;
            end
            if (raw_done)
                raw_done_seen <= 1'b1;
            // 完成信号必须等待新增后处理流水排空，不能直接透传旧顶层 done。
            if (active && raw_done_seen && !post_busy && !raw_valid) begin
                active <= 1'b0;
                raw_done_seen <= 1'b0;
                layer_done <= 1'b1;
            end
        end
    end

    always @(posedge clk) begin
        if (cfg_we && cfg_ready && cfg_co_group < MAX_CO_GROUPS) begin
            bias_mem[cfg_co_group] <= cfg_bias_bus;
            linear_multiplier_mem[cfg_co_group] <= cfg_linear_multiplier_bus;
            linear_shift_mem[cfg_co_group] <= cfg_linear_shift_bus;
            grid_multiplier_mem[cfg_co_group] <= cfg_grid_multiplier_bus;
            grid_shift_mem[cfg_co_group] <= cfg_grid_shift_bus;
        end
    end

    conv_engine_top #(
        .MAX_WIDTH(MAX_WIDTH), .PSUM_DEPTH(PSUM_DEPTH), .PE_LATENCY(PE_LATENCY),
        .SINGLE_GROUP_STREAM(SINGLE_GROUP_STREAM),
        .GROUP_INPUT_HANDSHAKE(GROUP_INPUT_HANDSHAKE),.K1_WIDE_ENABLE(K1_WIDE_ENABLE)
    ) u_engine (
        .clk(clk), .rst_n(rst_n), .layer_start(accepted_start),
        .frame_width(frame_width), .frame_height(frame_height),
        .cin_groups(cin_groups), .cout_groups(cout_groups),
        .kernel_1x1(kernel_1x1), .stride_2(stride_2), .padding_1(padding_1),
        .layer_ready(raw_ready), .layer_busy(), .layer_done(raw_done), .layer_error(raw_error),
        .weight_request(weight_request), .weight_ready(weight_ready),
        .weight_valid(weight_valid), .weight_word(weight_word),
        .ifm_request(ifm_request), .ifm_ready(ifm_ready),
        .input_group_request(input_group_request), .input_group_ready(input_group_ready),
        .ifm_valid(ifm_valid), .ifm_pixel(ifm_pixel),.k1_wide_mode(k1_wide_mode),.ifm_wide_pixel(ifm_wide_pixel),
        .current_ci_group(current_ci_group), .current_co_group(current_co_group),
        .future_weight_valid(future_weight_valid),.future_weight_ci(future_weight_ci),.future_weight_co(future_weight_co),
        .current_tile_base(current_tile_base),
        .out_valid(raw_valid), .out_co_group(raw_co_group), .out_index(raw_index),
        .out0(raw_data[0 +: 32]), .out1(raw_data[32 +: 32]),
        .out2(raw_data[64 +: 32]), .out3(raw_data[96 +: 32]),
        .out4(raw_data[128 +: 32]), .out5(raw_data[160 +: 32]),
        .out6(raw_data[192 +: 32]), .out7(raw_data[224 +: 32])
    );

    conv_postprocess #(.SHARED_PRODUCT(1)) u_postprocess (
        .clk(clk), .rst_n(rst_n), .in_valid(raw_valid),
        .in_co_group(raw_co_group), .in_index(raw_index), .in_psum(raw_data),
        .bias_bus(bias_mem[raw_co_group]),
        .linear_multiplier_bus(linear_multiplier_mem[raw_co_group]),
        .linear_shift_bus(linear_shift_mem[raw_co_group]),
        .grid_multiplier_bus(grid_multiplier_mem[raw_co_group]),
        .grid_shift_bus(grid_shift_mem[raw_co_group]),
        .silu_enable(configured_activation),
        .positive_input_threshold_bus(positive_input_threshold_mem[raw_co_group]),
        .lut_we(table_write), .lut_addr(lut_count), .lut_data(lut_load_data),
        .busy(post_busy), .out_valid(out_valid),
        .out_co_group(out_co_group), .out_index(out_index), .out_data(out_data)
    );
endmodule
