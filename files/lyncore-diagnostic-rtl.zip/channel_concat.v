`timescale 1ns/1ps

// 两张同空间尺寸特征图按 left -> right 拼接，并将两侧统一到输出尺度。
// 每个输出八通道字最多需要两个源八通道字，支持左侧通道数不是8的倍数。
// word0 是输出第一个实际通道所在的源字；word1 是最后一个实际通道所在的源字。
// 若首尾在同一个源字，word1 不使用。源字取得方法见 docs/c3_rtl.md。
module channel_concat (
    input wire clk, rst_n, clear,
    input wire in_valid,
    output wire in_ready,
    input wire [63:0] in_word0, in_word1,
    input wire [15:0] left_channels, right_channels,
    input wire [30:0] left_multiplier, right_multiplier,
    input wire [5:0] left_shift, right_shift,
    input wire [15:0] in_co_group,
    input wire [31:0] in_index,
    output wire out_valid,
    input wire out_ready,
    output wire [63:0] out_data,
    output wire [15:0] out_co_group,
    output wire [31:0] out_index
);
    wire [18:0] base_channel = {in_co_group, 3'b000};
    wire [16:0] total_channels = {1'b0, left_channels} + {1'b0, right_channels};
    wire first_is_right = base_channel >= left_channels;
    wire [18:0] first_source_channel = first_is_right ? base_channel-left_channels : base_channel;
    wire [15:0] first_source_group = first_source_channel >> 3;
    wire [63:0] selected_data;
    wire [247:0] selected_multiplier;
    wire [47:0] selected_shift, out_meta;
    genvar lane;
    generate
        for (lane = 0; lane < 8; lane = lane + 1) begin : g_channel
            wire [18:0] channel = base_channel + lane;
            wire is_right = channel >= left_channels;
            wire [18:0] source_channel = is_right ? channel-left_channels : channel;
            wire use_word0 = (is_right == first_is_right) &&
                            ((source_channel >> 3) == first_source_group);
            wire [7:0] selected = use_word0 ?
                in_word0[source_channel[2:0]*8 +: 8] : in_word1[source_channel[2:0]*8 +: 8];
            assign selected_data[lane*8 +: 8] = channel < total_channels ? selected : 8'd0;
            assign selected_multiplier[lane*31 +: 31] = is_right ? right_multiplier : left_multiplier;
            assign selected_shift[lane*6 +: 6] = is_right ? right_shift : left_shift;
        end
    endgenerate
    int8_requant scaling (
        .clk(clk), .rst_n(rst_n), .clear(clear), .in_valid(in_valid), .in_ready(in_ready),
        .in_data(selected_data), .in_multiplier(selected_multiplier), .in_shift(selected_shift),
        .in_meta({in_co_group, in_index}), .out_valid(out_valid), .out_ready(out_ready),
        .out_data(out_data), .out_meta(out_meta)
    );
    assign out_co_group = out_meta[47:32];
    assign out_index = out_meta[31:0];
endmodule
