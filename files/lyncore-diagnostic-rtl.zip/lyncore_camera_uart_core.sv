`timescale 1ns/1ps
module lyncore_camera_uart_core #(
 parameter integer USER_CLOCK_HZ=125000000,CPU_CLOCK_HZ=120000000,BAUD=115200,
 parameter [31:0] MODEL_BYTES=2000824,MODEL_CRC=32'hcae3a77e,TABLE_BYTES=5568,TABLE_CRC=32'h72ada019
)(
 input wire clk,cpu_clk,pclk,rst_n,ddr_init_done,sensor_configured,vsync,href,uart_rx,
 input wire [7:0] camera_data,input wire [31:0] frame_id,input wire [4:0] keys,
 input wire overlay_ready,
 output wire uart_tx,halted,failed,cpu_run_enable,raw_committed,tensor_committed,assets_ready,
 output wire [7:0] leds,output wire [2:0] phase,
 output wire [31:0] input_crc32,verified_bytes,committed_frame_id,
output wire overlay_capture,overlay_pixel_valid,overlay_packet_write,overlay_packet_valid,
 output wire [15:0] overlay_pixel_data,
 output wire [31:0] overlay_frame_id,overlay_packet_addr,overlay_packet_data,overlay_packet_bytes,
output wire [27:0] axi_araddr,
output wire axi_aruser_ap,
output wire [3:0] axi_aruser_id,
output wire [3:0] axi_arlen,
output wire axi_arvalid,
input wire axi_arready,
input wire [255:0] axi_rdata,
input wire [3:0] axi_rid,
input wire axi_rlast,
input wire axi_rvalid,
output wire [27:0] axi_awaddr,
output wire axi_awuser_ap,
output wire [3:0] axi_awuser_id,
output wire [3:0] axi_awlen,
output wire axi_awvalid,
input wire axi_awready,
output wire [255:0] axi_wdata,
output wire [31:0] axi_wstrb,
input wire axi_wready,
input wire [3:0] axi_wusero_id,
input wire axi_wusero_last
);
 wire load_byte_valid,load_byte_ready,load_ack_valid,load_ack_ready,transport_idle,transport_error,loader_tx,cpu_tx,load_failed;
 wire [7:0] load_byte_data,load_ack_data;wire [3:0] load_error;wire [2:0] load_committed;
 lyncore_loader_uart #(.CLOCK_HZ(USER_CLOCK_HZ),.BAUD(BAUD)) transport(
  .clk(clk),.rst_n(rst_n && ddr_init_done),.rx(uart_rx),.tx(loader_tx),
  .byte_valid(load_byte_valid),.byte_data(load_byte_data),.byte_ready(load_byte_ready),
  .ack_valid(load_ack_valid),.ack_data(load_ack_data),.ack_ready(load_ack_ready),.tx_idle(transport_idle),.transport_error(transport_error));
 assign uart_tx=cpu_run_enable?cpu_tx:loader_tx;
 lyncore_camera_boot_core #(.CPU_CLOCK_HZ(CPU_CLOCK_HZ),.BAUD(BAUD),
  .MODEL_BYTES(MODEL_BYTES),.MODEL_CRC(MODEL_CRC),.TABLE_BYTES(TABLE_BYTES),.TABLE_CRC(TABLE_CRC)) core(
  .uart_tx(cpu_tx),.*);
endmodule
