`timescale 1ns/1ps

// 上传专用小 FIFO：复用原四通道 Reader 拼字，只重叠取数与 DDR 写等待。
// 顺序固定为 group8 -> index；尾 lane 由原 Reader 补零，不改 Tensor 布局。
// 仅支持 2~4 字，数据存储最多 256bit；不缓存 Tile，不增加 PE 或大 RAM。
module tensor_upload_prefetch #(
    parameter integer FIFO_WORDS=4
) (
    input wire clk, rst_n, clear, start,
    output wire ready, busy,
    output reg error,
    input wire [2:0] source_slot,
    input wire [15:0] source_channels, source_groups,
    input wire [31:0] source_pixels,
    output wire request_valid,
    input wire request_ready,
    output wire [2:0] request_slot,
    output wire [15:0] request_ci_group,
    output wire [31:0] request_index,
    input wire response_valid,
    output wire response_ready,
    input wire [2:0] response_slot,
    input wire [15:0] response_ci_group,
    input wire [31:0] response_index, response_pixel,
    input wire response_error,
    output wire out_valid,
    input wire out_ready,
    output wire [63:0] out_data,
    output wire [15:0] out_co_group,
    output wire [31:0] out_index
);
    reg [63:0] words [0:FIFO_WORDS-1];
    reg [1:0] write_pointer, read_pointer;
    reg [2:0] count;
    reg active, stopping;
    reg [2:0] slot;
    reg [15:0] channels, groups, fetch_co, emit_co;
    reg [31:0] pixels, fetch_index, emit_index;
    wire reader_ready, reader_busy, reader_error, reader_valid;
    wire [63:0] reader_data;
    wire stop_now=clear || stopping || reader_error;
    // 取消只给 Reader 一拍 clear；随后继续接收已接受请求，防止孤立应答。
    wire reader_clear=(clear || reader_error) && !stopping;
    wire reader_start=active && !stop_now && fetch_co<groups &&
        count<FIFO_WORDS && reader_ready;
    wire reader_out_ready=active && !stop_now && count<FIFO_WORDS;
    wire push=reader_valid && reader_out_ready;
    wire pop=out_valid && out_ready;
    wire last_emit=emit_index==pixels-1 && emit_co==groups-1;
    assign ready=rst_n && !clear && !active && !reader_busy;
    assign busy=active || reader_busy;
    assign out_valid=rst_n && active && !stop_now && count!=0;
    assign out_data=words[read_pointer];
    assign out_co_group=emit_co;
    assign out_index=emit_index;

    tensor_word_reader reader (
        .clk(clk),.rst_n(rst_n),.clear(reader_clear),.start(reader_start),.ready(reader_ready),
        .source_slot(slot),.source_channels(channels),.source_co_group(fetch_co),.source_index(fetch_index),
        .busy(reader_busy),.error(reader_error),
        .request_valid(request_valid),.request_ready(request_ready),.request_slot(request_slot),
        .request_ci_group(request_ci_group),.request_index(request_index),
        .response_valid(response_valid),.response_ready(response_ready),.response_slot(response_slot),
        .response_ci_group(response_ci_group),.response_index(response_index),
        .response_pixel(response_pixel),.response_error(response_error),
        .out_valid(reader_valid),.out_ready(reader_out_ready),.out_data(reader_data)
    );

    always @(posedge clk or negedge rst_n) begin
        if(!rst_n) begin
            active<=0;stopping<=0;error<=0;count<=0;write_pointer<=0;read_pointer<=0;
            slot<=0;channels<=0;groups<=0;pixels<=0;
            fetch_co<=0;fetch_index<=0;emit_co<=0;emit_index<=0;
        end else if(start && ready) begin
            error<=FIFO_WORDS<2 || FIFO_WORDS>4 || source_channels==0 || source_pixels==0 ||
                source_groups==0 || source_groups!=(({1'b0,source_channels}+17'd7)>>3);
            active<=FIFO_WORDS>=2 && FIFO_WORDS<=4 && source_channels!=0 && source_pixels!=0 &&
                source_groups!=0 && source_groups==(({1'b0,source_channels}+17'd7)>>3);
            stopping<=0;count<=0;write_pointer<=0;read_pointer<=0;
            slot<=source_slot;channels<=source_channels;groups<=source_groups;pixels<=source_pixels;
            fetch_co<=0;fetch_index<=0;emit_co<=0;emit_index<=0;
        end else if(stop_now) begin
            count<=0;
            if(reader_error) error<=1;
            if(active || reader_busy) stopping<=1;
            if(!reader_busy) begin active<=0;stopping<=0;end
        end else begin
            case({push,pop})
                2'b10:count<=count+1'b1;
                2'b01:count<=count-1'b1;
                default:count<=count;
            endcase
            if(push) begin
                words[write_pointer]<=reader_data;
                write_pointer<=write_pointer==FIFO_WORDS-1 ? 2'd0 : write_pointer+1'b1;
                if(fetch_index==pixels-1) begin fetch_index<=0;fetch_co<=fetch_co+1'b1;end
                else fetch_index<=fetch_index+1'b1;
            end
            if(pop) begin
                read_pointer<=read_pointer==FIFO_WORDS-1 ? 2'd0 : read_pointer+1'b1;
                if(emit_index==pixels-1) begin emit_index<=0;emit_co<=emit_co+1'b1;end
                else emit_index<=emit_index+1'b1;
                if(last_emit) active<=0;
            end
        end
    end
endmodule
