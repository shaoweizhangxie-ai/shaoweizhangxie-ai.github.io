`timescale 1ns/1ps
// 单组权重暂存：仅在模型请求握手后登记在途所有权；完整填充后才复制。
// generation 是加载器侧的事务代号，不要求改变物理 DDR 协议。
module weight_tile_prefetch (
    input wire clk, rst_n, clear, enable,
    input wire [15:0] generation, task_id, cin_groups,
    input wire kernel_1x1,
    input wire demand, weight_ready,
    input wire [15:0] current_co, current_ci,
    input wire future_valid,
    input wire [15:0] future_co, future_ci,
    output wire weight_valid,
    output reg [31:0] weight_word,
    output wire request_valid,
    input wire request_ready,
    output wire [31:0] request_address,
    output wire [15:0] request_co, request_ci, request_generation,
    input wire response_valid,
    output wire response_ready,
    input wire [15:0] response_task, response_generation,
    input wire [1:0] response_kind,
    input wire [31:0] response_address, response_data,
    input wire response_error,
    output wire busy,
    output reg error, cancelled
);
    localparam FREE=0, FILLING=1, FULL=2, COPY=3, CANCEL_DRAIN=4;
    reg [2:0] state;
    reg [31:0] storage [0:71];
    reg [15:0] tag_task, tag_co, tag_ci, tag_generation;
    reg [31:0] base_address;
    reg [6:0] position, last_word, copy_position;
    reg pending, wanted, copy_primed;
    wire bad_response=response_error || response_kind!=2 || response_task!=tag_task ||
        response_address!=base_address+position || response_generation!=tag_generation ||
        generation!=tag_generation;
    assign busy=state!=FREE;
    assign request_valid=state==FILLING && !pending && enable && !clear;
    assign request_address=base_address+position;
    assign request_co=tag_co;
    assign request_ci=tag_ci;
    assign request_generation=tag_generation;
    assign response_ready=pending && (state==FILLING || state==CANCEL_DRAIN);
    // demand 只来自已排空当前计算的 LOAD_START；weight_ready 再由 LOAD_WAIT 确认。
    assign weight_valid=state==COPY && copy_primed && wanted && enable && !clear;
    // RAM 写端独立为同步进程；复位只撤销标签，不清空72字存储。
    always @(posedge clk) begin
        if(rst_n && state==FILLING && response_valid && response_ready && !bad_response && !clear)
            storage[position]<=response_data;
    end
    always @(posedge clk or negedge rst_n) begin
        if(!rst_n) begin
            state<=FREE;tag_task<=0;tag_co<=0;tag_ci<=0;tag_generation<=0;
            base_address<=0;position<=0;last_word<=0;copy_position<=0;
            pending<=0;wanted<=0;copy_primed<=0;weight_word<=0;error<=0;cancelled<=0;
        end else begin
            error<=0;cancelled<=0;
            case(state)
                FREE: if(enable && !clear && (demand || future_valid)) begin
                    tag_task<=task_id;tag_generation<=generation;
                    tag_co<=demand?current_co:future_co;
                    tag_ci<=demand?current_ci:future_ci;
                    base_address<=((demand?current_co:future_co)*cin_groups+
                        (demand?current_ci:future_ci))*(kernel_1x1?32'd8:32'd72);
                    last_word<=kernel_1x1?7'd7:7'd71;position<=0;
                    wanted<=demand;copy_primed<=0;state<=FILLING;
                end
                FILLING: begin
                    if(request_valid && request_ready) pending<=1;
                    if(demand) wanted<=1;
                    if(response_valid && response_ready) begin
                        pending<=0;
                        if(bad_response) begin error<=1;wanted<=0;state<=CANCEL_DRAIN;end
                        else begin
                            if(position==last_word) state<=FULL;
                            else position<=position+1'b1;
                        end
                    end
                end
                FULL: if(wanted || demand) begin
                    wanted<=1;copy_position<=0;copy_primed<=0;state<=COPY;
                end
                COPY: begin
                    // 同步读首字预热一拍，此后每次握手预读下一字；反压时保持输出。
                    if(!copy_primed) begin weight_word<=storage[0];copy_primed<=1;end
                    else if(weight_valid && weight_ready) begin
                        if(copy_position==last_word) begin state<=FREE;wanted<=0;copy_primed<=0;end
                        else begin copy_position<=copy_position+1'b1;weight_word<=storage[copy_position+1'b1];end
                    end
                end
                CANCEL_DRAIN: begin
                    if(response_valid && response_ready) pending<=0;
                    if(!pending || (response_valid && response_ready)) begin
                        state<=FREE;wanted<=0;copy_primed<=0;cancelled<=1;
                    end
                end
                default: begin state<=CANCEL_DRAIN;error<=1;wanted<=0;end
            endcase
            if(demand && state!=FREE && state!=CANCEL_DRAIN &&
                (current_co!=tag_co || current_ci!=tag_ci || generation!=tag_generation)) begin
                error<=1;wanted<=0;copy_primed<=0;state<=CANCEL_DRAIN;
            end
            // 取消后停止请求和复制；已经接受的一笔应答必须 drain 后才能再用暂存区。
            if(clear && state!=FREE && state!=CANCEL_DRAIN) begin
                wanted<=0;copy_primed<=0;
                if(response_valid && response_ready) pending<=0;
                state<=CANCEL_DRAIN;
            end
        end
    end
endmodule
