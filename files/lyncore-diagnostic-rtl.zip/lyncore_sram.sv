`timescale 1ns/1ps
// Synchronous reads, byte writes. Store completes on the write edge.
// RAM contents are deliberately not reset; startup software initializes them.
module lyncore_sram #(parameter integer WORDS = 4096) (
    input logic clk, rst, valid, write,
    input logic [31:0] addr, wdata,
    input logic [3:0] wstrb,
    output logic ready,
    output logic [31:0] rdata
);
    localparam integer ADDR_BITS = $clog2(WORDS);
    (* ram_style = "block" *) logic [31:0] ram [0:WORDS-1];
    logic read_pending;
    assign ready = valid && (write || read_pending);
    always_ff @(posedge clk) begin
        if (valid && !write && !read_pending && !rst)
            rdata <= ram[addr[ADDR_BITS+1:2]];
        if (!rst && valid && write) begin
            for (integer b = 0; b < 4; b = b + 1)
                if (wstrb[b]) ram[addr[ADDR_BITS+1:2]][b*8 +: 8] <= wdata[b*8 +: 8];
        end
        if (rst) read_pending <= 0;
        else if (read_pending) read_pending <= 0;
        else if (valid && !write) read_pending <= 1;
    end
endmodule
