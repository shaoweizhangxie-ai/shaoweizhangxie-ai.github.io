`timescale 1ns/1ps

// 独立的区域卷积入口：复用 DMA、缓存、Reader 和现有 Conv，不修改旧整网入口。
// TILE_AWARE=1：整行输出 Tile -> 下载所有输入组及 Halo -> 局部卷积 -> 提交上传。
// GROUP8_BATCH=1：同一 Tile/co 的 Conv 不重启，按全局 ci 请求逐 group8 下载。
// 缓存局部 ci 仅为 0/1；权重及 Psum first/last 始终使用全局 ci。
// FEATURE_RESIDENCY=0：高 Cin 跨 co 重装；开启后在预算内保留当前 Tile 全部 group8。
// TILE_AWARE=0：性能对照，真实旧 Conv 每次请求均从 DDR 重装该 group8 整帧。
// DDR 是已有桥支持的 32 位请求/响应端口，可接共享仲裁器的特征图客户。
// 不包含 PHY；结果整层有效仅在最后一个区域上传成功后发布。
module conv_region_ddr_top #(
    parameter integer GEOMETRY_PIPELINE=1, // Candidate only; 0 restores original planning.
    parameter integer K1_WIDE_ENABLE=0,
    parameter integer MAX_WIDTH=642, PSUM_DEPTH=16384, TILE_ROWS=48,
    parameter integer INPUT_CACHE_DEPTH=16384, OUTPUT_CACHE_DEPTH=16384,
    parameter integer MAX_CO_GROUPS=4, PE_LATENCY=10, TILE_AWARE=1,
    // 默认保留全部 Cin 缓存。开启后仅保存一个 group8，供数握手期间重装。
    parameter integer GROUP8_BATCH=0,
    // 默认保留旧入口；只在 Tile-aware + group8 模式启用双 Bank 预取。
    parameter integer INPUT_PING_PONG=0,
    parameter integer DDR_READ_PIPELINE=0,
    parameter integer WRITE_COMBINE=0,
    // 可选 Tile 输入驻留，端口和原调度顺序保持。
    parameter integer FEATURE_RESIDENCY=0, FEATURE_CACHE_WORDS=8192,
    // 默认关闭以兼容原线性入口；启用后复用原后处理的完整 SiLU 参数和表。
    parameter integer SUPPORT_SILU=0,
    // 可选官方首层：RGB K6/S2/P2 经奇偶拆分复用同一 K3 PE。
    parameter integer SUPPORT_STEM=0,
    parameter [31:0] DDR_WINDOW_BASE=32'h20000000,
    parameter [63:0] DDR_BYTES=64'h40000000,
    parameter integer UPLOAD_FIFO_WORDS=0,
    parameter integer CONFIG_PIPELINE=1
) (
    input wire clk, rst_n, clear, start,
    output wire ready, busy,
    output reg done, error, cancelled, result_valid,
    input wire [31:0] input_base, output_base,
    input wire [15:0] width, height, channels_in, channels_out,
    input wire kernel_1x1, stride_2, padding_1,
    input wire kernel_6x6,
    input wire cfg_we,
    output wire cfg_ready,
    input wire [15:0] cfg_co_group,
    input wire [255:0] cfg_bias_bus,
    input wire [247:0] cfg_multiplier_bus,
    input wire [47:0] cfg_shift_bus,
    input wire silu_enable,
    input wire [247:0] cfg_grid_multiplier_bus,
    input wire [47:0] cfg_grid_shift_bus,
    input wire lut_load_start, lut_load_valid,
    output wire lut_load_ready, lut_valid,
    input wire [7:0] lut_load_data,
    output wire weight_request, weight_ready,
    input wire weight_valid,
    input wire [31:0] weight_word,
    output wire [15:0] current_ci_group, current_co_group,
    output wire future_weight_valid,
    output wire [15:0] future_weight_ci, future_weight_co,
    output wire [31:0] current_tile_y,
    output wire raw_valid,
    output wire [15:0] raw_co_group,
    output wire [31:0] raw_index,
    output wire [255:0] raw_data,
    output wire out_valid,
    output wire [15:0] out_co_group,
    output wire [31:0] out_index,
    output wire [63:0] out_data,
    // 缓存读链路可由上层限流，数据/坐标只随真实握手推进。
    input wire input_allow,
    // 新分批模式的下载限流；旧模式忽略此端口，保持原入口兼容。
    input wire input_write_allow,
    output wire read_request_valid,
    input wire read_request_ready,
    output wire [31:0] read_request_address,
    input wire read_response_valid,
    output wire read_response_ready,
    input wire [31:0] read_response_address, read_response_data,
    input wire read_response_error,
    output wire write_request_valid,
    input wire write_request_ready,
    output wire [31:0] write_request_address, write_request_data,
    output wire [3:0] write_request_strobe,
    input wire write_response_valid,
    output wire write_response_ready,
    input wire [31:0] write_response_address,
    input wire write_response_error,
    input wire upload_pipeline_enable
);
    localparam IDLE=0, PLAN=1, IN_OPEN=2, DOWNLOAD=3, DOWN_WAIT=4,
        IN_COMMIT=5, OUT_OPEN=6, CONV_START=7, RUN=8, REPLAY_WAIT=9,
        READER_START=10, READER_WAIT=11, OUT_COMMIT=12, UPLOAD=13,
        UP_WAIT=14, ADVANCE=15, ABORT=16, FINISH=17, GEO_WIDTH=18, GEO_INIT=19, GEO_COUNT=20,
        PLAN_ROWS=21, PLAN_AREA=22, PLAN_SIZE=23;
    reg [4:0] state;
    reg [15:0] cw,ch,cin,cout,ow,oh,cig,cog,rows,region_w,region_h;
    reg k1,s2,p1;
    reg stem;
    wire new_stem=SUPPORT_STEM!=0 && kernel_6x6;
    reg activation;
    wire conv_ready;
    reg [31:0] ib,ob,tile_y;
    reg [15:0] replay_ci;
    reg cache_tag_valid;
    reg [15:0] cache_group8;
    reg stop_error, stop_cancel;
    wire [16:0] pw={1'b0,width}+(new_stem?17'd4:(padding_1?17'd2:17'd0));
    wire [16:0] ph={1'b0,height}+(new_stem?17'd4:(padding_1?17'd2:17'd0));
    wire [16:0] kernel=new_stem?17'd6:(kernel_1x1?17'd1:17'd3);
    wire [16:0] new_ow=((pw-kernel)>>(stride_2?1:0))+1;
    wire [16:0] new_oh=((ph-kernel)>>(stride_2?1:0))+1;
    wire [16:0] in_g8=({1'b0,channels_in}+7)>>3;
    wire [16:0] out_g8=({1'b0,channels_out}+7)>>3;
    wire [63:0] input_end={32'd0,input_base}+64'd8*width*height*in_g8;
    wire [63:0] output_end={32'd0,output_base}+64'd8*new_ow*new_oh*out_g8;
    wire [63:0] window_end={32'd0,DDR_WINDOW_BASE}+DDR_BYTES;
    // 在任何读写前验证两个完整 Feature Map 的范围和互斥关系。
    wire raw_prebad=width==0 || height==0 || channels_in==0 || channels_out==0 ||
        (new_stem && (channels_in!=3 || !stride_2 || kernel_1x1 || width[0] || height[0] || GROUP8_BATCH==0 || TILE_AWARE==0)) ||
        pw<kernel || ph<kernel || new_ow>65535 || new_oh>65535 ||
        (GROUP8_BATCH!=0 && TILE_AWARE==0) ||
        (INPUT_PING_PONG!=0 && (GROUP8_BATCH==0 || TILE_AWARE==0)) ||
        (FEATURE_RESIDENCY!=0 && INPUT_PING_PONG==0) ||
        out_g8>MAX_CO_GROUPS || width>MAX_WIDTH || new_ow==0 || new_oh==0 ||
        (TILE_AWARE!=0 && (new_ow>PSUM_DEPTH || TILE_ROWS<1)) ||
        input_base[2:0]!=0 || output_base[2:0]!=0 ||
        input_base<DDR_WINDOW_BASE || output_base<DDR_WINDOW_BASE;
    wire raw_bad_config=raw_prebad || input_end>window_end || output_end>window_end ||
        !(input_end<={32'd0,output_base} || output_end<={32'd0,input_base});
    // Configuration remains stable while the caller waits for ready. Split
    // shape, area, byte count and end-address checks across register boundaries.
    wire [132:0] config_key={width,height,channels_in,channels_out,input_base,output_base,
        kernel_1x1,stride_2,padding_1,kernel_6x6,silu_enable};
    reg [132:0] config_key1,config_key2,config_key3,config_key4;
    reg [3:0] config_valid;
    reg prebad1,prebad2,prebad3,prebad4;
    reg [16:0] cfg_ow1,cfg_oh1,cfg_ing1,cfg_outg1,cfg_outg2;
    reg [31:0] cfg_in_area1;
    reg [63:0] cfg_out_area2,cfg_in_bytes2,cfg_out_bytes3,cfg_in_end3,cfg_in_end4,cfg_out_end4;
    always @(posedge clk or negedge rst_n)begin
        if(!rst_n)begin
            config_valid<=0;config_key1<=0;config_key2<=0;config_key3<=0;config_key4<=0;
            prebad1<=0;prebad2<=0;prebad3<=0;prebad4<=0;
            cfg_ow1<=0;cfg_oh1<=0;cfg_ing1<=0;cfg_outg1<=0;cfg_outg2<=0;cfg_in_area1<=0;
            cfg_out_area2<=0;cfg_in_bytes2<=0;cfg_out_bytes3<=0;cfg_in_end3<=0;cfg_in_end4<=0;cfg_out_end4<=0;
        end else begin
            config_valid<={config_valid[2:0],1'b1};
            config_key1<=config_key;config_key2<=config_key1;config_key3<=config_key2;config_key4<=config_key3;
            prebad1<=raw_prebad;prebad2<=prebad1;prebad3<=prebad2;prebad4<=prebad3;
            cfg_ow1<=new_ow;cfg_oh1<=new_oh;cfg_ing1<=in_g8;cfg_outg1<=out_g8;
            cfg_in_area1<={16'd0,width}*{16'd0,height};
            cfg_out_area2<=64'd1*cfg_ow1*cfg_oh1;
            cfg_in_bytes2<=64'd8*cfg_in_area1*cfg_ing1;
            cfg_outg2<=cfg_outg1;
            cfg_in_end3<={32'd0,config_key2[68:37]}+cfg_in_bytes2;
            cfg_out_bytes3<=64'd8*cfg_out_area2*cfg_outg2;
            cfg_in_end4<=cfg_in_end3;
            cfg_out_end4<={32'd0,config_key3[36:5]}+cfg_out_bytes3;
        end
    end
    wire config_ready=CONFIG_PIPELINE==0 || (config_valid[3] && config_key4==config_key);
    wire piped_bad_config=prebad4 || cfg_in_end4>window_end || cfg_out_end4>window_end ||
        !(cfg_in_end4<={32'd0,output_base} || cfg_out_end4<={32'd0,input_base});
    wire bad_config=CONFIG_PIPELINE!=0?piped_bad_config:raw_bad_config;
    wire local_reset=rst_n && state!=ABORT && !(SUPPORT_SILU!=0 && clear && state==IDLE);
    // 查表装载未结束时不接受层启动。加载期间数据握手独立于 ready。
    assign ready=state==IDLE && !clear && conv_ready && config_ready;
    assign busy=state!=IDLE && state!=FINISH;
    assign current_tile_y=tile_y;
    wire upload_mode=state==UPLOAD || state==UP_WAIT;
    wire download_mode=state>=IN_OPEN && state<=IN_COMMIT;
    wire [15:0] cache_in_w=TILE_AWARE!=0 ? region_w : cw;
    wire [15:0] cache_in_h=TILE_AWARE!=0 ? region_h : ch;
    wire [15:0] replay_c=(cin-((replay_ci>>1)*8)>=8)?16'd8:cin-((replay_ci>>1)*8);
    wire [15:0] cache_in_c=(TILE_AWARE!=0 && GROUP8_BATCH==0) ? cin : replay_c;
    wire [16:0] total_input_g8=({1'b0,cin}+17'd7)>>3;
    wire [15:0] dma_groups=upload_mode?cog:((TILE_AWARE!=0 && GROUP8_BATCH==0)?total_input_g8[15:0]:16'd1);
    wire cache_write_allowed=(GROUP8_BATCH==0) || input_write_allow;
    wire [15:0] cache_out_w=TILE_AWARE!=0 ? ow : ow;
    wire [15:0] cache_out_h=TILE_AWARE!=0 ? rows : oh;
    reg [31:0] geo_local_pixels,local_pixels_q;
    reg [63:0] geo_wide_words;
    reg wide_mode_q;
    wire [31:0] local_pixels=GEOMETRY_PIPELINE!=0 ? local_pixels_q : {16'd0,ow}*{16'd0,rows};
    // The original expressions remain selectable for controlled regression.
    wire [31:0] max_rows=PSUM_DEPTH/{16'd0,ow};
    wire [31:0] normal_rows=max_rows<TILE_ROWS ? max_rows : TILE_ROWS;
    wire [31:0] legacy_rw=(ow-1)*(s2?2:1)+(stem?6:(k1?1:3));
    wire [31:0] stem_input_rows=INPUT_CACHE_DEPTH/legacy_rw;
    wire [31:0] stem_output_rows=stem_input_rows>4 ? (stem_input_rows-4)/2 : 0;
    wire [31:0] legacy_candidate=stem && stem_output_rows<normal_rows ? stem_output_rows : normal_rows;
    reg [31:0] geo_rw,geo_candidate,geo_rows;
    (* syn_preserve=1 *) reg [31:0] geo_rh;
    reg [63:0] geo_psum,geo_stem,geo_in_area,geo_out_area,geo_in_size,geo_out_size;
    wire [63:0] geo_next_psum=geo_psum+{48'd0,ow};
    wire [63:0] geo_next_stem=geo_stem+({32'd0,geo_rw}<<1);
    // Incrementing rows is exactly equivalent to the two capped floor divisions:
    // n*ow <= PSUM_DEPTH; for K6, (2*n+4)*rw <= INPUT_CACHE_DEPTH.
    // This runs once per accepted task, never on the PE or DDR transfer path.
    wire geo_can_add=geo_candidate<TILE_ROWS && geo_next_psum<=PSUM_DEPTH &&
        (!stem || geo_next_stem<=INPUT_CACHE_DEPTH);
    wire [31:0] next_rw=GEOMETRY_PIPELINE!=0 ? geo_rw : legacy_rw;
    wire [31:0] candidate_rows=GEOMETRY_PIPELINE!=0 ? geo_candidate : legacy_candidate;
    wire [31:0] selected_rows=(oh-tile_y)<candidate_rows ? oh-tile_y : candidate_rows;
    wire [31:0] selected_rh=(selected_rows-1)*(s2?2:1)+(stem?6:(k1?1:3));
    wire [31:0] next_rows=geo_rows;
    wire [31:0] next_rh=geo_rh;
    wire [63:0] need_in=GEOMETRY_PIPELINE!=0 ? geo_in_size :
        (TILE_AWARE!=0 ? 64'd1*next_rw*next_rh*(GROUP8_BATCH!=0?1:((cin+7)>>3)) : 64'd1*cw*ch);
    wire [63:0] need_out=GEOMETRY_PIPELINE!=0 ? geo_out_size :
        64'd1*ow*(TILE_AWARE!=0?next_rows:oh)*cog;
    // Planning rejects dimensions that cannot fit the 16-bit cache ports.
    // Area products may therefore use 16x16 multipliers without retaining a
    // four-APM 32x32 cascade for geometry that can never be transferred.
    wire [31:0] bounded_input_area=next_rw[15:0]*next_rh[15:0];
    wire [31:0] bounded_output_area=ow*(TILE_AWARE!=0?next_rows[15:0]:oh);
    wire [31:0] bounded_frame_area=cw*ch;
    wire plan_bad=(TILE_AWARE!=0 && (next_rw>MAX_WIDTH || next_rw>65535 || next_rh>65535 || next_rows>65535 || next_rows==0)) ||
        need_in>INPUT_CACHE_DEPTH || need_out>OUTPUT_CACHE_DEPTH;

    wire conv_done,conv_error,conv_busy,ifm_request,ifm_ready,conv_cfg_ready;
    wire table_ready;
    assign lut_load_ready=SUPPORT_SILU!=0 && state==IDLE && !clear && table_ready;
    wire input_group_request;
    // 在请求点 Reader 无在途响应，Conv 已排空；标签命中可连续读低/高四路。
    // 标签只在 DMA 和输入缓存提交成功后生效，切换 Tile 必须失效。
    wire prefetch_hit,prefetch_bank,prefetch_busy,prefetch_error;
    wire reader_bank;
    wire group_cache_hit=INPUT_PING_PONG!=0?prefetch_hit:
        (cache_tag_valid && cache_group8==(stem?16'd0:(current_ci_group>>1)));
    wire input_group_ready;
    // K1宽模式只覆盖当前官方S1/P0路径，容量不足和其他几何自动回退。
    // 四个group8银行共享原Feature Cache容量；每拍32通道，不增加PE乘法位置。
    wire legacy_wide_mode=K1_WIDE_ENABLE!=0 && INPUT_PING_PONG!=0 && FEATURE_RESIDENCY!=0 &&
        k1 && !s2 && !p1 && !stem && total_input_g8<=64 &&
        64'd1*((total_input_g8+3)>>2)*local_pixels<=FEATURE_CACHE_WORDS/4;
    wire wide_mode=GEOMETRY_PIPELINE!=0 ? wide_mode_q : legacy_wide_mode;
    wire [15:0] wide_group_base={current_ci_group[15:3],2'b0};
    wire [3:0] wide_group_valid;
    reg [1:0] missing_group;
    always @*begin
        if(!wide_group_valid[0])missing_group=0;
        else if(!wide_group_valid[1])missing_group=1;
        else if(!wide_group_valid[2])missing_group=2;
        else missing_group=3;
    end
    wire wide_cache_ready,wide_valid;
    wire [255:0] wide_pixel;
    reg wide_read_active;
    reg [31:0] wide_cursor;
    wire wide_request=wide_mode && wide_read_active && wide_cursor<local_pixels && input_allow && ifm_ready;
    always @(posedge clk or negedge local_reset)begin
        if(!local_reset)begin wide_cursor<=0;wide_read_active<=0;end
        else if(wide_mode && ifm_request)begin wide_cursor<=0;wide_read_active<=1;end
        else if(wide_request && wide_cache_ready)begin
            wide_cursor<=wide_cursor+1;
            if(wide_cursor+1==local_pixels)wide_read_active<=0;
        end
    end
    assign cfg_ready=ready && conv_cfg_ready;
    wire conv_out_valid,conv_raw_valid;
    wire [31:0] conv_out_index,conv_raw_index;
    wire reader_request,reader_request_ready,reader_response_ready,reader_valid,reader_error,reader_done,reader_ready;
    wire [15:0] reader_ci;
    wire [31:0] reader_index,reader_pixel;
    wire phase_valid,phase_ready,phase_error,phase_busy,phase_input_ready;
    wire [31:0] phase_pixel;
    wire phase_source_valid,phase_source_ready,phase_frame_ready;
    wire [31:0] phase_source_pixel;
    reg [1:0] phase_count;
    reg [31:0] phase_front,phase_back;
    assign phase_valid=phase_count!=0;
    assign phase_pixel=phase_front;
    assign phase_source_ready=stem && phase_count<2;
    assign phase_ready=phase_frame_ready && phase_count==0;
    wire phase_push=phase_source_valid && phase_source_ready;
    wire phase_pop=phase_valid && stem && ifm_ready;
    // Two entries break the Conv-ready -> RGB counter control path. A full
    // queue advertises space on the cycle after a pop, without a ready bypass.
    always @(posedge clk)if(local_reset && stem)begin
        if(phase_pop && phase_count==2)phase_front<=phase_back;
        if(phase_push)begin
            if(phase_count==0 || phase_pop)phase_front<=phase_source_pixel;
            else phase_back<=phase_source_pixel;
        end
    end
    always @(posedge clk or negedge local_reset)begin
        if(!local_reset)phase_count<=0;
        else if(!stem)phase_count<=0;
        else case({phase_push,phase_pop})
            2'b10:phase_count<=phase_count+1'b1;
            2'b01:phase_count<=phase_count-1'b1;
            default:begin end
        endcase
    end
    rgb_phase_pack #(.MAX_WIDTH(MAX_WIDTH)) stem_pack (
        .clk(clk),.rst_n(local_reset),.frame_start(stem && state==RUN && ifm_request && phase_count==0),
        .frame_width(region_w),.frame_height(region_h),.rgb_channel(current_ci_group[1:0]),
        .frame_ready(phase_frame_ready),.busy(phase_busy),.frame_done(),.frame_error(phase_error),
        .in_valid(stem && reader_valid),.in_ready(phase_input_ready),.in_pixel(reader_pixel[23:0]),
        .out_valid(phase_source_valid),.out_ready(phase_source_ready),.out_pixel(phase_source_pixel));
    wire dma_ready,dma_busy,dma_done,dma_error,dma_cancelled,dma_out_valid,dma_last,dma_source_request;
    wire [15:0] dma_out_co,dma_source_ci;
    wire [31:0] dma_out_index,dma_source_index;
    wire [63:0] dma_out_data;
    wire [2:0] dma_source_slot;
    assign out_valid=conv_out_valid && busy && state!=ABORT && !clear;
    assign raw_valid=conv_raw_valid && busy && state!=ABORT && !clear;
    assign out_index=conv_out_index+(TILE_AWARE!=0 ? tile_y*ow : 0);
    assign raw_index=conv_raw_index+(TILE_AWARE!=0 ? tile_y*ow : 0);
    wire conv_future_valid;
    // 外层区域切换不猜测下一权重；仅 RUN 内接受引擎的同 tile 提示。
    assign future_weight_valid=state==RUN && conv_future_valid && !clear;
    conv_layer_top #(.MAX_WIDTH(MAX_WIDTH),.PSUM_DEPTH(PSUM_DEPTH),
        .MAX_CO_GROUPS(MAX_CO_GROUPS),.PE_LATENCY(PE_LATENCY),.SINGLE_GROUP_STREAM(1),
        .GROUP_INPUT_HANDSHAKE(GROUP8_BATCH),.K1_WIDE_ENABLE(K1_WIDE_ENABLE)) conv (
        .clk(clk),.rst_n(local_reset),.layer_start(state==CONV_START && conv_ready && output_data_ready),
        .frame_width(stem?(region_w>>1):(TILE_AWARE!=0?region_w:cw)),
        .frame_height(stem?(region_h>>1):(TILE_AWARE!=0?region_h:ch)),
        .cin_groups(cig),.cout_groups(cog),.kernel_1x1(k1),.stride_2(stem?1'b0:s2),
        .padding_1(TILE_AWARE!=0?1'b0:p1),.silu_enable(activation),
        .layer_ready(conv_ready),.layer_busy(conv_busy),.layer_done(conv_done),.layer_error(conv_error),
        .cfg_we(cfg_we && ready),.cfg_ready(conv_cfg_ready),.cfg_co_group(cfg_co_group),
        .cfg_bias_bus(cfg_bias_bus),.cfg_linear_multiplier_bus(cfg_multiplier_bus),
        .cfg_linear_shift_bus(cfg_shift_bus),
        .cfg_grid_multiplier_bus(SUPPORT_SILU!=0?cfg_grid_multiplier_bus:248'd0),
        .cfg_grid_shift_bus(SUPPORT_SILU!=0?cfg_grid_shift_bus:48'd0),
        .lut_load_start(SUPPORT_SILU!=0 && state==IDLE && !clear && lut_load_start),
        .lut_load_valid(SUPPORT_SILU!=0 && state==IDLE && !clear && lut_load_valid),
        .lut_load_ready(table_ready),.lut_load_data(SUPPORT_SILU!=0?lut_load_data:8'd0),.lut_valid(lut_valid),
        .weight_request(weight_request),.weight_ready(weight_ready),.weight_valid(weight_valid),.weight_word(weight_word),
        .ifm_request(ifm_request),.ifm_ready(ifm_ready),.ifm_valid(wide_mode?wide_valid:(stem?phase_valid:reader_valid)),.ifm_pixel(stem?phase_pixel:reader_pixel),
        .k1_wide_mode(wide_mode),.ifm_wide_pixel(wide_pixel),
        .input_group_request(input_group_request),.input_group_ready(input_group_ready),
        .current_ci_group(current_ci_group),.current_co_group(current_co_group),.current_tile_base(),
        .future_weight_valid(conv_future_valid),.future_weight_ci(future_weight_ci),.future_weight_co(future_weight_co),
        .out_valid(conv_out_valid),.out_co_group(out_co_group),.out_index(conv_out_index),.out_data(out_data),
        .raw_valid(conv_raw_valid),.raw_co_group(raw_co_group),.raw_index(conv_raw_index),.raw_data(raw_data)
    );

    wire in_ready,in_data_ready,in_done,in_error,in_valid;
    assign input_group_ready=state==RUN && (wide_mode?(&wide_group_valid && !prefetch_busy && !wide_read_active):
        (group_cache_hit && in_valid && reader_ready && (!stem || phase_ready)));
    wire in_read_ready,in_response_valid,in_response_ready,in_read_error;
    wire [15:0] in_width,in_height,in_channels,in_response_ci;
    wire [31:0] in_pixels,in_response_index,in_pixel;
    wire in_response_bank;
    wire prefetch_write_start,prefetch_write_valid,prefetch_write_end,prefetch_write_bank;
    wire [15:0] prefetch_width,prefetch_height,prefetch_channels,prefetch_co;
    wire [31:0] prefetch_index;
    wire [63:0] prefetch_data;
    wire old_read_request_valid,old_read_response_ready;
    wire [31:0] old_read_request_address;
    wire bank0_valid,bank1_valid;
    // Optional next-tile hints wait for registered geometry. Demand requests
    // retain their current metadata and priority in the prefetch manager.
    wire [98:0] hint_geometry_key={tile_y,rows,oh,candidate_rows,s2,stem,k1};
    reg [98:0] hint_key1,hint_key2,hint_key3;
    reg hint_valid1,hint_valid2,hint_valid3;
    reg [31:0] hint_tile1,hint_tile2,future_tile,hint_limit1,hint_cap1,hint_rows2,future_height;
    reg [2:0] hint_mode2;
    wire [31:0] hint_remaining1=hint_limit1-hint_tile1;
    wire [31:0] hint_span2=hint_rows2-32'd1;
    wire hint_geometry_ready=hint_valid3 && hint_key3==hint_geometry_key;
    always @(posedge clk or negedge rst_n)begin
        if(!rst_n)begin
            hint_key1<=0;hint_key2<=0;hint_key3<=0;
            hint_valid1<=0;hint_valid2<=0;hint_valid3<=0;
            hint_tile1<=0;hint_tile2<=0;future_tile<=0;
            hint_limit1<=0;hint_cap1<=0;hint_rows2<=0;hint_mode2<=0;future_height<=0;
        end else begin
            hint_key1<=hint_geometry_key;hint_key2<=hint_key1;hint_key3<=hint_key2;
            hint_valid1<=!clear && state!=ABORT;
            hint_valid2<=hint_valid1 && !clear;hint_valid3<=hint_valid2 && !clear;
            hint_tile1<=tile_y+{16'd0,rows};hint_tile2<=hint_tile1;future_tile<=hint_tile2;
            hint_limit1<={16'd0,oh};hint_cap1<=candidate_rows;
            hint_rows2<=hint_remaining1<hint_cap1?hint_remaining1:hint_cap1;
            hint_mode2<=hint_key1[2:0];
            future_height<=(hint_mode2[2]?(hint_span2<<1):hint_span2)+
                (hint_mode2[1]?32'd6:(hint_mode2[0]?32'd1:32'd3));
        end
    end
    wire [15:0] next_group8=stem?16'd0:((current_ci_group>>1)+16'd1);
    wire more_groups=!stem && next_group8<total_input_g8;
    wire next_co=!stem && total_input_g8>1 && current_co_group+1<cog;
    // group8 只有一个时可提前预取下一 Tile，并跨当前输出组保留现有 Bank。
    wire hint_next_tile=stem || total_input_g8==1 || (!more_groups && !next_co);
    wire hint_valid=state==RUN && !reader_ready &&
        (hint_next_tile?(hint_geometry_ready && future_tile<oh):(more_groups || next_co));
    wire [15:0] hint_group=more_groups?next_group8:16'd0;
    generate if(INPUT_PING_PONG!=0) begin: g_input_prefetch
        conv_input_prefetch #(.K1_WIDE_ENABLE(K1_WIDE_ENABLE),.FEATURE_RESIDENCY(FEATURE_RESIDENCY),.FEATURE_CACHE_WORDS(FEATURE_CACHE_WORDS),.DDR_READ_PIPELINE(DDR_READ_PIPELINE),.DDR_WINDOW_BASE(DDR_WINDOW_BASE),.DDR_BYTES(DDR_BYTES)) manager (
            .clk(clk),.rst_n(rst_n),.clear(clear || state==ABORT),
            .invalidate(state==IDLE && start && ready),
            .frame_base(ib),.frame_width(cw),.frame_height(ch),.frame_channels(cin),
            .step(s2?2'd2:2'd1),.pad(stem?2'd2:(p1?2'd1:2'd0)),
            .demand_valid(state==RUN && input_group_request && reader_ready && (!wide_mode || !(&wide_group_valid))),
            .demand_tile(tile_y),.demand_group(wide_mode?(wide_group_base+missing_group):(stem?16'd0:(current_ci_group>>1))),
            .demand_width(region_w),.demand_height(region_h),.demand_hit(prefetch_hit),.demand_bank(prefetch_bank),
            .hint_valid(hint_valid && !wide_mode),.hint_tile(hint_next_tile?future_tile:tile_y),
            .hint_group(hint_group),.hint_width(region_w),.hint_height(hint_next_tile?future_height[15:0]:region_h),
            .protect_valid(!reader_ready),.protect_bank(reader_bank),.busy(prefetch_busy),.error(prefetch_error),
            .cache_write_start(prefetch_write_start),.cache_write_ready(in_ready),.cache_write_bank(prefetch_write_bank),
            .cache_width(prefetch_width),.cache_height(prefetch_height),.cache_channels(prefetch_channels),
            .cache_write_valid(prefetch_write_valid),.cache_data_ready(in_data_ready),.cache_write_allow(input_write_allow),
            .cache_co(prefetch_co),.cache_index(prefetch_index),.cache_data(prefetch_data),.cache_write_end(prefetch_write_end),
            .cache_write_done(in_done),.cache_error(in_error),
            .read_request_valid(read_request_valid),.read_request_ready(read_request_ready),.read_request_address(read_request_address),
            .read_response_valid(read_response_valid),.read_response_ready(read_response_ready),
            .read_response_address(read_response_address),.read_response_data(read_response_data),.read_response_error(read_response_error),
            .wide_mode(wide_mode),.wide_tile_y(tile_y),.wide_width(region_w),.wide_height(region_h),
            .wide_group8_base(wide_group_base),.wide_group_valid(wide_group_valid),.wide_request(wide_request),
            .wide_index(wide_cursor),.wide_ready(wide_cache_ready),.wide_response_valid(wide_valid),.wide_data(wide_pixel)
        );
    end else begin: g_serial_input
        assign prefetch_hit=1'b0;assign prefetch_bank=1'b0;assign prefetch_busy=1'b0;assign prefetch_error=1'b0;
        assign prefetch_write_start=1'b0;assign prefetch_write_valid=1'b0;assign prefetch_write_end=1'b0;
        assign prefetch_write_bank=1'b0;assign prefetch_width=16'd0;assign prefetch_height=16'd0;
        assign wide_group_valid=0;assign wide_cache_ready=0;assign wide_valid=0;assign wide_pixel=0;
        assign prefetch_channels=16'd0;assign prefetch_co=16'd0;assign prefetch_index=32'd0;assign prefetch_data=64'd0;
        assign read_request_valid=old_read_request_valid;assign read_request_address=old_read_request_address;
        assign read_response_ready=old_read_response_ready;
    end endgenerate
    feature_map_buffer #(.BANK_DEPTH(INPUT_CACHE_DEPTH)) input_cache (
        .clk(clk),.rst_n(local_reset),.write_start(INPUT_PING_PONG!=0?prefetch_write_start:(state==IN_OPEN && in_ready)),.write_ready(in_ready),
        .write_bank(INPUT_PING_PONG!=0?prefetch_write_bank:1'b0),
        .write_width(INPUT_PING_PONG!=0?prefetch_width:cache_in_w),.write_height(INPUT_PING_PONG!=0?prefetch_height:cache_in_h),
        .write_channels(INPUT_PING_PONG!=0?prefetch_channels:cache_in_c),
        .write_valid(INPUT_PING_PONG!=0?prefetch_write_valid:(dma_out_valid && download_mode && cache_write_allowed)),.write_data_ready(in_data_ready),
        .write_co_group(INPUT_PING_PONG!=0?prefetch_co:dma_out_co),.write_index(INPUT_PING_PONG!=0?prefetch_index:dma_out_index),
        .write_data(INPUT_PING_PONG!=0?prefetch_data:dma_out_data),
        .write_end(INPUT_PING_PONG!=0?prefetch_write_end:(dma_done && download_mode)),.write_abort(state==ABORT),.write_busy(),.write_done(in_done),.write_error(in_error),
        .bank0_valid(bank0_valid),.bank1_valid(bank1_valid),.read_bank(INPUT_PING_PONG!=0?reader_bank:1'b0),.read_config_valid(in_valid),
        .read_width(in_width),.read_height(in_height),.read_channels(in_channels),.read_pixels(in_pixels),
        .read_request_valid(reader_request && input_allow && !wide_mode),.read_request_ready(in_read_ready),
        .read_ci_group(reader_ci),.read_index(reader_index),.read_response_valid(in_response_valid),
        .read_response_ready(reader_response_ready),.read_response_bank(in_response_bank),
        .read_response_ci_group(in_response_ci),.read_response_index(in_response_index),.read_pixel(in_pixel),.read_error(in_read_error)
    );
    assign reader_request_ready=in_read_ready && input_allow;
    feature_map_reader reader (
        .clk(clk),.rst_n(local_reset),
        .frame_start(!wide_mode && (TILE_AWARE!=0 ? (state==RUN && ifm_request) : state==READER_START)),
        .frame_ready(reader_ready),.frame_bank(INPUT_PING_PONG!=0?prefetch_bank:1'b0),
        .frame_ci_group(stem?16'd0:(GROUP8_BATCH!=0?{15'd0,current_ci_group[0]}:
            (TILE_AWARE!=0?current_ci_group:{15'd0,replay_ci[0]}))),
        .source_valid(in_valid),.source_pixels(in_pixels),.source_channels(in_channels),.abort(state==ABORT),
        .busy(),.frame_done(reader_done),.error(reader_error),.request_valid(reader_request),
        .request_ready(reader_request_ready),.request_bank(reader_bank),.request_ci_group(reader_ci),.request_index(reader_index),
        .response_valid(in_response_valid),.response_ready(reader_response_ready),.response_bank(in_response_bank),
        .response_ci_group(in_response_ci),.response_index(in_response_index),.response_pixel(in_pixel),.response_error(in_read_error),
        .out_valid(reader_valid),.out_ready(stem?phase_input_ready:ifm_ready),.out_pixel(reader_pixel)
    );

    wire output_ready,output_data_ready,output_done,output_error,output_valid;
    wire source_ready,source_response_valid,source_response_ready,source_error,source_bank;
    wire [15:0] source_width,source_height,source_channels,source_response_ci;
    wire [31:0] source_response_index,source_pixel;
    feature_map_buffer #(.BANK_DEPTH(OUTPUT_CACHE_DEPTH)) output_cache (
        .clk(clk),.rst_n(local_reset),.write_start(state==OUT_OPEN && output_ready),.write_ready(output_ready),
        .write_bank(1'b0),.write_width(cache_out_w),.write_height(cache_out_h),.write_channels(cout),
        .write_valid(out_valid),.write_data_ready(output_data_ready),.write_co_group(out_co_group),
        .write_index(conv_out_index),.write_data(out_data),.write_end(conv_done),.write_abort(state==ABORT),
        .write_busy(),.write_done(output_done),.write_error(output_error),.bank0_valid(output_valid),.bank1_valid(),
        .read_bank(1'b0),.read_config_valid(),.read_width(source_width),.read_height(source_height),
        .read_channels(source_channels),.read_pixels(),.read_request_valid(dma_source_request),.read_request_ready(source_ready),
        .read_ci_group(dma_source_ci),.read_index(dma_source_index),.read_response_valid(source_response_valid),
        .read_response_ready(source_response_ready),.read_response_bank(source_bank),.read_response_ci_group(source_response_ci),
        .read_response_index(source_response_index),.read_pixel(source_pixel),.read_error(source_error)
    );
    // 写合并取消后仍需发送FENCE排空，不能持续Clear阻止刷新请求。
    reg dma_abort_sent;
    always @(posedge clk or negedge rst_n)begin
        if(!rst_n)dma_abort_sent<=0;
        else dma_abort_sent<=state==ABORT;
    end
    feature_map_ddr_dma #(.UPLOAD_FIFO_WORDS(UPLOAD_FIFO_WORDS),.WRITE_COMBINE(WRITE_COMBINE),.DDR_WINDOW_BASE(DDR_WINDOW_BASE),.DDR_BYTES(DDR_BYTES)) dma (
        .upload_pipeline_enable(upload_pipeline_enable),
        .clk(clk),.rst_n(rst_n),.clear(clear || (state==ABORT && (WRITE_COMBINE==0 || !dma_abort_sent))),
        .start(((INPUT_PING_PONG==0 && state==DOWNLOAD) || state==UPLOAD) && dma_ready),.ready(dma_ready),.busy(dma_busy),
        .done(dma_done),.error(dma_error),.cancelled(dma_cancelled),.download(!upload_mode),
        .frame_base(upload_mode?ob:ib),.frame_width(upload_mode?ow:cw),.frame_height(upload_mode?oh:ch),
        .frame_channels(upload_mode?cout:cin),
        .region_x(upload_mode || TILE_AWARE==0 ? 32'sd0 : -(stem?32'sd2:(p1?32'sd1:32'sd0))),
        .region_y(upload_mode ? (TILE_AWARE!=0?$signed(tile_y):32'sd0) :
            (TILE_AWARE!=0?$signed(tile_y*(s2?2:1))-(stem?32'sd2:(p1?32'sd1:32'sd0)):32'sd0)),
        .region_width(upload_mode?cache_out_w:cache_in_w),.region_height(upload_mode?cache_out_h:cache_in_h),
        .co_base(upload_mode || (TILE_AWARE!=0 && GROUP8_BATCH==0)?16'd0:(replay_ci>>1)),
        .co_groups(dma_groups),.source_slot(3'd0),
        .source_config_slot(),.source_config_valid(output_valid),.source_width(source_width),
        .source_height(source_height),.source_channels(source_channels),
        .source_request_valid(dma_source_request),.source_request_ready(source_ready),
        .source_request_slot(dma_source_slot),.source_request_ci_group(dma_source_ci),.source_request_index(dma_source_index),
        .source_response_valid(source_response_valid),.source_response_ready(source_response_ready),
        .source_response_slot({2'd0,source_bank}),.source_response_ci_group(source_response_ci),
        .source_response_index(source_response_index),.source_response_pixel(source_pixel),.source_response_error(source_error),
        .transfer_width(),.transfer_height(),.transfer_channels(),.out_valid(dma_out_valid),
        .out_ready(in_data_ready && download_mode && cache_write_allowed),.out_data(dma_out_data),.out_co_group(dma_out_co),
        .out_index(dma_out_index),.out_last(dma_last),
        .read_request_valid(old_read_request_valid),.read_request_ready(INPUT_PING_PONG==0 && read_request_ready),.read_request_address(old_read_request_address),
        .read_response_valid(INPUT_PING_PONG==0 && read_response_valid),.read_response_ready(old_read_response_ready),
        .read_response_address(read_response_address),.read_response_data(read_response_data),.read_response_error(read_response_error),
        .write_request_valid(write_request_valid),.write_request_ready(write_request_ready),.write_request_address(write_request_address),
        .write_request_data(write_request_data),.write_request_strobe(write_request_strobe),
        .write_response_valid(write_response_valid),.write_response_ready(write_response_ready),
        .write_response_address(write_response_address),.write_response_error(write_response_error)
    );

    // 无 ready 的 Conv 输出必须进入已预留容量的缓存；正常路径不丢弃/暂停结果。
    wire fault=dma_error || prefetch_error || in_error || output_error || reader_error || conv_error || source_error || (stem && phase_error) ||
        (out_valid && !output_data_ready);
    always @(posedge clk or negedge rst_n) begin
        if(!rst_n) begin
            state<=IDLE;done<=0;error<=0;cancelled<=0;result_valid<=0;stop_error<=0;stop_cancel<=0;
            cw<=0;ch<=0;cin<=0;cout<=0;ow<=1;oh<=0;cig<=0;cog<=0;rows<=0;
            region_w<=0;region_h<=0;k1<=0;s2<=0;p1<=0;ib<=0;ob<=0;tile_y<=0;replay_ci<=0;
            cache_tag_valid<=0;cache_group8<=0;
            activation<=0;stem<=0;
            geo_rw<=0;geo_candidate<=0;geo_rows<=0;geo_rh<=0;
            geo_psum<=0;geo_stem<=0;geo_in_area<=0;geo_out_area<=0;geo_in_size<=0;geo_out_size<=0;
            geo_local_pixels<=0;local_pixels_q<=0;geo_wide_words<=0;wide_mode_q<=0;
        end else begin
            done<=0;error<=0;cancelled<=0;
            case(state)
                IDLE: if(start && ready) begin
                    result_valid<=0;stop_error<=0;stop_cancel<=0;
                    if(bad_config) begin stop_error<=1;state<=FINISH;end
                    else begin
                        cw<=width;ch<=height;cin<=channels_in;cout<=channels_out;
                        ow<=new_ow;oh<=new_oh;cig<=new_stem?16'd3:((channels_in+3)>>2);cog<=out_g8;stem<=new_stem;
                        k1<=kernel_1x1;s2<=stride_2;p1<=padding_1;ib<=input_base;ob<=output_base;
                        activation<=SUPPORT_SILU!=0 && silu_enable;
                        tile_y<=0;state<=GEOMETRY_PIPELINE!=0 ? GEO_WIDTH : PLAN_ROWS;
                    end
                end
                GEO_WIDTH: begin geo_rw<=legacy_rw;state<=GEO_INIT;end
                GEO_INIT: begin
                    geo_candidate<=0;geo_psum<=0;geo_stem<={32'd0,geo_rw}<<2;
                    state<=GEO_COUNT;
                end
                GEO_COUNT: if(geo_can_add)begin
                    geo_candidate<=geo_candidate+1;geo_psum<=geo_next_psum;geo_stem<=geo_next_stem;
                end else state<=PLAN_ROWS;
                PLAN_ROWS: begin geo_rows<=selected_rows;geo_rh<=selected_rh;state<=GEOMETRY_PIPELINE!=0 ? PLAN_AREA : PLAN;end
                PLAN_AREA: begin
                    geo_local_pixels<=ow*next_rows[15:0];
                    geo_in_area<=TILE_AWARE!=0 ? {32'd0,bounded_input_area} : {32'd0,bounded_frame_area};
                    geo_out_area<={32'd0,bounded_output_area};
                    state<=PLAN_SIZE;
                end
                PLAN_SIZE: begin
                    geo_wide_words<=64'd1*((total_input_g8+3)>>2)*geo_local_pixels;
                    geo_in_size<=geo_in_area*(TILE_AWARE!=0 && GROUP8_BATCH==0 ? ((cin+7)>>3) : 1);
                    geo_out_size<=geo_out_area*cog;state<=PLAN;
                end
                PLAN: if(plan_bad) begin stop_error<=1;state<=ABORT;end
                    else begin rows<=next_rows;region_w<=next_rw;region_h<=next_rh;
                        local_pixels_q<=geo_local_pixels;
                        wide_mode_q<=K1_WIDE_ENABLE!=0 && INPUT_PING_PONG!=0 && FEATURE_RESIDENCY!=0 &&
                            k1 && !s2 && !p1 && !stem && total_input_g8<=64 && geo_wide_words<=FEATURE_CACHE_WORDS/4;
                        cache_tag_valid<=0;
                        state<=(TILE_AWARE!=0 && GROUP8_BATCH==0)?IN_OPEN:OUT_OPEN;end
                IN_OPEN: if(in_ready) state<=DOWNLOAD;
                DOWNLOAD: if(dma_ready) state<=DOWN_WAIT;
                DOWN_WAIT: if(dma_done) state<=IN_COMMIT;
                IN_COMMIT: if(in_done) begin
                    cache_tag_valid<=1;cache_group8<=replay_ci>>1;
                    state<=GROUP8_BATCH!=0?RUN:(TILE_AWARE!=0?OUT_OPEN:READER_START);
                end
                OUT_OPEN: if(output_ready) state<=CONV_START;
                CONV_START: if(conv_ready && output_data_ready) state<=TILE_AWARE!=0?RUN:REPLAY_WAIT;
                RUN: begin
                    // 重装期间 Conv 停在 FRAME_START，输出缓存保持打开，Psum 不复位。
                    if(INPUT_PING_PONG==0 && GROUP8_BATCH!=0 && input_group_request && !group_cache_hit && reader_ready) begin
                        replay_ci<=stem?16'd0:current_ci_group;cache_tag_valid<=0;state<=IN_OPEN;
                    end
                    if(conv_done) state<=OUT_COMMIT;
                end
                REPLAY_WAIT: begin
                    if(ifm_request) begin replay_ci<=current_ci_group;state<=IN_OPEN;end
                    if(conv_done) state<=OUT_COMMIT;
                end
                READER_START: if(reader_ready) state<=READER_WAIT;
                READER_WAIT: if(reader_done) state<=REPLAY_WAIT;
                OUT_COMMIT: if(output_done) state<=UPLOAD;
                UPLOAD: if(dma_ready) state<=UP_WAIT;
                UP_WAIT: if(dma_done) state<=ADVANCE;
                ADVANCE: if(TILE_AWARE==0 || tile_y+rows>=oh) begin result_valid<=1;state<=FINISH;end
                    else begin tile_y<=tile_y+rows;state<=PLAN_ROWS;end
                ABORT: if(!dma_busy && !prefetch_busy) state<=FINISH;
                FINISH: begin done<=!stop_error && !stop_cancel;error<=stop_error;cancelled<=stop_cancel;state<=IDLE;end
                default: begin stop_error<=1;state<=ABORT;end
            endcase
            if(busy && state!=ABORT && (clear || fault)) begin
                stop_error<=!clear;stop_cancel<=clear;result_valid<=0;cache_tag_valid<=0;state<=ABORT;
            end
            if(clear && state==IDLE) result_valid<=0;
        end
    end
endmodule
