`timescale 1ns/1ps
// 有限、只读的本层权重驻留缓存，位于 loader 和 model_memory_adapter 之间。
// 保留完整 co8 组前缀；未驻留组直通 DDR，绝不淘汰前缀导致 tile 复用失效。
// 数据 RAM 同步读、逐字写；valid 按一个 ci4/co8 权重 tile 标记。
// dirty 表示 tile 装载不完整，不是待写回DDR。权重镜像运行期间必须只读。
module weight_residency_cache #(
    parameter integer CACHE_WORDS=16384,
    // 保留旧 valid 向量回退；RAM 模式逐项失效，可与参数/LUT 装载重叠。
    parameter integer VALID_RAM=1
) (
    input wire clk,rst_n,clear,layer_start,
    input wire [15:0] layer_id,cin_groups,cout_groups,
    input wire kernel_1x1,
    input wire [15:0] request_co_group,request_ci_group,
    input wire request_valid,
    output wire request_ready,
    input wire [1:0] request_kind,
    input wire [15:0] request_task,
    input wire [31:0] request_address,
    output wire response_valid,
    input wire response_ready,
    output wire [1:0] response_kind,
    output wire [15:0] response_task,
    output wire [31:0] response_address,
    output wire [847:0] response_data,
    output wire response_error,
    output wire memory_request_valid,
    input wire memory_request_ready,
    output wire [1:0] memory_request_kind,
    output wire [15:0] memory_request_task,
    output wire [31:0] memory_request_address,
    input wire memory_response_valid,
    output wire memory_response_ready,
    input wire [1:0] memory_response_kind,
    input wire [15:0] memory_response_task,
    input wire [31:0] memory_response_address,
    input wire [847:0] memory_response_data,
    input wire memory_response_error,
    // 仅事件输出；累加性能计数由TB完成，不增加硬件大计数器。
    output wire cache_hit,cache_miss,cache_bypass,
    output wire cache_fill_busy
);
    function integer clog2;
        input integer value;integer v;
        begin v=value-1;clog2=0;while(v>0)begin v=v>>1;clog2=clog2+1;end
            if(clog2==0)clog2=1;end
    endfunction
    localparam integer AW=clog2(CACHE_WORDS), SLOTS=CACHE_WORDS/8, BW=clog2(SLOTS);
    localparam [1:0] IDLE=0,EXTERNAL=1,HIT=2;
    reg [1:0] state;
    reg [31:0] words [0:CACHE_WORDS-1];
    wire tile_valid_bit,valid_clearing;
    reg [15:0] tag_layer,tag_cin,tag_cout,resident_co_groups;
    reg tag_k1,tag_valid,allocating;
    reg [31:0] co_words,resident_words;
    // 预算分配逐co组加法，隐藏在参数读取期间，避免运行时大除法器。
    reg [31:0] held_address,hit_word;
    reg [15:0] held_task;
    reg [1:0] held_kind;
    reg held_cacheable;
    reg [BW-1:0] held_block,fill_block;
    reg [6:0] held_position,fill_next;
    reg dirty;
    wire [31:0] block_id=request_co_group*tag_cin+request_ci_group;
    wire [31:0] block_base=tag_k1?(block_id<<3):block_id*32'd72;
    wire [31:0] position=request_address-block_base;
    wire eligible=tag_valid && !allocating && request_kind==2 && request_task==tag_layer &&
        request_co_group<resident_co_groups && request_ci_group<tag_cin &&
        block_id<SLOTS && request_address<resident_words && position<(tag_k1?8:72);
    wire hit=eligible && !valid_clearing && tile_valid_bit;
    // 清理期间仍允许系数和 SiLU 表请求；权重请求等待元数据失效完成。
    wire valid_wait=valid_clearing && request_kind==2;
    assign request_ready=rst_n && !clear && !layer_start && !valid_wait && state==IDLE && (hit || memory_request_ready);
    assign memory_request_valid=rst_n && !clear && !layer_start && !valid_wait && state==IDLE && request_valid && !hit;
    assign memory_request_kind=request_kind;
    assign memory_request_task=request_task;
    assign memory_request_address=request_address;
    // Miss无额外请求寄存级，沿用原adapter的应答保持及取消语义。
    assign response_valid=state==HIT || (state==EXTERNAL && memory_response_valid);
    assign response_kind=state==HIT?held_kind:memory_response_kind;
    assign response_task=state==HIT?held_task:memory_response_task;
    assign response_address=state==HIT?held_address:memory_response_address;
    assign response_data=state==HIT?{816'd0,hit_word}:memory_response_data;
    assign response_error=state==HIT?1'b0:memory_response_error;
    assign memory_response_ready=state==EXTERNAL && response_ready;
    assign cache_hit=request_valid && request_ready && request_kind==2 && hit;
    assign cache_miss=request_valid && request_ready && request_kind==2 && !hit;
    assign cache_bypass=cache_miss && !eligible;
    assign cache_fill_busy=state==EXTERNAL && held_kind==2;
    wire successful=memory_response_task==held_task && memory_response_kind==held_kind &&
        memory_response_address==held_address && !memory_response_error;

    wire fill_ordered=dirty && fill_block==held_block && held_position==fill_next;
    wire mark_complete=successful && held_position!=0 && fill_ordered && held_position==(tag_k1?7:71);
    wire mark_invalid=!successful || held_position==0 || !fill_ordered;
    wire valid_update=state==EXTERNAL && memory_response_valid && memory_response_ready &&
        held_cacheable && !clear && !layer_start && (mark_complete || mark_invalid);
    generate if(VALID_RAM!=0) begin : g_valid_ram
        // 单写口、异步单读口，2048 位可映射为 LUT RAM，无逐位异步复位扇出。
        (* syn_ramstyle="lut_ram" *) reg valid_mem [0:SLOTS-1];
        reg clearing;
        reg [BW-1:0] clear_index;
        assign valid_clearing=clearing;
        assign tile_valid_bit=valid_mem[block_id[BW-1:0]];
        always @(posedge clk) begin
            if(rst_n) begin
                if(clearing) valid_mem[clear_index]<=1'b0;
                else if(valid_update) valid_mem[held_block]<=mark_complete;
            end
        end
        always @(posedge clk or negedge rst_n) begin
            if(!rst_n)begin clearing<=1'b1;clear_index<=0;end
            else if(clear || layer_start)begin clearing<=1'b1;clear_index<=0;end
            else if(clearing) begin
                if(clear_index==SLOTS-1)clearing<=1'b0;
                else clear_index<=clear_index+1'b1;
            end
        end
    end else begin : g_valid_vector
        reg [SLOTS-1:0] tile_valid;
        assign valid_clearing=1'b0;
        assign tile_valid_bit=tile_valid[block_id[BW-1:0]];
        always @(posedge clk or negedge rst_n) begin
            if(!rst_n)tile_valid<=0;
            else if(clear || layer_start)tile_valid<=0;
            else if(valid_update)tile_valid[held_block]<=mark_complete;
        end
    end endgenerate

    // RAM不复位；每层失效valid即可。同步读取结果在整个HIT反压期间保持。
    always @(posedge clk) begin
        if(request_valid && request_ready && hit) hit_word<=words[request_address[AW-1:0]];
        if(state==EXTERNAL && memory_response_valid && memory_response_ready && successful &&
            held_cacheable && !clear && !layer_start)
            words[held_address[AW-1:0]]<=memory_response_data[31:0];
    end
    always @(posedge clk or negedge rst_n) begin
        if(!rst_n) begin
            state<=IDLE;tag_layer<=0;tag_cin<=0;tag_cout<=0;
            resident_co_groups<=0;tag_k1<=0;tag_valid<=0;allocating<=0;
            co_words<=0;resident_words<=0;held_address<=0;held_task<=0;held_kind<=0;
            held_cacheable<=0;held_block<=0;held_position<=0;fill_block<=0;fill_next<=0;dirty<=0;
        end else begin
            if(allocating) begin
                if(resident_co_groups<tag_cout && {1'b0,resident_words}+{1'b0,co_words}<=CACHE_WORDS) begin
                    resident_words<=resident_words+co_words;resident_co_groups<=resident_co_groups+1'b1;
                end else allocating<=0;
            end
            case(state)
                IDLE: if(request_valid && request_ready) begin
                    held_address<=request_address;held_task<=request_task;held_kind<=request_kind;
                    held_cacheable<=eligible;held_block<=block_id[BW-1:0];held_position<=position[6:0];
                    state<=hit?HIT:EXTERNAL;
                end
                HIT: if(response_ready) state<=IDLE;
                EXTERNAL: if(memory_response_valid && memory_response_ready) begin
                    state<=IDLE;
                    if(held_cacheable) begin
                        if(!successful) begin dirty<=0;end
                        else if(held_position==0) begin
                            dirty<=1;fill_block<=held_block;fill_next<=1;
                        end else if(dirty && fill_block==held_block && held_position==fill_next) begin
                            if(held_position==(tag_k1?7:71))begin dirty<=0;end
                            else fill_next<=fill_next+1'b1;
                        end else begin dirty<=0;end
                    end
                end
                default: state<=IDLE;
            endcase
            // clear不撤销已接受请求/已呈现响应；上游ABORT负责收回它们。
            // 同一layer_id重启也冷启动，可安全更换同地址的模型镜像。
            if(clear || layer_start) begin
                dirty<=0;resident_co_groups<=0;resident_words<=0;
                held_cacheable<=0;tag_valid<=layer_start && !clear;
                allocating<=layer_start && !clear && cin_groups!=0 && cout_groups!=0;
                if(layer_start) begin
                    tag_layer<=layer_id;tag_cin<=cin_groups;tag_cout<=cout_groups;tag_k1<=kernel_1x1;
                    co_words<=kernel_1x1?({16'd0,cin_groups}<<3):({16'd0,cin_groups}*32'd72);
                end
            end
        end
    end
endmodule
