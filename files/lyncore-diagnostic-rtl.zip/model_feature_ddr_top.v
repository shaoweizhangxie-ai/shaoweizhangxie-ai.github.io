`timescale 1ns/1ps

// 模型读、特征图搬运和主机写共用一个 DDR 用户端；clk 接 IP core_clk。
// 客户 0=模型读，1=特征图 DMA，2=主机写；不包含 PHY 或整网区域调度。
module model_feature_ddr_top #(
    parameter [31:0] DDR_WINDOW_BASE=32'h20000000,
    parameter [63:0] DDR_BYTES=64'h40000000,
    parameter integer READ_BEAT_CACHE=0
) (
    input wire clk, rst_n, clear, start,
    output wire ready, busy,
    output wire done, error, cancelled,
    // download=0 上传，=1 下载；以下配置仅在 start && ready 时锁存。
    input wire download,
    input wire [31:0] frame_base,
    input wire [15:0] frame_width, frame_height, frame_channels,
    input wire signed [31:0] region_x, region_y,
    input wire [15:0] region_width, region_height, co_base, co_groups,
    input wire [2:0] source_slot,
    // 上传源是局部区域，通道数为所选 group8 的实际有效通道数。
    output wire [2:0] source_config_slot,
    input wire source_config_valid,
    input wire [15:0] source_width, source_height, source_channels,
    output wire source_request_valid,
    input wire source_request_ready,
    output wire [2:0] source_request_slot,
    output wire [15:0] source_request_ci_group,
    output wire [31:0] source_request_index,
    input wire source_response_valid,
    output wire source_response_ready,
    input wire [2:0] source_response_slot,
    input wire [15:0] source_response_ci_group,
    input wire [31:0] source_response_index, source_response_pixel,
    input wire source_response_error,
    // 下载元数据为局部区域配置；输出组从 0 编号，index=row*区域宽度+列。
    output wire [15:0] transfer_width, transfer_height, transfer_channels,
    output wire out_valid,
    input wire out_ready,
    output wire [63:0] out_data,
    output wire [15:0] out_co_group,
    output wire [31:0] out_index,
    output wire out_last,
    // 模型接口直接连接 network_storage_top 的统一 32 位读口。
    input wire model_read_request_valid,
    output wire model_read_request_ready,
    input wire [31:0] model_read_request_address,
    output wire model_read_response_valid,
    input wire model_read_response_ready,
    output wire [31:0] model_read_response_address, model_read_response_data,
    output wire model_read_response_error,
    // 主机只能写自己拥有的区域；本模块不判断模型或特征图地址是否重叠。
    input wire host_write_request_valid,
    output wire host_write_request_ready,
    input wire [31:0] host_write_request_address, host_write_request_data,
    input wire [3:0] host_write_request_strobe,
    output wire host_write_response_valid,
    input wire host_write_response_ready,
    output wire [31:0] host_write_response_address,
    output wire host_write_response_error,
    output wire arbiter_busy, arbiter_protocol_fault, memory_busy,
    input wire ddr_init_done,
    output wire ddr_ready, ddr_busy, ddr_protocol_fault,
    // 这些端口直接连接 HMIC_S 对应同名端口。LEN=0 表示一拍 256 位数据。
    output wire [27:0] axi_araddr,
    output wire axi_aruser_ap,
    output wire [3:0] axi_aruser_id, axi_arlen,
    output wire axi_arvalid,
    input wire axi_arready,
    input wire [255:0] axi_rdata,
    input wire [3:0] axi_rid,
    input wire axi_rlast, axi_rvalid,
    output wire [27:0] axi_awaddr,
    output wire axi_awuser_ap,
    output wire [3:0] axi_awuser_id, axi_awlen,
    output wire axi_awvalid,
    input wire axi_awready,
    output wire [255:0] axi_wdata,
    output wire [31:0] axi_wstrb,
    input wire axi_wready,
    input wire [3:0] axi_wusero_id,
    input wire axi_wusero_last
);
    wire dma_ready, dma_busy, dma_error;
    wire feature_read_request_valid, feature_read_request_ready, feature_read_response_valid, feature_read_response_ready, feature_read_response_error;
    wire [31:0] feature_read_request_address, feature_read_response_address, feature_read_response_data;
    wire feature_write_request_valid, feature_write_request_ready, feature_write_response_valid, feature_write_response_ready, feature_write_response_error;
    wire [31:0] feature_write_request_address, feature_write_request_data, feature_write_response_address;
    wire [3:0] feature_write_request_strobe;
    assign ready=dma_ready && ddr_ready && !arbiter_protocol_fault && !clear;
    assign busy=dma_busy;
    assign memory_busy=dma_busy || arbiter_busy || ddr_busy;
    assign error=dma_error || ddr_protocol_fault || arbiter_protocol_fault;
    feature_map_ddr_dma #(.DDR_WINDOW_BASE(DDR_WINDOW_BASE),.DDR_BYTES(DDR_BYTES)) dma (
        .clk(clk),
        .rst_n(rst_n),
        .clear(clear),
        .start(start && ready),
        .ready(dma_ready),
        .busy(dma_busy),
        .done(done),
        .error(dma_error),
        .cancelled(cancelled),
        .download(download),
        .frame_base(frame_base),
        .frame_width(frame_width),
        .frame_height(frame_height),
        .frame_channels(frame_channels),
        .region_x(region_x),
        .region_y(region_y),
        .region_width(region_width),
        .region_height(region_height),
        .co_base(co_base),
        .co_groups(co_groups),
        .source_slot(source_slot),
        .source_config_slot(source_config_slot),
        .source_config_valid(source_config_valid),
        .source_width(source_width),
        .source_height(source_height),
        .source_channels(source_channels),
        .source_request_valid(source_request_valid),
        .source_request_ready(source_request_ready),
        .source_request_slot(source_request_slot),
        .source_request_ci_group(source_request_ci_group),
        .source_request_index(source_request_index),
        .source_response_valid(source_response_valid),
        .source_response_ready(source_response_ready),
        .source_response_slot(source_response_slot),
        .source_response_ci_group(source_response_ci_group),
        .source_response_index(source_response_index),
        .source_response_pixel(source_response_pixel),
        .source_response_error(source_response_error),
        .transfer_width(transfer_width),
        .transfer_height(transfer_height),
        .transfer_channels(transfer_channels),
        .out_valid(out_valid),
        .out_ready(out_ready),
        .out_data(out_data),
        .out_co_group(out_co_group),
        .out_index(out_index),
        .out_last(out_last),
        .read_request_valid(feature_read_request_valid),
        .read_request_ready(feature_read_request_ready),
        .read_request_address(feature_read_request_address),
        .read_response_valid(feature_read_response_valid),
        .read_response_ready(feature_read_response_ready),
        .read_response_address(feature_read_response_address),
        .read_response_data(feature_read_response_data),
        .read_response_error(feature_read_response_error),
        .write_request_valid(feature_write_request_valid),
        .write_request_ready(feature_write_request_ready),
        .write_request_address(feature_write_request_address),
        .write_request_data(feature_write_request_data),
        .write_request_strobe(feature_write_request_strobe),
        .write_response_valid(feature_write_response_valid),
        .write_response_ready(feature_write_response_ready),
        .write_response_address(feature_write_response_address),
        .write_response_error(feature_write_response_error)
    );
    wire read_request_valid, read_request_ready, read_response_valid, read_response_ready, read_response_error;
    wire [31:0] read_request_address, read_response_address, read_response_data;
    wire write_request_valid, write_request_ready, write_response_valid, write_response_ready, write_response_error;
    wire [31:0] write_request_address, write_request_data, write_response_address;
    wire [3:0] write_request_strobe;
    wire [2:0] client_read_request_ready, client_write_request_ready;
    wire [2:0] client_read_response_valid, client_read_response_error, client_write_response_valid, client_write_response_error;
    wire [95:0] client_read_response_address, client_read_response_data, client_write_response_address;
    assign model_read_request_ready=client_read_request_ready[0];
    assign feature_read_request_ready=client_read_request_ready[1];
    assign model_read_response_valid=client_read_response_valid[0];
    assign model_read_response_address=client_read_response_address[0 +: 32];
    assign model_read_response_data=client_read_response_data[0 +: 32];
    assign model_read_response_error=client_read_response_error[0];
    assign feature_read_response_valid=client_read_response_valid[1];
    assign feature_read_response_address=client_read_response_address[32 +: 32];
    assign feature_read_response_data=client_read_response_data[32 +: 32];
    assign feature_read_response_error=client_read_response_error[1];
    assign feature_write_request_ready=client_write_request_ready[1];
    assign host_write_request_ready=client_write_request_ready[2];
    assign feature_write_response_valid=client_write_response_valid[1];
    assign feature_write_response_address=client_write_response_address[32 +: 32];
    assign feature_write_response_error=client_write_response_error[1];
    assign host_write_response_valid=client_write_response_valid[2];
    assign host_write_response_address=client_write_response_address[64 +: 32];
    assign host_write_response_error=client_write_response_error[2];
    ddr_request_arbiter #(.CLIENTS(3)) arbiter (
        .clk(clk),.rst_n(rst_n),.clear(clear),.enable(ddr_ready),
        .busy(arbiter_busy),.protocol_fault(arbiter_protocol_fault),
        .client_read_request_valid({1'b0,feature_read_request_valid,model_read_request_valid}),
        .client_read_request_ready(client_read_request_ready),
        .client_read_request_address({32'd0,feature_read_request_address,model_read_request_address}),
        .client_read_response_valid(client_read_response_valid),
        .client_read_response_ready({1'b0,feature_read_response_ready,model_read_response_ready}),
        .client_read_response_address(client_read_response_address),
        .client_read_response_data(client_read_response_data),.client_read_response_error(client_read_response_error),
        .client_write_request_valid({host_write_request_valid,feature_write_request_valid,1'b0}),
        .client_write_request_ready(client_write_request_ready),
        .client_write_request_address({host_write_request_address,feature_write_request_address,32'd0}),
        .client_write_request_data({host_write_request_data,feature_write_request_data,32'd0}),
        .client_write_request_strobe({host_write_request_strobe,feature_write_request_strobe,4'd0}),
        .client_write_response_valid(client_write_response_valid),
        .client_write_response_ready({host_write_response_ready,feature_write_response_ready,1'b0}),
        .client_write_response_address(client_write_response_address),.client_write_response_error(client_write_response_error),
        .read_request_valid(read_request_valid),
        .read_request_ready(read_request_ready),
        .read_request_address(read_request_address),
        .read_response_valid(read_response_valid),
        .read_response_ready(read_response_ready),
        .read_response_address(read_response_address),
        .read_response_error(read_response_error),
        .read_response_data(read_response_data),
        .write_request_valid(write_request_valid),
        .write_request_ready(write_request_ready),
        .write_request_address(write_request_address),
        .write_response_valid(write_response_valid),
        .write_response_ready(write_response_ready),
        .write_response_address(write_response_address),
        .write_response_error(write_response_error),
        .write_request_data(write_request_data),
        .write_request_strobe(write_request_strobe)
    );
    pango_ddr_bridge #(.DDR_WINDOW_BASE(DDR_WINDOW_BASE),.DDR_BYTES(DDR_BYTES),
        .READ_BEAT_CACHE(READ_BEAT_CACHE)) bridge (
        .clk(clk),
        .rst_n(rst_n),
        .clear(clear),
        .ddr_init_done(ddr_init_done),
        .ddr_ready(ddr_ready),
        .busy(ddr_busy),
        .protocol_fault(ddr_protocol_fault),
        .read_request_valid(read_request_valid),
        .read_request_ready(read_request_ready),
        .read_request_address(read_request_address),
        .read_response_valid(read_response_valid),
        .read_response_ready(read_response_ready),
        .read_response_address(read_response_address),
        .read_response_data(read_response_data),
        .read_response_error(read_response_error),
        .write_request_valid(write_request_valid),
        .write_request_ready(write_request_ready),
        .write_request_address(write_request_address),
        .write_request_data(write_request_data),
        .write_request_strobe(write_request_strobe),
        .write_response_valid(write_response_valid),
        .write_response_ready(write_response_ready),
        .write_response_address(write_response_address),
        .write_response_error(write_response_error),
        .axi_araddr(axi_araddr),
        .axi_aruser_ap(axi_aruser_ap),
        .axi_aruser_id(axi_aruser_id),
        .axi_arlen(axi_arlen),
        .axi_arvalid(axi_arvalid),
        .axi_arready(axi_arready),
        .axi_rdata(axi_rdata),
        .axi_rid(axi_rid),
        .axi_rlast(axi_rlast),
        .axi_rvalid(axi_rvalid),
        .axi_awaddr(axi_awaddr),
        .axi_awuser_ap(axi_awuser_ap),
        .axi_awuser_id(axi_awuser_id),
        .axi_awlen(axi_awlen),
        .axi_awvalid(axi_awvalid),
        .axi_awready(axi_awready),
        .axi_wdata(axi_wdata),
        .axi_wstrb(axi_wstrb),
        .axi_wready(axi_wready),
        .axi_wusero_id(axi_wusero_id),
        .axi_wusero_last(axi_wusero_last)
    );
endmodule
