`timescale 1ns/1ps

// 单个输出位置的八通道部分和累加器。
// partial_valid=1 时接收 PE 的八个部分和；所有控制标记必须与部分和同拍到达。
// first_group=1 表示当前部分和是该位置的第一组，直接写入以开始新一轮累加。
// last_group=1 表示当前部分和是最后一组，更新后令 result_valid=1。
// first_group 和 last_group 可同时为 1，此时一组部分和就是最终结果。
module psum_accumulator (
    input  wire               clk,
    input  wire               rst_n,
    input  wire               partial_valid,
    input  wire               first_group,
    input  wire               last_group,
    input  wire signed [31:0] partial0,
    input  wire signed [31:0] partial1,
    input  wire signed [31:0] partial2,
    input  wire signed [31:0] partial3,
    input  wire signed [31:0] partial4,
    input  wire signed [31:0] partial5,
    input  wire signed [31:0] partial6,
    input  wire signed [31:0] partial7,
    output wire signed [31:0] accum0,
    output wire signed [31:0] accum1,
    output wire signed [31:0] accum2,
    output wire signed [31:0] accum3,
    output wire signed [31:0] accum4,
    output wire signed [31:0] accum5,
    output wire signed [31:0] accum6,
    output wire signed [31:0] accum7,
    output reg                result_valid
);
    localparam integer PCOUT = 8;

    // 将八个端口映射到数组，方便用同一段逻辑处理各输出通道。
    wire signed [31:0] partial [0:PCOUT-1];
    reg  signed [31:0] accum   [0:PCOUT-1];
    assign partial[0] = partial0;
    assign partial[1] = partial1;
    assign partial[2] = partial2;
    assign partial[3] = partial3;
    assign partial[4] = partial4;
    assign partial[5] = partial5;
    assign partial[6] = partial6;
    assign partial[7] = partial7;
    assign accum0 = accum[0];
    assign accum1 = accum[1];
    assign accum2 = accum[2];
    assign accum3 = accum[3];
    assign accum4 = accum[4];
    assign accum5 = accum[5];
    assign accum6 = accum[6];
    assign accum7 = accum[7];

    integer co;
    always @(posedge clk or negedge rst_n) begin
        if (!rst_n) begin
            result_valid <= 1'b0;
            for (co = 0; co < PCOUT; co = co + 1)
                accum[co] <= 32'sd0;
        end else begin
            // result_valid 与最后一组相加后的 accum 在同一上升沿后生效。
            result_valid <= partial_valid && last_group;
            if (partial_valid) begin
                for (co = 0; co < PCOUT; co = co + 1) begin
                    if (first_group)
                        accum[co] <= partial[co];
                    else
                        accum[co] <= accum[co] + partial[co];
                end
            end
            // 无有效部分和时保留上次累加值。
        end
    end
endmodule
