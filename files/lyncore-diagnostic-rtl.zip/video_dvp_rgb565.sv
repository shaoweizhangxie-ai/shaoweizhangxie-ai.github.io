`timescale 1ns/1ps
// One full 1280x720 frame per common reset. Sensor 0x4300=0x60 requires
// R/B exchange. Keep native RGB565 precision; no image decimation.
module video_dvp_rgb565(
 input wire pclk,rst_n,enable,vsync,href,input wire [7:0] data,
 output reg pixel_valid,output reg [15:0] pixel_data,input wire pixel_ready,
 output reg finished,failed
);
 (* ASYNC_REG="TRUE" *) reg [1:0] reset_sync,enable_sync;
 reg [7:0] d,first;
 reg h,v,old_h,old_v,active;
 reg [11:0] bytes_in_line;
 reg [9:0] lines;
 wire [15:0] raw_pixel={first,d};
 always @(posedge pclk or negedge rst_n)
  if(!rst_n)reset_sync<=0;else reset_sync<={reset_sync[0],1'b1};
 always @(posedge pclk or negedge rst_n)begin
  if(!rst_n)begin
   enable_sync<=0;d<=0;h<=0;v<=1;old_h<=0;old_v<=1;
   first<=0;active<=0;bytes_in_line<=0;lines<=0;
   pixel_valid<=0;pixel_data<=0;finished<=0;failed<=0;
  end else if(!reset_sync[1])begin
   enable_sync<=0;active<=0;pixel_valid<=0;finished<=0;failed<=0;
  end else begin
   enable_sync<={enable_sync[0],enable};
   d<=data;h<=href;v<=vsync;old_h<=h;old_v<=v;
   pixel_valid<=0;
   if(pixel_valid && !pixel_ready)begin failed<=1;active<=0;end
   if(active && !enable_sync[1])begin failed<=1;active<=0;end
   if(!active && !finished && !failed && enable_sync[1] && old_v && !v)begin
    active<=1;bytes_in_line<=0;lines<=0;
   end
   if(active && !failed && enable_sync[1])begin
    if(h && !v)begin
     if(bytes_in_line>=2560 || lines>=720)begin failed<=1;active<=0;end
     else begin
      bytes_in_line<=bytes_in_line+1'b1;
      if(!bytes_in_line[0])first<=d;
      else begin
       pixel_data<={raw_pixel[4:0],raw_pixel[10:5],raw_pixel[15:11]};
       pixel_valid<=1;
      end
     end
    end
    if(old_h && !h)begin
     if(bytes_in_line!=2560)begin failed<=1;active<=0;end
     bytes_in_line<=0;lines<=lines+1'b1;
    end
    if(!old_v && v)begin
     active<=0;
     if(lines==720 && !h && !old_h && bytes_in_line==0)finished<=1;
     else failed<=1;
    end
   end
  end
 end
endmodule
