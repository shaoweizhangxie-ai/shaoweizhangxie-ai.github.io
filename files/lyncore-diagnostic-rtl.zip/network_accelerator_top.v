`timescale 1ns/1ps

// 可综合的小图整网顶层：程序控制 + 执行器 + 八 Slot 缓存 + 三头读出。
// 外部只装原 RGB、响应程序/参数/权重存储事务，并接收最终检测头。
// 当前缓存放完整小图；大图区域/DDR 数据流仍由后续存储适配阶段实现。
module network_accelerator_top #(
    parameter integer MAX_WIDTH=640,
    parameter integer BANK_DEPTH=4096,
    parameter integer PSUM_DEPTH=256,
    parameter integer MAX_CO_GROUPS=128,
    parameter integer MAX_TASKS=256,
    parameter integer PE_LATENCY=7
) (
    input wire clk, rst_n, clear, start,
    input wire [15:0] task_count,
    output wire ready, busy, done, error,
    output wire program_request_valid,
    input wire program_request_ready,
    output wire [15:0] program_request_index,
    input wire program_response_valid,
    output wire program_response_ready,
    input wire [15:0] program_response_index,
    input wire [255:0] program_response_data,
    input wire program_response_error,
    output wire memory_request_valid,
    input wire memory_request_ready,
    output wire [1:0] memory_request_kind,
    output wire [15:0] memory_request_task,
    output wire [31:0] memory_request_address,
    input wire memory_response_valid,
    output wire memory_response_ready,
    input wire [1:0] memory_response_kind,
    input wire [15:0] memory_response_task,
    input wire [31:0] memory_response_address,
    input wire [847:0] memory_response_data,
    input wire memory_response_error,
    // 输入先按八通道缓存字装入 Slot0；RGB 三个 lane，其余补零。
    input wire input_start,
    output wire input_ready,
    input wire [15:0] input_width, input_height, input_channels,
    input wire input_valid,
    output wire input_data_ready,
    input wire [15:0] input_co_group,
    input wire [31:0] input_index,
    input wire [63:0] input_data,
    input wire input_end, input_abort,
    output wire input_busy, input_done, input_error,
    input wire heads_start,
    output wire heads_ready, heads_busy, heads_done, heads_error,
    input wire [8:0] head_slot_bus,
    input wire [47:0] head_width_bus, head_height_bus,
    input wire [15:0] head_channels,
    output wire out_valid,
    input wire out_ready,
    output wire [63:0] out_data,
    output wire [1:0] out_head,
    output wire [15:0] out_co_group,
    output wire [31:0] out_index,
    output wire [7:0] out_lane_mask,
    // 观测端口用于仿真/板上逐层对拍，不参与任务调度。
    output wire task_active,
    output wire [15:0] active_task_index,
    output wire result_valid,
    output wire [15:0] result_co_group,
    output wire [31:0] result_index,
    output wire [63:0] result_data,
    output wire raw_valid,
    output wire [15:0] raw_co_group,
    output wire [31:0] raw_index,
    output wire [255:0] raw_data
);
    wire seq_ready, seq_busy, seq_done, seq_error, seq_cancel, task_valid, task_ready;
    wire [15:0] task_index, completion_index;
    wire [255:0] descriptor;
    wire executor_busy, compute_done, commit_done, executor_error;
    wire [2:0] config_slot, ex_read_slot, ex_write_slot;
    wire ex_read_valid, ex_read_ready, ex_response_ready;
    wire [15:0] ex_read_ci;
    wire [31:0] ex_read_index;
    wire ex_write_start, ex_write_ready, ex_write_valid, ex_write_data_ready, ex_write_end, ex_write_abort;
    wire [15:0] ex_write_width, ex_write_height, ex_write_channels, ex_write_co;
    wire [31:0] ex_write_index;
    wire [63:0] ex_write_data;
    wire [3:0] wr_ready, wr_data_ready, wr_busy, wr_done, wr_error, cfg_valid;
    wire [3:0] rd_ready, rd_valid, rd_bank, rd_error;
    wire [15:0] cfg_width [0:3], cfg_height [0:3], cfg_channels [0:3], rd_ci [0:3];
    wire [31:0] rd_index [0:3], rd_pixel [0:3];
    wire head_ready_internal, head_read_valid, head_response_ready;
    wire [2:0] head_read_slot;
    wire [15:0] head_read_ci;
    wire [31:0] head_read_index;
    reg host_writing, route_pending, route_error;
    reg [2:0] response_owner;
    wire head_owner=heads_busy;
    wire req_valid=head_owner ? head_read_valid : ex_read_valid;
    wire [2:0] req_slot=head_owner ? head_read_slot : ex_read_slot;
    wire [15:0] req_ci=head_owner ? head_read_ci : ex_read_ci;
    wire [31:0] req_index=head_owner ? head_read_index : ex_read_index;
    wire rsp_ready=head_owner ? head_response_ready : ex_response_ready;
    // 缓存地址错误只有 error 脉冲、没有 RAM 响应；转换成可保持的错误响应。
    wire rsp_valid=route_pending && (rd_valid[response_owner[2:1]] || route_error);
    wire rsp_error=route_pending && (route_error || rd_error[response_owner[2:1]]);
    wire [2:0] rsp_slot={response_owner[2:1],rd_bank[response_owner[2:1]]};
    wire request_free=!route_pending || (rsp_valid && rsp_ready);
    wire req_ready=request_free && rd_ready[req_slot[2:1]];
    assign ex_read_ready=req_ready && !head_owner;
    wire [2:0] target_slot=host_writing ? 3'd0 : ex_write_slot;
    assign ex_write_ready=wr_ready[ex_write_slot[2:1]] && !host_writing;
    assign ex_write_data_ready=wr_data_ready[ex_write_slot[2:1]] && !host_writing;
    assign input_ready=rst_n && !clear && !seq_busy && !executor_busy && !heads_busy && !host_writing && !route_pending && wr_ready[0];
    assign input_data_ready=host_writing && wr_data_ready[0] && !clear;
    assign input_busy=host_writing;
    assign input_done=host_writing && wr_done[0];
    assign input_error=host_writing && wr_error[0];
    assign heads_ready=head_ready_internal && !seq_busy && !executor_busy && !host_writing && !route_pending;
    assign ready=seq_ready && !host_writing && !heads_busy && !route_pending && !clear && wr_busy==0;
    assign busy=seq_busy || executor_busy;
    assign done=seq_done;
    assign error=seq_error || executor_error || input_error || heads_error;
    assign task_active=executor_busy;
    assign active_task_index=completion_index;
    assign result_valid=ex_write_valid && ex_write_data_ready;
    assign result_co_group=ex_write_co; assign result_index=ex_write_index; assign result_data=ex_write_data;
    always @(posedge clk or negedge rst_n) begin
        if (!rst_n) begin host_writing<=0; route_pending<=0; response_owner<=0; route_error<=0; end
        else begin
            if (input_start && input_ready) host_writing<=1;
            if (host_writing && (wr_done[0] || wr_error[0] || input_abort || clear)) host_writing<=0;
            if (route_pending && rd_error[response_owner[2:1]]) route_error<=1;
            if (rsp_valid && rsp_ready) begin route_pending<=0; route_error<=0; end
            if (req_valid && req_ready) begin route_pending<=1; response_owner<=req_slot; route_error<=0; end
        end
    end
    genvar pair;
    generate for (pair=0; pair<4; pair=pair+1) begin : g_cache
        feature_map_buffer #(.BANK_DEPTH(BANK_DEPTH)) cache (
            .clk(clk),.rst_n(rst_n),
            .write_start((input_start && input_ready && pair==0) || (ex_write_start && !host_writing && ex_write_slot[2:1]==pair)),
            .write_ready(wr_ready[pair]),.write_bank(host_writing || input_start && input_ready ? 1'b0 : ex_write_slot[0]),
            .write_width(host_writing || input_start && input_ready ? input_width : ex_write_width),
            .write_height(host_writing || input_start && input_ready ? input_height : ex_write_height),
            .write_channels(host_writing || input_start && input_ready ? input_channels : ex_write_channels),
            .write_valid((host_writing ? input_valid && !clear : ex_write_valid) && target_slot[2:1]==pair),
            .write_data_ready(wr_data_ready[pair]),.write_co_group(host_writing ? input_co_group : ex_write_co),
            .write_index(host_writing ? input_index : ex_write_index),.write_data(host_writing ? input_data : ex_write_data),
            .write_end((host_writing ? input_end : ex_write_end) && target_slot[2:1]==pair),
            .write_abort((host_writing ? input_abort || clear || wr_error[0] : ex_write_abort) && target_slot[2:1]==pair),
            .write_busy(wr_busy[pair]),.write_done(wr_done[pair]),.write_error(wr_error[pair]),.bank0_valid(),.bank1_valid(),
            .read_bank(req_valid && req_slot[2:1]==pair ? req_slot[0] : config_slot[0]),
            .read_config_valid(cfg_valid[pair]),.read_width(cfg_width[pair]),.read_height(cfg_height[pair]),
            .read_channels(cfg_channels[pair]),.read_pixels(),
            .read_request_valid(req_valid && request_free && req_slot[2:1]==pair),.read_request_ready(rd_ready[pair]),
            .read_ci_group(req_ci),.read_index(req_index),.read_response_valid(rd_valid[pair]),
            .read_response_ready(route_pending && response_owner[2:1]==pair && rsp_ready),
            .read_response_bank(rd_bank[pair]),.read_response_ci_group(rd_ci[pair]),.read_response_index(rd_index[pair]),
            .read_pixel(rd_pixel[pair]),.read_error(rd_error[pair])
        );
    end endgenerate
    network_sequencer #(.MAX_TASKS(MAX_TASKS),.MAX_SLOTS(8)) sequence_control (
        .clk(clk),.rst_n(rst_n),.clear(clear),.start(start && ready),.task_count(task_count),
        .executor_idle(!executor_busy && !host_writing && !heads_busy && !route_pending),
        .ready(seq_ready),.busy(seq_busy),.done(seq_done),.error(seq_error),.task_cancel(seq_cancel),
        .program_request_valid(program_request_valid),.program_request_ready(program_request_ready),
        .program_request_index(program_request_index),.program_response_valid(program_response_valid),
        .program_response_ready(program_response_ready),.program_response_index(program_response_index),
        .program_response_data(program_response_data),.program_response_error(program_response_error),
        .task_valid(task_valid),.task_ready(task_ready),.task_index(task_index),.task_descriptor(descriptor),
        .compute_done(compute_done),.commit_done(commit_done),.task_error(executor_error),.completion_index(completion_index)
    );
    network_executor #(.MAX_WIDTH(MAX_WIDTH),.PSUM_DEPTH(PSUM_DEPTH),.MAX_CO_GROUPS(MAX_CO_GROUPS),.PE_LATENCY(PE_LATENCY)) executor (
        .clk(clk),.rst_n(rst_n),.cancel(clear || seq_cancel),.task_valid(task_valid),.task_ready(task_ready),
        .task_index(task_index),.task_descriptor(descriptor),.busy(executor_busy),.compute_done(compute_done),
        .commit_done(commit_done),.error(executor_error),.completion_index(completion_index),
        .memory_request_valid(memory_request_valid),.memory_request_ready(memory_request_ready),
        .memory_request_kind(memory_request_kind),.memory_request_task(memory_request_task),.memory_request_address(memory_request_address),
        .memory_response_valid(memory_response_valid),.memory_response_ready(memory_response_ready),
        .memory_response_kind(memory_response_kind),.memory_response_task(memory_response_task),.memory_response_address(memory_response_address),
        .memory_response_data(memory_response_data),.memory_response_error(memory_response_error),
        .source_config_slot(config_slot),.source_config_valid(cfg_valid[config_slot[2:1]]),
        .source_width(cfg_width[config_slot[2:1]]),.source_height(cfg_height[config_slot[2:1]]),.source_channels(cfg_channels[config_slot[2:1]]),
        .read_request_valid(ex_read_valid),.read_request_ready(ex_read_ready),.read_request_slot(ex_read_slot),
        .read_request_ci_group(ex_read_ci),.read_request_index(ex_read_index),.read_response_valid(rsp_valid && !head_owner),
        .read_response_ready(ex_response_ready),.read_response_slot(rsp_slot),.read_response_ci_group(rd_ci[response_owner[2:1]]),
        .read_response_index(rd_index[response_owner[2:1]]),.read_response_pixel(rd_pixel[response_owner[2:1]]),
        .read_response_error(rsp_error),.write_start(ex_write_start),.write_ready(ex_write_ready),
        .write_slot(ex_write_slot),.write_width(ex_write_width),.write_height(ex_write_height),.write_channels(ex_write_channels),
        .write_valid(ex_write_valid),.write_data_ready(ex_write_data_ready),.write_co_group(ex_write_co),.write_index(ex_write_index),
        .write_data(ex_write_data),.write_end(ex_write_end),.write_abort(ex_write_abort),.write_busy(wr_busy[ex_write_slot[2:1]]),
        .write_done(wr_done[ex_write_slot[2:1]]),.write_error(wr_error[ex_write_slot[2:1]]),
        .raw_valid(raw_valid),.raw_co_group(raw_co_group),.raw_index(raw_index),.raw_data(raw_data)
    );
    detect_head_reader #(.MAX_SLOTS(8)) heads (
        .clk(clk),.rst_n(rst_n),.clear(clear),.start(heads_start && heads_ready),.ready(head_ready_internal),
        .head_slot_bus(head_slot_bus),.head_width_bus(head_width_bus),.head_height_bus(head_height_bus),.head_channels(head_channels),
        .busy(heads_busy),.done(heads_done),.error(heads_error),.request_valid(head_read_valid),.request_ready(req_ready && head_owner),
        .request_slot(head_read_slot),.request_ci_group(head_read_ci),.request_index(head_read_index),
        .response_valid(rsp_valid && head_owner),.response_ready(head_response_ready),.response_slot(rsp_slot),
        .response_ci_group(rd_ci[response_owner[2:1]]),.response_index(rd_index[response_owner[2:1]]),
        .response_pixel(rd_pixel[response_owner[2:1]]),.response_error(rsp_error),
        .out_valid(out_valid),.out_ready(out_ready),.out_data(out_data),.out_head(out_head),
        .out_co_group(out_co_group),.out_index(out_index),.out_lane_mask(out_lane_mask)
    );
endmodule
