`timescale 1ns/1ps

// 两路同尺寸 INT8 特征图的残差相加；两侧各有自己的尺度转换系数。
// 输入必须是同一组/同一位置，外部读取器负责配对。内部保存40位转换值，
// 完成相加后才饱和到INT8；支持连续输入、输出反压以及 clear 丢弃未完成事务。
module residual_add (
    input wire clk, rst_n, clear,
    input wire in_valid,
    output wire in_ready,
    input wire [63:0] in_left, in_right,
    input wire [30:0] left_multiplier, right_multiplier,
    input wire [5:0] left_shift, right_shift,
    input wire [15:0] in_co_group,
    input wire [31:0] in_index,
    output wire out_valid,
    input wire out_ready,
    output reg [63:0] out_data,
    output reg [15:0] out_co_group,
    output reg [31:0] out_index
);
    wire scaled_valid;
    wire [639:0] scaled_data;
    wire [47:0] scaled_meta;
    reg result_valid;
    assign out_valid = result_valid && !clear;
    wire result_slot_free = !result_valid || out_ready;
    int8_requant #(.LANES(16), .OUTPUT_WIDTH(40)) scaling (
        .clk(clk), .rst_n(rst_n), .clear(clear), .in_valid(in_valid), .in_ready(in_ready),
        .in_data({in_right, in_left}),
        .in_multiplier({{8{right_multiplier}}, {8{left_multiplier}}}),
        .in_shift({{8{right_shift}}, {8{left_shift}}}),
        .in_meta({in_co_group, in_index}), .out_valid(scaled_valid),
        .out_ready(result_slot_free), .out_data(scaled_data), .out_meta(scaled_meta)
    );
    function [7:0] saturate;
        input signed [40:0] value;
        begin
            if (value > 127) saturate = 8'd127;
            else if (value < -128) saturate = 8'h80;
            else saturate = value[7:0];
        end
    endfunction
    wire [63:0] sum_data;
    genvar lane;
    generate
        for (lane = 0; lane < 8; lane = lane + 1) begin : g_sum
            wire signed [39:0] left_value = scaled_data[lane*40 +: 40];
            wire signed [39:0] right_value = scaled_data[(lane+8)*40 +: 40];
            wire signed [40:0] sum = $signed({left_value[39], left_value}) +
                                     $signed({right_value[39], right_value});
            assign sum_data[lane*8 +: 8] = saturate(sum);
        end
    endgenerate
    always @(posedge clk or negedge rst_n) begin
        if (!rst_n) begin
            result_valid <= 0;
            out_co_group <= 0;
            out_index <= 0;
        end else if (clear) result_valid <= 0;
        else if (result_slot_free) begin
            result_valid <= scaled_valid;
            if (scaled_valid) begin
                out_data <= sum_data;
                out_co_group <= scaled_meta[47:32];
                out_index <= scaled_meta[31:0];
            end
        end
    end
endmodule
