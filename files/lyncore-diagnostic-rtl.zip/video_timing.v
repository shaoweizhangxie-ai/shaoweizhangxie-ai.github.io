`timescale 1ns/1ps
// 视频并行时序；pixel_clk由板级PLL提供，MS7210初始化另行接入。
module video_timing #(
 parameter integer H_ACTIVE=640,H_FRONT=16,H_SYNC=96,H_BACK=48,
 parameter integer V_ACTIVE=480,V_FRONT=10,V_SYNC=2,V_BACK=33,SYNC_POSITIVE=0
)(input wire pixel_clk,rst_n,output wire de,hsync,vsync,frame_start,output wire [15:0] x,y);
 localparam integer HT=H_ACTIVE+H_FRONT+H_SYNC+H_BACK,VT=V_ACTIVE+V_FRONT+V_SYNC+V_BACK;
 reg [15:0] hc,vc;
 assign x=hc;assign y=vc;assign de=rst_n&&hc<H_ACTIVE&&vc<V_ACTIVE;
 assign frame_start=rst_n&&hc==0&&vc==0;
 assign hsync=SYNC_POSITIVE?(hc>=H_ACTIVE+H_FRONT&&hc<H_ACTIVE+H_FRONT+H_SYNC):!(hc>=H_ACTIVE+H_FRONT&&hc<H_ACTIVE+H_FRONT+H_SYNC);
 assign vsync=SYNC_POSITIVE?(vc>=V_ACTIVE+V_FRONT&&vc<V_ACTIVE+V_FRONT+V_SYNC):!(vc>=V_ACTIVE+V_FRONT&&vc<V_ACTIVE+V_FRONT+V_SYNC);
 always @(posedge pixel_clk or negedge rst_n)begin
  if(!rst_n)begin hc<=0;vc<=0;end
  else if(hc==HT-1)begin hc<=0;vc<=vc==VT-1?0:vc+1'b1;end else hc<=hc+1'b1;
 end
endmodule
