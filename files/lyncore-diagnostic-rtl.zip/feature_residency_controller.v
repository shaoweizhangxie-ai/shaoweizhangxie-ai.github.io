`timescale 1ns/1ps
// 单表项写穿透驻留区，最多两个显式消费者。DDR 镜像仍由原 DMA 写入。
// 捕获顺序为 tile -> co_group -> tile 内位置；存储布局为 group8 -> 全局像素。
// RAM 不复位；只有完整捕获且 DDR/Slot 提交成功的 generation 才能被读取。
module feature_residency_controller #(
    parameter integer CACHE_WORDS=6400,MULTI_CONSUMER=0
)(
    input wire clk,rst_n,clear,
    input wire capture_begin,publish,retire,
    input wire [15:0] cfg_producer,cfg_consumer,cfg_generation,
    // 单消费者旧入口保持兼容；MULTI_CONSUMER=0 时忽略以下新增配置及释放输入。
    input wire [15:0] cfg_consumer2,cfg_consumer_count,
    input wire release_valid,release_cancelled,
    input wire [15:0] release_task,release_generation,
    input wire [31:0] cfg_base,
    input wire [15:0] cfg_channels,cfg_height,cfg_width,cfg_tile_rows,
    input wire capture_valid,
    input wire [15:0] capture_co_group,
    input wire [31:0] capture_index,
    input wire [63:0] capture_data,
    input wire consumer_enable,
    input wire [15:0] consumer_task,consumer_generation,
    input wire [31:0] consumer_base,
    input wire [15:0] consumer_channels,consumer_height,consumer_width,
    input wire read_request_valid,
    output wire read_hit,read_request_ready,
    input wire [31:0] read_request_address,
    output reg read_response_valid,
    input wire read_response_ready,
    output reg [31:0] read_response_address,
    output wire [31:0] read_response_data,
    output wire read_response_error,
    output reg entry_valid,capture_complete,capture_fault,
    output reg [15:0] producer_task,consumer_task_id,generation,channels,height,width,
    output reg [31:0] base_address,word_count,captured_words,
    output reg [15:0] consumer_count,remaining_consumers,consumer_task2,
    // bit0/bit1 表示对应已配置消费者尚未释放；不是以整个网络 task_id 为位号。
    output reg [1:0] consumer_bitmap,cancelled_bitmap,
    output reg [2:0] release_state,
    output wire reservation_ready,
    output reg reservation_reject,
    output wire busy
);
    function integer clog2;
        input integer value;
        integer v;
        begin v=value-1;clog2=0;while(v>0)begin clog2=clog2+1;v=v>>1;end
            if(clog2<1)clog2=1;
        end
    endfunction
    localparam integer ADDR_BITS=clog2(CACHE_WORDS);
    localparam FREE=0,RESERVED=1,FILLING=2,PUBLISHED=3,READING=4,RETIRE=5;
    reg [63:0] memory[0:CACHE_WORDS-1];
    reg [63:0] ram_read_data;
    reg response_high,capturing;
    reg [31:0] pixels,tile_base,tile_pixels,local_index,tile_rows,tile_y,current_rows;
    reg [15:0] groups,expected_co;
    wire [63:0] cfg_pixels=64'd1*cfg_height*cfg_width;
    wire [16:0] cfg_groups=({1'b0,cfg_channels}+17'd7)>>3;
    wire [63:0] cfg_words=cfg_pixels*{47'd0,cfg_groups};
    wire [63:0] cfg_end={32'd0,cfg_base}+cfg_words*8;
    wire [15:0] cfg_refs=MULTI_CONSUMER!=0?cfg_consumer_count:16'd1;
    wire cfg_bad=cfg_width==0 || cfg_height==0 || cfg_channels==0 || cfg_tile_rows==0 ||
        cfg_base[2:0]!=0 || cfg_words>64'd1*CACHE_WORDS || cfg_end>64'h100000000 ||
        cfg_refs==0 || cfg_refs>2 || cfg_consumer==cfg_producer ||
        (cfg_refs==2 && (cfg_consumer2==cfg_consumer || cfg_consumer2==cfg_producer));
    wire [31:0] cfg_rows=cfg_height<cfg_tile_rows?{16'd0,cfg_height}:{16'd0,cfg_tile_rows};
    // 直接维护行号，避免为了检查捕获顺序额外推断可变除法器。
    wire [31:0] remaining_rows={16'd0,height}-tile_y-current_rows;
    wire [31:0] next_rows=remaining_rows<tile_rows?remaining_rows:tile_rows;
    wire [31:0] capture_word=capture_co_group*pixels+capture_index;
    assign reservation_ready=release_state==FREE && !read_response_valid && !clear;
    wire reserve=capture_begin && reservation_ready;
    wire accept_capture=capturing && capture_valid && !clear && !reserve;
    wire ordered_capture=capture_co_group==expected_co && capture_index==tile_base+local_index &&
        capture_word<word_count && !capture_complete;
    wire [32:0] byte_offset={1'b0,read_request_address}-{1'b0,base_address};
    wire member=(consumer_bitmap[0] && consumer_task==consumer_task_id) ||
        (consumer_bitmap[1] && consumer_task==consumer_task2);
    wire release0=consumer_bitmap[0] && release_task==consumer_task_id;
    wire release1=consumer_bitmap[1] && release_task==consumer_task2;
    wire release_accept=MULTI_CONSUMER!=0 && release_valid && release_generation==generation &&
        entry_valid && (release0 || release1);
    wire tag_match=entry_valid && consumer_enable && member &&
        consumer_generation==generation && consumer_base==base_address &&
        consumer_channels==channels && consumer_height==height && consumer_width==width;
    assign read_hit=tag_match && !clear && !reserve && !retire &&
        !(release_accept && release_task==consumer_task) &&
        read_request_address[1:0]==0 && !byte_offset[32] && (byte_offset>>3)<{1'b0,word_count};
    assign read_request_ready=read_hit && !read_response_valid;
    assign read_response_data=response_high?ram_read_data[63:32]:ram_read_data[31:0];
    assign read_response_error=1'b0;
    assign busy=read_response_valid;
    // 同步单读单写 RAM；应答反压时数据及地址保持不变。
    always @(posedge clk) begin
        if(accept_capture && ordered_capture)
            memory[capture_word[ADDR_BITS-1:0]]<=capture_data;
        if(read_request_valid && read_request_ready)begin
            ram_read_data<=memory[byte_offset[ADDR_BITS+2:3]];
            response_high<=read_request_address[2];
        end
    end
    always @(posedge clk or negedge rst_n) begin
        if(!rst_n)begin
            entry_valid<=0;capturing<=0;capture_complete<=0;capture_fault<=0;
            producer_task<=0;consumer_task_id<=0;generation<=0;channels<=0;height<=0;width<=1;
            base_address<=0;word_count<=0;captured_words<=0;pixels<=0;groups<=0;
            tile_base<=0;tile_pixels<=0;local_index<=0;tile_rows<=0;tile_y<=0;current_rows<=0;expected_co<=0;
            read_response_valid<=0;read_response_address<=0;
            consumer_count<=0;remaining_consumers<=0;consumer_task2<=0;consumer_bitmap<=0;cancelled_bitmap<=0;
            release_state<=FREE;reservation_reject<=0;
        end else begin
            reservation_reject<=capture_begin && !reservation_ready && !clear;
            if(read_response_valid && read_response_ready)read_response_valid<=0;
            if(read_request_valid && read_request_ready)begin
                read_response_valid<=1;read_response_address<=read_request_address;
            end
            // Clear 禁止新读取，但已接受的应答必须保留至握手，供原 Aux 取消流程排空。
            if(clear || retire)begin
                entry_valid<=0;capturing<=0;capture_complete<=0;
                remaining_consumers<=0;consumer_bitmap<=0;
                release_state<=read_response_valid && !read_response_ready?RETIRE:FREE;
            end else if(reserve)begin
                entry_valid<=0;capturing<=!cfg_bad;capture_complete<=0;capture_fault<=cfg_bad;
                producer_task<=cfg_producer;consumer_task_id<=cfg_consumer;generation<=cfg_generation;
                base_address<=cfg_base;channels<=cfg_channels;height<=cfg_height;width<=cfg_width;
                word_count<=cfg_words[31:0];pixels<=cfg_pixels[31:0];groups<=cfg_groups[15:0];
                captured_words<=0;tile_base<=0;tile_pixels<=cfg_rows*cfg_width;tile_rows<={16'd0,cfg_tile_rows};
                tile_y<=0;current_rows<=cfg_rows;
                expected_co<=0;local_index<=0;
                consumer_count<=cfg_refs;remaining_consumers<=cfg_bad?16'd0:cfg_refs;
                consumer_task2<=MULTI_CONSUMER!=0?cfg_consumer2:16'hffff;
                consumer_bitmap<=cfg_bad?2'b00:(cfg_refs==2?2'b11:2'b01);cancelled_bitmap<=0;
                release_state<=cfg_bad?FREE:RESERVED;
            end else begin
                if(release_state==RESERVED)release_state<=FILLING;
                if(read_request_valid && read_request_ready)release_state<=READING;
                if(release_state==READING && read_response_valid && read_response_ready)
                    release_state<=PUBLISHED;
                if(release_state==RETIRE && (!read_response_valid || read_response_ready))begin
                    release_state<=FREE;capture_complete<=0;
                end
                if(capture_complete && capture_valid)begin
                    capture_fault<=1;entry_valid<=0;
                    remaining_consumers<=0;consumer_bitmap<=0;
                    release_state<=read_response_valid && !read_response_ready?RETIRE:FREE;
                end
                if(accept_capture)begin
                    if(!ordered_capture)begin
                        capture_fault<=1;capturing<=0;entry_valid<=0;
                        remaining_consumers<=0;consumer_bitmap<=0;release_state<=FREE;
                    end
                    else begin
                        captured_words<=captured_words+1;
                        if(captured_words+1==word_count)begin capture_complete<=1;capturing<=0;end
                        if(local_index+1==tile_pixels)begin
                            local_index<=0;
                            if(expected_co+1==groups)begin
                                expected_co<=0;tile_base<=tile_base+tile_pixels;
                                tile_pixels<=next_rows*width;
                                tile_y<=tile_y+current_rows;current_rows<=next_rows;
                            end else expected_co<=expected_co+1;
                        end else local_index<=local_index+1;
                    end
                end
                // publish 由网络层写屏障和 Slot 提交后触发；未完整捕获则回退 DDR。
                if(publish)begin
                    entry_valid<=capture_complete && !capture_fault && !capture_valid && captured_words==word_count;
                    capturing<=0;
                    if(capture_complete && !capture_fault && !capture_valid && captured_words==word_count)
                        release_state<=PUBLISHED;
                    else begin release_state<=FREE;remaining_consumers<=0;consumer_bitmap<=0;end
                end
                // 一次完整消费或取消只释放对应一个引用，重复释放及错误 generation 均忽略。
                if(release_accept)begin
                    remaining_consumers<=remaining_consumers-16'd1;
                    if(release0)begin consumer_bitmap[0]<=0;if(release_cancelled)cancelled_bitmap[0]<=1;end
                    if(release1)begin consumer_bitmap[1]<=0;if(release_cancelled)cancelled_bitmap[1]<=1;end
                    if(remaining_consumers==1)begin
                        entry_valid<=0;release_state<=RETIRE;
                    end
                end
            end
        end
    end
endmodule
