`timescale 1ns/1ps
// 从 DDR 顺序读取 16 个小端 word，组合成一个 512 位任务。
// 仅一笔读取在途；取消后收回原响应，禁止重用错误标签。
module task_descriptor_reader (
    input wire clk,rst_n,clear,request_valid,
    output wire request_ready,
    input wire [31:0] table_base,
    input wire [15:0] request_index,task_count,
    output wire response_valid,
    input wire response_ready,
    output reg [15:0] response_index,
    output wire [511:0] response_descriptor,
    output reg response_error,
    output wire busy,
    output wire read_request_valid,
    input wire read_request_ready,
    output wire [31:0] read_request_address,
    input wire read_response_valid,
    output wire read_response_ready,
    input wire [31:0] read_response_address,read_response_data,
    input wire read_response_error
);
    localparam IDLE=0,REQ=1,WAIT=2,RESP=3,DRAIN=4;
    reg [2:0] state;
    reg [3:0] beat;
    reg [31:0] base,address;
    reg [511:0] payload;
    wire [63:0] end_address={32'd0,table_base}+({48'd0,task_count}<<6);
    assign request_ready=rst_n && !clear && state==IDLE;
    assign response_valid=state==RESP;
    assign response_descriptor=response_error?512'd0:payload;
    assign busy=state!=IDLE;
    assign read_request_valid=state==REQ && !clear;
    assign read_request_address=address;
    assign read_response_ready=state==WAIT || state==DRAIN;
    always @(posedge clk or negedge rst_n) begin
        if(!rst_n) begin state<=IDLE;beat<=0;base<=0;address<=0;payload<=0;response_error<=0;response_index<=0;end
        else begin
            case(state)
                IDLE: if(request_valid && request_ready) begin
                    response_index<=request_index;beat<=0;payload<=0;
                    response_error<=table_base[5:0]!=0 || task_count==0 || request_index>=task_count || end_address>64'h100000000;
                    base<=table_base+({16'd0,request_index}<<6);address<=table_base+({16'd0,request_index}<<6);
                    state<=(table_base[5:0]!=0 || task_count==0 || request_index>=task_count || end_address>64'h100000000)?RESP:REQ;
                end
                REQ: if(read_request_valid && read_request_ready) state<=WAIT;
                WAIT: if(read_response_valid) begin
                    if(read_response_error || read_response_address!=address) begin response_error<=1;state<=RESP;end
                    else begin payload[beat*32+:32]<=read_response_data;
                        if(beat==15) state<=RESP;
                        else begin beat<=beat+1'b1;address<=address+4;state<=REQ;end
                    end
                end
                RESP: if(response_ready) state<=IDLE;
                DRAIN: if(read_response_valid) begin response_error<=1;state<=RESP;end
                default: state<=IDLE;
            endcase
            if(clear && state!=IDLE && state!=RESP && state!=DRAIN) begin
                // WAIT 的 ready 恒为 1；若同拍回包有效，它已经被接收，不能再等一次。
                response_error<=1;state<=(state==WAIT && !read_response_valid)?DRAIN:RESP;
            end
        end
    end
endmodule
