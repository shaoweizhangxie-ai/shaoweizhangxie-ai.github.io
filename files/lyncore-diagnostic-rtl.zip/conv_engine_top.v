`timescale 1ns/1ps

// 可配置的整层 INT32 卷积引擎，固定 PCIN=4、PCOUT=8。
// 累加路径循环：输出通道组 -> 空间 tile -> 输入通道组。
// 可选单输入组路径：每个输出通道组只扫描一帧，PE 结果直接送输出对齐流水。
// 所有计算配置在 layer_start && layer_ready 时锁存，运行期间只使用 cfg_*。
module conv_engine_top #(
    parameter integer MAX_WIDTH = 640,
    parameter integer PSUM_DEPTH = 256,
    parameter integer PSUM_ADDR_WIDTH = address_width(PSUM_DEPTH),
    // 包含输入采样级的 PE 寄存级数：边沿 n 输入，n+PE_LATENCY-1 后输出。
    // 同一参数同时传入 pe_array，并决定下面全部 PE 元数据寄存器的长度。
    parameter integer PE_LATENCY = 10,
    // 默认关闭以保留原入口；开启后仅 cin_groups==1 使用流式旁路。
    // 多输入组仍经过 Psum RAM；运行时旁路不会移除这块物理存储。
    parameter integer SINGLE_GROUP_STREAM = 0,
    // 开启后在帧启动前等待供数确认；不重启 layer、不清除 Psum。
    parameter integer GROUP_INPUT_HANDSHAKE = 0,
    parameter integer K1_WIDE_ENABLE = 0
) (
    input  wire                         clk,
    input  wire                         rst_n,
    input  wire                         layer_start,
    input  wire [15:0]                  frame_width,
    input  wire [15:0]                  frame_height,
    input  wire [15:0]                  cin_groups,
    input  wire [15:0]                  cout_groups,
    input  wire                         kernel_1x1,
    input  wire                         stride_2,
    input  wire                         padding_1,
    output wire                         layer_ready,
    output wire                         layer_busy,
    output wire                         layer_done,
    output reg                          layer_error,
    output wire                         weight_request,
    output wire                         weight_ready,
    input  wire                         weight_valid,
    input  wire [31:0]                  weight_word,
    output wire                         ifm_request,
    output wire                         input_group_request,
    input  wire                         input_group_ready,
    output wire                         ifm_ready,
    input  wire                         ifm_valid,
    input  wire [31:0]                  ifm_pixel,
    input wire k1_wide_mode,
    input wire [255:0] ifm_wide_pixel,
    output wire [15:0]                  current_ci_group,
    output wire [15:0]                  current_co_group,
    output wire [31:0]                  current_tile_base,
    // 仅报告同一空间 tile 内可预测的下一组，不改变计算状态机。
    output wire                         future_weight_valid,
    output wire [15:0]                  future_weight_ci, future_weight_co,
    output wire                         out_valid,
    output wire [15:0]                  out_co_group,
    output wire [31:0]                  out_index,
    output wire signed [31:0]           out0,
    output wire signed [31:0]           out1,
    output wire signed [31:0]           out2,
    output wire signed [31:0]           out3,
    output wire signed [31:0]           out4,
    output wire signed [31:0]           out5,
    output wire signed [31:0]           out6,
    output wire signed [31:0]           out7
);
    // Verilog-2001 常量函数，DEPTH=1 时地址仍占一位。
    function integer address_width;   //这是verilog中的函数功能 也就是说我现在定义了一个叫address_width的函数，这个函数是用来算“要用多少根二进制线才能表示 DEPTH 个地址”的
        input integer depth;
        integer value;
        begin
            value = depth - 1;
            address_width = 0;
            while (value > 0) begin
                address_width = address_width + 1;
                value = value >> 1;
            end
            if (address_width == 0)
                address_width = 1;
        end
    endfunction

    localparam [3:0] S_IDLE        = 4'd0;
    localparam [3:0] S_PREPARE     = 4'd1;
    localparam [3:0] S_LOAD_START  = 4'd2;
    localparam [3:0] S_LOAD_WAIT   = 4'd3;
    localparam [3:0] S_FRAME_START = 4'd4;
    localparam [3:0] S_FRAME_WAIT  = 4'd5;
    localparam [3:0] S_DRAIN       = 4'd6;
    localparam [3:0] S_ADVANCE     = 4'd7;
    localparam [3:0] S_DONE        = 4'd8;
    localparam [31:0] TILE_CAPACITY = PSUM_DEPTH;
    // 每拍最多进入一个窗口；计数表示尚未被 Psum 接收的 PE 事务。
    localparam integer PENDING_WIDTH = address_width(PE_LATENCY + 4);

    reg [3:0] state;
    reg [15:0] cfg_width;
    reg [15:0] cfg_height;
    reg [15:0] cfg_cin_groups;
    reg [15:0] cfg_cout_groups;
    reg cfg_kernel_1x1;
    reg cfg_stride_2;
    reg cfg_padding_1;
    reg cfg_streaming;
    reg cfg_wide;
    reg [15:0] ci_group;
    wire [15:0] block_ci=cfg_wide?{ci_group[15:3],3'b0}:ci_group;
    reg [31:0] cfg_output_positions;
    reg [15:0] co_group;
    reg [31:0] tile_base;
    reg [31:0] tile_size;
    reg [31:0] window_position;

    wire [2303:0] weight_bus;
    wire weight_load_ready;
    wire weight_load_busy;
    wire weight_load_done;
    wire weight_tile_valid;
    reg resident_valid;
    reg [15:0] resident_ci_group;
    reg [15:0] resident_co_group;

    wire window_frame_ready;
    wire window_busy;
    wire window_frame_done;
    wire window_input_ready;
    wire window_valid;
    wire [287:0] window_bus,legacy_window_bus;
    wire legacy_window_ready,legacy_window_busy,legacy_window_done,legacy_window_input_ready,legacy_window_valid;
    reg [1:0] scan_phase;
    always @(posedge clk or negedge rst_n)
        if(!rst_n)scan_phase<=0;else scan_phase<=scan_phase+1'b1;
    wire scan_enable=scan_phase==0;
    wire wide_finish=cfg_wide && state==S_FRAME_WAIT && ifm_valid && window_position+1==cfg_output_positions;
    assign window_frame_ready=cfg_wide?1'b1:legacy_window_ready;
    assign window_busy=cfg_wide?1'b0:legacy_window_busy;
    assign window_frame_done=cfg_wide?wide_finish:legacy_window_done;
    assign window_input_ready=cfg_wide?scan_enable:legacy_window_input_ready;
    assign window_valid=cfg_wide?(state==S_FRAME_WAIT && ifm_valid):legacy_window_valid;
    genvar wc,wk;
    generate for(wc=0;wc<4;wc=wc+1)begin:g_wide_channel
        for(wk=0;wk<9;wk=wk+1)begin:g_position
            if(wk<8)assign window_bus[(wc*9+wk)*8 +:8]=cfg_wide?ifm_wide_pixel[(wc*8+wk)*8 +:8]:legacy_window_bus[(wc*9+wk)*8 +:8];
            else assign window_bus[(wc*9+wk)*8 +:8]=cfg_wide?8'd0:legacy_window_bus[(wc*9+wk)*8 +:8];
        end
    end endgenerate
    wire pe_valid;
    wire signed [31:0] pe0;
    wire signed [31:0] pe1;
    wire signed [31:0] pe2;
    wire signed [31:0] pe3;
    wire signed [31:0] pe4;
    wire signed [31:0] pe5;
    wire signed [31:0] pe6;
    wire signed [31:0] pe7;
    wire psum_busy;
    wire psum_result_valid;
    wire [PSUM_ADDR_WIDTH-1:0] psum_result_addr;
    wire [255:0] psum_result_data;
    reg [PENDING_WIDTH-1:0] pending_pe;

    reg [PE_LATENCY-1:0] meta_valid;
    reg [PE_LATENCY-1:0] meta_first;
    reg [PE_LATENCY-1:0] meta_last;
    reg [PSUM_ADDR_WIDTH-1:0] meta_addr [0:PE_LATENCY-1];
    reg [15:0] meta_co_group [0:PE_LATENCY-1];
    reg [31:0] meta_tile_base [0:PE_LATENCY-1];
    // 流式位置独立于 Psum 地址宽度，整图索引不能截断成局部地址。
    reg [31:0] meta_index [0:PE_LATENCY-1];
    reg [1:0] stream_valid;
    reg [255:0] stream_data [0:1];
    reg [31:0] stream_index [0:1];
    reg [15:0] stream_co_group [0:1];

    // 实时端口只用于启动时检查、计算并锁存配置。
    // Window Generator 的扫描尺寸为 16 位，填充后也必须能被完整表示。
    wire [16:0] start_padded_w =
        {1'b0, frame_width} + (padding_1 ? 17'd2 : 17'd0);
    wire [16:0] start_padded_h =
        {1'b0, frame_height} + (padding_1 ? 17'd2 : 17'd0);
    wire [16:0] start_kernel = kernel_1x1 ? 17'd1 : 17'd3;
    wire [16:0] start_span_w = start_padded_w - start_kernel;
    wire [16:0] start_span_h = start_padded_h - start_kernel;
    wire [16:0] start_out_w =
        (stride_2 ? (start_span_w >> 1) : start_span_w) + 17'd1;
    wire [16:0] start_out_h =
        (stride_2 ? (start_span_h >> 1) : start_span_h) + 17'd1;
    wire [31:0] start_positions =
        {16'd0, start_out_w[15:0]} * {16'd0, start_out_h[15:0]};
    wire start_streaming = (SINGLE_GROUP_STREAM != 0) && (cin_groups == 16'd1);
    wire bad_start_config =
        (frame_width == 0) || (frame_height == 0) ||
        (frame_width > MAX_WIDTH) ||
        (cin_groups == 0) || (cout_groups == 0) ||
        (start_padded_w > 17'd65535) ||
        (start_padded_h > 17'd65535) ||
        (start_padded_w < start_kernel) ||
        (start_padded_h < start_kernel) ||
        (start_out_w == 0) || (start_out_h == 0) ||
        (start_out_w > 17'd65535) || (start_out_h > 17'd65535);

    // 半开区间 [tile_base,tile_limit)，末尾 tile_size 可小于 PSUM_DEPTH。
    // tile_limit 始终不超过 cfg_output_positions，地址不会访问未存在的位置。
    wire [31:0] tile_limit = tile_base + tile_size;
    assign future_weight_valid=((state==S_FRAME_WAIT) || (state==S_DRAIN)) &&
        ((ci_group+16'd1<cfg_cin_groups) ||
         (tile_limit==cfg_output_positions && co_group+16'd1<cfg_cout_groups));
    assign future_weight_ci=ci_group+16'd1<cfg_cin_groups?ci_group+16'd1:16'd0;
    assign future_weight_co=ci_group+16'd1<cfg_cin_groups?co_group:co_group+16'd1;
    wire replay_active = (state == S_FRAME_WAIT) || (state == S_DRAIN);
    wire selected_window =
        replay_active && window_valid && weight_tile_valid &&
        (window_position >= tile_base) &&
        (window_position < tile_limit) &&
        (window_position < cfg_output_positions);
    // 单输入组不访问 Psum，本地地址固定零，全局坐标走 meta_index。
    wire [31:0] local_offset = cfg_streaming ? 32'd0 : window_position - tile_base;
    wire [PSUM_ADDR_WIDTH-1:0] local_addr = local_offset;

    // 一层开始时使 resident_valid 失效，确保新层参数不会复用上一层权重。
    // 同一层内，仅当 co/ci 均匹配时复用当前实际驻留的权重。
    wire resident_match =
        !cfg_wide && resident_valid && weight_tile_valid &&
        (resident_ci_group == ci_group) &&
        (resident_co_group == co_group);

    assign layer_ready = (state == S_IDLE);
    assign layer_busy = (state != S_IDLE) && (state != S_DONE);
    assign layer_done = (state == S_DONE);
    assign current_ci_group = ci_group;
    assign current_co_group = co_group;
    assign current_tile_base = tile_base;

    // request 是一个开始事件，word/pixel 只在各自 valid && ready 时接收。
    // 空闲、换组和排空时不向外部开放数据接收，也不推进输入源坐标。
    assign weight_request = (state == S_LOAD_START) && !weight_load_busy;
    assign weight_ready = (state == S_LOAD_WAIT) && weight_load_ready;
    // request 为持续请求，ci/co/tile 在等待期间稳定。上一组经过 S_DRAIN
    // 的真实 pipeline_empty 检查后才会到此；供数方可安全更换输入缓存。
    // ready 确认缓存已提交；ifm_request 仍是开始读取帧的单拍事件。
    assign input_group_request = (GROUP_INPUT_HANDSHAKE != 0) &&
                                 (state == S_FRAME_START) && window_frame_ready;
    wire input_group_granted = (GROUP_INPUT_HANDSHAKE == 0) || input_group_ready;
    assign ifm_request = (state == S_FRAME_START) && window_frame_ready && input_group_granted;
    assign ifm_ready = (state == S_FRAME_WAIT) && window_input_ready;

    // PE 在途计数 + 元数据有效位 + Window/Psum 的实际忙碌状态。
    // result_valid 也必须清空，确保最后一笔输出已经展示后才换组或完成。
    wire pipeline_empty =
        (pending_pe == 0) && !(|meta_valid) && !pe_valid &&
        !psum_busy && !psum_result_valid &&
        !(|stream_valid) &&
        !window_busy && !window_valid;

    // 调度只在 S_ADVANCE 修改 co/ci/tile，进入此状态前已确认整条流水排空。
    // 累加模式每个 tile/ci 重放整帧；流式模式 tile_size 为整图位置数。
    // 后续 tile-aware 输入可替换 S_FRAME_START/WAIT 与窗口选择部分。
    always @(posedge clk or negedge rst_n) begin
        if (!rst_n) begin
            state <= S_IDLE;
            cfg_width <= 16'd0;
            cfg_height <= 16'd0;
            cfg_cin_groups <= 16'd0;
            cfg_cout_groups <= 16'd0;
            cfg_kernel_1x1 <= 1'b0;
            cfg_stride_2 <= 1'b0;
            cfg_padding_1 <= 1'b0;
            cfg_streaming <= 1'b0;
            cfg_wide <= 1'b0;
            cfg_output_positions <= 32'd0;
            ci_group <= 16'd0;
            co_group <= 16'd0;
            tile_base <= 32'd0;
            tile_size <= 32'd0;
            layer_error <= 1'b0;
        end else begin
            layer_error <= 1'b0;
            case (state)
                S_IDLE: begin
                    if (layer_start) begin
                        if (bad_start_config) begin
                            layer_error <= 1'b1;
                        end else begin
                            cfg_width <= frame_width;
                            cfg_height <= frame_height;
                            cfg_cin_groups <= cin_groups;
                            cfg_cout_groups <= cout_groups;
                            cfg_kernel_1x1 <= kernel_1x1;
                            cfg_stride_2 <= stride_2;
                            cfg_padding_1 <= padding_1;
                            cfg_streaming <= start_streaming;
                            cfg_wide <= K1_WIDE_ENABLE!=0 && k1_wide_mode && kernel_1x1 && !stride_2 && !padding_1;
                            cfg_output_positions <= start_positions;
                            ci_group <= 16'd0;
                            co_group <= 16'd0;
                            tile_base <= 32'd0;
                            tile_size <= start_streaming ? start_positions :
                                         (start_positions < TILE_CAPACITY) ?
                                         start_positions : TILE_CAPACITY;
                            state <= S_PREPARE;
                        end
                    end
                end
                S_PREPARE: begin
                    if (resident_match)
                        state <= S_FRAME_START;
                    else
                        state <= S_LOAD_START;
                end
                S_LOAD_START: begin
                    if (!weight_load_busy)
                        state <= S_LOAD_WAIT;
                end
                S_LOAD_WAIT: begin
                    // 使用本次装载完成事件，避免把旧 tile_valid 当成新权重。
                    if (weight_load_done) begin
                        if(cfg_wide && ci_group[2:0]!=7 && ci_group+1<cfg_cin_groups)begin
                            ci_group<=ci_group+1;state<=S_LOAD_START;
                        end else state <= S_FRAME_START;
                    end
                end
                S_FRAME_START: begin
                    if (window_frame_ready && input_group_granted)
                        state <= S_FRAME_WAIT;
                end
                S_FRAME_WAIT: begin
                    if (window_frame_done)
                        state <= S_DRAIN;
                end
                S_DRAIN: begin
                    if (pipeline_empty)
                        state <= S_ADVANCE;
                end
                S_ADVANCE: begin
                    if (block_ci+(cfg_wide?16'd8:16'd1) < cfg_cin_groups) begin
                        ci_group <= block_ci+(cfg_wide?16'd8:16'd1);
                        state <= S_PREPARE;
                    end else begin
                        ci_group <= 16'd0;
                        if (tile_limit < cfg_output_positions) begin
                            tile_base <= tile_limit;
                            tile_size <=
                                (cfg_output_positions - tile_limit < TILE_CAPACITY) ?
                                (cfg_output_positions - tile_limit) : TILE_CAPACITY;
                            state <= S_PREPARE;
                        end else if (co_group < cfg_cout_groups - 16'd1) begin
                            co_group <= co_group + 16'd1;
                            tile_base <= 32'd0;
                            tile_size <= cfg_streaming ? cfg_output_positions :
                                         (cfg_output_positions < TILE_CAPACITY) ?
                                         cfg_output_positions : TILE_CAPACITY;
                            state <= S_PREPARE;
                        end else begin
                            state <= S_DONE;
                        end
                    end
                end
                S_DONE: state <= S_IDLE;
                default: state <= S_IDLE;
            endcase
        end
    end

    // 单 tile 权重标签：Cin_groups=1 时，同一 co 的空间 tile 可以直接复用。
    // 多 Cin 组时，末组权重已覆盖首组，因此新 tile 仍需要重新装载。
    // 扩大缓存保存多个 ci 的权重，是后续 weight-cache 的明确优化点。
    always @(posedge clk or negedge rst_n) begin
        if (!rst_n) begin
            resident_valid <= 1'b0;
            resident_ci_group <= 16'd0;
            resident_co_group <= 16'd0;
        end else begin
            if (layer_start && layer_ready && !bad_start_config)
                resident_valid <= 1'b0;
            if (weight_request)
                resident_valid <= 1'b0;
            if (weight_load_done) begin
                resident_valid <= 1'b1;
                resident_ci_group <= ci_group;
                resident_co_group <= co_group;
            end
        end
    end

    weight_buffer #(.PCIN(4), .PCOUT(8),.K1_WIDE_ENABLE(K1_WIDE_ENABLE)) u_weight_buffer (
        .clk(clk), .rst_n(rst_n),
        .load_start(weight_request), .wide_mode(cfg_wide),.wide_subgroup(ci_group[2:0]),.kernel_1x1(cfg_kernel_1x1),
        .load_valid(weight_valid && (state == S_LOAD_WAIT)),
        .load_ready(weight_load_ready), .load_word(weight_word),
        .load_busy(weight_load_busy), .load_done(weight_load_done),
        .tile_valid(weight_tile_valid), .weight_bus(weight_bus)
    );

    window_generator #(.MAX_WIDTH(MAX_WIDTH),.SCAN_THROTTLE(1)) u_window_generator (
        .clk(clk), .rst_n(rst_n), .frame_start(ifm_request && !cfg_wide),
        .frame_width(cfg_width), .frame_height(cfg_height),
        .kernel_1x1(cfg_kernel_1x1), .stride_2(cfg_stride_2), .padding_1(cfg_padding_1),
        .frame_ready(legacy_window_ready), .busy(legacy_window_busy), .frame_done(legacy_window_done),
        .in_valid(ifm_valid && (state == S_FRAME_WAIT) && !cfg_wide),
        .in_ready(legacy_window_input_ready), .in_pixel(ifm_pixel),.scan_enable(scan_enable),
        .out_valid(legacy_window_valid), .out_x(), .out_y(), .out_window(legacy_window_bus)
    );

    // 此计数只数窗口输出，源端坐标由 Window 的 valid/ready 握手推进。
    // 窗口在当前 tile 之外仍被扫描；未来优化重放时只需改此筛选边界。
    always @(posedge clk or negedge rst_n) begin
        if (!rst_n)
            window_position <= 32'd0;
        else if (ifm_request)
            window_position <= 32'd0;
        else if (replay_active && window_valid)
            window_position <= window_position + 32'd1;
    end

    pe_array #(.PE_LATENCY(PE_LATENCY)) u_pe (
        .clk(clk), .rst_n(rst_n), .in_valid(selected_window),
        .window_bus(window_bus), .weight_bus(weight_bus),
        .psum0(pe0), .psum1(pe1), .psum2(pe2), .psum3(pe3),
        .psum4(pe4), .psum5(pe5), .psum6(pe6), .psum7(pe7),
        .out_valid(pe_valid)
    );

    // 每笔事务独立携带 co/tile，输出标签不再读取未经流水延迟的当前计数器。
    // valid、地址、首尾标记、co、tile 全部共用 PE_LATENCY。
    integer meta_stage;
    always @(posedge clk or negedge rst_n) begin
        if (!rst_n) begin
            meta_valid <= {PE_LATENCY{1'b0}};
            meta_first <= {PE_LATENCY{1'b0}};
            meta_last <= {PE_LATENCY{1'b0}};
            for (meta_stage = 0; meta_stage < PE_LATENCY; meta_stage = meta_stage + 1) begin
                meta_addr[meta_stage] <= {PSUM_ADDR_WIDTH{1'b0}};
                meta_co_group[meta_stage] <= 16'd0;
                meta_tile_base[meta_stage] <= 32'd0;
                meta_index[meta_stage] <= 32'd0;
            end
        end else begin
            meta_valid[0] <= selected_window;
            meta_first[0] <= selected_window && (block_ci == 0);
            meta_last[0] <= selected_window && (block_ci+(cfg_wide?16'd8:16'd1)>=cfg_cin_groups);
            if (selected_window) begin
                meta_addr[0] <= local_addr;
                meta_co_group[0] <= co_group;
                meta_tile_base[0] <= tile_base;
                meta_index[0] <= window_position;
            end
            for (meta_stage = 1; meta_stage < PE_LATENCY; meta_stage = meta_stage + 1) begin
                meta_valid[meta_stage] <= meta_valid[meta_stage-1];
                meta_first[meta_stage] <= meta_first[meta_stage-1];
                meta_last[meta_stage] <= meta_last[meta_stage-1];
                if (meta_valid[meta_stage-1]) begin
                    meta_addr[meta_stage] <= meta_addr[meta_stage-1];
                    meta_co_group[meta_stage] <= meta_co_group[meta_stage-1];
                    meta_tile_base[meta_stage] <= meta_tile_base[meta_stage-1];
                    meta_index[meta_stage] <= meta_index[meta_stage-1];
                end
            end
        end
    end

    always @(posedge clk or negedge rst_n) begin
        if (!rst_n)
            pending_pe <= {PENDING_WIDTH{1'b0}};
        else begin
            case ({selected_window, pe_valid})
                2'b10: pending_pe <= pending_pe + 1'b1;
                2'b01: pending_pe <= pending_pe - 1'b1;
                default: pending_pe <= pending_pe;
            endcase
        end
    end

    psum_buffer #(.ADDR_WIDTH(PSUM_ADDR_WIDTH), .DEPTH(PSUM_DEPTH)) u_psum_buffer (
        .clk(clk), .rst_n(rst_n), .partial_valid(pe_valid && !cfg_streaming),
        .first_group(meta_first[PE_LATENCY-1]),
        .last_group(meta_last[PE_LATENCY-1]),
        .partial_addr(meta_addr[PE_LATENCY-1]),
        .partial0(pe0), .partial1(pe1), .partial2(pe2), .partial3(pe3),
        .partial4(pe4), .partial5(pe5), .partial6(pe6), .partial7(pe7),
        .result_valid(psum_result_valid), .result_addr(psum_result_addr),
        .result0(psum_result_data[0 +: 32]), .result1(psum_result_data[32 +: 32]),
        .result2(psum_result_data[64 +: 32]), .result3(psum_result_data[96 +: 32]),
        .result4(psum_result_data[128 +: 32]), .result5(psum_result_data[160 +: 32]),
        .result6(psum_result_data[192 +: 32]), .result7(psum_result_data[224 +: 32]),
        .busy(psum_busy)
    );

    // Psum 第一级接收部分和并同步读 RAM，第二级在 busy=1 的边沿写回。
    // 标签分别在实际接收、实际写回边沿更新，与 result_valid/result_addr 同拍。
    reg [15:0] psum_read_co_group;
    reg [31:0] psum_read_tile_base;
    reg [15:0] result_co_group;
    reg [31:0] result_tile_base;
    always @(posedge clk or negedge rst_n) begin
        if (!rst_n) begin
            psum_read_co_group <= 16'd0;
            psum_read_tile_base <= 32'd0;
            result_co_group <= 16'd0;
            result_tile_base <= 32'd0;
        end else begin
            if (pe_valid) begin
                psum_read_co_group <= meta_co_group[PE_LATENCY-1];
                psum_read_tile_base <= meta_tile_base[PE_LATENCY-1];
            end
            if (psum_busy) begin
                result_co_group <= psum_read_co_group;
                result_tile_base <= psum_read_tile_base;
            end
        end
    end
    // PE 单输入组结果已包含全部贡献；两级对齐寄存器保留原 Psum 的输出延迟。
    // 输入边沿 n -> INT32 n+PE_LATENCY+1，数据、co、位置和 valid 同步推进。
    // 排空包含这两级，复位时丢弃在途事务。
    integer stream_stage;
    always @(posedge clk or negedge rst_n) begin
        if (!rst_n) begin
            stream_valid <= 2'b0;
            for (stream_stage=0; stream_stage<2; stream_stage=stream_stage+1) begin
                stream_data[stream_stage] <= 256'd0;
                stream_index[stream_stage] <= 32'd0;
                stream_co_group[stream_stage] <= 16'd0;
            end
        end else begin
            stream_valid <= {stream_valid[0], pe_valid && cfg_streaming};
            if (pe_valid && cfg_streaming) begin
                stream_data[0] <= {pe7,pe6,pe5,pe4,pe3,pe2,pe1,pe0};
                stream_index[0] <= meta_index[PE_LATENCY-1];
                stream_co_group[0] <= meta_co_group[PE_LATENCY-1];
            end
            if (stream_valid[0]) begin
                stream_data[1] <= stream_data[0];
                stream_index[1] <= stream_index[0];
                stream_co_group[1] <= stream_co_group[0];
            end
        end
    end
    assign out_valid = cfg_streaming ? stream_valid[1] : psum_result_valid;
    assign out_co_group = cfg_streaming ? stream_co_group[1] : result_co_group;
    assign out_index = cfg_streaming ? stream_index[1] : result_tile_base + psum_result_addr;
    wire [255:0] output_data = cfg_streaming ? stream_data[1] : psum_result_data;
    assign out0 = output_data[0 +: 32];
    assign out1 = output_data[32 +: 32];
    assign out2 = output_data[64 +: 32];
    assign out3 = output_data[96 +: 32];
    assign out4 = output_data[128 +: 32];
    assign out5 = output_data[160 +: 32];
    assign out6 = output_data[192 +: 32];
    assign out7 = output_data[224 +: 32];

    // synthesis translate_off
    initial begin
        if (PSUM_DEPTH < 1 || PSUM_ADDR_WIDTH < address_width(PSUM_DEPTH) ||
            MAX_WIDTH < 1 || MAX_WIDTH > 65535 || PE_LATENCY < 7) begin
            $display("ERROR: invalid conv_engine_top elaboration parameters");
            $finish;
        end
    end
    // synthesis translate_on
endmodule
