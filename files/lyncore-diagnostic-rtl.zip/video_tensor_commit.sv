`timescale 1ns/1ps
// Fixed slot0. Publish only after all 819200 bytes, FENCE and CRC readback.
// The caller holds exclusive DDR ownership and the input lease until release.
// Any transfer/producer fault is fail-stop until a common pipeline reset.
module video_tensor_commit(
 input wire clk,rst_n,start,slot_available,release_frame,ddr_ready,bridge_busy,bridge_fault,producer_failed,
 input wire [31:0] frame_id,
 output wire ready,busy,verify_active,
 output reg committed,failed,output reg [31:0] committed_frame_id,verified_bytes,
 output wire [31:0] tensor_crc32,
 input wire in_valid,output wire in_ready,input wire [63:0] in_data,
 input wire [31:0] in_index,in_frame_id,input wire in_last,
 output wire write_request_valid,input wire write_request_ready,
 output wire [31:0] write_request_address,write_request_data,output wire [3:0] write_request_strobe,
 input wire write_response_valid,output wire write_response_ready,
 input wire [31:0] write_response_address,input wire write_response_error,
 output wire read_request_valid,input wire read_request_ready,output wire [31:0] read_request_address,
 input wire read_response_valid,output wire read_response_ready,
 input wire [31:0] read_response_address,read_response_data,input wire read_response_error
);
 localparam [31:0] BASE=32'h20400000;
 localparam [3:0] IDLE=0,TAKE=1,CRC_WRITE=2,WRITE_LO=3,REPLY_LO=4,WRITE_HI=5,REPLY_HI=6,
  FENCE=7,FENCE_REPLY=8,DRAIN=9,READ=10,READ_REPLY=11,CRC_READ=12,FAULT=13;
 reg [3:0] state;
 reg [16:0] index;
 reg [17:0] read_index;
 reg [2:0] byte_index;
 reg [63:0] word_data;
 reg [31:0] read_word,write_crc,read_crc;
 function automatic [31:0] crc_byte(input [31:0] old_crc,input [7:0] data);
  reg [31:0] c;
  begin
   c=old_crc^{24'd0,data};
   for(integer n=0;n<8;n++)c=c[0]?(c>>1)^32'hedb88320:c>>1;
   crc_byte=c;
  end
 endfunction
 wire [31:0] next_read_crc=crc_byte(read_crc,read_word[byte_index*8+:8]);
 assign ready=rst_n && state==IDLE && !committed && !failed && slot_available && ddr_ready && !bridge_fault;
 assign busy=state!=IDLE && state!=FAULT;
 assign verify_active=state==READ || state==READ_REPLY || state==CRC_READ;
 assign tensor_crc32=~write_crc;
 assign in_ready=rst_n && state==TAKE && !failed;
 assign write_request_valid=rst_n && (state==WRITE_LO || state==WRITE_HI || state==FENCE);
 assign write_request_address=state==FENCE?BASE:BASE+{12'd0,index,3'b000}+(state==WRITE_HI || state==REPLY_HI?32'd4:32'd0);
 assign write_request_data=state==WRITE_HI || state==REPLY_HI?word_data[63:32]:word_data[31:0];
 assign write_request_strobe=state==FENCE?4'd0:4'hf;
 assign write_response_ready=state==REPLY_LO || state==REPLY_HI || state==FENCE_REPLY;
 assign read_request_valid=rst_n && state==READ;
 assign read_request_address=BASE+{12'd0,read_index,2'b00};
 assign read_response_ready=state==READ_REPLY;
 always @(posedge clk or negedge rst_n)begin
  if(!rst_n)begin
   state<=IDLE;index<=0;read_index<=0;byte_index<=0;word_data<=0;read_word<=0;
   write_crc<=32'hffffffff;read_crc<=32'hffffffff;
   committed<=0;failed<=0;committed_frame_id<=0;verified_bytes<=0;
  end else if(bridge_fault || (busy && (!ddr_ready || producer_failed)))begin
   failed<=1;committed<=0;state<=FAULT;
  end else case(state)
   IDLE:begin
    if(release_frame)committed<=0;
    if(start && ready)begin
     index<=0;read_index<=0;verified_bytes<=0;committed_frame_id<=frame_id;
     write_crc<=32'hffffffff;read_crc<=32'hffffffff;state<=TAKE;
    end
   end
   TAKE:if(in_valid)begin
    if(in_index!={15'd0,index} || in_frame_id!=committed_frame_id ||
      in_last!=(index==102399) || in_data[63:24]!=0)begin failed<=1;state<=FAULT;end
    else begin word_data<=in_data;byte_index<=0;state<=CRC_WRITE;end
   end
   CRC_WRITE:begin
    write_crc<=crc_byte(write_crc,word_data[byte_index*8+:8]);
    if(byte_index==7)state<=WRITE_LO;else byte_index<=byte_index+1'b1;
   end
   WRITE_LO:if(write_request_ready)state<=REPLY_LO;
   WRITE_HI:if(write_request_ready)state<=REPLY_HI;
   REPLY_LO,REPLY_HI:if(write_response_valid)begin
    if(write_response_error || write_response_address!=write_request_address)begin failed<=1;state<=FAULT;end
    else if(state==REPLY_LO)state<=WRITE_HI;
    else if(index==102399)state<=FENCE;
    else begin index<=index+1'b1;state<=TAKE;end
   end
   FENCE:if(write_request_ready)state<=FENCE_REPLY;
   FENCE_REPLY:if(write_response_valid)begin
    if(write_response_error || write_response_address!=BASE)begin failed<=1;state<=FAULT;end
    else state<=DRAIN;
   end
   DRAIN:if(!bridge_busy)state<=READ;
   READ:if(read_request_ready)state<=READ_REPLY;
   READ_REPLY:if(read_response_valid)begin
    if(read_response_error || read_response_address!=read_request_address)begin failed<=1;state<=FAULT;end
    else begin read_word<=read_response_data;byte_index<=0;state<=CRC_READ;end
   end
   CRC_READ:begin
    read_crc<=next_read_crc;
    if(byte_index==3)begin
     verified_bytes<=verified_bytes+32'd4;
     if(read_index==204799)begin
      if(next_read_crc!=write_crc)begin failed<=1;state<=FAULT;end
      else begin committed<=1;state<=IDLE;end
     end else begin read_index<=read_index+1'b1;state<=READ;end
    end else byte_index<=byte_index+1'b1;
   end
   default:begin end
  endcase
 end
endmodule
