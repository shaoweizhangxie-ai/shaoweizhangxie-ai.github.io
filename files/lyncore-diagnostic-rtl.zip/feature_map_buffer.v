`timescale 1ns/1ps

// 两个独立 Bank：前一层只读一个 Bank，当前层向另一个 Bank 顺序写入。
// 写入排列与 Conv 输出相同：co_group -> 空间位置，每个字包含八个 INT8。
// 读取返回四个 INT8：偶数 ci_group 取低半字，奇数 ci_group 取高半字。
// 完整且按序写完后才能提交；RAM 不复位，复位只清除有效标记和控制状态。
module feature_map_buffer #(
    parameter integer BANK_DEPTH = 4096,
    parameter integer ADDR_WIDTH = address_width(BANK_DEPTH)  //它的作用相当于一个log
) (
    input  wire clk,
    input  wire rst_n,
    input  wire write_start,
    output wire write_ready,
    input  wire write_bank,
    input  wire [15:0] write_width,
    input  wire [15:0] write_height,
    input  wire [15:0] write_channels,
    input  wire write_valid,
    output wire write_data_ready,
    input  wire [15:0] write_co_group,
    input  wire [31:0] write_index,
    input  wire [63:0] write_data,
    input  wire write_end,
    input  wire write_abort,
    output wire write_busy,
    output reg  write_done,
    output reg  write_error,
    output wire bank0_valid,
    output wire bank1_valid,
    // read_bank 同时选择下面的帧配置和请求目标。
    input  wire read_bank,
    output wire read_config_valid,
    output wire [15:0] read_width,
    output wire [15:0] read_height,
    output wire [15:0] read_channels,
    output wire [31:0] read_pixels,
    input  wire read_request_valid,
    output wire read_request_ready,
    input  wire [15:0] read_ci_group,
    input  wire [31:0] read_index,
    output reg  read_response_valid,
    input  wire read_response_ready,
    output reg  read_response_bank,
    output reg  [15:0] read_response_ci_group,
    output reg  [31:0] read_response_index,
    output wire [31:0] read_pixel,
    output reg  read_error
);
    function integer address_width;
        input integer depth;
        integer value;
        begin
            value = depth - 1;
            address_width = 0;
            while (value > 0) begin
                address_width = address_width + 1;
                value = value >> 1;
            end
            if (address_width == 0) address_width = 1;
        end
    endfunction

    reg [63:0] bank0_mem [0:BANK_DEPTH-1];
    reg [63:0] bank1_mem [0:BANK_DEPTH-1];
    reg [1:0] bank_valid;
    reg [15:0] bank_width [0:1];
    reg [15:0] bank_height [0:1];
    reg [15:0] bank_channels [0:1];
    reg [31:0] bank_pixels [0:1];
    reg writing;
    reg target_bank;
    reg write_fault;
    reg [31:0] cfg_pixels;
    reg [31:0] cfg_words;
    reg [31:0] word_count;
    reg [15:0] expected_co;
    reg [31:0] expected_index;

    reg [1:0] config_phase;
    reg config_bank, config_zero;
    reg [15:0] config_width, config_height, config_channels;
    reg [31:0] config_pixels;
    reg [16:0] config_groups;
    reg [47:0] config_words;
    wire [31:0] start_pixels = {16'd0, write_width} * {16'd0, write_height};
    wire [16:0] start_groups = ({1'b0, write_channels} + 17'd7) >> 3;
    wire bad_write_config = config_zero || (config_words > BANK_DEPTH);
    assign write_ready = !writing && config_phase == 0;
    assign write_busy = writing || config_phase != 0;
    // Configuration is admitted first; data-ready follows validated capacity.
    assign write_data_ready = writing && !write_fault && !write_abort;
    wire write_accept = write_valid && write_data_ready;
    wire bad_write_order = (word_count >= cfg_words) ||
                           (write_co_group != expected_co) ||
                           (write_index != expected_index);
    wire write_store = write_accept && !bad_write_order;
    wire write_complete = (word_count == cfg_words) ||
                          (write_store && word_count == cfg_words - 32'd1);
    wire [ADDR_WIDTH-1:0] write_addr = word_count;
    assign bank0_valid = bank_valid[0];
    assign bank1_valid = bank_valid[1];
    assign read_config_valid = bank_valid[read_bank];
    assign read_width = bank_width[read_bank];
    assign read_height = bank_height[read_bank];
    assign read_channels = bank_channels[read_bank];
    assign read_pixels = bank_pixels[read_bank];

    // 偶/奇四通道组分别读取同一个八通道字的低/高半字。
    wire [16:0] read_groups = ({1'b0, read_channels} + 17'd3) >> 2;
    wire [47:0] read_addr_full =
        {32'd0, (read_ci_group >> 1)} * {16'd0, read_pixels} + {16'd0, read_index};
    wire [ADDR_WIDTH-1:0] read_addr = read_addr_full;
    wire bad_read_address = (read_index >= read_pixels) ||
                            ({1'b0, read_ci_group} >= read_groups);
    wire response_slot_free = !read_response_valid || read_response_ready;
    // 正在重写或本拍即将重写的 Bank 不接受读请求；另一 Bank 可同时读写。
    assign read_request_ready = response_slot_free && read_config_valid &&
        !(writing && target_bank == read_bank) &&
        !(config_phase != 0 && config_bank == read_bank) &&
        !(write_start && write_ready && write_bank == read_bank);
    wire read_accept = read_request_valid && read_request_ready;
    wire read_fetch = read_accept && !bad_read_address;
    reg read_upper_half;
    reg [3:0] read_lane_mask;
    reg [63:0] bank0_read_word;
    reg [63:0] bank1_read_word;
    wire [63:0] response_word = read_response_bank ? bank1_read_word : bank0_read_word;
    wire [31:0] response_half = read_upper_half ? response_word[63:32] : response_word[31:0];
    genvar lane;
    generate
        for (lane = 0; lane < 4; lane = lane + 1) begin : g_lane_mask
            assign read_pixel[lane*8 +: 8] =
                read_lane_mask[lane] ? response_half[lane*8 +: 8] : 8'd0;
        end
    endgenerate

    // 显式同步 RAM 读写。两个读数据寄存器不复位，valid 控制是否可使用。
    always @(posedge clk) begin
        if (write_store && !target_bank) bank0_mem[write_addr] <= write_data;
        if (write_store && target_bank) bank1_mem[write_addr] <= write_data;
        // Bounds errors still suppress response valid. The RAM read itself has no side effects.
        if (read_accept && !read_bank) bank0_read_word <= bank0_mem[read_addr];
        if (read_accept && read_bank) bank1_read_word <= bank1_mem[read_addr];
    end

    integer bank;
    always @(posedge clk or negedge rst_n) begin
        if (!rst_n) begin
            bank_valid <= 2'b00;
            writing <= 1'b0;
            config_phase <= 0;
            config_bank <= 0; config_zero <= 0;
            config_width <= 0; config_height <= 0; config_channels <= 0;
            config_pixels <= 0; config_groups <= 0; config_words <= 0;
            target_bank <= 1'b0;
            write_fault <= 1'b0;
            cfg_pixels <= 32'd0;
            cfg_words <= 32'd0;
            word_count <= 32'd0;
            expected_co <= 16'd0;
            expected_index <= 32'd0;
            write_done <= 1'b0;
            write_error <= 1'b0;
            for (bank = 0; bank < 2; bank = bank + 1) begin
                bank_width[bank] <= 16'd0;
                bank_height[bank] <= 16'd0;
                bank_channels[bank] <= 16'd0;
                bank_pixels[bank] <= 32'd0;
            end
        end else begin
            write_done <= 1'b0;
            write_error <= 1'b0;
            if (write_start && write_ready && !write_abort) begin
                config_phase <= 1;
                config_bank <= write_bank;
                config_width <= write_width; config_height <= write_height;
                config_channels <= write_channels;
                config_pixels <= start_pixels; config_groups <= start_groups;
                config_zero <= write_width == 0 || write_height == 0 || write_channels == 0;
            end
            if (config_phase == 1) begin
                config_words <= config_pixels * config_groups;
                config_phase <= 2;
            end
            if (config_phase == 2 && !write_abort) begin
                config_phase <= 0;
                if (bad_write_config) begin
                    // 错误启动不破坏这个 Bank 原来已提交的特征图。
                    write_error <= 1'b1;
                end else begin
                    writing <= 1'b1;
                    target_bank <= config_bank;
                    write_fault <= 1'b0;
                    cfg_pixels <= config_pixels;
                    cfg_words <= config_words[31:0];
                    word_count <= 32'd0;
                    expected_co <= 16'd0;
                    expected_index <= 32'd0;
                    bank_valid[config_bank] <= 1'b0;
                    bank_width[config_bank] <= config_width;
                    bank_height[config_bank] <= config_height;
                    bank_channels[config_bank] <= config_channels;
                    bank_pixels[config_bank] <= config_pixels;
                end
            end
            if (write_accept) begin
                if (bad_write_order) begin
                    write_fault <= 1'b1;
                    write_error <= 1'b1;
                end else begin
                    word_count <= word_count + 32'd1;
                    if (expected_index == cfg_pixels - 32'd1) begin
                        expected_index <= 32'd0;
                        expected_co <= expected_co + 16'd1;
                    end else expected_index <= expected_index + 32'd1;
                end
            end
            if (writing && write_end) begin
                writing <= 1'b0;
                if (!write_fault && !(write_accept && bad_write_order) && write_complete) begin
                    bank_valid[target_bank] <= 1'b1;
                    write_done <= 1'b1;
                end else begin
                    bank_valid[target_bank] <= 1'b0;
                    write_error <= 1'b1;
                end
            end
            // 中止优先于提交，未完成内容永远不发布为有效特征图。
            if (write_abort) config_phase <= 0;
            if (writing && write_abort) begin
                writing <= 1'b0;
                bank_valid[target_bank] <= 1'b0;
                write_done <= 1'b0;
            end
        end
    end

    integer read_lane;
    always @(posedge clk or negedge rst_n) begin
        if (!rst_n) begin
            read_response_valid <= 1'b0;
            read_response_bank <= 1'b0;
            read_response_ci_group <= 16'd0;
            read_response_index <= 32'd0;
            read_upper_half <= 1'b0;
            read_lane_mask <= 4'b0000;
            read_error <= 1'b0;
        end else begin
            read_error <= 1'b0;
            if (response_slot_free) begin
                read_response_valid <= read_fetch;
                if (read_fetch) begin
                    read_response_bank <= read_bank;
                    read_response_ci_group <= read_ci_group;
                    read_response_index <= read_index;
                    read_upper_half <= read_ci_group[0];
                    for (read_lane = 0; read_lane < 4; read_lane = read_lane + 1)
                        read_lane_mask[read_lane] <=
                            ({read_ci_group, 2'b00} + read_lane < read_channels);
                end
            end
            if (read_accept && bad_read_address) read_error <= 1'b1;
        end
    end

    // synthesis translate_off
    initial begin
        if (BANK_DEPTH < 1 || ADDR_WIDTH < address_width(BANK_DEPTH)) begin
            $display("ERROR: invalid feature_map_buffer capacity/address width");
            $finish;
        end
    end
    // synthesis translate_on
endmodule
