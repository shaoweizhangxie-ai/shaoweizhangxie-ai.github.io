`timescale 1ns/1ps

// 官方 YOLOv5 v7 首层：RGB、K6/S2/P2，精确映射到现有 K3/S1/P1 卷积。
// 12 个等价输入通道按 原 RGB 通道 -> 四种奇偶位置 排列，分成三个 ci 组。
// 外部每次 rgb_request 都从头重放同一张完整 RGB 图，不能只送 current_rgb_channel。
// 权重必须装载 stem_weight.hex 的 K3 排列；原 K6 weight.hex 不能直接送入。
module yolov5_stem_top #(
    parameter integer MAX_WIDTH = 640,
    parameter integer PSUM_DEPTH = 256,
    parameter integer MAX_CO_GROUPS = 128,
    parameter integer PE_LATENCY = 7
) (
    input wire clk, rst_n,
    input wire layer_start,
    input wire [15:0] frame_width, frame_height, cout_groups,
    input wire silu_enable,
    output wire layer_ready, layer_busy, layer_done, layer_error,
    input wire cfg_we,
    output wire cfg_ready,
    input wire [15:0] cfg_co_group,
    input wire [255:0] cfg_bias_bus,
    input wire [247:0] cfg_linear_multiplier_bus,
    input wire [47:0] cfg_linear_shift_bus,
    input wire [247:0] cfg_grid_multiplier_bus,
    input wire [47:0] cfg_grid_shift_bus,
    input wire lut_load_start, lut_load_valid,
    output wire lut_load_ready,
    input wire [7:0] lut_load_data,
    output wire lut_valid,
    output wire weight_request, weight_ready,
    input wire weight_valid,
    input wire [31:0] weight_word,
    output wire rgb_request, rgb_ready,
    input wire rgb_valid,
    input wire [23:0] rgb_pixel,
    output wire [1:0] current_rgb_channel,
    output wire [15:0] current_co_group,
    output wire [31:0] current_tile_base,
    // 原始 INT32 结果用于联调，与原 K6 参考逐位相同。
    output wire raw_valid,
    output wire [15:0] raw_co_group,
    output wire [31:0] raw_index,
    output wire [255:0] raw_data,
    output wire out_valid,
    output wire [15:0] out_co_group,
    output wire [31:0] out_index,
    output wire [63:0] out_data
);
    reg [15:0] cfg_width, cfg_height;
    reg shape_error;
    wire core_ready, core_error, core_done, core_busy;
    wire phase_ready, phase_busy, phase_error, phase_valid, phase_consume;
    wire [31:0] phase_pixel;
    wire [15:0] core_ci_group;
    wire bad_shape = (frame_width < 2) || (frame_height < 2) ||
        frame_width[0] || frame_height[0] || (frame_width > MAX_WIDTH);
    assign layer_ready = core_ready && phase_ready;
    wire start_core = layer_start && layer_ready && !bad_shape;
    assign layer_busy = core_busy || phase_busy;
    assign layer_done = core_done;
    assign layer_error = shape_error || core_error || phase_error;
    assign current_rgb_channel = core_ci_group[1:0];
    // 参数和查表配置沿用 conv_layer_top；运行中的实时帧尺寸不会影响重放。
    always @(posedge clk or negedge rst_n) begin
        if (!rst_n) begin
            cfg_width <= 0; cfg_height <= 0; shape_error <= 0;
        end else begin
            shape_error <= 0;
            if (layer_start && layer_ready && !lut_load_start) begin
                if (bad_shape)
                    shape_error <= 1;
                else begin
                    cfg_width <= frame_width; cfg_height <= frame_height;
                end
            end
        end
    end

    rgb_phase_pack #(.MAX_WIDTH(MAX_WIDTH)) u_pack (
        .clk(clk), .rst_n(rst_n), .frame_start(rgb_request),
        .frame_width(cfg_width), .frame_height(cfg_height),
        .rgb_channel(current_rgb_channel), .frame_ready(phase_ready),
        .busy(phase_busy), .frame_done(), .frame_error(phase_error),
        .in_valid(rgb_valid), .in_ready(rgb_ready), .in_pixel(rgb_pixel),
        .out_valid(phase_valid), .out_ready(phase_consume), .out_pixel(phase_pixel)
    );

    conv_layer_top #(.MAX_WIDTH(MAX_WIDTH/2), .PSUM_DEPTH(PSUM_DEPTH),
        .MAX_CO_GROUPS(MAX_CO_GROUPS), .PE_LATENCY(PE_LATENCY)) u_conv (
        .clk(clk), .rst_n(rst_n), .layer_start(start_core),
        .frame_width(frame_width >> 1), .frame_height(frame_height >> 1),
        .cin_groups(16'd3), .cout_groups(cout_groups),
        .kernel_1x1(1'b0), .stride_2(1'b0), .padding_1(1'b1),
        .silu_enable(silu_enable), .layer_ready(core_ready), .layer_busy(core_busy),
        .layer_done(core_done), .layer_error(core_error),
        .cfg_we(cfg_we), .cfg_ready(cfg_ready), .cfg_co_group(cfg_co_group),
        .cfg_bias_bus(cfg_bias_bus), .cfg_linear_multiplier_bus(cfg_linear_multiplier_bus),
        .cfg_linear_shift_bus(cfg_linear_shift_bus),
        .cfg_grid_multiplier_bus(cfg_grid_multiplier_bus), .cfg_grid_shift_bus(cfg_grid_shift_bus),
        .lut_load_start(lut_load_start), .lut_load_valid(lut_load_valid),
        .lut_load_ready(lut_load_ready), .lut_load_data(lut_load_data), .lut_valid(lut_valid),
        .weight_request(weight_request), .weight_ready(weight_ready),
        .weight_valid(weight_valid), .weight_word(weight_word),
        .ifm_request(rgb_request), .ifm_ready(phase_consume),
        .ifm_valid(phase_valid), .ifm_pixel(phase_pixel),
        .current_ci_group(core_ci_group), .current_co_group(current_co_group),
        .current_tile_base(current_tile_base),
        .raw_valid(raw_valid), .raw_co_group(raw_co_group), .raw_index(raw_index), .raw_data(raw_data),
        .out_valid(out_valid), .out_co_group(out_co_group), .out_index(out_index), .out_data(out_data)
    );
endmodule
