`timescale 1ns/1ps
// 一个 Tile 的只读输入驻留缓存。完整 group8 提交后有效，容量不足直接旁路。
// 不改变 DDR 布局、Halo、group4 Reader、Psum 或 co/ci 循环顺序。
module feature_residency_cache #(
    parameter integer CACHE_WORDS=8192, MAX_GROUPS=64, K1_WIDE_ENABLE=0, PIPELINE_GEOMETRY=0
) (
    input wire clk,rst_n,clear,invalidate,
    input wire [31:0] frame_base,tile_y,
    input wire [15:0] frame_width,frame_height,frame_channels,region_width,region_height,group8,
    input wire [1:0] step,pad,
    input wire begin_request,
    output wire eligible,hit,
    output wire geometry_ready,
    input wire fill_valid,
    input wire [31:0] fill_index,
    input wire [63:0] fill_data,
    input wire fill_commit,
    output reg replay_valid,
    input wire replay_ready,
    output reg [31:0] replay_index,
    output reg [63:0] replay_data,
    output reg replay_done,
    output wire replay_busy,
    input wire wide_mode,
    input wire [31:0] wide_tile_y,
    input wire [15:0] wide_width,wide_height,wide_group8_base,
    output wire [3:0] wide_group_valid,
    input wire wide_request,
    input wire [31:0] wide_index,
    output wire wide_ready,
    output reg wide_response_valid,
    output reg [255:0] wide_data
);
    function integer clog2;
        input integer n;integer v;
        begin v=n-1;clog2=0;while(v>0)begin clog2=clog2+1;v=v>>1;end if(clog2==0)clog2=1;end
    endfunction
    localparam AW=clog2(CACHE_WORDS);
    reg tag_valid;
    reg [MAX_GROUPS-1:0] group_valid;
    reg [31:0] tag_base,tag_tile;
    reg [15:0] tag_fw,tag_fh,tag_fc,tag_rw,tag_rh;
    reg [1:0] tag_step,tag_pad;
    // Snapshot geometry across two stages. No multiply-to-multiply chain feeds
    // a BRAM address. The caller holds LAUNCH until geometry_ready.
    wire [31:0] live_pixels={16'd0,region_width}*{16'd0,region_height};
    reg [63:0] geo_key1,geo_key2;
    reg [47:0] wide_key1,wide_key2;
    reg geo_valid1,geo_valid2;
    reg [31:0] pixels1,pixels2,wide_pixels1,wide_pixels2;
    reg [16:0] groups1;
    reg [63:0] words2,bank_words2;
    reg [31:0] group_base2,bank_base2,wide_base2;
    wire [63:0] geo_key={region_width,region_height,frame_channels,group8};
    wire [47:0] wide_key={wide_width,wide_height,wide_group8_base};
    assign geometry_ready=PIPELINE_GEOMETRY==0 || (geo_valid2 && geo_key==geo_key2);
    wire wide_geometry_ready=PIPELINE_GEOMETRY==0 || (geo_valid2 && wide_key==wide_key2);
    always @(posedge clk or negedge rst_n)begin
        if(!rst_n)begin
            geo_valid1<=0;geo_valid2<=0;geo_key1<=0;geo_key2<=0;wide_key1<=0;wide_key2<=0;
            pixels1<=0;pixels2<=0;wide_pixels1<=0;wide_pixels2<=0;groups1<=0;
            words2<=0;bank_words2<=0;group_base2<=0;bank_base2<=0;wide_base2<=0;
        end else begin
            geo_valid1<=1;geo_valid2<=geo_valid1;
            geo_key1<=geo_key;geo_key2<=geo_key1;wide_key1<=wide_key;wide_key2<=wide_key1;
            pixels1<=live_pixels;wide_pixels1<={16'd0,wide_width}*{16'd0,wide_height};
            groups1<=({1'b0,frame_channels}+17'd7)>>3;
            pixels2<=pixels1;wide_pixels2<=wide_pixels1;
            words2<=64'd1*pixels1*groups1;
            bank_words2<=64'd1*((groups1+3)>>2)*pixels1;
            group_base2<=geo_key1[15:0]*pixels1;
            bank_base2<=(geo_key1[15:0]>>2)*pixels1;
            wide_base2<=(wide_key1[15:0]>>2)*wide_pixels1;
        end
    end
    wire [31:0] pixels=PIPELINE_GEOMETRY!=0?pixels2:live_pixels;
    wire [16:0] groups=({1'b0,frame_channels}+17'd7)>>3;
    wire [63:0] required_words=PIPELINE_GEOMETRY!=0?words2:64'd1*pixels*groups;
    // 一/两个 group8 已由现有两 Bank 复用，无需重复镜像。
    // 宽端口按group8低两位分银行，容量不变；每银行保存ceil(groups/4)个平面。
    wire banked_fits=PIPELINE_GEOMETRY!=0?bank_words2<=CACHE_WORDS/4:64'd1*((groups+3)>>2)*pixels<=CACHE_WORDS/4;
    assign eligible=geometry_ready && (groups>2 || (K1_WIDE_ENABLE!=0 && wide_mode)) && groups<=MAX_GROUPS &&
        group8<groups && pixels!=0 && required_words<=CACHE_WORDS && (K1_WIDE_ENABLE==0 || banked_fits);
    wire same_tag=tag_valid && tag_base==frame_base && tag_tile==tile_y &&
        tag_fw==frame_width && tag_fh==frame_height && tag_fc==frame_channels &&
        tag_rw==region_width && tag_rh==region_height && tag_step==step && tag_pad==pad;
    assign hit=eligible && same_tag && group8<MAX_GROUPS && group_valid[group8] && !clear && !invalidate;
    reg filling,fill_bad,replaying,replay_start;
    reg [15:0] held_group;
    reg [31:0] held_pixels,fill_count,held_base,held_bank_base;
    wire [31:0] next_read=held_base+replay_index+32'd1;
    wire [31:0] query_read=PIPELINE_GEOMETRY!=0?group_base2:group8*pixels;
    wire fetch_first=replay_start;
    wire fetch_next=replay_valid && replay_ready && replay_index+1<held_pixels;
    wire [31:0] read_address=fetch_first?held_base:next_read;
    wire [31:0] write_address=held_base+fill_index;
    assign replay_busy=replaying;
    wire wide_tag=tag_valid && tag_base==frame_base && tag_tile==wide_tile_y &&
        tag_fw==frame_width && tag_fh==frame_height && tag_fc==frame_channels &&
        tag_rw==wide_width && tag_rh==wide_height && tag_step==step && tag_pad==pad;
    genvar vg;
    generate for(vg=0;vg<4;vg=vg+1)begin:g_wide_valid
        assign wide_group_valid[vg]=K1_WIDE_ENABLE!=0 && wide_mode && !clear && !invalidate &&
            (wide_group8_base+vg>=groups ||
             (wide_tag && wide_group8_base+vg<MAX_GROUPS && group_valid[wide_group8_base+vg]));
    end endgenerate
    wire [31:0] wide_pixels=PIPELINE_GEOMETRY!=0?wide_pixels2:{16'd0,wide_width}*{16'd0,wide_height};
    assign wide_ready=wide_geometry_ready && K1_WIDE_ENABLE!=0 && wide_mode && &wide_group_valid && !filling && !replaying &&
        wide_index<wide_pixels && !clear && !invalidate;
    wire write_enable=rst_n && !clear && !invalidate && filling && fill_valid &&
        fill_index==fill_count && fill_index<held_pixels && write_address<CACHE_WORDS;
    generate if(K1_WIDE_ENABLE==0)begin:g_legacy_ram
        reg [63:0] memory[0:CACHE_WORDS-1];
        always @(posedge clk)if(!clear && !invalidate && (fetch_first || fetch_next))
            replay_data<=memory[read_address[AW-1:0]];
        always @(posedge clk)if(write_enable)memory[write_address[AW-1:0]]<=fill_data;
        always @(posedge clk)begin wide_data<=0;wide_response_valid<=0;end
    end else begin:g_banked_ram
        localparam DEPTH=CACHE_WORDS/4,BAW=clog2(DEPTH);
        wire [15:0] read_group=held_group;
        wire [31:0] read_pixel=fetch_first?32'd0:replay_index+1;
        wire [31:0] replay_addr=PIPELINE_GEOMETRY!=0?
            held_bank_base+read_pixel:(read_group>>2)*held_pixels+read_pixel;
        wire [31:0] write_addr=PIPELINE_GEOMETRY!=0?held_bank_base+fill_index:(held_group>>2)*held_pixels+fill_index;
        wire [31:0] wide_addr=PIPELINE_GEOMETRY!=0?wide_base2+wide_index:(wide_group8_base>>2)*wide_pixels+wide_index;
        wire do_replay=!clear && !invalidate && (fetch_first || fetch_next);
        reg [1:0] response_bank;
        wire [255:0] bank_words;
        genvar b;
        for(b=0;b<4;b=b+1)begin:g_bank
            reg [63:0] memory[0:DEPTH-1];
            reg [63:0] q;
            // 显式合并读地址，保证工具只推断一个同步读端口。
            // 两个条件语句各自引用memory会被PDS复制成双读RAM。
            wire wide_read=wide_request && wide_ready;
            wire narrow_read=do_replay && read_group[1:0]==b;
            wire [BAW-1:0] bank_read_address=wide_read?wide_addr[BAW-1:0]:replay_addr[BAW-1:0];
            always @(posedge clk)begin
                if(write_enable && held_group[1:0]==b)memory[write_addr[BAW-1:0]]<=fill_data;
                if(wide_read || narrow_read)q<=memory[bank_read_address];
            end
            assign bank_words[b*64 +:64]=q;
        end
        always @(posedge clk)if(do_replay)response_bank<=read_group[1:0];
        always @*replay_data=bank_words[response_bank*64 +:64];
        reg [255:0] lane_mask;
        integer c;
        always @*begin
            lane_mask=0;
            for(c=0;c<32;c=c+1)if(wide_group8_base*8+c<frame_channels)lane_mask[c*8 +:8]=8'hff;
            wide_data=bank_words & lane_mask;
        end
        always @(posedge clk or negedge rst_n)begin
            if(!rst_n)wide_response_valid<=0;
            else wide_response_valid<=wide_request && wide_ready && !clear && !invalidate;
        end
    end endgenerate
    always @(posedge clk or negedge rst_n) begin
        if(!rst_n)begin
            tag_valid<=0;group_valid<=0;filling<=0;fill_bad<=0;replaying<=0;replay_start<=0;
            held_group<=0;held_pixels<=0;held_base<=0;held_bank_base<=0;fill_count<=0;
            tag_base<=0;tag_tile<=0;tag_fw<=0;tag_fh<=0;tag_fc<=0;tag_rw<=0;tag_rh<=0;tag_step<=0;tag_pad<=0;
            replay_valid<=0;replay_index<=0;replay_done<=0;
        end else begin
            replay_done<=0;replay_start<=0;
            // Start the synchronous RAM read from captured request metadata.
            // The tag comparison no longer drives the RAM clock-enable cone.
            if(replay_start)replay_valid<=1;
            if(begin_request)begin
                held_group<=group8;held_pixels<=pixels;held_base<=query_read;held_bank_base<=bank_base2;
                fill_count<=0;fill_bad<=0;filling<=eligible && !hit;
                if(hit)begin
                    replaying<=1;replay_start<=1;replay_valid<=0;replay_index<=0;
                end else if(eligible)begin
                    if(!same_tag)begin
                        tag_valid<=1;group_valid<=0;tag_base<=frame_base;tag_tile<=tile_y;
                        tag_fw<=frame_width;tag_fh<=frame_height;tag_fc<=frame_channels;
                        tag_rw<=region_width;tag_rh<=region_height;tag_step<=step;tag_pad<=pad;
                    end else group_valid[group8]<=0;
                end
            end
            if(filling && fill_valid)begin
                if(fill_index!=fill_count || fill_index>=held_pixels || write_address>=CACHE_WORDS)fill_bad<=1;
                else fill_count<=fill_count+1;
            end
            // Bank 的完整提交确认，不以 DMA 最后一字提前发布 tag。
            if(filling && fill_commit)begin
                if(!fill_bad && fill_count==held_pixels)group_valid[held_group]<=1;
                filling<=0;
            end
            if(replay_valid && replay_ready)begin
                if(replay_index+1==held_pixels)begin replay_valid<=0;replaying<=0;replay_done<=1;end
                else replay_index<=replay_index+1;
            end
            if(clear || invalidate)begin
                tag_valid<=0;group_valid<=0;filling<=0;replaying<=0;replay_start<=0;replay_valid<=0;replay_done<=0;
            end
        end
    end
endmodule
