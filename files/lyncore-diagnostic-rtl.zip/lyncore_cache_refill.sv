`timescale 1ns/1ps
// One logical 16-byte line transaction -> four ordered, contiguous word beats.
// Native backend remains blocking; this is not a claim of an external AXI4 bus.
module lyncore_cache_refill (
    input logic clk, rst, line_valid,
    input logic [31:0] line_addr,
    output logic line_ready, line_error,
    output logic [127:0] line_rdata,
    output logic word_valid,
    output logic [31:0] word_addr,
    input logic word_ready, word_error,
    input logic [31:0] word_rdata
);
    logic active;
    logic [31:0] base;
    logic [1:0] beat;
    logic [127:0] assembled;
    assign word_valid=!rst && active;
    assign word_addr=base+{28'b0,beat,2'b0};
    assign line_ready=!rst && active && word_ready && (beat==3 || word_error);
    assign line_error=line_ready && word_error;
    always_comb begin
        line_rdata=assembled;
        line_rdata[beat*32 +: 32]=word_rdata;
    end
    always_ff @(posedge clk) begin
        if(rst) begin active<=0; base<=0; beat<=0; assembled<=0; end
        else if(!active) begin
            if(line_valid) begin active<=1; base<={line_addr[31:4],4'b0}; beat<=0; end
        end else if(word_ready) begin
            assembled[beat*32 +: 32]<=word_rdata;
            if(beat==3 || word_error) active<=0;
            else beat<=beat+1;
        end
    end
endmodule
