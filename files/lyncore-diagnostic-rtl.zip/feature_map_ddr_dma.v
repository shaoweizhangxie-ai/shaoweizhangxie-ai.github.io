`timescale 1ns/1ps

// 已提交片上区域与 DDR 特征图之间的搬运：group8 -> y -> x，每字八个 INT8。
// 上传从原四通道缓存口取数，复用 tensor_word_reader；下载输出可停顿的八通道流。
// 卷积输出应先进入容量足够的片上区域缓存，再启动上传，不能直接阻塞 PE 末端。
module feature_map_ddr_dma #(
    parameter [31:0] DDR_WINDOW_BASE=32'h20000000,
    parameter [63:0] DDR_BYTES=64'h40000000,
    parameter integer WRITE_COMBINE=0,
    // 默认 0 保留旧路径；2~4 字仅供指定上传实验，下载不使用此 FIFO。
    parameter integer UPLOAD_FIFO_WORDS=0
) (
    input wire clk, rst_n, clear, start,
    output wire ready, busy,
    output reg done, error, cancelled,
    // download=0 上传，=1 下载；以下配置仅在 start && ready 时锁存。
    input wire download,
    input wire [31:0] frame_base,
    input wire [15:0] frame_width, frame_height, frame_channels,
    input wire signed [31:0] region_x, region_y,
    input wire [15:0] region_width, region_height, co_base, co_groups,
    input wire [2:0] source_slot,
    // 上传源是局部区域，通道数为所选 group8 的实际有效通道数。
    output wire [2:0] source_config_slot,
    input wire source_config_valid,
    input wire [15:0] source_width, source_height, source_channels,
    output wire source_request_valid,
    input wire source_request_ready,
    output wire [2:0] source_request_slot,
    output wire [15:0] source_request_ci_group,
    output wire [31:0] source_request_index,
    input wire source_response_valid,
    output wire source_response_ready,
    input wire [2:0] source_response_slot,
    input wire [15:0] source_response_ci_group,
    input wire [31:0] source_response_index, source_response_pixel,
    input wire source_response_error,
    // 下载元数据为局部区域配置；输出组从 0 编号，index=row*区域宽度+列。
    output reg [15:0] transfer_width, transfer_height, transfer_channels,
    output wire out_valid,
    input wire out_ready,
    output reg [63:0] out_data,
    output wire [15:0] out_co_group,
    output wire [31:0] out_index,
    output wire out_last,
    // 与已有 pango_ddr_bridge 的 32 位系统字节地址端口直接连接。
    output wire read_request_valid,
    input wire read_request_ready,
    output wire [31:0] read_request_address,
    input wire read_response_valid,
    output wire read_response_ready,
    input wire [31:0] read_response_address, read_response_data,
    input wire read_response_error,
    output wire write_request_valid,
    input wire write_request_ready,
    output wire [31:0] write_request_address, write_request_data,
    output wire [3:0] write_request_strobe,
    input wire write_response_valid,
    output wire write_response_ready,
    input wire [31:0] write_response_address,
    input wire write_response_error,
    input wire upload_pipeline_enable
);
    localparam [4:0] IDLE=0, SELECT=1, SOURCE_START=2, SOURCE_WAIT=3,
        WRITE_LOW=4, WAIT_WRITE_LOW=5, WRITE_HIGH=6, WAIT_WRITE_HIGH=7,
        READ_LOW=8, WAIT_READ_LOW=9, READ_HIGH=10, WAIT_READ_HIGH=11,
        EMIT=12, ADVANCE=13, FINISH=14, CANCEL_SOURCE=15, FLUSH_REQUEST=16, FLUSH_WAIT=17,
        CONFIG_PIXELS=18, CONFIG_BYTES=19, CONFIG_END=20, CONFIG_CHECK=21,
        ADDRESS_COMMIT=22;
    localparam [63:0] WINDOW_END={32'd0,DDR_WINDOW_BASE}+DDR_BYTES;
    localparam BAD_PARAMETERS=DDR_WINDOW_BASE[4:0]!=0 || DDR_BYTES==0 || DDR_BYTES[4:0]!=0 ||
        DDR_BYTES>64'h40000000 || WINDOW_END>64'h100000000;
    reg [4:0] state;
    reg flushed;
    reg downloading, aborted, transfer_error;
    reg [31:0] base_address, frame_pixels, bus_address, low_data;
    reg [15:0] cfg_width, cfg_height, cfg_channels, first_co, group_count;
    reg signed [31:0] cfg_x, cfg_y;
    reg [2:0] cfg_source_slot;
    reg [15:0] column, row, group;
    reg [63:0] upload_data;
    reg upload_pipelined;
    reg fifo_start_q;
    reg [31:0] upload_pixels;
    reg config_bad_q;
    reg [16:0] config_groups_q;
    reg [63:0] config_bytes_q,config_end_q;

    // 范围计算先扩展，再乘加，避免大图/通道分组在 32 位中回绕。
    wire [16:0] start_groups=({1'b0,frame_channels}+17'd7)>>3;
    wire [16:0] selected_end={1'b0,co_base}+{1'b0,co_groups};
    wire [18:0] first_channel={co_base,3'd0};
    wire [18:0] selected_channels={co_groups,3'd0};
    wire [18:0] available_channels={3'd0,frame_channels}-first_channel;
    wire [18:0] local_channels=selected_channels<available_channels ? selected_channels : available_channels;
    wire signed [32:0] right_edge=$signed({region_x[31],region_x})+$signed({17'd0,region_width});
    wire signed [32:0] bottom_edge=$signed({region_y[31],region_y})+$signed({17'd0,region_height});
    wire bad_config_basic=BAD_PARAMETERS || frame_width==0 || frame_height==0 || frame_channels==0 ||
        region_width==0 || region_height==0 || co_groups==0 || selected_end>start_groups ||
        frame_base[2:0]!=0 || frame_base<DDR_WINDOW_BASE ||
        (!download && (region_x<0 || region_y<0 || right_edge>$signed({17'd0,frame_width}) ||
            bottom_edge>$signed({17'd0,frame_height}) || !source_config_valid ||
            source_width!=region_width || source_height!=region_height || source_channels!=local_channels));

    wire signed [32:0] current_x=$signed({cfg_x[31],cfg_x})+$signed({17'd0,column});
    wire signed [32:0] current_y=$signed({cfg_y[31],cfg_y})+$signed({17'd0,row});
    wire outside=current_x<0 || current_y<0 || current_x>=$signed({17'd0,cfg_width}) ||
        current_y>=$signed({17'd0,cfg_height});
    wire [16:0] absolute_co={1'b0,first_co}+{1'b0,group};
    reg [63:0] row_words, group_and_column_words;
    always @(posedge clk) begin
        if (state==SELECT && !clear && !aborted && !(downloading && outside)) begin
            row_words <= {31'd0,current_y}*{48'd0,cfg_width};
            group_and_column_words <= {47'd0,absolute_co}*{32'd0,frame_pixels}+{31'd0,current_x};
        end
    end
    wire [63:0] current_address={32'd0,base_address}+((row_words+group_and_column_words)<<3);
    wire last_word=column==transfer_width-1 && row==transfer_height-1 && group==group_count-1;
    wire high_read=state==READ_HIGH || state==WAIT_READ_HIGH;
    wire high_write=state==WRITE_HIGH || state==WAIT_WRITE_HIGH;

    wire source_reader_ready, source_reader_busy, source_reader_error, source_word_valid, source_word_ready;
    wire [63:0] source_word;
    wire serial_ready,serial_busy,serial_error,serial_valid,serial_request,serial_response_ready;
    wire [63:0] serial_word;
    wire [2:0] serial_slot;
    wire [15:0] serial_ci;
    wire [31:0] serial_index;
    wire fifo_ready,fifo_busy,fifo_error,fifo_valid,fifo_request,fifo_response_ready;
    wire [63:0] fifo_word;
    wire [2:0] fifo_slot;
    wire [15:0] fifo_ci,fifo_co;
    wire [31:0] fifo_index,fifo_word_index;
    wire fifo_start=fifo_start_q && !clear && !aborted && !transfer_error;
    wire fifo_stop=clear || (state!=IDLE && (aborted || transfer_error));
    assign source_reader_ready=upload_pipelined ? fifo_ready : serial_ready;
    assign source_reader_busy=upload_pipelined ? fifo_busy : serial_busy;
    assign source_reader_error=upload_pipelined ? fifo_error : serial_error;
    assign source_word_valid=upload_pipelined ? fifo_valid : serial_valid;
    assign source_word=upload_pipelined ? fifo_word : serial_word;
    assign source_request_valid=upload_pipelined ? fifo_request : serial_request;
    assign source_request_slot=upload_pipelined ? fifo_slot : serial_slot;
    assign source_request_ci_group=upload_pipelined ? fifo_ci : serial_ci;
    assign source_request_index=upload_pipelined ? fifo_index : serial_index;
    assign source_response_ready=upload_pipelined ? fifo_response_ready : serial_response_ready;
    assign ready=rst_n && !clear && state==IDLE && !serial_busy && !fifo_busy;
    assign busy=state!=IDLE || serial_busy || fifo_busy;
    assign source_config_slot=state==IDLE ? source_slot : cfg_source_slot;
    assign out_valid=state==EMIT;
    assign out_co_group=group;
    assign out_index={16'd0,row}*{16'd0,transfer_width}+{16'd0,column};
    assign out_last=last_word;
    assign read_request_valid=rst_n && !clear && !aborted && (state==READ_LOW || state==READ_HIGH);
    assign write_request_valid=rst_n && !clear && !aborted && (state==WRITE_LOW || state==WRITE_HIGH) || (rst_n && !clear && state==FLUSH_REQUEST);
    assign read_request_address=bus_address+(high_read ? 32'd4 : 32'd0);
    assign write_request_address=bus_address+(high_write ? 32'd4 : 32'd0);
    assign write_request_data=high_write ? upload_data[63:32] : upload_data[31:0];
    // 写合并模式下零掩码为FENCE，应答表示原生写已全部退休。
    assign write_request_strobe=state==FLUSH_REQUEST || state==FLUSH_WAIT?4'h0:4'hf;
    assign read_response_ready=state==WAIT_READ_LOW || state==WAIT_READ_HIGH;
    assign write_response_ready=state==WAIT_WRITE_LOW || state==WAIT_WRITE_HIGH || state==FLUSH_WAIT;
    assign source_word_ready=state==SOURCE_WAIT && !clear && !aborted;

    tensor_word_reader source_reader (
        .clk(clk),.rst_n(rst_n),.clear(clear),
        .start(!upload_pipelined && state==SOURCE_START && !clear && !aborted),.ready(serial_ready),
        .source_slot(cfg_source_slot),.source_channels(transfer_channels),.source_co_group(group),.source_index(out_index),
        .busy(serial_busy),.error(serial_error),
        .request_valid(serial_request),.request_ready(source_request_ready && !upload_pipelined),
        .request_slot(serial_slot),.request_ci_group(serial_ci),.request_index(serial_index),
        .response_valid(source_response_valid && !upload_pipelined),.response_ready(serial_response_ready),
        .response_slot(source_response_slot),.response_ci_group(source_response_ci_group),
        .response_index(source_response_index),.response_pixel(source_response_pixel),.response_error(source_response_error),
        .out_valid(serial_valid),.out_ready(source_word_ready && !upload_pipelined),.out_data(serial_word)
    );

    generate if(UPLOAD_FIFO_WORDS!=0) begin:g_upload_fifo
        tensor_upload_prefetch #(.FIFO_WORDS(UPLOAD_FIFO_WORDS)) prefetch (
            .clk(clk),.rst_n(rst_n),.clear(fifo_stop),.start(fifo_start),.ready(fifo_ready),.busy(fifo_busy),.error(fifo_error),
            // Launch one cycle after acceptance, from registered config/product only.
            .source_slot(cfg_source_slot),.source_channels(transfer_channels),.source_groups(group_count),
            .source_pixels(upload_pixels),
            .request_valid(fifo_request),.request_ready(source_request_ready && upload_pipelined),
            .request_slot(fifo_slot),.request_ci_group(fifo_ci),.request_index(fifo_index),
            .response_valid(source_response_valid && upload_pipelined),.response_ready(fifo_response_ready),
            .response_slot(source_response_slot),.response_ci_group(source_response_ci_group),
            .response_index(source_response_index),.response_pixel(source_response_pixel),.response_error(source_response_error),
            .out_valid(fifo_valid),.out_ready(source_word_ready && upload_pipelined),.out_data(fifo_word),
            .out_co_group(fifo_co),.out_index(fifo_word_index)
        );
    end else begin:g_no_upload_fifo
        assign fifo_ready=1'b1;assign fifo_busy=1'b0;assign fifo_error=1'b0;assign fifo_valid=1'b0;
        assign fifo_request=1'b0;assign fifo_response_ready=1'b0;assign fifo_word=64'd0;
        assign fifo_slot=3'd0;assign fifo_ci=16'd0;assign fifo_index=32'd0;
        assign fifo_co=16'd0;assign fifo_word_index=32'd0;
    end endgenerate

    function [63:0] mask_tail;
        input [63:0] data;
        input [16:0] co;
        input [15:0] channels;
        integer lane;
        begin
            for(lane=0;lane<8;lane=lane+1)
                mask_tail[lane*8 +: 8]=({co,3'd0}+lane<channels) ? data[lane*8 +: 8] : 8'd0;
        end
    endfunction

    always @(posedge clk or negedge rst_n) begin
        if(!rst_n) begin
            state<=IDLE;flushed<=0;done<=0;error<=0;cancelled<=0;downloading<=0;aborted<=0;transfer_error<=0;
            base_address<=0;frame_pixels<=0;bus_address<=0;low_data<=0;
            cfg_width<=0;cfg_height<=0;cfg_channels<=0;first_co<=0;group_count<=0;cfg_x<=0;cfg_y<=0;cfg_source_slot<=0;
            column<=0;row<=0;group<=0;upload_data<=0;out_data<=0;
            upload_pipelined<=0;fifo_start_q<=0;upload_pixels<=0;
            config_bad_q<=0;config_groups_q<=0;config_bytes_q<=0;config_end_q<=0;
            transfer_width<=0;transfer_height<=0;transfer_channels<=0;
        end else begin
            done<=0;error<=0;cancelled<=0;
            fifo_start_q<=0;
            if(clear && state!=IDLE) aborted<=1;
            case(state)
                IDLE: if(start && ready) begin
                    downloading<=download;flushed<=0;aborted<=0;transfer_error<=0;
                    config_bad_q<=bad_config_basic;
                    upload_pipelined<=UPLOAD_FIFO_WORDS!=0 && upload_pipeline_enable && !download;
                    upload_pixels<={16'd0,region_width}*{16'd0,region_height};
                    base_address<=frame_base;
                    cfg_width<=frame_width;cfg_height<=frame_height;cfg_channels<=frame_channels;
                    cfg_x<=region_x;cfg_y<=region_y;first_co<=co_base;group_count<=co_groups;cfg_source_slot<=source_slot;
                    transfer_width<=region_width;transfer_height<=region_height;transfer_channels<=local_channels[15:0];
                    column<=0;row<=0;group<=0;state<=CONFIG_PIXELS;
                end
                // No source read or DDR transaction escapes before the complete
                // accepted configuration has passed the 64-bit range check.
                CONFIG_PIXELS: begin
                    frame_pixels<={16'd0,cfg_width}*{16'd0,cfg_height};
                    config_groups_q<=({1'b0,cfg_channels}+17'd7)>>3;
                    state<=CONFIG_BYTES;
                end
                CONFIG_BYTES: begin
                    config_bytes_q<=({32'd0,frame_pixels}*{47'd0,config_groups_q})<<3;
                    state<=CONFIG_END;
                end
                CONFIG_END: begin
                    config_end_q<={32'd0,base_address}+config_bytes_q;
                    state<=CONFIG_CHECK;
                end
                CONFIG_CHECK: begin
                    if(clear || aborted)state<=FINISH;
                    else if(config_bad_q || config_end_q>WINDOW_END)begin
                        transfer_error<=1;state<=FINISH;
                    end else begin
                        fifo_start_q<=upload_pipelined;state<=SELECT;
                    end
                end
                SELECT: begin
                    if(clear || aborted) state<=FINISH;
                    else if(downloading && outside) begin out_data<=0;state<=EMIT;end
                    else state<=ADDRESS_COMMIT;
                end
                ADDRESS_COMMIT: begin
                    if(clear || aborted) state<=FINISH;
                    else begin bus_address<=current_address[31:0];state<=downloading ? READ_LOW : (upload_pipelined ? SOURCE_WAIT : SOURCE_START);end
                end
                SOURCE_START: begin
                    if(clear || aborted) state<=CANCEL_SOURCE;
                    else if(source_reader_ready) state<=SOURCE_WAIT;
                end
                SOURCE_WAIT: begin
                    if(clear || aborted) state<=CANCEL_SOURCE;
                    else if(source_reader_error) begin transfer_error<=1;state<=upload_pipelined ? CANCEL_SOURCE : FINISH;end
                    else if(source_word_valid && source_word_ready) begin
                        if(upload_pipelined && (fifo_co!=group || fifo_word_index!=out_index)) begin
                            transfer_error<=1;state<=CANCEL_SOURCE;
                        end else begin upload_data<=source_word;state<=WRITE_LOW;end
                    end
                end
                CANCEL_SOURCE: if(!source_reader_busy) state<=FINISH;
                WRITE_LOW,WRITE_HIGH: begin
                    if(clear || aborted) state<=FINISH;
                    else if(write_request_valid && write_request_ready) state<=high_write ? WAIT_WRITE_HIGH : WAIT_WRITE_LOW;
                end
                WAIT_WRITE_LOW,WAIT_WRITE_HIGH: if(write_response_valid && write_response_ready) begin
                    if(clear || aborted) state<=FINISH;
                    else if(write_response_error || write_response_address!=write_request_address) begin transfer_error<=1;state<=FINISH;end
                    else state<=high_write ? ADVANCE : WRITE_HIGH;
                end
                READ_LOW,READ_HIGH: begin
                    if(clear || aborted) state<=FINISH;
                    else if(read_request_valid && read_request_ready) state<=high_read ? WAIT_READ_HIGH : WAIT_READ_LOW;
                end
                WAIT_READ_LOW,WAIT_READ_HIGH: if(read_response_valid && read_response_ready) begin
                    if(clear || aborted) state<=FINISH;
                    else if(read_response_error || read_response_address!=read_request_address) begin transfer_error<=1;state<=FINISH;end
                    else if(high_read) begin out_data<=mask_tail({read_response_data,low_data},absolute_co,cfg_channels);state<=EMIT;end
                    else begin low_data<=read_response_data;state<=READ_HIGH;end
                end
                // 已呈现的下载数据不可在 clear 时撤回；接收后再报告 cancelled。
                EMIT: if(out_valid && out_ready) state<=(clear || aborted) ? FINISH : ADVANCE;
                ADVANCE: begin
                    if(clear || aborted || last_word) state<=FINISH;
                    else begin
                        if(column==transfer_width-1) begin
                            column<=0;
                            if(row==transfer_height-1) begin row<=0;group<=group+1;end
                            else row<=row+1;
                        end else column<=column+1;
                        state<=SELECT;
                    end
                end
                FLUSH_REQUEST: if(write_request_valid && write_request_ready)state<=FLUSH_WAIT;
                FLUSH_WAIT: if(write_response_valid && write_response_ready)begin
                    flushed<=1;
                    if(write_response_error || write_response_address!=write_request_address)transfer_error<=1;
                    state<=FINISH;
                end
                // 预取接受的源响应必须先排空，然后才允许 Fence/完成/Slot 发布。
                FINISH: if(!upload_pipelined || !fifo_busy) begin
                if(WRITE_COMBINE!=0 && !downloading && !flushed)state<=FLUSH_REQUEST;
                else begin
                    done<=!transfer_error && !aborted && !clear;
                    error<=transfer_error && !aborted && !clear;
                    cancelled<=aborted || clear;state<=IDLE;
                end
                end
                default: state<=IDLE;
            endcase
        end
    end
endmodule
