module lyncore_yolo_soc (
	clk,
	cpu_clk,
	rst_n,
	clear,
	uart_rx,
	keys,
	uart_tx,
	halted,
	leds,
	cycle_count,
	instret_count,
	ddr_ready,
	memory_idle,
	input_allow,
	input_write_allow,
	read_request_valid,
	read_request_ready,
	read_request_address,
	read_response_valid,
	read_response_ready,
	read_response_address,
	read_response_data,
	read_response_error,
	write_request_valid,
	write_request_ready,
	write_request_address,
	write_request_data,
	write_request_strobe,
	write_response_valid,
	write_response_ready,
	write_response_address,
	write_response_error,
	job_started,
	job_finished,
	task_id,
	active_descriptor,
	raw_valid,
	raw_co_group,
	raw_index,
	raw_data,
	out_valid,
	out_co_group,
	out_index,
	out_data,
	executor_start,
	executor_busy,
	executor_done,
	executor_error,
	executor_cancelled,
	result_valid,
	publish_seq,
	adapter_state,
	memory_owner,
	packet_valid,
	packet_bytes,
	camera_frame_id,
	camera_frame_done
);
	input wire [31:0] camera_frame_id;
	output wire camera_frame_done;
	parameter ROM_INIT_FILE = "boot128.hex";
	parameter integer ROM_WORDS = 8192;
	parameter integer CLOCK_HZ = 120000000;
	parameter integer BAUD = 115200;
	parameter [0:0] ENABLE_M = 1;
	parameter [0:0] ENABLE_CACHE = 1;
    // Exact qualified standalone CPU profile (joint timing requires a new run).
    parameter [0:0] ENABLE_ZBA = 1;
    parameter [0:0] ENABLE_ZBB = 1;
    parameter [0:0] ENABLE_BP = 1;
    parameter integer BP_INDEX_BITS = 7;
    parameter [0:0] BP_HASH_INDEX = 1;
    parameter [0:0] LOAD_USE_INTERLOCK = 0;
    parameter [0:0] PIPELINED_MUL = 1;
    parameter [0:0] ENABLE_RAS = 1;
    parameter [0:0] DUAL_ISSUE = 1;
	parameter integer ICACHE_SET_BITS = 8;
	parameter integer DCACHE_SET_BITS = 6;
	parameter integer AUX_PIPELINE_ENABLE = 2;
	parameter integer K1_WIDE_ENABLE = 1;
	input wire clk;
	input wire cpu_clk;
	input wire rst_n;
	input wire clear;
	input wire uart_rx;
	input wire [4:0] keys;
	output wire uart_tx;
	output wire halted;
	output wire [7:0] leds;
	output wire [63:0] cycle_count;
	output wire [63:0] instret_count;
	input wire ddr_ready;
	input wire memory_idle;
	input wire input_allow;
	input wire input_write_allow;
	output wire read_request_valid;
	input wire read_request_ready;
	output wire [31:0] read_request_address;
	input wire read_response_valid;
	output wire read_response_ready;
	input wire [31:0] read_response_address;
	input wire [31:0] read_response_data;
	input wire read_response_error;
	output wire write_request_valid;
	input wire write_request_ready;
	output wire [31:0] write_request_address;
	output wire [31:0] write_request_data;
	output wire [3:0] write_request_strobe;
	input wire write_response_valid;
	output wire write_response_ready;
	input wire [31:0] write_response_address;
	input wire write_response_error;
	output wire job_started;
	output wire job_finished;
	output wire [15:0] task_id;
	output wire [511:0] active_descriptor;
	output wire raw_valid;
	output wire [15:0] raw_co_group;
	output wire [31:0] raw_index;
	output wire [255:0] raw_data;
	output wire out_valid;
	output wire [15:0] out_co_group;
	output wire [31:0] out_index;
	output wire [63:0] out_data;
	output wire executor_start;
	output wire executor_busy;
	output wire executor_done;
	output wire executor_error;
	output wire executor_cancelled;
	output wire result_valid;
	output wire [31:0] publish_seq;
	output wire [4:0] adapter_state;
	output wire [1:0] memory_owner;
	output wire packet_valid;
	output wire [31:0] packet_bytes;
	wire cpu_reset, accel_reset;
	wire rst = accel_reset;
	wire accel_valid;
	wire accel_write;
	wire accel_ready;
	wire accel_error;
	wire [31:0] accel_addr;
	wire [31:0] accel_wdata;
	wire [31:0] accel_rdata;
	wire [3:0] accel_wstrb;
	wire [31:0] s_awaddr;
	wire [31:0] s_wdata;
	wire [31:0] s_araddr;
	wire [31:0] s_rdata;
	wire [3:0] s_wstrb;
	wire s_awvalid;
	wire s_awready;
	wire s_wvalid;
	wire s_wready;
	wire s_bvalid;
	wire s_bready;
	wire s_arvalid;
	wire s_arready;
	wire s_rvalid;
	wire s_rready;
	wire [1:0] s_bresp;
	wire [1:0] s_rresp;
	wire [2:0] awprot;
	wire [2:0] arprot;
	lyncore_soc #(
		.ROM_INIT_FILE(ROM_INIT_FILE),
		.ROM_WORDS(ROM_WORDS),
		.CLOCK_HZ(CLOCK_HZ),
		.BAUD(BAUD),
		.ENABLE_M(ENABLE_M),
		.ENABLE_CACHE(ENABLE_CACHE),
        .ENABLE_ZBA(ENABLE_ZBA), .ENABLE_ZBB(ENABLE_ZBB),
        .ENABLE_BP(ENABLE_BP), .BP_INDEX_BITS(BP_INDEX_BITS),
        .BP_HISTORY_BITS(0), .BP_HASH_INDEX(BP_HASH_INDEX),
        .LOAD_USE_INTERLOCK(LOAD_USE_INTERLOCK),
        .PIPELINED_MUL(PIPELINED_MUL), .ENABLE_RAS(ENABLE_RAS),
        .DUAL_ISSUE(DUAL_ISSUE), .DECOUPLED_FETCH(0),
		.ICACHE_SET_BITS(ICACHE_SET_BITS),
		.DCACHE_SET_BITS(DCACHE_SET_BITS),
		.ENABLE_ACCEL(1),
		.ACCEL_BASE(32'h30000000)
	) soc(
		.clk(cpu_clk),
		.rst(cpu_reset),
		.uart_rx(uart_rx),
		.keys(keys),
		.uart_tx(uart_tx),
		.camera_frame_id(camera_frame_id),
		.camera_frame_done(camera_frame_done),
		.leds(leds),
		.halted(halted),
		.cycle_count(cycle_count),
		.instret_count(instret_count),
		.accel_valid(accel_valid),
		.accel_write(accel_write),
		.accel_addr(accel_addr),
		.accel_wdata(accel_wdata),
		.accel_wstrb(accel_wstrb),
		.accel_ready(accel_ready),
		.accel_error(accel_error),
		.accel_rdata(accel_rdata)
	);
    wire d_valid,d_write,d_ready,d_error;
    wire [31:0] d_addr,d_wdata,d_rdata;
    wire [3:0] d_wstrb;
    lyncore_mmio_cdc mmio_cdc(
        .cpu_clk(cpu_clk),.accel_clk(clk),.reset_n(rst_n),
        .cpu_reset(cpu_reset),.accel_reset(accel_reset),
        .s_valid(accel_valid),.s_write(accel_write),.s_addr(accel_addr),
        .s_wdata(accel_wdata),.s_wstrb(accel_wstrb),.s_ready(accel_ready),
        .s_error(accel_error),.s_rdata(accel_rdata),
        .m_valid(d_valid),.m_write(d_write),.m_addr(d_addr),
        .m_wdata(d_wdata),.m_wstrb(d_wstrb),.m_ready(d_ready),
        .m_error(d_error),.m_rdata(d_rdata));
	lyncore_axi_lite_bridge cpu_bridge(
		.clk(clk),
		.rst(rst),
		.valid(d_valid),
		.write(d_write),
		.addr(d_addr),
		.wdata(d_wdata),
		.wstrb(d_wstrb),
		.ready(d_ready),
		.error(d_error),
		.rdata(d_rdata),
		.m_awaddr(s_awaddr),
		.m_awprot(awprot),
		.m_awvalid(s_awvalid),
		.m_awready(s_awready),
		.m_wdata(s_wdata),
		.m_wstrb(s_wstrb),
		.m_wvalid(s_wvalid),
		.m_wready(s_wready),
		.m_bresp(s_bresp),
		.m_bvalid(s_bvalid),
		.m_bready(s_bready),
		.m_araddr(s_araddr),
		.m_arprot(arprot),
		.m_arvalid(s_arvalid),
		.m_arready(s_arready),
		.m_rdata(s_rdata),
		.m_rresp(s_rresp),
		.m_rvalid(s_rvalid),
		.m_rready(s_rready)
	);
	network_mailbox_system_top #(
		.K1_WIDE_ENABLE(K1_WIDE_ENABLE),
		.CPU_OFFSET_ADDRESS(1),
		.AUX_PIPELINE_ENABLE(AUX_PIPELINE_ENABLE)
	) accelerator(
		.clk(clk),
		.rst_n(!accel_reset),
		.clear(clear),
		.ddr_ready(ddr_ready),
		.memory_idle(memory_idle),
		.input_allow(input_allow),
		.input_write_allow(input_write_allow),
		.s_awaddr(s_awaddr),
		.s_awvalid(s_awvalid),
		.s_awready(s_awready),
		.s_wdata(s_wdata),
		.s_wstrb(s_wstrb),
		.s_wvalid(s_wvalid),
		.s_wready(s_wready),
		.s_bresp(s_bresp),
		.s_bvalid(s_bvalid),
		.s_bready(s_bready),
		.s_araddr(s_araddr),
		.s_arvalid(s_arvalid),
		.s_arready(s_arready),
		.s_rdata(s_rdata),
		.s_rresp(s_rresp),
		.s_rvalid(s_rvalid),
		.s_rready(s_rready),
		.read_request_valid(read_request_valid),
		.read_request_ready(read_request_ready),
		.read_request_address(read_request_address),
		.read_response_valid(read_response_valid),
		.read_response_ready(read_response_ready),
		.read_response_address(read_response_address),
		.read_response_data(read_response_data),
		.read_response_error(read_response_error),
		.write_request_valid(write_request_valid),
		.write_request_ready(write_request_ready),
		.write_request_address(write_request_address),
		.write_request_data(write_request_data),
		.write_request_strobe(write_request_strobe),
		.write_response_valid(write_response_valid),
		.write_response_ready(write_response_ready),
		.write_response_address(write_response_address),
		.write_response_error(write_response_error),
		.job_started(job_started),
		.job_finished(job_finished),
		.task_id(task_id),
		.active_descriptor(active_descriptor),
		.raw_valid(raw_valid),
		.raw_co_group(raw_co_group),
		.raw_index(raw_index),
		.raw_data(raw_data),
		.out_valid(out_valid),
		.out_co_group(out_co_group),
		.out_index(out_index),
		.out_data(out_data),
		.executor_start(executor_start),
		.executor_busy(executor_busy),
		.executor_done(executor_done),
		.executor_error(executor_error),
		.executor_cancelled(executor_cancelled),
		.result_valid(result_valid),
		.publish_seq(publish_seq),
		.adapter_state(adapter_state),
		.memory_owner(memory_owner),
		.packet_valid(packet_valid),
		.packet_bytes(packet_bytes)
	);
endmodule
