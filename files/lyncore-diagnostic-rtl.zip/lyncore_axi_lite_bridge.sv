`timescale 1ns/1ps
// One ordered outstanding transaction. Completion is the AXI response handshake.
module lyncore_axi_lite_bridge (
    input logic clk, rst, valid, write,
    input logic [31:0] addr, wdata,
    input logic [3:0] wstrb,
    output logic ready, error,
    output logic [31:0] rdata,
    output logic [31:0] m_awaddr, m_wdata, m_araddr,
    output logic [2:0] m_awprot, m_arprot,
    output logic [3:0] m_wstrb,
    output logic m_awvalid, m_wvalid, m_bready, m_arvalid, m_rready,
    input logic m_awready, m_wready, m_bvalid, m_arready, m_rvalid,
    input logic [1:0] m_bresp, m_rresp,
    input logic [31:0] m_rdata
);
    typedef enum logic [2:0] {IDLE, WRITE_SEND, WRITE_RESPONSE, READ_SEND, READ_RESPONSE} state_t;
    state_t state;
    logic aw_pending, w_pending;
    assign m_awprot = 3'b001; // Privileged secure data, no security isolation here.
    assign m_arprot = 3'b001;
    assign m_awvalid = !rst && state == WRITE_SEND && aw_pending;
    assign m_wvalid = !rst && state == WRITE_SEND && w_pending;
    assign m_bready = !rst && state == WRITE_RESPONSE;
    assign m_arvalid = !rst && state == READ_SEND;
    assign m_rready = !rst && state == READ_RESPONSE;
    assign ready = !rst && valid && ((m_bready && m_bvalid) || (m_rready && m_rvalid));
    assign error = ready && ((state == WRITE_RESPONSE && m_bresp != 0) ||
                            (state == READ_RESPONSE && m_rresp != 0));
    assign rdata = m_rdata;
    always_ff @(posedge clk) begin
        if (rst) begin
            state <= IDLE; aw_pending <= 0; w_pending <= 0;
            m_awaddr <= 0; m_araddr <= 0; m_wdata <= 0; m_wstrb <= 0;
        end else case (state)
            IDLE: if (valid) begin
                if (write) begin
                    m_awaddr <= {addr[31:2], 2'b0}; m_wdata <= wdata; m_wstrb <= wstrb;
                    aw_pending <= 1; w_pending <= 1; state <= WRITE_SEND;
                end else begin m_araddr <= {addr[31:2], 2'b0}; state <= READ_SEND; end
            end
            WRITE_SEND: begin
                if (m_awvalid && m_awready) aw_pending <= 0;
                if (m_wvalid && m_wready) w_pending <= 0;
                if ((!aw_pending || m_awready) && (!w_pending || m_wready)) state <= WRITE_RESPONSE;
            end
            WRITE_RESPONSE: if (m_bvalid && m_bready) state <= IDLE;
            READ_SEND: if (m_arvalid && m_arready) state <= READ_RESPONSE;
            READ_RESPONSE: if (m_rvalid && m_rready) state <= IDLE;
            default: state <= IDLE;
        endcase
    end
endmodule
