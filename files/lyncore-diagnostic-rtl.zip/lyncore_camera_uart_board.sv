module lyncore_camera_uart_board (
 pix_clk,hs_out,vs_out,de_out,r_out,g_out,b_out,rstn_out,iic_tx_scl,iic_tx_sda,
	cmos1_pclk,cmos1_data,cmos1_href,cmos1_vsync,cmos1_scl,cmos1_sda,cmos1_reset,
	clk_27m,
	ref_clk_p,
	ref_clk_n,
	reset_n,
	uart_rx,
	keys_n,
	uart_tx,
	led,
	ddr3_addr,
	ddr3_ba,
	ddr3_ras_n,
	ddr3_cas_n,
	ddr3_we_n,
	ddr3_reset_n,
	ddr3_ck_p,
	ddr3_ck_n,
	ddr3_cke,
	ddr3_cs_n,
	ddr3_odt,
	ddr3_dm,
	ddr3_dq,
	ddr3_dqs_p,
	ddr3_dqs_n
) /* synthesis syn_allowed_resources = "blockmults=160" */;
	parameter ROM_INIT_FILE = "boot128.hex";
	parameter integer CORE_CLOCK_HZ = 120000000;
	input wire clk_27m;
	input wire ref_clk_p;
	input wire ref_clk_n;
	input wire reset_n;
	input wire uart_rx;
	input wire [3:0] keys_n;
	output wire uart_tx;
	output wire [7:0] led;
	output wire [14:0] ddr3_addr;
	output wire [2:0] ddr3_ba;
	output wire ddr3_ras_n;
	output wire ddr3_cas_n;
	output wire ddr3_we_n;
	output wire ddr3_reset_n;
	output wire ddr3_ck_p;
	output wire ddr3_ck_n;
	output wire ddr3_cke;
	output wire ddr3_cs_n;
	output wire ddr3_odt;
	output wire [3:0] ddr3_dm;
	inout wire [31:0] ddr3_dq;
	inout wire [3:0] ddr3_dqs_p;
	inout wire [3:0] ddr3_dqs_n;
 input wire cmos1_pclk,cmos1_href,cmos1_vsync;
 input wire [7:0] cmos1_data;
 inout wire cmos1_scl,cmos1_sda;output wire cmos1_reset;
 output wire pix_clk,hs_out,vs_out,de_out,rstn_out,iic_tx_scl;
 output wire [7:0] r_out,g_out,b_out;
 inout wire iic_tx_sda;
 wire clk,core_reset_n,ddr_init_done,cpu_clk120,cpu_locked,cfg_locked,cfg_clk,camera_cfg_clk;
 wire sensor_ready,initial_en,camera_power_reset,camera_config_reset,system_release;
 wire run_enable,raw_committed,tensor_committed,assets_ready,failed,halted;
 wire [7:0] cpu_led;wire [2:0] phase;
 wire [31:0] input_crc32,verified_bytes,committed_frame_id,phy_status;
 lyncore_clock120 cpu_clock(.clk_27m(clk_27m),.reset_n(reset_n),.clk_cpu(cpu_clk120),.locked(cpu_locked));
 wire overlay_capture,overlay_pixel_valid,overlay_packet_write,overlay_packet_valid,overlay_ready;
 wire [15:0] overlay_pixel_data;
 wire [31:0] overlay_frame_id,overlay_packet_addr,overlay_packet_data,overlay_packet_bytes;
 wire pixel_clk;
 lyncore_video_camera_clock clock_cfg(.clk_27m(clk_27m),.reset_n(reset_n),
  .pixel_clk(pixel_clk),.cfg_clk(cfg_clk),.camera_cfg_clk(camera_cfg_clk),.locked(cfg_locked));
 lyncore_hdmi_preview hdmi(.pixel_clk(pixel_clk),.cfg_clk(cfg_clk),
  .async_n(reset_n && cfg_locked),.clk(clk),.rst_n(system_release),
  .overlay_capture(overlay_capture), .overlay_pixel_valid(overlay_pixel_valid), .overlay_packet_write(overlay_packet_write), .overlay_packet_valid(overlay_packet_valid), .overlay_pixel_data(overlay_pixel_data), .overlay_frame_id(overlay_frame_id), .overlay_packet_addr(overlay_packet_addr), .overlay_packet_data(overlay_packet_data), .overlay_packet_bytes(overlay_packet_bytes),.frame_visible(),.overlay_ready(overlay_ready),.pix_clk(pix_clk),.hs_out(hs_out),.vs_out(vs_out),
  .de_out(de_out),.r_out(r_out),.g_out(g_out),.b_out(b_out),.rstn_out(rstn_out),
  .iic_tx_scl(iic_tx_scl),.iic_tx_sda(iic_tx_sda),.configured());
 lyncore_reset_release power_reset(.clk(camera_cfg_clk),.async_n(reset_n && cfg_locked),.release_n(camera_power_reset));
 power_on_delay power_sequence(.clk_50M(camera_cfg_clk),.reset_n(camera_power_reset),
  .camera1_rstn(cmos1_reset),.camera2_rstn(),.camera_pwnd(),.initial_en(initial_en));
 lyncore_reset_release config_reset(.clk(camera_cfg_clk),.async_n(reset_n && cfg_locked && cmos1_reset),.release_n(camera_config_reset));
 (* syn_preserve=1 *) reg [1:0] init_sync;
 always @(posedge camera_cfg_clk or negedge camera_config_reset)
  if(!camera_config_reset)init_sync<=0;else init_sync<={init_sync[0],initial_en};
 reg_config sensor_config(.clk_25M(camera_cfg_clk),.camera_rstn(camera_config_reset),.initial_en(init_sync[1]),
  .reg_conf_done(sensor_ready),.i2c_sclk(cmos1_scl),.i2c_sdat(cmos1_sda),.clock_20k(),.reg_index());
 lyncore_reset_release user_reset(.clk(clk),.async_n(reset_n && core_reset_n && cpu_locked && cfg_locked && ddr_init_done),.release_n(system_release));
 assign led={failed,run_enable,tensor_committed,raw_committed,sensor_ready,ddr_init_done,cfg_locked,cpu_locked};
 wire [27:0] axi_araddr;
 wire axi_aruser_ap;
 wire [3:0] axi_aruser_id;
 wire [3:0] axi_arlen;
 wire axi_arvalid;
 wire axi_arready;
 wire [255:0] axi_rdata;
 wire [3:0] axi_rid;
 wire axi_rlast;
 wire axi_rvalid;
 wire [27:0] axi_awaddr;
 wire axi_awuser_ap;
 wire [3:0] axi_awuser_id;
 wire [3:0] axi_awlen;
 wire axi_awvalid;
 wire axi_awready;
 wire [255:0] axi_wdata;
 wire [31:0] axi_wstrb;
 wire axi_wready;
 wire [3:0] axi_wusero_id;
 wire axi_wusero_last;
 lyncore_camera_uart_core #(.USER_CLOCK_HZ(125000000),.CPU_CLOCK_HZ(120000000),.BAUD(115200)) core(
  .clk(clk),.cpu_clk(cpu_clk120),.pclk(cmos1_pclk),.rst_n(system_release),.ddr_init_done(ddr_init_done),
  .sensor_configured(sensor_ready),.vsync(cmos1_vsync),.href(cmos1_href),.camera_data(cmos1_data),.frame_id(32'd20),
  .uart_rx(uart_rx),.overlay_ready(overlay_ready),.keys({1'b0,~keys_n}),.uart_tx(uart_tx),.leds(cpu_led),.halted(halted),.failed(failed),.phase(phase),
  .cpu_run_enable(run_enable),.raw_committed(raw_committed),.tensor_committed(tensor_committed),.assets_ready(assets_ready),
  .overlay_capture(overlay_capture), .overlay_pixel_valid(overlay_pixel_valid), .overlay_packet_write(overlay_packet_write), .overlay_packet_valid(overlay_packet_valid), .overlay_pixel_data(overlay_pixel_data), .overlay_frame_id(overlay_frame_id), .overlay_packet_addr(overlay_packet_addr), .overlay_packet_data(overlay_packet_data), .overlay_packet_bytes(overlay_packet_bytes),
  .input_crc32(input_crc32),.verified_bytes(verified_bytes),.committed_frame_id(committed_frame_id),
  .axi_araddr(axi_araddr),
  .axi_aruser_ap(axi_aruser_ap),
  .axi_aruser_id(axi_aruser_id),
  .axi_arlen(axi_arlen),
  .axi_arvalid(axi_arvalid),
  .axi_arready(axi_arready),
  .axi_rdata(axi_rdata),
  .axi_rid(axi_rid),
  .axi_rlast(axi_rlast),
  .axi_rvalid(axi_rvalid),
  .axi_awaddr(axi_awaddr),
  .axi_awuser_ap(axi_awuser_ap),
  .axi_awuser_id(axi_awuser_id),
  .axi_awlen(axi_awlen),
  .axi_awvalid(axi_awvalid),
  .axi_awready(axi_awready),
  .axi_wdata(axi_wdata),
  .axi_wstrb(axi_wstrb),
  .axi_wready(axi_wready),
  .axi_wusero_id(axi_wusero_id),
  .axi_wusero_last(axi_wusero_last));
	vendor_100pro_ddr3 memory(
		.clk_27m(clk_27m),
		.ref_clk_p(ref_clk_p),
		.ref_clk_n(ref_clk_n),
		.reset_n(reset_n && cpu_locked && cfg_locked),
		.core_clk(clk),
		.core_reset_n(core_reset_n),
		.ddr_init_done(ddr_init_done),
		.axi_araddr(axi_araddr),
		.axi_aruser_ap(axi_aruser_ap),
		.axi_aruser_id(axi_aruser_id),
		.axi_arlen(axi_arlen),
		.axi_arvalid(axi_arvalid),
		.axi_arready(axi_arready),
		.axi_rdata(axi_rdata),
		.axi_rid(axi_rid),
		.axi_rlast(axi_rlast),
		.axi_rvalid(axi_rvalid),
		.axi_awaddr(axi_awaddr),
		.axi_awuser_ap(axi_awuser_ap),
		.axi_awuser_id(axi_awuser_id),
		.axi_awlen(axi_awlen),
		.axi_awvalid(axi_awvalid),
		.axi_awready(axi_awready),
		.axi_wdata(axi_wdata),
		.axi_wstrb(axi_wstrb),
		.axi_wready(axi_wready),
		.axi_wusero_id(axi_wusero_id),
		.axi_wusero_last(axi_wusero_last),
		.ddr3_addr(ddr3_addr),
		.ddr3_ba(ddr3_ba),
		.ddr3_ras_n(ddr3_ras_n),
		.ddr3_cas_n(ddr3_cas_n),
		.ddr3_we_n(ddr3_we_n),
		.ddr3_reset_n(ddr3_reset_n),
		.ddr3_ck_p(ddr3_ck_p),
		.ddr3_ck_n(ddr3_ck_n),
		.ddr3_cke(ddr3_cke),
		.ddr3_cs_n(ddr3_cs_n),
		.ddr3_odt(ddr3_odt),
		.ddr3_dm(ddr3_dm),
		.ddr3_dq(ddr3_dq),
		.ddr3_dqs_p(ddr3_dqs_p),
		.ddr3_dqs_n(ddr3_dqs_n)
	);
endmodule
