`timescale 1ns/1ps    //这个执行文件可以体现出加速器自主执行的内涵。


//这玩意儿还有别的路径  就是pool和upsample上采样，接下来开始写写这俩路径。
//pool:     一个5x5的区域中找到一个最大的数字，是5x5最后输出一个数
//upsample：这个是一个1x1的数变成一个2x2的区域。   这是它们和原来的add/concat的最大区别，不是一个空间位置输出一次了，而是多个空间位置输出一个或者一个空间位置多次输出。
//因此这两种路径的数据流是:给算子喂完整的一帧数据，让算子自己产生输出流。

//Sequencer决定“下一项做什么”，Executor决定这一项怎么做。
//必须知道的是slot里面存的是特征图，但是特征图是由不同的tensor构成的，也就是说本质上实际上一张特征图由好几张特征图构成

// 执行一项 256 位任务：验证源缓存，装参数/LUT，供权重与算子源字，提交目标。
// 外部存储只提供带标签的事务，不参与算子循环或任务提交的控制。
module network_executor #(
    parameter integer MAX_WIDTH=640,
    parameter integer PSUM_DEPTH=256,
    parameter integer MAX_CO_GROUPS=128,
    parameter integer PE_LATENCY=7
) (
    input wire clk, rst_n, cancel,
    input wire task_valid,
    output wire task_ready,
    input wire [15:0] task_index,
    input wire [255:0] task_descriptor,   //这四项来源于sequencer的输出
    output wire busy,
    output reg compute_done, commit_done, error,
    output wire [15:0] completion_index,
    // kind=0：848 位八通道参数；1：低 8 位 LUT；2：低 32 位权重。
    // address 是本任务该 kind 文件内的元素编号，响应必须保持原标签。
    output wire memory_request_valid,
    input wire memory_request_ready,
    output wire [1:0] memory_request_kind,
    output wire [15:0] memory_request_task,
    output wire [31:0] memory_request_address,
    input wire memory_response_valid,
    output wire memory_response_ready,
    input wire [1:0] memory_response_kind,
    input wire [15:0] memory_response_task,
    input wire [31:0] memory_response_address,
    input wire [847:0] memory_response_data,
    input wire memory_response_error,
    output wire [2:0] source_config_slot,
    input wire source_config_valid,
    input wire [15:0] source_width, source_height, source_channels,
    output wire read_request_valid,
    input wire read_request_ready,
    output wire [2:0] read_request_slot,
    output wire [15:0] read_request_ci_group,
    output wire [31:0] read_request_index,
    input wire read_response_valid,
    output wire read_response_ready,
    input wire [2:0] read_response_slot,
    input wire [15:0] read_response_ci_group,
    input wire [31:0] read_response_index, read_response_pixel,
    input wire read_response_error,
    output wire write_start,
    input wire write_ready,
    output wire [2:0] write_slot,
    output wire [15:0] write_width, write_height, write_channels,
    output wire write_valid,
    input wire write_data_ready,
    output wire [15:0] write_co_group,
    output wire [31:0] write_index,
    output wire [63:0] write_data,
    output wire write_end, write_abort,
    input wire write_busy, write_done, write_error,
    output wire raw_valid,
    output wire [15:0] raw_co_group,
    output wire [31:0] raw_index,
    output wire [255:0] raw_data
);
    localparam [4:0] IDLE=0, CHECK_LEFT=1, CHECK_RIGHT=2,
        PARAM_REQ=3, PARAM_WAIT=4, LUT_START=5, LUT_REQ=6, LUT_WAIT=7,
        WRITE_START=8, CONV_START=9, CONV_RUN=10, GROUP_START=11,
        READ0_START=12, READ0_WAIT=13, READ1_START=14, READ1_WAIT=15,
        BINARY_SEND=16, BINARY_WAIT=17, STREAM_SEND=18, GROUP_WAIT=19,
        FINISH=20, COMMIT=21, COMMIT_WAIT=22, CANCEL=23;                //这是一个拥有24个路径的状态机，看起来是目前遇到的状态最复杂的状态机
    localparam [1:0] WEIGHT_IDLE=0, WEIGHT_REQ=1, WEIGHT_WAIT=2;
//接取任务：IDLE   CHECK_LEFT   CHECK_RIGHT(只有add/concat需要，这俩是特殊的，即便是读也是特殊的)
//Conv准备  PARAM_REQ/PARAM_WAIT   LUT_START/LUT_REQ/LUT_WAIT    WRITE_START   CONV_START/CONV_RUN
//其他算子：WRITE_START   GROUP_START    READ0/READ1    BINARY_SEND或者STREAM_SEND  GROUP_WAIT
//所有算子最后   FINISH   COMMIT  COMMIT_WAIT   IDLE
//异常：     CANCLE(取消) 

    reg [4:0] state;
    reg [1:0] weight_state;
    reg [255:0] d;
    reg [15:0] id, co;
    reg [31:0] input_index, output_count, load_address, weight_base, weight_position;
    reg [63:0] word0, word1;
    reg group_done_seen, memory_pending;
    reg [31:0] read_pending;
    reg [1:0] expected_kind;
    reg [31:0] expected_address;
    wire cancelling = state==CANCEL;
    // 取消时复位只作用于本执行端计算核；缓存有效图和外部存储仍保留。
    wire core_rst_n = rst_n && !cancelling;
    wire [2:0] op=d[2:0], lhs=d[5:3], rhs=d[8:6], dst=d[11:9];
    wire [15:0] iw=d[31:16], ih=d[47:32], ow=d[63:48], oh=d[79:64];     //输入宽高和输出宽高
    wire [15:0] lc=d[95:80], rc=d[111:96], oc=d[127:112];                //左右通道输入和输出信息。
    wire is_conv = op==0 || op==5;         //op=0表示的是普通卷积，op=5表示的是STEM，是官方的6x6卷积。
    wire [16:0] groups=({1'b0,oc}+17'd7)>>3;      //这里是在表示groups=oc/8;是在计算当前channel的groups的总数，一个groups的通道数是8
    wire [16:0] cin_groups=op==5 ? 17'd3 : ({1'b0,lc}+17'd3)>>2;    //这里是在表示cin_groups，因为卷积的输入并行度是4，所以需要单独计算输入的时候的通道的组数
    wire [31:0] in_pixels={16'd0,iw}*{16'd0,ih};                    //计算输入时的空间位置像素数
    wire [31:0] out_pixels={16'd0,ow}*{16'd0,oh};                   //计算输出时的空间位置像素数
    wire [47:0] total_words={16'd0,out_pixels}*{31'd0,groups};      //每个空间位置*每个空间位置对应的组数，最后的计算结果是表示的这个任务最终必须往目标 Slot 完整写入 total_words 个 64bit word  最后的output_take将会和total_words对照，不然就会报错
    wire [16:0] padded_w={1'b0,iw}+(d[14] ? 17'd2 : 17'd0);
    wire [16:0] padded_h={1'b0,ih}+(d[14] ? 17'd2 : 17'd0);
    wire [16:0] kernel=d[12] ? 17'd1 : 17'd3;
    wire [16:0] conv_w=((padded_w-kernel)>>(d[13] ? 1 : 0))+17'd1;
    wire [16:0] conv_h=((padded_h-kernel)>>(d[13] ? 1 : 0))+17'd1;    //这里就是在重新拆解d的指令内容。
    wire bad_descriptor = op>5 || dst==lhs || dst==rhs || iw==0 || ih==0 || ow==0 || oh==0 ||
        lc==0 || rc==0 || oc==0 || iw>MAX_WIDTH || total_words[47:32]!=0 ||
        d[159] || d[191] || d[199:198]!=0 || d[207:206]!=0 || d[255:208]!=0 ||
        (is_conv && groups>MAX_CO_GROUPS) ||
        (op==0 && (padded_w<kernel || padded_h<kernel || conv_w!={1'b0,ow} || conv_h!={1'b0,oh})) ||
        (op==1 && (lc!=rc || oc!=lc || ow!=iw || oh!=ih)) ||
        (op==2 && ({1'b0,lc}+{1'b0,rc}!={1'b0,oc} || ow!=iw || oh!=ih)) ||
        (op==3 && (oc!=lc || ow!=iw || oh!=ih)) ||
        (op==4 && (oc!=lc || {1'b0,ow}!={iw,1'b0} || {1'b0,oh}!={ih,1'b0})) ||
        (op==5 && (lc!=3 || iw<2 || ih<2 || iw[0] || ih[0] || ow!=(iw>>1) || oh!=(ih>>1) || d[12] || !d[13] || d[14])) ||
        (!is_conv && d[15:12]!=0);
    assign task_ready = rst_n && !cancel && state==IDLE;
    assign busy = state!=IDLE;
    assign completion_index = id;
    assign source_config_slot = state==CHECK_RIGHT ? rhs : lhs;    
    wire bad_source = !source_config_valid || source_width!=iw || source_height!=ih ||
        source_channels!=(state==CHECK_RIGHT ? rc : lc);

    // 参数和运行期权重共用一个最多一笔在途的存储端口。
    wire conv_ready, conv_busy, conv_done, conv_error, cfg_ready, lut_ready, lut_valid;
    wire weight_request, weight_ready, ifm_request, ifm_ready, ifm_valid;
    wire [31:0] ifm_pixel;
    wire [15:0] source_ci, weight_ci, current_co;
    wire conv_out_valid;
    wire [63:0] conv_out_data;
    wire [15:0] conv_out_co;
    wire [31:0] conv_out_index;
    wire response_bad = memory_response_error || memory_response_task!=id ||
        memory_response_kind!=expected_kind || memory_response_address!=expected_address;
    assign memory_request_valid = rst_n && !cancel && (state==PARAM_REQ || state==LUT_REQ ||
        (state==CONV_RUN && weight_state==WEIGHT_REQ));
    assign memory_request_kind = state==PARAM_REQ ? 2'd0 : state==LUT_REQ ? 2'd1 : 2'd2;
    assign memory_request_task = id;
    assign memory_request_address = state==CONV_RUN ? weight_base+weight_position : load_address;
    assign memory_response_ready = rst_n && (cancelling ? memory_pending : !cancel &&
        (state==PARAM_WAIT ? cfg_ready : state==LUT_WAIT ? lut_ready :
        state==CONV_RUN && weight_state==WEIGHT_WAIT ? weight_ready : 1'b0));
    wire memory_take = memory_response_valid && memory_response_ready;
    wire cfg_we = state==PARAM_WAIT && memory_response_valid && !response_bad && !cancel;
    wire weight_valid = state==CONV_RUN && weight_state==WEIGHT_WAIT && memory_response_valid && !response_bad && !cancel;
    conv_task_top #(.MAX_WIDTH(MAX_WIDTH),.PSUM_DEPTH(PSUM_DEPTH),
        .MAX_CO_GROUPS(MAX_CO_GROUPS),.PE_LATENCY(PE_LATENCY)) conv (
        .clk(clk),.rst_n(core_rst_n),.layer_start(state==CONV_START && conv_ready && write_data_ready && !cancel),
        .frame_width(iw),.frame_height(ih),.cin_groups(op==5 ? 16'd1 : cin_groups[15:0]),.cout_groups(groups[15:0]),
        .kernel_6x6(op==5),.kernel_1x1(d[12]),.stride_2(d[13]),.padding_1(d[14]),.silu_enable(d[15]),
        .layer_ready(conv_ready),.layer_busy(conv_busy),.layer_done(conv_done),.layer_error(conv_error),
        .cfg_we(cfg_we),.cfg_ready(cfg_ready),.cfg_co_group(load_address[15:0]),
        .cfg_bias_bus(memory_response_data[255:0]),.cfg_linear_multiplier_bus(memory_response_data[503:256]),
        .cfg_linear_shift_bus(memory_response_data[551:504]),.cfg_grid_multiplier_bus(memory_response_data[799:552]),
        .cfg_grid_shift_bus(memory_response_data[847:800]),.lut_load_start(state==LUT_START && !cancel),
        .lut_load_valid(state==LUT_WAIT && memory_response_valid && !response_bad && !cancel),
        .lut_load_ready(lut_ready),.lut_load_data(memory_response_data[7:0]),.lut_valid(lut_valid),
        .weight_request(weight_request),.weight_ready(weight_ready),.weight_valid(weight_valid),
        .weight_word(memory_response_data[31:0]),.ifm_request(ifm_request),.ifm_ready(ifm_ready),
        .ifm_valid(ifm_valid),.ifm_pixel(ifm_pixel),.source_ci_group(source_ci),.weight_ci_group(weight_ci),
        .current_co_group(current_co),.current_tile_base(),.raw_valid(raw_valid),.raw_co_group(raw_co_group),
        .raw_index(raw_index),.raw_data(raw_data),.out_valid(conv_out_valid),.out_co_group(conv_out_co),
        .out_index(conv_out_index),.out_data(conv_out_data)
    );
    wire frame_ready, frame_busy, frame_done, frame_error;
    wire frame_request_valid, frame_request_bank, frame_response_ready;
    wire [15:0] frame_request_ci;
    wire [31:0] frame_request_index;
    feature_map_reader frame_reader (
        .clk(clk),.rst_n(core_rst_n),.frame_start(ifm_request && state==CONV_RUN && !cancel),
        .frame_ready(frame_ready),.frame_bank(lhs[0]),.frame_ci_group(source_ci),
        .source_valid(source_config_valid),.source_pixels(in_pixels),.source_channels(lc),.abort(cancel),
        .busy(frame_busy),.frame_done(frame_done),.error(frame_error),.request_valid(frame_request_valid),
        .request_ready(read_request_ready && state==CONV_RUN),.request_bank(frame_request_bank),
        .request_ci_group(frame_request_ci),.request_index(frame_request_index),
        .response_valid(read_response_valid && state==CONV_RUN),.response_ready(frame_response_ready),
        .response_bank(read_response_slot[0]),.response_ci_group(read_response_ci_group),
        .response_index(read_response_index),.response_pixel(read_response_pixel),
        .response_error(read_response_error || (read_response_valid && read_response_slot!=lhs)),
        .out_valid(ifm_valid),.out_ready(ifm_ready),.out_pixel(ifm_pixel)
    );          //这里调用了feature map reader主要服务于的是conv的第三个数据流feature map，权重从外部静态存储读，而输入的feature map来自于lhs slot ，不需要从内存中得到request，而是从 feature_map_reader中得到数据
//在这里我们可以区分一下conv中用到的四种数据的不同，它们分别是parameter(参数) silu lut(使用silu需要用到的查表信息)    weight(比如conv kernel)    feature map(比如输入激活) 
//parameter:每一层固定  来源于外部存储，即内存   去向是postprocess后处理
//silu lut：每一层固定，来源于外部存储，
//weight：每个tile一变化，来源于外部存储
//feature map：  来源于lhs slot，每个空间位置一变化
    // Concat 首尾通道可能位于两个不同源字；Add 固定取两侧同组、同位置。
    wire [18:0] first_channel={co,3'b000};
    wire [18:0] last_channel=first_channel+19'd7<oc ? first_channel+19'd7 : {3'd0,oc}-19'd1;
    wire first_right=first_channel>=lc, last_right=last_channel>=lc;
    wire [15:0] first_group=(first_right ? first_channel-lc : first_channel)>>3;
    wire [15:0] last_group=(last_right ? last_channel-lc : last_channel)>>3;
    wire second_read=op==1 || (op==2 && (first_right!=last_right || first_group!=last_group));
    wire reading_second=state==READ1_START || state==READ1_WAIT;
    wire [2:0] word_slot=op==2 ? (reading_second ? (last_right ? rhs : lhs) : (first_right ? rhs : lhs)) : reading_second ? rhs : lhs;
    wire [15:0] word_group=op==2 ? (reading_second ? last_group : first_group) : co;
    wire [15:0] word_channels=op==2 ? (reading_second ? (last_right ? rc : lc) : (first_right ? rc : lc)) : reading_second ? rc : lc;
    wire word_ready, word_busy, word_error, word_request_valid, word_response_ready, word_valid;
    wire [2:0] word_request_slot;
    wire [15:0] word_request_ci;
    wire [31:0] word_request_index;
    wire [63:0] word_data;
    tensor_word_reader word_reader (
        .clk(clk),.rst_n(core_rst_n),.clear(cancel),
        .start((state==READ0_START || state==READ1_START) && word_ready && !cancel),.ready(word_ready),
        .source_slot(word_slot),.source_channels(word_channels),.source_co_group(word_group),.source_index(input_index),
        .busy(word_busy),.error(word_error),.request_valid(word_request_valid),
        .request_ready(read_request_ready && state!=CONV_RUN),.request_slot(word_request_slot),
        .request_ci_group(word_request_ci),.request_index(word_request_index),
        .response_valid(read_response_valid && state!=CONV_RUN && !cancelling),.response_ready(word_response_ready),
        .response_slot(read_response_slot),.response_ci_group(read_response_ci_group),
        .response_index(read_response_index),.response_pixel(read_response_pixel),.response_error(read_response_error),
        .out_valid(word_valid),.out_ready(state==READ0_WAIT || state==READ1_WAIT),.out_data(word_data)
    );
    assign read_request_valid = rst_n && !cancel && !cancelling && (state==CONV_RUN ? frame_request_valid : word_request_valid);
    assign read_request_slot = state==CONV_RUN ? lhs : word_request_slot;
    assign read_request_ci_group = state==CONV_RUN ? frame_request_ci : word_request_ci;
    assign read_request_index = state==CONV_RUN ? frame_request_index : word_request_index;
    assign read_response_ready = rst_n && (cancelling ? read_pending!=0 : !cancel &&
        (state==CONV_RUN ? frame_response_ready : word_response_ready));

    wire add_in_ready, add_valid, cat_in_ready, cat_valid;
    wire [63:0] add_data, cat_data;
    wire [15:0] add_co, cat_co;
    wire [31:0] add_index, cat_index;
    wire op_clear=cancel || state==CHECK_LEFT;
    wire op_out_ready=write_data_ready && !cancel && !cancelling;
    residual_add add (
        .clk(clk),.rst_n(core_rst_n),.clear(op_clear),.in_valid(state==BINARY_SEND && op==1 && !cancel),
        .in_ready(add_in_ready),.in_left(word0),.in_right(word1),.left_multiplier(d[158:128]),
        .right_multiplier(d[190:160]),.left_shift(d[197:192]),.right_shift(d[205:200]),
        .in_co_group(co),.in_index(input_index),.out_valid(add_valid),.out_ready(op_out_ready),
        .out_data(add_data),.out_co_group(add_co),.out_index(add_index)
    );
    channel_concat concat (
        .clk(clk),.rst_n(core_rst_n),.clear(op_clear),.in_valid(state==BINARY_SEND && op==2 && !cancel),
        .in_ready(cat_in_ready),.in_word0(word0),.in_word1(word1),.left_channels(lc),.right_channels(rc),
        .left_multiplier(d[158:128]),.right_multiplier(d[190:160]),.left_shift(d[197:192]),.right_shift(d[205:200]),
        .in_co_group(co),.in_index(input_index),.out_valid(cat_valid),.out_ready(op_out_ready),
        .out_data(cat_data),.out_co_group(cat_co),.out_index(cat_index)
    );
    wire pool_ready, pool_busy, pool_done, pool_error, pool_in_ready, pool_valid;
    wire up_ready, up_busy, up_done, up_error, up_in_ready, up_valid;
    wire [63:0] pool_data, up_data;
    wire [15:0] pool_co, up_co;
    wire [31:0] pool_index, up_index;
    maxpool5x5 #(.MAX_WIDTH(MAX_WIDTH)) pool (
        .clk(clk),.rst_n(core_rst_n),.clear(op_clear),.frame_start(state==GROUP_START && op==3 && pool_ready && !cancel),   //接下来我要送一整张属于co_group=co的空间特征图
        .frame_ready(pool_ready),.frame_width(iw),.frame_height(ih),.frame_co_group(co),                                    //同时给这张特征图给出基础信息，比如长和宽还有co也就是第几组，非常像feature_map_reader中的“frame”的概念。     
        .busy(pool_busy),.frame_done(pool_done),.error(pool_error),.in_valid(state==STREAM_SEND && op==3 && !cancel),           //之后会进入tensor_word_reader阶段，不过区别是这里没有第二个输入源，所以，second_read一直是false（说一嘴，这里的基础信息是给出相关的标签，reader这个行为就会返回相关的标签的64bit word）
        .in_ready(pool_in_ready),.in_data(word0),.out_valid(pool_valid),.out_ready(op_out_ready),
        .out_data(pool_data),.out_co_group(pool_co),.out_index(pool_index)
    );
    upsample2x #(.MAX_WIDTH(MAX_WIDTH)) up (
        .clk(clk),.rst_n(core_rst_n),.clear(op_clear),.frame_start(state==GROUP_START && op==4 && up_ready && !cancel),
        .frame_ready(up_ready),.frame_width(iw),.frame_height(ih),.frame_co_group(co),
        .busy(up_busy),.frame_done(up_done),.error(up_error),.in_valid(state==STREAM_SEND && op==4 && !cancel),
        .in_ready(up_in_ready),.in_data(word0),.out_valid(up_valid),.out_ready(op_out_ready),
        .out_data(up_data),.out_co_group(up_co),.out_index(up_index)
    );
    wire result_valid=is_conv ? conv_out_valid : op==1 ? add_valid : op==2 ? cat_valid : op==3 ? pool_valid : up_valid;       //这两行是给不同的算子类型做了一个统一的输出有效信号和输出有效数据，没有进行分类，是一个不错的统一出口。
    wire [63:0] result_data=is_conv ? conv_out_data : op==1 ? add_data : op==2 ? cat_data : op==3 ? pool_data : up_data;      //
    assign write_co_group=is_conv ? conv_out_co : op==1 ? add_co : op==2 ? cat_co : op==3 ? pool_co : up_co;
    assign write_index=is_conv ? conv_out_index : op==1 ? add_index : op==2 ? cat_index : op==3 ? pool_index : up_index;
    assign write_slot=dst;
    assign write_width=ow; assign write_height=oh; assign write_channels=oc;
    assign write_start=rst_n && !cancel && state==WRITE_START && write_ready;
    assign write_valid=rst_n && !cancel && state!=IDLE && !cancelling && result_valid;
    assign write_end=rst_n && !cancel && state==COMMIT;
    assign write_abort=rst_n && cancelling;
    function [63:0] zero_tail;
        input [63:0] data;
        input [15:0] group_number, channels;
        integer lane;
        begin
            for (lane=0; lane<8; lane=lane+1)
                zero_tail[lane*8 +: 8]=({group_number,3'b000}+lane)<channels ? data[lane*8 +: 8] : 8'd0;
        end
    endfunction
    assign write_data=zero_tail(result_data,write_co_group,oc);
    wire write_take=write_valid && write_data_ready;    //有一个结果真正写入目标buffer,那么write_take置一
    wire [47:0] result_address={32'd0,write_co_group}*{16'd0,out_pixels}+{16'd0,write_index};
    wire fault = write_error || conv_error || frame_error || word_error || pool_error || up_error ||
        (memory_take && !cancelling && response_bad) ||
        (write_valid && (is_conv && !write_data_ready || write_take &&
            (write_index>=out_pixels || result_address!={16'd0,output_count} || result_address>=total_words))) ||
        (state==CONV_RUN && weight_request && weight_state!=WEIGHT_IDLE);
    always @(posedge clk or negedge rst_n) begin
        if (!rst_n) begin
            state<=IDLE; weight_state<=WEIGHT_IDLE; d<=0; id<=0; co<=0; input_index<=0; output_count<=0;
            load_address<=0; weight_base<=0; weight_position<=0; word0<=0; word1<=0; group_done_seen<=0;
            compute_done<=0; commit_done<=0; error<=0; memory_pending<=0; read_pending<=0;
            expected_kind<=0; expected_address<=0;
        end else begin
            compute_done<=0; commit_done<=0; error<=0;
            if (memory_request_valid && memory_request_ready) begin
                memory_pending<=1; expected_kind<=memory_request_kind; expected_address<=memory_request_address;
            end
            if (memory_take) memory_pending<=0;
            case ({read_request_valid && read_request_ready,read_response_valid && read_response_ready})
                2'b10: read_pending<=read_pending+1'b1;
                2'b01: read_pending<=read_pending-1'b1;
                default: begin end
            endcase
            if (write_take) output_count<=output_count+1'b1;     //每发生一次write_take 就会对output_count加一，注意不是产生了result_valid就加一的，而是产生了write_valid&&write_data_ready才真正完成加一的，也就是产生结果和完成写入本来就是两件无法等同的事情
            if (pool_done || up_done) group_done_seen<=1;        //当pool或者up_done的最后一个输出完成的时候，把done_seen拉高，这样的话最后一个输出握手就真正完成了
            if ((cancel || fault) && state!=IDLE && !cancelling) begin
                state<=CANCEL; weight_state<=WEIGHT_IDLE;
                if (fault && !cancel) error<=1;
            end else case (state)
                IDLE: if (task_valid && task_ready) begin
                    d<=task_descriptor; id<=task_index; co<=0; input_index<=0; output_count<=0;
                    load_address<=0; group_done_seen<=0; state<=CHECK_LEFT;
                end                                                                              //注意，这里把指令内容锁存到了d中，之后从d里重新拆解了指令，赋值给不同的新变量
                CHECK_LEFT: if (bad_descriptor || bad_source) begin state<=CANCEL; error<=1; end
                    else if (op==1 || op==2) state<=CHECK_RIGHT;      //如果要add或者concat继续检查right
                    else state<=is_conv ? PARAM_REQ : WRITE_START;    //需要卷积的话，不需要检查right，直接跳转到别的状态 
                CHECK_RIGHT: if (bad_source) begin state<=CANCEL; error<=1; end
                    else state<=WRITE_START;
                PARAM_REQ: if (memory_request_valid && memory_request_ready) state<=PARAM_WAIT;
                PARAM_WAIT: if (memory_take) begin
                    if (load_address==groups-1'b1) begin load_address<=0; state<=d[15] ? LUT_START : WRITE_START; end   //d[15]决定是否开始单独加载lut，目前的阶段是开始前的参数准备阶段。如果有silu，那么路径就会是param  lut_start  lut_req   lut_wait
                    else begin load_address<=load_address+1'b1; state<=PARAM_REQ; end                                       //没有的话，路径就是param  然后直接准备写输出
                end
                LUT_START: if (conv_ready) state<=LUT_REQ;
                LUT_REQ: if (memory_request_valid && memory_request_ready) state<=LUT_WAIT;
                LUT_WAIT: if (memory_take) begin
                    if (load_address==1023) begin load_address<=0; state<=WRITE_START; end   //当load_address加载到了1023的时候（这个数字代表着的是lut表中的所有数，正好是1024个） 将地址归零并准备可以开始卷积，这是一个层级静态配置，一层装好之后可以反复利用 和 conv加载的其他参数一样
                    else begin load_address<=load_address+1'b1; state<=LUT_REQ; end                        
                end
                WRITE_START: if (write_start) state<=is_conv ? CONV_START : (op==3 || op==4) ? GROUP_START : READ0_START;
                CONV_START: if (conv_ready && write_data_ready) state<=CONV_RUN;
                CONV_RUN: begin
                    if (weight_request) begin    //weight_request是由底层来的，不由这个文件得到。我要开始算新的 (co_group, ci_group) 了，请把对应 tile 权重给我
                        weight_base<=({16'd0,current_co}*{15'd0,cin_groups}+{16'd0,weight_ci})*(d[12] ? 32'd8 : 32'd72);   //权重地址公式，前面计算的是当前是第几号weight_tile，后面再乘8或者72就可以计算出目前这个卷积核的基地址,然后就得从内存中取出来weight的地址
                        weight_position<=0; weight_state<=WEIGHT_REQ;
                    end else if (weight_state==WEIGHT_REQ && memory_request_valid && memory_request_ready) weight_state<=WEIGHT_WAIT;
                    else if (weight_state==WEIGHT_WAIT && memory_take) begin
                        if (weight_position==(d[12] ? 32'd7 : 32'd71)) weight_state<=WEIGHT_IDLE;   //权重这个参数并不会提前载入到conv开始之前，因为整体太过庞大，所以每次只会加载一个tile，一个tile有288个int8，也就是72次读取，因为mem每次可以提供4bytes，而如果卷积核尺寸是1x1，就只需要8次读取了。
                        else begin weight_position<=weight_position+1'b1; weight_state<=WEIGHT_REQ; end
                    end
                    if (conv_done && !frame_busy && read_pending==0 && weight_state==WEIGHT_IDLE && !memory_pending) state<=FINISH;
                end
                GROUP_START: if (op==3 ? pool_ready : up_ready) begin group_done_seen<=0; state<=READ0_START; end   //值得注意的是，group在pool  upsample阶段都不会改变，所以可以一组一组处理。然后直接状态跳转read0;
                READ0_START: if (word_ready) state<=READ0_WAIT;
                READ0_WAIT: if (word_valid) begin
                    word0<=word_data;
                    if (second_read) state<=READ1_START;
                    else begin word1<=word_data; state<=op==1 || op==2 ? BINARY_SEND : STREAM_SEND; end
                end
                READ1_START: if (word_ready) state<=READ1_WAIT;
                READ1_WAIT: if (word_valid) begin word1<=word_data; state<=BINARY_SEND; end
                BINARY_SEND: if (op==1 ? add_in_ready : cat_in_ready) state<=BINARY_WAIT;
                BINARY_WAIT: if (write_take) begin
                    if (input_index!=out_pixels-1'b1) begin input_index<=input_index+1'b1; state<=READ0_START; end
                    else if ({1'b0,co}!=groups-1'b1) begin co<=co+1'b1; input_index<=0; state<=READ0_START; end
                    else state<=FINISH;
                end
                STREAM_SEND: if (op==3 ? pool_in_ready : up_in_ready) begin
                    if (input_index!=in_pixels-1'b1) begin input_index<=input_index+1'b1; state<=READ0_START; end      //再来看这个状态下是怎么遍历输入的？如果空间位置还没到最后一个像素，那么就把状态跳转到read0，顺便给相关的空间位置加一。而所谓的read0就是把当前空间位置的八通道给读出来。没有别的意思，代码级实现暂时不用看。
                    else state<=GROUP_WAIT;                                                                             //在这里可以解释一下read0_wait，wait的原因是ram的读不是组合读，所以读的时候会等待一段时间，把每次读出来的高低部分拼起来，所以一点会有多余的时间，read0_wait就是因此而生的，在等待一个reader把一个真正的64bit word准备好，然后才能进行下一步，他和start构成了完整的read0
                end                 //在这个状态下，pool 和 upsample的valid会产生，word0就可以作为输入了。
                GROUP_WAIT: if (group_done_seen && !word_busy && read_pending==0) begin        //把三个条件翻译一下，就是   算子说这一组结束了，tensor_word_reader确实没有再读别的数据，也没有别的buffer响应在路上，这样的话就可以认为一个8通道祖彻底结束了。
                    if (output_count!=({16'd0,co}+32'd1)*out_pixels) begin state<=CANCEL; error<=1; end
                    else if ({1'b0,co}!=groups-1'b1) begin co<=co+1'b1; input_index<=0; state<=GROUP_START; end
                    else state<=FINISH; 
                end                
                FINISH: if (output_count!={total_words[31:0]}) begin state<=CANCEL; error<=1; end
                    else begin compute_done<=1; state<=COMMIT; end   //如果目前完成的写入计数不等于所有的word数量，就会报错，然后正确的话就会跳转状态
                COMMIT: state<=COMMIT_WAIT;     //COMMIT存在的主要意义是制造一个明确的一拍脉冲，告诉feature_map_buffer所有的tensor都已经写完了，请你检查并提交。
                COMMIT_WAIT: if (write_done) begin commit_done<=1; state<=IDLE; end
                CANCEL: if (!memory_pending && read_pending==0 && !write_busy) begin state<=IDLE; weight_state<=WEIGHT_IDLE; end
                default: begin state<=CANCEL; error<=1; end
            endcase
        end
    end
endmodule

//目前简单说说尾声部分，尾声部分的主线是这样的，算子主体执行完  FINISH   确认输出数量完全正确   compute_done=1   COMMIT  write_end=1   feature map buffer提交整张Tensor  COMMIT_wait  write_done=1  commit_done=1  IDLE 
//因此算完了不等于完成了，算完并且保存起来，写完了才是真的成功。

//feature_map_reader   一次得到某个4通道组的一整张HxW特征图流，也就是这家伙每次直接读一张图    并且有一个特点是，reader内部负责空间遍历，每次会自己index++
//tensor_word_reader    一次得到某个空间位置的一个8通道word  因此想要实现，必须把每次得到的4个通道拼成8通道，每次的输出一定是64bit，也就是这家伙每次需要你给出要读的空间位置的参数，然后他负责把特定的空间位置上的数读出来。如果没有收到start就不会读
//                       对于word_reader，空间位置index++的指令是由executor发出的，内部只负责执行读出来和拼起来两件事。  上面的feature_map_reader只服务于conv一种运算，后面的word_reader服务于其他的算子类型                   