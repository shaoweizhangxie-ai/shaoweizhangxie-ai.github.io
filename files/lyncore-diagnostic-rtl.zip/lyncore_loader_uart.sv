`timescale 1ns/1ps
// Reuse the frozen eight-byte 8N1 UART. One buffered RX byte and one ACK TX.
module lyncore_loader_uart #(
    parameter integer CLOCK_HZ=125000000,BAUD=115200
)(
    input wire clk,rst_n,rx,output wire tx,
    output reg byte_valid,output reg [7:0] byte_data,input wire byte_ready,
    input wire ack_valid,input wire [7:0] ack_data,output wire ack_ready,
    output wire tx_idle,output reg transport_error
);
    localparam [1:0] POLL=0,RX_DATA=1,TX_DATA=2;
    reg [1:0] state;
    reg tx_pending,tx_active,tx_seen_busy;
    reg [7:0] tx_byte;
    wire ready,error;
    wire [31:0] rdata;
    wire valid=rst_n;
    wire write=state==TX_DATA;
    wire [3:0] word_addr=state==POLL?4'd1:4'd0;
    lyncore_uart #(.CLOCK_HZ(CLOCK_HZ),.BAUD(BAUD)) uart(
        .clk(clk),.rst(!rst_n),.rx(rx),.tx(tx),.irq(),
        .valid(valid),.write(write),.word_addr(word_addr),.wdata({24'd0,tx_byte}),
        .wstrb(4'b0001),.ready(ready),.error(error),.rdata(rdata));
    assign ack_ready=rst_n && !tx_pending && !tx_active;
    assign tx_idle=ack_ready;
    always @(posedge clk or negedge rst_n)begin
        if(!rst_n)begin
            state<=POLL;byte_valid<=0;byte_data<=0;tx_pending<=0;tx_active<=0;tx_seen_busy<=0;
            tx_byte<=0;transport_error<=0;
        end else begin
            if(byte_valid && byte_ready)byte_valid<=0;
            if(ack_valid && ack_ready)begin tx_pending<=1;tx_byte<=ack_data;end
            if(valid && ready)begin
                if(error)transport_error<=1;
                case(state)
                    POLL:begin
                        if(|rdata[4:3])transport_error<=1;
                        if(tx_active)begin
                            if(rdata[2])tx_seen_busy<=1;
                            else if(tx_seen_busy)begin tx_active<=0;tx_seen_busy<=0;end
                        end
                        if(tx_pending)state<=TX_DATA;
                        else if(rdata[0] && !byte_valid)state<=RX_DATA;
                    end
                    RX_DATA:begin byte_data<=rdata[7:0];byte_valid<=1;state<=POLL;end
                    TX_DATA:begin tx_pending<=0;tx_active<=1;tx_seen_busy<=0;state<=POLL;end
                    default:state<=POLL;
                endcase
            end
        end
    end
endmodule
