`timescale 1ns/1ps
// Two ways, 16-byte lines, write-through/no-write-allocate. One CPU request.
// Async hit reads; byte banks share one write address and need no reset.
module lyncore_cache #(parameter integer SET_BITS=6, parameter bit FETCH_PAIR=0,
                       parameter integer ADDRESS_BITS=32, parameter bit LOOKAHEAD=0,
                       parameter bit HOLD_PREVIEW=0) (
    input logic clk, rst, invalidate,
    input logic cpu_valid, cpu_write, cpu_cacheable,
    input logic [31:0] cpu_addr, cpu_wdata,
    input logic [31:0] preview_addr,
    input logic preview_stall,
    input logic [3:0] cpu_wstrb,
    output logic cpu_ready, cpu_error,
    output logic [31:0] cpu_rdata,
    output logic cpu_second_valid,
    output logic [31:0] cpu_second_data,
    output logic line_valid,
    output logic [31:0] line_addr,
    input logic line_ready, line_error,
    input logic [127:0] line_rdata,
    output logic word_valid, word_write,
    output logic [31:0] word_addr, word_wdata,
    output logic [3:0] word_wstrb,
    input logic word_ready, word_error,
    input logic [31:0] word_rdata,
    output logic [31:0] hit_count, miss_count
);
    localparam integer SETS=1<<SET_BITS, TAG_BITS=ADDRESS_BITS-4-SET_BITS;
    // Data-cache miss responses cross a register before MEM forwarding.
    // The instruction pair port and asynchronous-cache configurations retain
    // their original completion timing; data-cache hit timing is unchanged.
    localparam bit REGISTER_MISS=LOOKAHEAD && !FETCH_PAIR;
    logic reply_pending,reply_error;
    logic [31:0] reply_data;
    wire [127:0] data0_read, data1_read;
    wire [127:0] preview_data0,preview_data1;
    wire [1:0] read_word_index;
    generate if(LOOKAHEAD && !FETCH_PAIR)begin:preview_word_offset
        logic [1:0] saved_word_index;
        // Capture the word offset with the pre-read line and tag flags. The
        // current MEM address must not select data on its own forwarding path.
        always_ff @(posedge clk) if(!HOLD_PREVIEW || !preview_stall)
            saved_word_index<=preview_addr[3:2];
        assign read_word_index=saved_word_index;
    end else begin:current_word_offset
        assign read_word_index=cpu_addr[3:2];
    end endgenerate
    logic [TAG_BITS-1:0] tag0[0:SETS-1], tag1[0:SETS-1];
    logic [SETS-1:0] valid0, valid1, lru;
    logic filling, invalidate_pending, fill_way;
    logic [31:0] fill_addr;
    logic [SET_BITS-1:0] fill_index;
    logic [1:0] fill_word;
    wire [SET_BITS-1:0] index=cpu_addr[SET_BITS+3:4];
    wire [SET_BITS-1:0] preview_index=preview_addr[SET_BITS+3:4];
    // The SoC guarantees one aligned cacheable window. Noncacheable accesses
    // still bypass, so upper constant window bits need not occupy every tag.
    wire [TAG_BITS-1:0] tag=cpu_addr[ADDRESS_BITS-1:SET_BITS+4];
    wire valid0_read,valid1_read;
    wire hit0,hit1;
    wire bypass=cpu_write || !cpu_cacheable;
    wire replacement=!valid0_read ? 0 : (!valid1_read ? 1 : lru[index]);
    wire fill_commit=!rst && filling && line_ready && !line_error && !invalidate && !invalidate_pending;
    wire store_commit=!rst && !filling && !reply_pending && !invalidate && cpu_valid && cpu_write && cpu_cacheable &&
                      word_ready && !word_error && (hit0 || hit1);
    wire [SET_BITS-1:0] write_index=filling ? fill_index : index;
    wire [127:0] write_data=filling ? line_rdata : {4{cpu_wdata}};
    wire [15:0] write_mask=filling ? 16'hffff : ({12'b0,cpu_wstrb} << {cpu_addr[3:2],2'b00});
    wire write0=(fill_commit && !fill_way) || (store_commit && hit0);
    wire write1=(fill_commit && fill_way) || (store_commit && !hit0 && hit1);
    generate if(LOOKAHEAD) begin : preview_tags
        logic saved_hit0,saved_hit1;
        logic saved_valid0,saved_valid1;
        wire [TAG_BITS-1:0] preview_tag=preview_addr[ADDRESS_BITS-1:SET_BITS+4];
        wire preview_hit0=!rst && !invalidate &&
            ((fill_commit && !fill_way && fill_index==preview_index) ?
            fill_addr[ADDRESS_BITS-1:SET_BITS+4]==preview_tag :
            (valid0[preview_index] && tag0[preview_index]==preview_tag));
        always_ff @(posedge clk) if(!HOLD_PREVIEW || !preview_stall || rst || invalidate) begin
            // Compare on the same edge as the data pre-read, including a
            // same-edge refill. Only the hit flags enter load forwarding.
            saved_hit0<=preview_hit0;
            saved_hit1<=!rst && !invalidate &&
                ((fill_commit && fill_way && fill_index==preview_index) ?
                fill_addr[ADDRESS_BITS-1:SET_BITS+4]==preview_tag :
                (valid1[preview_index] && tag1[preview_index]==preview_tag));
            saved_valid0<=!rst && !invalidate &&
                ((fill_commit && !fill_way && fill_index==preview_index) || valid0[preview_index]);
            saved_valid1<=!rst && !invalidate &&
                ((fill_commit && fill_way && fill_index==preview_index) || valid1[preview_index]);
        end
        assign hit0=saved_hit0;
        assign hit1=saved_hit1;
        assign valid0_read=saved_valid0;
        assign valid1_read=saved_valid1;
    end else begin : asynchronous_tags
        assign valid0_read=valid0[index];
        assign valid1_read=valid1[index];
        assign hit0=valid0_read && tag0[index]==tag;
        assign hit1=valid1_read && tag1[index]==tag;
    end endgenerate
    // One static, whole-byte write per bank avoids mixed full-line/dynamic-slice
    // writes being inferred as multiple RAM write ports by PDS.
    for(genvar byte_index=0;byte_index<16;byte_index++) begin : data_bank
        logic [7:0] data0[0:SETS-1], data1[0:SETS-1];
        assign preview_data0[byte_index*8 +: 8]=
            (write0 && write_mask[byte_index] && write_index==preview_index) ?
            write_data[byte_index*8 +: 8] : data0[preview_index];
        assign preview_data1[byte_index*8 +: 8]=
            (write1 && write_mask[byte_index] && write_index==preview_index) ?
            write_data[byte_index*8 +: 8] : data1[preview_index];
        if(LOOKAHEAD) begin : preview_data
            logic [7:0] saved0,saved1;
            // Explicit same-edge forwarding preserves store-hit and refill
            // semantics independent of the FPGA RAM read-during-write mode.
            always_ff @(posedge clk) if(FETCH_PAIR || !HOLD_PREVIEW || !preview_stall) begin
                saved0<=preview_data0[byte_index*8 +: 8];
                saved1<=preview_data1[byte_index*8 +: 8];
            end
            assign data0_read[byte_index*8 +: 8]=saved0;
            assign data1_read[byte_index*8 +: 8]=saved1;
        end else if(!LOOKAHEAD) begin : asynchronous_data
            assign data0_read[byte_index*8 +: 8]=data0[index];
            assign data1_read[byte_index*8 +: 8]=data1[index];
        end
        always_ff @(posedge clk) begin
            if(write0 && write_mask[byte_index]) data0[write_index]<=write_data[byte_index*8 +: 8];
            if(write1 && write_mask[byte_index]) data1[write_index]<=write_data[byte_index*8 +: 8];
        end
    end
    assign line_valid=!rst && filling;
    assign line_addr={fill_addr[31:4],4'b0};
    assign word_valid=!rst && !filling && !reply_pending && !invalidate && cpu_valid && bypass;
    assign word_write=cpu_write;
    assign word_addr=cpu_addr;
    assign word_wdata=cpu_wdata;
    assign word_wstrb=cpu_wstrb;
    always_comb begin
        cpu_ready=0; cpu_error=0; cpu_rdata=0;
        cpu_second_valid=0; cpu_second_data=0;
        if(!rst && reply_pending) begin
            cpu_ready=1;
            cpu_error=reply_error;
            cpu_rdata=reply_data;
        end else if(!rst && filling) begin
            cpu_ready=!REGISTER_MISS && line_ready;
            cpu_error=!REGISTER_MISS && line_ready && line_error;
            cpu_rdata=REGISTER_MISS ? 32'b0 : line_rdata[fill_word*32 +: 32];
            if (FETCH_PAIR && line_ready && !line_error && fill_word!=2'd3) begin
                cpu_second_valid=1;
                cpu_second_data=line_rdata[(int'(fill_word)+1)*32 +: 32];
            end
        end else if(!rst && !invalidate && cpu_valid) begin
            if(bypass) begin
                cpu_ready=word_ready;
                cpu_error=word_ready && word_error;
                cpu_rdata=word_rdata;
            end else begin
                cpu_ready=hit0 || hit1;
                cpu_rdata=hit0 ? data0_read[read_word_index*32 +: 32] :
                                data1_read[read_word_index*32 +: 32];
                if (FETCH_PAIR && cpu_ready && cpu_addr[3:2]!=2'd3) begin
                    cpu_second_valid=1;
                    cpu_second_data=hit0 ? data0_read[(int'(cpu_addr[3:2])+1)*32 +: 32] :
                                          data1_read[(int'(cpu_addr[3:2])+1)*32 +: 32];
                end
            end
        end
        // The lookahead data port is consumed only on a completed CPU load.
        // Keep the payload independent of request/write qualification; all
        // ready/error and backend transaction controls above remain qualified.
        if (LOOKAHEAD && !FETCH_PAIR)
            cpu_rdata=reply_pending ? reply_data : (filling ? 32'b0 :
                (!cpu_cacheable ? word_rdata :
                 (hit0 ? data0_read[read_word_index*32 +: 32] :
                         data1_read[read_word_index*32 +: 32])));
    end
    always_ff @(posedge clk) begin
        if(rst) begin
            valid0<=0; valid1<=0; lru<=0;
            filling<=0; invalidate_pending<=0; fill_way<=0;
            fill_addr<=0; fill_index<=0; fill_word<=0;
            hit_count<=0; miss_count<=0;
            reply_pending<=0;reply_error<=0;reply_data<=0;
        end else begin
            reply_pending<=0;
            if(invalidate) begin
                valid0<=0; valid1<=0;
                invalidate_pending<=filling;
            end
            if(filling) begin
                if(line_ready) begin
                    filling<=0;
                    invalidate_pending<=0;
                    if(REGISTER_MISS) begin
                        reply_pending<=1;
                        reply_error<=line_error;
                        reply_data<=line_rdata[fill_word*32 +: 32];
                    end
                    if(!line_error && !invalidate && !invalidate_pending) begin
                        if(fill_way) begin
                            tag1[fill_index]<=fill_addr[ADDRESS_BITS-1:SET_BITS+4];
                            valid1[fill_index]<=1;
                        end else begin
                            tag0[fill_index]<=fill_addr[ADDRESS_BITS-1:SET_BITS+4];
                            valid0[fill_index]<=1;
                        end
                        lru[fill_index]<=!fill_way;
                    end
                end
            end else if(!reply_pending && cpu_valid && !invalidate) begin
                if(!bypass) begin
                    if(hit0 || hit1) begin
                        hit_count<=hit_count+1;
                        lru[index]<=hit0;
                    end else begin
                        miss_count<=miss_count+1;
                        filling<=1; fill_way<=replacement;
                        fill_index<=index; fill_word<=cpu_addr[3:2]; fill_addr<=cpu_addr;
                    end
                end else if(cpu_write && cpu_cacheable && word_ready && !word_error && (hit0 || hit1)) begin
                    // Backing store commits first; only successful writes update a hit.
                    lru[index]<=hit0;
                end
            end
        end
    end
endmodule
