`timescale 1ns/1ps

// INT8 逐通道重新量化：signed(INT8) * 非负31位乘数，再按半值远离零右移。
// 两级弹性流水，输出阻塞时整条流水保持；系数和元数据均在输入握手时采样。
// OUTPUT_WIDTH=8 用于 Concat，=40 用于 Add，避免两侧相加前提前饱和。
// 面积实验保持默认关闭；选择0即原Phase9.6逐lane算术实现。
module int8_requant #(
    parameter integer LANES = 8,
    parameter integer OUTPUT_WIDTH = 8,
    parameter integer META_WIDTH = 48,
    parameter integer COMPACT_ROUND = 1,
    parameter integer LUT_REQUANT_ENABLE = 1
) (
    input wire clk, rst_n, clear,
    input wire in_valid, output wire in_ready,
    input wire [LANES*8-1:0] in_data,
    input wire [LANES*31-1:0] in_multiplier,
    input wire [LANES*6-1:0] in_shift,
    input wire [META_WIDTH-1:0] in_meta,
    output wire out_valid, input wire out_ready,
    output wire [LANES*OUTPUT_WIDTH-1:0] out_data,
    output wire [META_WIDTH-1:0] out_meta
);
    // 保留既有独立舍入测试的函数入口；综合时未使用该测试入口会被移除。
    function signed [40:0] rounded;
        input signed [39:0] value;
        input [5:0] shift;
        reg [40:0] magnitude;
        reg signed [40:0] adjusted;
        begin
            if(COMPACT_ROUND!=0) begin
                if(shift>=41) rounded=0;
                else if(shift==0) rounded={value[39],value};
                else begin
                    adjusted=$signed({value[39],value})+$signed(41'd1<<(shift-1))-
                        (value[39]?41'sd1:41'sd0);
                    rounded=adjusted>>>shift;
                end
            end else begin
                magnitude=value[39]?-$signed({value[39],value}):{1'b0,value};
                if(shift>=41) magnitude=0;
                else if(shift!=0) magnitude=(magnitude+(41'd1<<(shift-1)))>>shift;
                rounded=value[39]?-$signed(magnitude):$signed(magnitude);
            end
        end
    endfunction
    generate if(LUT_REQUANT_ENABLE!=0) begin:g_table
        int8_requant_table #(.LANES(LANES),.OUTPUT_WIDTH(OUTPUT_WIDTH),.META_WIDTH(META_WIDTH)) impl(
            .clk(clk),.rst_n(rst_n),.clear(clear),.in_valid(in_valid),.in_ready(in_ready),
            .in_data(in_data),.in_multiplier(in_multiplier),.in_shift(in_shift),.in_meta(in_meta),
            .out_valid(out_valid),.out_ready(out_ready),.out_data(out_data),.out_meta(out_meta));
    end else begin:g_arithmetic
        int8_requant_arithmetic #(.LANES(LANES),.OUTPUT_WIDTH(OUTPUT_WIDTH),
            .META_WIDTH(META_WIDTH),.COMPACT_ROUND(COMPACT_ROUND)) impl(
            .clk(clk),.rst_n(rst_n),.clear(clear),.in_valid(in_valid),.in_ready(in_ready),
            .in_data(in_data),.in_multiplier(in_multiplier),.in_shift(in_shift),.in_meta(in_meta),
            .out_valid(out_valid),.out_ready(out_ready),.out_data(out_data),.out_meta(out_meta));
    end endgenerate
endmodule

module int8_requant_arithmetic #(
    parameter integer LANES = 8,
    parameter integer OUTPUT_WIDTH = 8,
    parameter integer META_WIDTH = 48,
    parameter integer COMPACT_ROUND = 1
) (
    input wire clk, rst_n, clear,
    input wire in_valid,
    output wire in_ready,
    input wire [LANES*8-1:0] in_data,
    input wire [LANES*31-1:0] in_multiplier,
    input wire [LANES*6-1:0] in_shift,
    input wire [META_WIDTH-1:0] in_meta,
    output wire out_valid,
    input wire out_ready,
    output reg [LANES*OUTPUT_WIDTH-1:0] out_data,
    output reg [META_WIDTH-1:0] out_meta
);
    reg [1:0] valid_pipe;
    reg signed [39:0] product [0:LANES-1];
    reg [5:0] shift_pipe [0:LANES-1];
    reg [META_WIDTH-1:0] meta_pipe;
    wire advance = rst_n && !clear && (!valid_pipe[1] || out_ready);
    assign in_ready = advance;
    assign out_valid = valid_pipe[1] && !clear;

    function signed [40:0] rounded;
        input signed [39:0] value;
        input [5:0] shift;
        reg [40:0] magnitude;
        reg signed [40:0] adjusted;
        begin
            if (COMPACT_ROUND != 0) begin
                // 与原41位半值远离零完全相同，保留Add的40位未饱和值。
                if (shift >= 41) rounded = 0;
                else if (shift == 0) rounded = {value[39],value};
                else begin
                    adjusted = $signed({value[39],value}) +
                               $signed(41'd1 << (shift-1)) -
                               (value[39] ? 41'sd1 : 41'sd0);
                    rounded = adjusted >>> shift;
                end
            end else begin
                magnitude = value[39] ? -$signed({value[39], value}) : {1'b0, value};
                // 41位保存绝对值和舍入增量，大于等于41的右移必然得到0。
                if (shift >= 41) magnitude = 0;
                else if (shift != 0)
                    magnitude = (magnitude + (41'd1 << (shift-1))) >> shift;
                rounded = value[39] ? -$signed(magnitude) : $signed(magnitude);
            end
        end
    endfunction
    localparam signed [40:0] MAX_VALUE = (41'sd1 << (OUTPUT_WIDTH-1)) - 1;
    localparam signed [40:0] MIN_VALUE = -(41'sd1 << (OUTPUT_WIDTH-1));
    function [OUTPUT_WIDTH-1:0] clipped;
        input signed [40:0] value;
        begin
            if (value > MAX_VALUE) clipped = MAX_VALUE;
            else if (value < MIN_VALUE) clipped = MIN_VALUE;
            else clipped = value[OUTPUT_WIDTH-1:0];
        end
    endfunction

    integer lane;
    always @(posedge clk or negedge rst_n) begin
        if (!rst_n) begin
            valid_pipe <= 0;
            meta_pipe <= 0;
            out_meta <= 0;
        end else if (clear) begin
            valid_pipe <= 0;
        end else if (advance) begin
            valid_pipe <= {valid_pipe[0], in_valid};
            if (in_valid) begin
                meta_pipe <= in_meta;
                for (lane = 0; lane < LANES; lane = lane + 1) begin
                    product[lane] <= $signed(in_data[lane*8 +: 8]) *
                                     $signed({1'b0, in_multiplier[lane*31 +: 31]});
                    shift_pipe[lane] <= in_shift[lane*6 +: 6];
                end
            end
            if (valid_pipe[0]) begin
                out_meta <= meta_pipe;
                for (lane = 0; lane < LANES; lane = lane + 1)
                    out_data[lane*OUTPUT_WIDTH +: OUTPUT_WIDTH] <=
                        clipped(rounded(product[lane], shift_pipe[lane]));
            end
        end
    end
    // synthesis translate_off
    initial begin
        if (LANES < 1 || OUTPUT_WIDTH < 8 || OUTPUT_WIDTH > 40 || META_WIDTH < 1)
            $fatal(1, "invalid int8_requant parameters");
    end
    // synthesis translate_on
endmodule
