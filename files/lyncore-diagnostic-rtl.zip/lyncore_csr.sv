`timescale 1ns/1ps
// M-mode only. Unsupported CSRs trap; unsupported writable fields read as zero.
module lyncore_csr #(parameter bit ENABLE_M = 0, parameter bit DUAL_ISSUE=0) (
    input logic clk, rst,
    input logic [11:0] read_addr, write_addr,
    input logic write_en, retire_en, retire2_en,
    input logic [31:0] write_data,
    output logic [31:0] read_data,
    output logic read_legal, read_only,
    input logic trap_enter, trap_return,
    input logic [31:0] trap_pc, trap_cause, trap_value,
    input logic irq_software, irq_timer, irq_external,
    output logic irq_pending,
    output logic [31:0] irq_cause, trap_vector, return_pc,
    output logic [63:0] cycle_count, instret_count
);
    logic mie_global, mie_previous;
    logic [31:0] mie, mip, mtvec, mscratch, mepc, mcause, mtval;
    logic [31:0] inhibit;
    localparam logic [31:0] IRQ_MASK = 32'h00000888;
    assign mip = {20'b0, irq_external, 3'b0, irq_timer, 3'b0, irq_software, 3'b0};
    assign irq_pending = mie_global && |(mie & mip);
    assign irq_cause = (mie[11] && mip[11]) ? 32'h8000000b :
                       (mie[3] && mip[3]) ? 32'h80000003 : 32'h80000007;
    assign trap_vector = {mtvec[31:2], 2'b0} +
        ((trap_cause[31] && mtvec[1:0] == 1) ? ((trap_cause & 32'h7fffffff) << 2) : 0);
    assign return_pc = mepc;
    always_comb begin
        read_data = 0;
        read_legal = 1;
        read_only = (read_addr[11:10] == 2'b11);
        case (read_addr)
            12'h300: read_data = 32'h00001800 | (mie_global ? 32'h8 : 0) |
                                (mie_previous ? 32'h80 : 0);
            12'h301: read_data = ENABLE_M ? 32'h40001100 : 32'h40000100; // Fixed RV32I / RV32IM
            12'h304: read_data = mie;
            12'h305: read_data = mtvec;
            12'h310: read_data = 0; // mstatush: little endian, no extensions
            12'h320: read_data = inhibit;
            12'h340: read_data = mscratch;
            12'h341: read_data = mepc;
            12'h342: read_data = mcause;
            12'h343: read_data = mtval;
            12'h344: read_data = mip;
            12'hb00, 12'hc00: read_data = cycle_count[31:0];
            12'hb80, 12'hc80: read_data = cycle_count[63:32];
            12'hb02, 12'hc02: read_data = instret_count[31:0];
            12'hb82, 12'hc82: read_data = instret_count[63:32];
            12'hf11, 12'hf12, 12'hf13, 12'hf14: read_data = 0;
            default: read_legal = 0;
        endcase
    end
    always_ff @(posedge clk) begin
        if (rst) begin
            mie_global <= 0;
            mie_previous <= 0;
            mie <= 0;
            mtvec <= 0;
            mscratch <= 0;
            mepc <= 0;
            mcause <= 0;
            mtval <= 0;
            inhibit <= 0;
            cycle_count <= 0;
            instret_count <= 0;
        end else begin
            if (!inhibit[0]) cycle_count <= cycle_count + 1;
            if (retire_en && !inhibit[2])
                instret_count <= instret_count + ((DUAL_ISSUE && retire2_en) ? 64'd2 : 64'd1);
            if (write_en) begin
                case (write_addr)
                    12'h300: begin
                        mie_global <= write_data[3];
                        mie_previous <= write_data[7];
                    end
                    12'h304: mie <= write_data & IRQ_MASK;
                    12'h305: mtvec <= {write_data[31:2], 1'b0, (write_data[1:0] == 1)};
                    12'h320: inhibit <= write_data & 32'h5;
                    12'h340: mscratch <= write_data;
                    12'h341: mepc <= {write_data[31:2], 2'b0};
                    12'h342: mcause <= write_data;
                    12'h343: mtval <= write_data;
                    // Counter writes override increment, including on the other half.
                    12'hb00: cycle_count <= {cycle_count[63:32], write_data};
                    12'hb80: cycle_count <= {write_data, cycle_count[31:0]};
                    12'hb02: instret_count <= {instret_count[63:32], write_data};
                    12'hb82: instret_count <= {write_data, instret_count[31:0]};
                    default: begin end // misa/mstatush/mip have fixed or external fields
                endcase
            end
            if (trap_return) begin
                mie_global <= mie_previous;
                mie_previous <= 1;
            end
            if (trap_enter) begin
                mepc <= {trap_pc[31:2], 2'b0};
                mcause <= trap_cause;
                mtval <= trap_value;
                mie_previous <= mie_global;
                mie_global <= 0;
            end
        end
    end
endmodule
