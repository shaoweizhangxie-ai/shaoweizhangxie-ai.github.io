`timescale 1ns/1ps

// 整网计算核加统一外存读适配；配置镜像后装 RGB，再启动任务。
// 保留片上特征图 Slot；network_ddr_top 用本读接口连接盘古 DDR 桥。
module network_storage_top #(
    parameter integer MAX_WIDTH=640,
    parameter integer BANK_DEPTH=4096,
    parameter integer PSUM_DEPTH=256,
    parameter integer MAX_CO_GROUPS=128,
    parameter integer MAX_TASKS=256,
    parameter integer PE_LATENCY=7
) (
    input wire clk, rst_n, clear, start,
    input wire [15:0] task_count,
    output wire ready, busy, done, error,
    input wire cfg_valid,
    output wire cfg_ready,
    input wire [31:0] cfg_image_base, cfg_image_bytes,
    input wire [31:0] cfg_program_offset, cfg_directory_offset,
    input wire [15:0] cfg_task_count,
    output wire cfg_error, storage_configured, storage_busy,
    output wire read_request_valid,
    input wire read_request_ready,
    output wire [31:0] read_request_address,
    input wire read_response_valid,
    output wire read_response_ready,
    input wire [31:0] read_response_address, read_response_data,
    input wire read_response_error,
    // 输入先按八通道缓存字装入 Slot0；RGB 三个 lane，其余补零。
    input wire input_start,
    output wire input_ready,
    input wire [15:0] input_width, input_height, input_channels,
    input wire input_valid,
    output wire input_data_ready,
    input wire [15:0] input_co_group,
    input wire [31:0] input_index,
    input wire [63:0] input_data,
    input wire input_end, input_abort,
    output wire input_busy, input_done, input_error,
    input wire heads_start,
    output wire heads_ready, heads_busy, heads_done, heads_error,
    input wire [8:0] head_slot_bus,
    input wire [47:0] head_width_bus, head_height_bus,
    input wire [15:0] head_channels,
    output wire out_valid,
    input wire out_ready,
    output wire [63:0] out_data,
    output wire [1:0] out_head,
    output wire [15:0] out_co_group,
    output wire [31:0] out_index,
    output wire [7:0] out_lane_mask,
    // 观测端口用于仿真/板上逐层对拍，不参与任务调度。
    output wire task_active,
    output wire [15:0] active_task_index,
    output wire result_valid,
    output wire [15:0] result_co_group,
    output wire [31:0] result_index,
    output wire [63:0] result_data,
    output wire raw_valid,
    output wire [15:0] raw_co_group,
    output wire [31:0] raw_index,
    output wire [255:0] raw_data
);
    wire core_ready, core_busy, core_error, adapter_cfg_ready;
    reg control_error;
    wire [15:0] configured_task_count;
    wire can_configure=core_ready && !input_busy && !heads_busy;
    assign cfg_ready=adapter_cfg_ready && can_configure;
    assign ready=core_ready && storage_configured && !storage_busy && !cfg_valid && !clear;
    assign busy=core_busy || storage_busy;
    assign error=core_error || cfg_error || control_error;
    wire bad_count=task_count==0 || task_count>configured_task_count;
    always @(posedge clk or negedge rst_n) begin
        if (!rst_n) control_error<=0;
        else control_error<=start && ready && bad_count;
    end
    wire program_request_valid, program_request_ready, program_response_valid, program_response_ready, program_response_error;
    wire [15:0] program_request_index, program_response_index;
    wire [255:0] program_response_data;
    wire memory_request_valid, memory_request_ready, memory_response_valid, memory_response_ready, memory_response_error;
    wire [1:0] memory_request_kind, memory_response_kind;
    wire [15:0] memory_request_task, memory_response_task;
    wire [31:0] memory_request_address, memory_response_address;
    wire [847:0] memory_response_data;
    wire core_input_ready, core_heads_ready;
    assign input_ready=core_input_ready && storage_configured && !cfg_valid;
    assign heads_ready=core_heads_ready && storage_configured && !cfg_valid;
    network_accelerator_top #(.MAX_WIDTH(MAX_WIDTH),.BANK_DEPTH(BANK_DEPTH),.PSUM_DEPTH(PSUM_DEPTH),
        .MAX_CO_GROUPS(MAX_CO_GROUPS),.MAX_TASKS(MAX_TASKS),.PE_LATENCY(PE_LATENCY)) core (
        .clk(clk),
        .rst_n(rst_n),
        .clear(clear),
        .start(start && ready && !bad_count),
        .task_count(task_count),
        .ready(core_ready),
        .busy(core_busy),
        .done(done),
        .error(core_error),
        .program_request_valid(program_request_valid),
        .program_request_ready(program_request_ready),
        .program_request_index(program_request_index),
        .program_response_valid(program_response_valid),
        .program_response_ready(program_response_ready),
        .program_response_index(program_response_index),
        .program_response_data(program_response_data),
        .program_response_error(program_response_error),
        .memory_request_valid(memory_request_valid),
        .memory_request_ready(memory_request_ready),
        .memory_request_kind(memory_request_kind),
        .memory_request_task(memory_request_task),
        .memory_request_address(memory_request_address),
        .memory_response_valid(memory_response_valid),
        .memory_response_ready(memory_response_ready),
        .memory_response_kind(memory_response_kind),
        .memory_response_task(memory_response_task),
        .memory_response_address(memory_response_address),
        .memory_response_data(memory_response_data),
        .memory_response_error(memory_response_error),
        .input_start(input_start && !cfg_valid && storage_configured),
        .input_ready(core_input_ready),
        .input_width(input_width),
        .input_height(input_height),
        .input_channels(input_channels),
        .input_valid(input_valid),
        .input_data_ready(input_data_ready),
        .input_co_group(input_co_group),
        .input_index(input_index),
        .input_data(input_data),
        .input_end(input_end),
        .input_abort(input_abort),
        .input_busy(input_busy),
        .input_done(input_done),
        .input_error(input_error),
        .heads_start(heads_start && !cfg_valid && storage_configured),
        .heads_ready(core_heads_ready),
        .heads_busy(heads_busy),
        .heads_done(heads_done),
        .heads_error(heads_error),
        .head_slot_bus(head_slot_bus),
        .head_width_bus(head_width_bus),
        .head_height_bus(head_height_bus),
        .head_channels(head_channels),
        .out_valid(out_valid),
        .out_ready(out_ready),
        .out_data(out_data),
        .out_head(out_head),
        .out_co_group(out_co_group),
        .out_index(out_index),
        .out_lane_mask(out_lane_mask),
        .task_active(task_active),
        .active_task_index(active_task_index),
        .result_valid(result_valid),
        .result_co_group(result_co_group),
        .result_index(result_index),
        .result_data(result_data),
        .raw_valid(raw_valid),
        .raw_co_group(raw_co_group),
        .raw_index(raw_index),
        .raw_data(raw_data)
    );
    model_memory_adapter #(.MAX_TASKS(MAX_TASKS)) adapter (
        .clk(clk),
        .rst_n(rst_n),
        .clear(clear),
        .cfg_valid(cfg_valid && can_configure),
        .cfg_ready(adapter_cfg_ready),
        .cfg_image_base(cfg_image_base),
        .cfg_image_bytes(cfg_image_bytes),
        .cfg_program_offset(cfg_program_offset),
        .cfg_directory_offset(cfg_directory_offset),
        .cfg_task_count(cfg_task_count),
        .cfg_error(cfg_error),
        .configured(storage_configured),
        .configured_task_count(configured_task_count),
        .busy(storage_busy),
        .program_request_valid(program_request_valid),
        .program_request_ready(program_request_ready),
        .program_request_index(program_request_index),
        .program_response_valid(program_response_valid),
        .program_response_ready(program_response_ready),
        .program_response_index(program_response_index),
        .program_response_data(program_response_data),
        .program_response_error(program_response_error),
        .memory_request_valid(memory_request_valid),
        .memory_request_ready(memory_request_ready),
        .memory_request_kind(memory_request_kind),
        .memory_request_task(memory_request_task),
        .memory_request_address(memory_request_address),
        .memory_response_valid(memory_response_valid),
        .memory_response_ready(memory_response_ready),
        .memory_response_kind(memory_response_kind),
        .memory_response_task(memory_response_task),
        .memory_response_address(memory_response_address),
        .memory_response_data(memory_response_data),
        .memory_response_error(memory_response_error),
        .read_request_valid(read_request_valid),
        .read_request_ready(read_request_ready),
        .read_request_address(read_request_address),
        .read_response_valid(read_response_valid),
        .read_response_ready(read_response_ready),
        .read_response_address(read_response_address),
        .read_response_data(read_response_data),
        .read_response_error(read_response_error)
    );
endmodule
