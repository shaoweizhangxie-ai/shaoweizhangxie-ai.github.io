`timescale 1ns/1ps

// 八通道卷积后处理：偏置 -> 定点缩放 -> SiLU 查表或直通 -> INT8。
// 系数随每笔输入采样；低位通道是通道 0。所有量化零点均为 0。
module conv_postprocess #(
    parameter integer LANES = 8,
    // 可独立回退；等价舍入消除绝对值和恢复符号的两套宽加法器。
    parameter integer COMPACT_ROUND = 1,
    parameter integer SHARED_PRODUCT = 0
) (
    input  wire                   clk,
    input  wire                   rst_n,
    input  wire                   in_valid,
    input  wire [15:0]            in_co_group,
    input  wire [31:0]            in_index,
    input  wire [LANES*32-1:0]     in_psum,
    input  wire [LANES*32-1:0]     bias_bus,
    input  wire [LANES*31-1:0]     linear_multiplier_bus,
    input  wire [LANES*6-1:0]      linear_shift_bus,
    input  wire [LANES*31-1:0]     grid_multiplier_bus,
    input  wire [LANES*6-1:0]      grid_shift_bus,
    input  wire                   silu_enable,
    input wire [LANES*34-1:0] positive_input_threshold_bus,
    // 1024 个表项覆盖 [-8,8)，步长 1/64；软件按本层输出尺度生成表。
    // 配表须在流水线空闲时完成；写一次同时更新八份可并行读的表。
    input  wire                   lut_we,
    input  wire [9:0]             lut_addr,
    input  wire [7:0]             lut_data,
    output wire                   busy,
    output wire                   out_valid,
    output wire [15:0]            out_co_group,
    output wire [31:0]            out_index,
    output wire [LANES*8-1:0]      out_data
);
    // Six stages: separate quotient/guard selection from rounding/saturation.
    reg [5:0] valid_pipe;
    reg [15:0] group_pipe [0:5];
    reg [31:0] index_pipe [0:5];
    integer stage;
    assign busy = |valid_pipe;
    assign out_valid = valid_pipe[5];
    assign out_co_group = group_pipe[5];
    assign out_index = index_pipe[5];

    always @(posedge clk or negedge rst_n) begin
        if (!rst_n) begin
            valid_pipe <= 6'd0;
            for (stage = 0; stage < 6; stage = stage + 1) begin
                group_pipe[stage] <= 16'd0;
                index_pipe[stage] <= 32'd0;
            end
        end else begin
            valid_pipe <= {valid_pipe[4:0], in_valid};
            group_pipe[0] <= in_co_group;
            index_pipe[0] <= in_index;
            for (stage = 1; stage < 6; stage = stage + 1) begin
                group_pipe[stage] <= group_pipe[stage-1];
                index_pipe[stage] <= index_pipe[stage-1];
            end
        end
    end

    // 对绝对值加半个最低保留位，再恢复符号，保证正负数都四舍五入。
    // 恰好半整数时远离零；移位为 0 时不加舍入量。
    function signed [65:0] round_shift;
        input signed [64:0] value;
        input [5:0] shift;
        reg signed [65:0] extended;
        reg [65:0] magnitude;
        reg [65:0] rounded;
        reg signed [65:0] adjusted;
        begin
            if (COMPACT_ROUND != 0) begin
                // floor((v + 2^(s-1) - (v<0))/2^s) 与半值远离零等价。
                // 66 位容纳全部 signed 65 位输入及舍入量，不截精度。
                if (shift == 0) round_shift = {value[64],value};
                else begin
                    adjusted = $signed({value[64],value}) +
                               $signed(66'd1 << (shift-1)) -
                               (value[64] ? 66'sd1 : 66'sd0);
                    round_shift = adjusted >>> shift;
                end
            end else begin
                extended = {value[64], value};
                magnitude = (extended < 0) ? -extended : extended;
                if (shift == 0) rounded = magnitude;
                else rounded = (magnitude + (66'd1 << (shift-1))) >> shift;
                round_shift = (extended < 0) ? -$signed(rounded) : $signed(rounded);
            end
        end
    endfunction

    // Only INT8 saturation and the [-512,511] SiLU interval consume this
    // quotient. Values outside signed 11-bit remain outside both intervals
    // even after a rounding increment, so retain a signed sentinel instead
    // of constructing and shifting the complete 66-bit rounded value.
    // {signed bounded floor quotient, increment}; increment is applied next cycle.
    function [12:0] round_parts;
        input signed [64:0] value;
        input [5:0] shift;
        reg [64:0] same_sign;
        reg [63:0] low_or;
        reg [6:0] threshold;
        reg signed [10:0] quotient;
        reg increment, fits;
        reg [5:0] guard_index, sticky_index;
        reg signed [65:0] legacy;
        integer bit_index;
        begin
            if (COMPACT_ROUND == 0) begin
                legacy = round_shift(value, shift);
                if (legacy < -66'sd2048) round_parts = {12'h800,1'b0};
                else if (legacy > 66'sd2047) round_parts = {12'h7ff,1'b0};
                else round_parts = {legacy[11:0],1'b0};
            end else begin
                same_sign[64] = 1'b1;
                for (bit_index = 63; bit_index >= 0; bit_index = bit_index-1)
                    same_sign[bit_index] = same_sign[bit_index+1] & (value[bit_index] == value[64]);
                low_or[0] = value[0];
                for (bit_index = 1; bit_index < 64; bit_index = bit_index+1)
                    low_or[bit_index] = low_or[bit_index-1] | value[bit_index];
                threshold = {1'b0, shift} + 7'd10;
                fits = threshold >= 64 ? 1'b1 : same_sign[threshold];
                quotient = $signed(value) >>> shift;
                guard_index = shift - 6'd1;
                sticky_index = shift - 6'd2;
                // Positive ties increment floor(v/2^s); negative ties do not.
                increment = shift != 0 && value[guard_index] &&
                            (!value[64] || (shift > 1 && low_or[sticky_index]));
                if (!fits) round_parts = {value[64] ? 12'h800 : 12'h7ff,1'b0};
                else round_parts = {quotient[10],quotient,increment};
            end
        end
    endfunction

    function [7:0] saturate_int8;
        input signed [11:0] value;
        begin
            if (value > 12'sd127)
                saturate_int8 = 8'h7f;
            else if (value < -12'sd128)
                saturate_int8 = 8'h80;
            else
                saturate_int8 = value[7:0];
        end
    endfunction

    genvar lane;
    generate
        for (lane = 0; lane < LANES; lane = lane + 1) begin : g_lane
            reg [7:0] silu_lut [0:1023];
            wire signed [31:0] input_value = in_psum[lane*32 +: 32];
            wire signed [31:0] bias_value = bias_bus[lane*32 +: 32];
            reg signed [32:0] biased;
            reg [30:0] linear_m0;
            reg [30:0] grid_m0;
            reg [5:0] linear_s0;
            reg [5:0] grid_s0;
            reg act0;
            reg signed [64:0] linear_product;
            reg signed [64:0] grid_product;
            reg [5:0] linear_s1;
            reg [5:0] grid_s1;
            reg act1;
            reg [12:0] linear_round_q,grid_round_q;
            reg act_round;
            wire signed [11:0] linear_rounded = $signed(linear_round_q[12:1]) +
                (linear_round_q[0] ? 12'sd1 : 12'sd0);
            wire signed [11:0] grid_rounded = SHARED_PRODUCT != 0 ? linear_rounded :
                $signed(grid_round_q[12:1]) + (grid_round_q[0] ? 12'sd1 : 12'sd0);
            wire select_grid = silu_enable &&
                ($signed({{2{input_value[31]}},input_value}) <
                 $signed(positive_input_threshold_bus[lane*34+:34]));
            reg [7:0] linear2;
            // 超出查表区间只保留方向，不对大数截位后生成错误地址。
            reg signed [10:0] grid2;
            reg act2;
            reg [7:0] lut3;
            reg [7:0] linear3;
            reg negative_tail3;
            reg positive_tail3;
            reg act3;
            reg [7:0] result;
            assign out_data[lane*8 +: 8] = result;

            // 第 0 级：偏置加法使用 33 位，避免两个 INT32 相加溢出。
            // 第 1 级：31 位非负系数扩成 signed 32 位，再做 33x32 乘法。
            // linear 系数换成输出量化单位；grid 系数换成实数的 1/64 单位。
            always @(posedge clk) begin
                if (lut_we)
                    silu_lut[lut_addr] <= lut_data;
                if (in_valid) begin
                    biased <= $signed({input_value[31], input_value}) +
                              $signed({bias_value[31], bias_value});
                    linear_m0 <= SHARED_PRODUCT != 0 && select_grid ?
                        grid_multiplier_bus[lane*31+:31] : linear_multiplier_bus[lane*31 +: 31];
                    grid_m0 <= grid_multiplier_bus[lane*31 +: 31];
                    linear_s0 <= SHARED_PRODUCT != 0 && select_grid ?
                        grid_shift_bus[lane*6+:6] : linear_shift_bus[lane*6 +: 6];
                    grid_s0 <= grid_shift_bus[lane*6 +: 6];
                    act0 <= SHARED_PRODUCT != 0 ? select_grid : silu_enable;
                end
                if (valid_pipe[0]) begin
                    linear_product <= biased * $signed({1'b0, linear_m0});
                    if (SHARED_PRODUCT == 0) grid_product <= biased * $signed({1'b0, grid_m0});
                    linear_s1 <= linear_s0;
                    grid_s1 <= grid_s0;
                    act1 <= act0;
                end
                if (valid_pipe[1]) begin
                    linear_round_q <= round_parts(linear_product,linear_s1);
                    if(SHARED_PRODUCT == 0) grid_round_q <= round_parts(grid_product,grid_s1);
                    act_round <= act1;
                end
                // The registered quotient and guard bit drive only narrow arithmetic.
                if (valid_pipe[2]) begin
                    linear2 <= saturate_int8(linear_rounded);
                    if (grid_rounded < -12'sd512)
                        grid2 <= -11'sd513;
                    else if (grid_rounded >= 12'sd512)
                        grid2 <= 11'sd512;
                    else
                        grid2 <= grid_rounded[10:0];
                    act2 <= act_round;
                end
                // 第 3 级：同步读表。负尾近似 0，正尾近似恒等映射。
                if (valid_pipe[3]) begin
                    if (grid2 >= -11'sd512 && grid2 < 11'sd512)
                        lut3 <= silu_lut[grid2 + 11'sd512];
                    else
                        lut3 <= 8'd0;
                    linear3 <= linear2;
                    negative_tail3 <= (grid2 < -11'sd512);
                    positive_tail3 <= (grid2 >= 11'sd512);
                    act3 <= act2;
                end
            end

            // 第 4 级：选择查表结果或直通结果，数据和元数据一起输出。
            always @(posedge clk or negedge rst_n) begin
                if (!rst_n)
                    result <= 8'd0;
                else if (valid_pipe[4]) begin
                    if (!act3 || positive_tail3)
                        result <= linear3;
                    else if (negative_tail3)
                        result <= 8'd0;
                    else
                        result <= lut3;
                end
            end
        end
    endgenerate
endmodule
