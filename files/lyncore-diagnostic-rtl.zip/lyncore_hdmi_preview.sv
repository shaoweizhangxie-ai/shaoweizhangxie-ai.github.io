`timescale 1ns/1ps
// 720p60 output with a frame-matched object label.
module lyncore_hdmi_preview(
 input wire pixel_clk,cfg_clk,async_n,
 input wire clk,rst_n,
 input wire overlay_capture,overlay_pixel_valid,overlay_packet_write,overlay_packet_valid,
 input wire [15:0] overlay_pixel_data,
 input wire [31:0] overlay_frame_id,overlay_packet_addr,overlay_packet_data,overlay_packet_bytes,
 output wire frame_visible,overlay_ready,
 output wire pix_clk,hs_out,vs_out,de_out,rstn_out,iic_tx_scl,
 output wire [7:0] r_out,g_out,b_out,
 inout wire iic_tx_sda,
 output wire configured
);
 wire cfg_release,pixel_release;
 lyncore_reset_release hdmi_reset(.clk(cfg_clk),.async_n(async_n),.release_n(cfg_release));
 lyncore_reset_release pixel_reset(.clk(pixel_clk),.async_n(async_n),.release_n(pixel_release));
 reg [13:0] reset_count;
 always @(posedge cfg_clk or negedge cfg_release)
  if(!cfg_release) reset_count<=0;
  else if(reset_count!=14'd10000) reset_count<=reset_count+1'b1;
 assign rstn_out=cfg_release && reset_count==14'd10000;
 ms72xx_ctl hdmi_config(.clk(cfg_clk),.rst_n(rstn_out),.init_over_rx(),
  .init_over(configured),.iic_scl(iic_tx_scl),.iic_sda(iic_tx_sda));
 wire de,hsync,vsync;
 wire [15:0] x,y;
 video_timing #(.H_ACTIVE(1280),.H_FRONT(110),.H_SYNC(40),.H_BACK(220),
  .V_ACTIVE(720),.V_FRONT(5),.V_SYNC(5),.V_BACK(20),.SYNC_POSITIVE(1)) timing(
  .pixel_clk(pixel_clk),.rst_n(pixel_release),.de(de),.hsync(hsync),.vsync(vsync),
  .frame_start(),.x(x),.y(y));
 reg hsync_q,vsync_q,de_q,hsync_out_q,vsync_out_q,de_out_q;
 reg border_q,visible_q;
 reg [15:0] rgb_q;
 wire label_bg,label_ink;
 wire frame_reset_n,border;
 wire [15:0] rgb;
 lyncore_reset_release frame_reset(.clk(pixel_clk),.async_n(rst_n && async_n),.release_n(frame_reset_n));
 preview_detection_frame preview(.clk(clk),.rst_n(rst_n),.capture(overlay_capture),
  .pixel_valid(overlay_pixel_valid),.pixel_data(overlay_pixel_data),.frame_id(overlay_frame_id),
  .packet_write(overlay_packet_write),.packet_valid(overlay_packet_valid),.packet_addr(overlay_packet_addr),
  .packet_data(overlay_packet_data),.packet_bytes(overlay_packet_bytes),.pixel_clk(pixel_clk),
  .pixel_reset_n(frame_reset_n),.de(de),.x(x),.y(y),.rgb(rgb),.capture_ready(overlay_ready),.border(border),.visible(frame_visible),.label_bg(label_bg),.label_ink(label_ink));
 always @(posedge pixel_clk or negedge pixel_release)
  if(!pixel_release)begin
   hsync_q<=0;vsync_q<=0;de_q<=0;hsync_out_q<=0;vsync_out_q<=0;de_out_q<=0;
   rgb_q<=0;border_q<=0;visible_q<=0;
  end else begin
   hsync_q<=hsync;vsync_q<=vsync;de_q<=de;
   hsync_out_q<=hsync_q;vsync_out_q<=vsync_q;de_out_q<=de_q;
   rgb_q<=rgb;border_q<=border;visible_q<=frame_visible;
  end
 assign pix_clk=pixel_clk;
 assign hs_out=hsync_out_q;
 assign vs_out=vsync_out_q;
 assign de_out=de_out_q;
 wire show_pixel=de_out_q && visible_q;
 assign r_out=show_pixel ? (label_bg ? {8{label_ink}} : border_q ? 8'hff : {rgb_q[15:11],rgb_q[15:13]}) : 8'd0;
 assign g_out=show_pixel ? (label_bg ? {8{label_ink}} : border_q ? 8'hff : {rgb_q[10:5],rgb_q[10:9]}) : 8'd0;
 assign b_out=show_pixel ? (label_bg ? {8{label_ink}} : border_q ? 8'h00 : {rgb_q[4:0],rgb_q[4:2]}) : 8'd0;
endmodule
