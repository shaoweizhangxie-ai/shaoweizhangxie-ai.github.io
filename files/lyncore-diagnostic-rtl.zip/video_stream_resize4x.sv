`timescale 1ns/1ps
// Streaming content only: 1280x720 RGB565 -> the 320x180 content of a
// 320x320 letterbox. The writer must supply the 70 top/bottom gray rows.
// Upstream DVP validates line/frame geometry. A failed frame must be discarded
// by every downstream consumer; no result may publish before frame_done.
module video_stream_resize4x(
 input wire pclk,rst_n,start_valid,output wire start_ready,
 input wire [31:0] start_frame_id,
 input wire pixel_valid,input wire [15:0] pixel_data,
 input wire input_finished,input_failed,
 output reg out_valid,input wire out_ready,
 output reg [63:0] out_data,output reg [31:0] out_index,out_frame_id,
 output reg out_last,output reg frame_done,failed,output wire busy
);
 reg active,finish_seen;reg [10:0] x;reg [9:0] y;
 reg [19:0] pixel_count;reg [15:0] content_count;reg [31:0] identity;
 reg [23:0] left_rgb;
 reg [26:0] top_sum[0:319];reg [26:0] top_read;
 wire [23:0] rgb={{pixel_data[4:0],pixel_data[4:2]},
                         {pixel_data[10:5],pixel_data[10:9]},
                         {pixel_data[15:11],pixel_data[15:13]}};
 wire upper_pair=active&&pixel_valid&&y[1:0]==1&&x[1:0]==2;
 wire lower_first=active&&pixel_valid&&y[1:0]==2&&x[1:0]==1;
 wire emit=active&&pixel_valid&&y[1:0]==2&&x[1:0]==2;
 wire [8:0] content_x=x[10:2];wire [9:0] tensor_y={2'b0,y[9:2]}+10'd70;
 wire [31:0] tensor_index=({22'd0,tensor_y}<<8)+({22'd0,tensor_y}<<6)+{23'd0,content_x};
 assign start_ready=rst_n&&!active&&!out_valid;
 assign busy=active||out_valid;
 // Data RAM/read register have no reset, allowing an ordinary synchronous RAM.
 always @(posedge pclk)begin
  if(rst_n&&upper_pair)begin
   for(integer c=0;c<3;c++)top_sum[content_x][c*9+:9]<={1'b0,left_rgb[c*8+:8]}+{1'b0,rgb[c*8+:8]};
  end
  if(rst_n&&lower_first)top_read<=top_sum[content_x];
 end
 reg [9:0] total;
 always @(posedge pclk or negedge rst_n)begin
  if(!rst_n)begin
   active<=0;finish_seen<=0;x<=0;y<=0;pixel_count<=0;content_count<=0;identity<=0;left_rgb<=0;
   out_valid<=0;out_data<=0;out_index<=0;out_frame_id<=0;out_last<=0;frame_done<=0;failed<=0;
  end else begin
   frame_done<=0;
   if(out_valid&&out_ready)out_valid<=0;
   if(start_valid&&start_ready)begin
    active<=1;finish_seen<=0;failed<=0;x<=0;y<=0;pixel_count<=0;content_count<=0;identity<=start_frame_id;
   end else if(active)begin
    if(input_failed || (pixel_valid && pixel_count>=921600))begin
     failed<=1;active<=0;out_valid<=0;
    end else begin
     if(pixel_valid)begin
      pixel_count<=pixel_count+1'b1;
      if(x==1279)begin x<=0;y<=y+1'b1;end else x<=x+1'b1;
      if(x[1:0]==1 && (y[1:0]==1 || y[1:0]==2))left_rgb<=rgb;
      if(emit)begin
       if(out_valid&&!out_ready)begin failed<=1;active<=0;out_valid<=0;end
       else begin
        out_valid<=1;out_data<=0;out_index<=tensor_index;out_frame_id<=identity;
        out_last<=content_count==57599;content_count<=content_count+1'b1;
        for(integer c=0;c<3;c++)begin
         total={1'b0,top_read[c*9+:9]}+{2'b0,left_rgb[c*8+:8]}+{2'b0,rgb[c*8+:8]}+10'd2;
         // Identical to average4(...)->uint8 then p>>1 in the baseline.
         out_data[c*8+:8]<={1'b0,total[9:3]};
        end
       end
      end
     end
     if(input_finished)begin
      finish_seen<=1;
      if(pixel_count!=921600 || content_count!=57600)begin failed<=1;active<=0;out_valid<=0;end
     end
     if(finish_seen&&!out_valid)begin active<=0;frame_done<=1;end
    end
   end
  end
 end
endmodule
