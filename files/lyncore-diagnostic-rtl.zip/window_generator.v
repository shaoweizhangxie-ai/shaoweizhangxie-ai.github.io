`timescale 1ns/1ps

// 将按行输入的四通道像素流转换为 PE 使用的窗口总线。
// 每个输入像素包含同一坐标的四个有符号 INT8 通道。
module window_generator #(
    parameter integer MAX_WIDTH = 640,
    // 0 保留原移行结构；1 使用奇偶行 RAM，接口和窗口延迟完全相同。
    parameter integer BANKED_LINE_RAM = 1,
    parameter integer SCAN_THROTTLE = 0
) (
    input  wire          clk,
    input  wire          rst_n,
    input  wire          frame_start,
    input  wire [15:0]   frame_width,
    input  wire [15:0]   frame_height,
    input  wire          kernel_1x1,
    input  wire          stride_2,
    input  wire          padding_1,
    output wire          frame_ready,
    output wire          busy,
    output reg           frame_done,
    input  wire          in_valid,
    input wire scan_enable,
    output wire          in_ready,
    input  wire [31:0]   in_pixel,
    output reg           out_valid,
    output reg  [15:0]   out_x,
    output reg  [15:0]   out_y,
    output reg  [287:0]  out_window
);

    localparam integer ROW_DEPTH = MAX_WIDTH + 2;

    // 运行时尺寸在帧开始时锁存；扫描坐标包含零填充区域。
    reg          scan_active;
    reg [15:0]   cfg_width;
    reg [15:0]   cfg_height;
    reg [15:0]   padded_width;
    reg [15:0]   padded_height;
    reg          cfg_kernel_1x1;
    reg          cfg_stride_2;
    reg          cfg_padding_1;
    reg [15:0]   scan_x;
    reg [15:0]   scan_y;
    reg          a_valid;

    wire [15:0] pad_offset = cfg_padding_1 ? 16'd1 : 16'd0;
    wire in_image = (scan_x >= pad_offset) &&
                    (scan_x < cfg_width + pad_offset) &&
                    (scan_y >= pad_offset) &&
                    (scan_y < cfg_height + pad_offset);
    wire scan_allowed = SCAN_THROTTLE == 0 || scan_enable;
    wire scan_advance = scan_active && (!in_image || in_valid) && scan_allowed;
    wire [31:0] scan_pixel = in_image ? in_pixel : 32'd0;

    assign in_ready    = scan_active && in_image && scan_allowed;
    assign busy        = scan_active || a_valid;
    assign frame_ready = !busy;

    // 两行 RAM 保存此前两行的四通道像素；不复位 RAM 内容。
    // 在读写同一地址时，非阻塞赋值取得写入前的旧行数据。
    wire [31:0] a_top;
    wire [31:0] a_middle;
    reg [31:0] a_bottom;
    reg        a_last;
    reg [15:0] a_x;
    reg [15:0] a_y;

    generate if (BANKED_LINE_RAM != 0) begin : g_banked_lines
        // 同一奇偶银行保存 y-2 行；另一银行保存 y-1 行。
        // 两个 RAM 各一个同步读口和一个写口。读写同址取写前值。
        // 不将 RAM 输出作为另一 RAM 的组合写数据，避免综合为整行 FF。
        reg [31:0] even_line [0:ROW_DEPTH-1];
        reg [31:0] odd_line  [0:ROW_DEPTH-1];
        reg [31:0] even_q;
        reg [31:0] odd_q;
        always @(posedge clk) begin
            if (rst_n && scan_advance) begin
                even_q <= even_line[scan_x];
                odd_q <= odd_line[scan_x];
                if (!scan_y[0]) even_line[scan_x] <= scan_pixel;
                else odd_line[scan_x] <= scan_pixel;
            end
        end
        // a_y 与同步 RAM 输出在同一边沿更新，不能使用已经推进的 scan_y。
        assign a_top = (a_y >= 16'd2) ? (a_y[0] ? odd_q : even_q) : 32'd0;
        assign a_middle = (a_y >= 16'd1) ? (a_y[0] ? even_q : odd_q) : 32'd0;
    end else begin : g_legacy_lines
        reg [31:0] line_recent [0:ROW_DEPTH-1];
        reg [31:0] line_older  [0:ROW_DEPTH-1];
        reg [31:0] top_q;
        reg [31:0] middle_q;
        always @(posedge clk) begin
            if (rst_n && scan_advance) begin
                top_q <= (scan_y >= 16'd2) ? line_older[scan_x] : 32'd0;
                middle_q <= (scan_y >= 16'd1) ? line_recent[scan_x] : 32'd0;
                line_older[scan_x] <= line_recent[scan_x];
                line_recent[scan_x] <= scan_pixel;
            end
        end
        assign a_top = top_q;
        assign a_middle = middle_q;
    end endgenerate

    always @(posedge clk) begin
        if (rst_n && scan_advance) a_bottom <= scan_pixel;
    end

    // 每行的最近两列保存在寄存器中，形成 3×3 滑动窗口。
    reg [31:0] top_prev2;
    reg [31:0] top_prev1;
    reg [31:0] middle_prev2;
    reg [31:0] middle_prev1;
    reg [31:0] bottom_prev2;
    reg [31:0] bottom_prev1;

    wire [31:0] top_left =
        (a_x >= 16'd2) ? top_prev2 : 32'd0;
    wire [31:0] top_center =
        (a_x >= 16'd1) ? top_prev1 : 32'd0;
    wire [31:0] middle_left =
        (a_x >= 16'd2) ? middle_prev2 : 32'd0;
    wire [31:0] middle_center =
        (a_x >= 16'd1) ? middle_prev1 : 32'd0;
    wire [31:0] bottom_left =
        (a_x >= 16'd2) ? bottom_prev2 : 32'd0;
    wire [31:0] bottom_center =
        (a_x >= 16'd1) ? bottom_prev1 : 32'd0;

    // 1×1 模式只填 k=0，其余八个位置填零；权重供给须使用同样布局。
    // 3×3 模式中 k=ky*3+kx，最低 8 bit 为通道 0 的左上角。
    reg [287:0] window_next;
    integer channel;
    always @* begin
        window_next = 288'd0;
        for (channel = 0; channel < 4; channel = channel + 1) begin
            if (cfg_kernel_1x1) begin
                window_next[(channel*9)*8 +: 8] =
                    a_bottom[channel*8 +: 8];
            end else begin
                window_next[(channel*9 + 0)*8 +: 8] =
                    top_left[channel*8 +: 8];
                window_next[(channel*9 + 1)*8 +: 8] =
                    top_center[channel*8 +: 8];
                window_next[(channel*9 + 2)*8 +: 8] =
                    a_top[channel*8 +: 8];
                window_next[(channel*9 + 3)*8 +: 8] =
                    middle_left[channel*8 +: 8];
                window_next[(channel*9 + 4)*8 +: 8] =
                    middle_center[channel*8 +: 8];
                window_next[(channel*9 + 5)*8 +: 8] =
                    a_middle[channel*8 +: 8];
                window_next[(channel*9 + 6)*8 +: 8] =
                    bottom_left[channel*8 +: 8];
                window_next[(channel*9 + 7)*8 +: 8] =
                    bottom_center[channel*8 +: 8];
                window_next[(channel*9 + 8)*8 +: 8] =
                    a_bottom[channel*8 +: 8];
            end
        end
    end

    wire [15:0] kernel_last =
        cfg_kernel_1x1 ? 16'd0 : 16'd2;
    wire [15:0] window_x = a_x - kernel_last;
    wire [15:0] window_y = a_y - kernel_last;
    wire emit_window =
        a_valid &&
        (a_x >= kernel_last) &&
        (a_y >= kernel_last) &&
        (!cfg_stride_2 || (!window_x[0] && !window_y[0]));

    // Data is consumed only when out_valid is asserted. Keep the runtime
    // clear off the APM input data reset after register packing.
    always @(posedge clk) if (rst_n && emit_window) out_window <= window_next;

    always @(posedge clk or negedge rst_n) begin
        if (!rst_n) begin
            scan_active    <= 1'b0;
            cfg_width      <= 16'd0;
            cfg_height     <= 16'd0;
            padded_width   <= 16'd0;
            padded_height  <= 16'd0;
            cfg_kernel_1x1 <= 1'b0;
            cfg_stride_2   <= 1'b0;
            cfg_padding_1  <= 1'b0;
            scan_x         <= 16'd0;
            scan_y         <= 16'd0;
            a_valid        <= 1'b0;
            a_last         <= 1'b0;
            a_x            <= 16'd0;
            a_y            <= 16'd0;
            out_valid      <= 1'b0;
            out_x          <= 16'd0;
            out_y          <= 16'd0;

            frame_done     <= 1'b0;
        end else begin
            a_valid    <= scan_advance;
            out_valid  <= emit_window;
            frame_done <= a_valid && a_last;

            if (scan_advance) begin
                a_x    <= scan_x;
                a_y    <= scan_y;
                a_last <= (scan_x == padded_width - 16'd1) &&
                          (scan_y == padded_height - 16'd1);
                if (scan_x == padded_width - 16'd1) begin
                    scan_x <= 16'd0;
                    if (scan_y == padded_height - 16'd1)
                        scan_active <= 1'b0;
                    else
                        scan_y <= scan_y + 16'd1;
                end else begin
                    scan_x <= scan_x + 16'd1;
                end
            end

            if (a_valid) begin
                top_prev2    <= top_prev1;
                top_prev1    <= a_top;
                middle_prev2 <= middle_prev1;
                middle_prev1 <= a_middle;
                bottom_prev2 <= bottom_prev1;
                bottom_prev1 <= a_bottom;
            end

            if (emit_window) begin

                out_x <= cfg_stride_2 ? (window_x >> 1) : window_x;
                out_y <= cfg_stride_2 ? (window_y >> 1) : window_y;
            end

            if (frame_ready && frame_start) begin
                cfg_width      <= frame_width;
                cfg_height     <= frame_height;
                padded_width   <= frame_width +
                                  (padding_1 ? 16'd2 : 16'd0);
                padded_height  <= frame_height +
                                  (padding_1 ? 16'd2 : 16'd0);
                cfg_kernel_1x1 <= kernel_1x1;
                cfg_stride_2   <= stride_2;
                cfg_padding_1  <= padding_1;
                scan_x         <= 16'd0;
                scan_y         <= 16'd0;
                scan_active    <= 1'b1;
            end
        end
    end

endmodule
