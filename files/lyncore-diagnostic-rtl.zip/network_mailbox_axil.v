`timescale 1ns/1ps
// 32bit AXI4-Lite扩展页；AW/W独立接收，读写响应可反压，不覆盖旧Job接口。
// 本模块与mailbox同clk；跨到实际DDR core_clk需要后续系统CDC包装。
module network_mailbox_axil #(parameter [31:0] ACCEL_BASE=32'h30000000,CAPABILITY_BITS=32'd1,
 parameter integer EXTENSION_ENABLE=0)(
 input wire clk,rst_n,clear,
 input wire [31:0] s_awaddr,input wire s_awvalid,output wire s_awready,
 input wire [31:0] s_wdata,input wire [3:0] s_wstrb,input wire s_wvalid,output wire s_wready,
 output reg [1:0] s_bresp,output reg s_bvalid,input wire s_bready,
 input wire [31:0] s_araddr,input wire s_arvalid,output wire s_arready,
 output reg [31:0] s_rdata,output reg [1:0] s_rresp,output reg s_rvalid,input wire s_rready,
 output wire engine_start,input wire engine_ready,output wire engine_cancel,
 input wire engine_idle,engine_done,engine_error,writes_drained,input wire [767:0] engine_result_desc,
 input wire [31:0] engine_error_detail,
 output wire result_ack,result_valid,output wire [319:0] engine_config,output wire [191:0] engine_geometry,
 output wire [31:0] publish_seq,active_session,active_frame,
 // 默认关闭的读回扩展；旧实例可省略，控制页语义保持。
 output wire extension_valid,input wire extension_ready,output wire extension_write,
 output wire [11:0] extension_address,output wire [31:0] extension_wdata,output wire [3:0] extension_wstrb,
 input wire extension_response_valid,output wire extension_response_ready,
 input wire [31:0] extension_response_data,input wire extension_response_error
);
 reg aw_full,w_full,ar_full,waiting,owner_write,owner_extension,prefer_write;
 reg [31:0] aw_address,ar_address,w_data;reg [3:0] w_strobe;
 wire can_write=aw_full&&w_full&&!s_bvalid,can_read=ar_full&&!s_rvalid;
 wire choose_write=!waiting&&can_write&&(!can_read||prefer_write);
 wire choose_read=!waiting&&can_read&&!choose_write;
 wire [31:0] address=choose_write?aw_address:ar_address;
 wire [31:0] offset=address-ACCEL_BASE;
 wire mail_legal=address>=ACCEL_BASE+32'h100&&address<ACCEL_BASE+32'h1e0&&address[1:0]==0;
 wire ext_legal=EXTENSION_ENABLE!=0&&address>=ACCEL_BASE+32'h200&&address<=ACCEL_BASE+32'h21c&&address[1:0]==0;
 wire legal=mail_legal||ext_legal;
 wire request_valid=(choose_write||choose_read)&&mail_legal;
 wire request_ready,response_valid,response_ready,response_error;
 wire [31:0] response_data;
 assign s_awready=rst_n&&!aw_full;assign s_wready=rst_n&&!w_full;assign s_arready=rst_n&&!ar_full;
 wire selected_ready=ext_legal?extension_ready:request_ready;
 wire selected_response_valid=owner_extension?extension_response_valid:response_valid;
 wire [31:0] selected_response_data=owner_extension?extension_response_data:response_data;
 wire selected_response_error=owner_extension?extension_response_error:response_error;
 wire selected_response_ready=waiting&&(owner_write?!s_bvalid:!s_rvalid);
 assign response_ready=selected_response_ready&&!owner_extension;
 assign extension_valid=(choose_write||choose_read)&&ext_legal;
 assign extension_write=choose_write;assign extension_address=offset[11:0];
 assign extension_wdata=w_data;assign extension_wstrb=w_strobe;
 assign extension_response_ready=selected_response_ready&&owner_extension;
 network_mailbox #(.ACCEL_BASE(ACCEL_BASE),.CAPABILITY_BITS(CAPABILITY_BITS)) mailbox(.clk(clk),.rst_n(rst_n),.clear(clear),
  .bus_valid(request_valid),.bus_ready(request_ready),.bus_write(choose_write),.bus_address(offset[11:0]),.bus_wdata(w_data),.bus_wstrb(w_strobe),
  .response_valid(response_valid),.response_ready(response_ready),.response_data(response_data),.response_error(response_error),
  .engine_start(engine_start),.engine_ready(engine_ready),.engine_cancel(engine_cancel),.engine_idle(engine_idle),.engine_done(engine_done),
  .engine_error(engine_error),.engine_error_detail(engine_error_detail),.writes_drained(writes_drained),.engine_result_desc(engine_result_desc),.result_ack(result_ack),
  .engine_config(engine_config),.engine_geometry(engine_geometry),.result_valid(result_valid),.publish_seq(publish_seq),
  .active_session(active_session),.active_frame(active_frame));
 always @(posedge clk or negedge rst_n)begin
  if(!rst_n)begin aw_full<=0;w_full<=0;ar_full<=0;waiting<=0;owner_write<=0;owner_extension<=0;prefer_write<=1;
   aw_address<=0;ar_address<=0;w_data<=0;w_strobe<=0;s_bvalid<=0;s_rvalid<=0;s_bresp<=0;s_rresp<=0;s_rdata<=0;
  end else begin
   if(s_bvalid&&s_bready)s_bvalid<=0;if(s_rvalid&&s_rready)s_rvalid<=0;
   if(s_awvalid&&s_awready)begin aw_address<=s_awaddr;aw_full<=1;end
   if(s_wvalid&&s_wready)begin w_data<=s_wdata;w_strobe<=s_wstrb;w_full<=1;end
   if(s_arvalid&&s_arready)begin ar_address<=s_araddr;ar_full<=1;end
   if((choose_write||choose_read)&&(!legal||selected_ready))begin
    if(choose_write)begin aw_full<=0;w_full<=0;end else ar_full<=0;
    prefer_write<=!choose_write;
    if(legal)begin waiting<=1;owner_write<=choose_write;owner_extension<=ext_legal;end
    else if(choose_write)begin s_bvalid<=1;s_bresp<=2'b10;end
    else begin s_rvalid<=1;s_rresp<=2'b10;s_rdata<=0;end
   end
   if(selected_response_valid&&selected_response_ready)begin waiting<=0;
    if(owner_write)begin s_bvalid<=1;s_bresp<=selected_response_error?2'b10:2'b00;end
    else begin s_rvalid<=1;s_rresp<=selected_response_error?2'b10:2'b00;s_rdata<=selected_response_data;end
   end
  end
 end
endmodule
