`timescale 1ns/1ps

//名字既然叫psum_buffer，作用就是把每次计算的中间结果psum存到ram(片上存储中)，方便拿出来用继续加。
// 带地址的部分和缓冲区：每个地址保存一个输出位置的 8 个输出通道。
// 地址由上层控制器映射到输出通道组和空间坐标。

//先来说明一下group是啥，比如我现在有128个输入通道，然后每一拍只可以计算4拍，那么总共就有128/4=32组。first group 就是第一拍做得4个运算，last group就是最后一拍做的四个运算。
module psum_buffer #(
    parameter ADDR_WIDTH = 8,
    parameter DEPTH = 256
) (
    input  wire                    clk,
    input  wire                    rst_n,
    input  wire                    partial_valid,
    input  wire                    first_group,
    input  wire                    last_group,
    input  wire [ADDR_WIDTH-1:0]   partial_addr,
    input  wire signed [31:0]      partial0,
    input  wire signed [31:0]      partial1,
    input  wire signed [31:0]      partial2,
    input  wire signed [31:0]      partial3,
    input  wire signed [31:0]      partial4,
    input  wire signed [31:0]      partial5,
    input  wire signed [31:0]      partial6,
    input  wire signed [31:0]      partial7,
    output reg                     result_valid,
    output reg  [ADDR_WIDTH-1:0]   result_addr,
    output wire signed [31:0]      result0,
    output wire signed [31:0]      result1,
    output wire signed [31:0]      result2,
    output wire signed [31:0]      result3,
    output wire signed [31:0]      result4,
    output wire signed [31:0]      result5,
    output wire signed [31:0]      result6,
    output wire signed [31:0]      result7,
    // 任意输入组尚在等待 RAM 写回时为 1，包括不会产生 result_valid 的中间组。
    output wire                    busy
);

    // 第一级同步读取 RAM，并保存本次输入的地址、标志和部分和。
    reg                    read_valid;
    reg                    read_first;
    reg                    read_last;
    reg [ADDR_WIDTH-1:0]   read_addr;
    assign busy = read_valid;

    // 第二级写回 RAM；紧邻的同地址访问从最近一次写回结果旁路取数。（作用类似于forwarding）
    reg                    last_write_valid;
    reg [ADDR_WIDTH-1:0]   last_write_addr;
    wire                   use_bypass = last_write_valid &&
                                        (last_write_addr == read_addr);

    wire [255:0] partial_bus = {
        partial7, partial6, partial5, partial4,
        partial3, partial2, partial1, partial0
    };
    wire [255:0] result_bus;

    assign result0 = result_bus[ 31:  0];
    assign result1 = result_bus[ 63: 32];
    assign result2 = result_bus[ 95: 64];
    assign result3 = result_bus[127: 96];
    assign result4 = result_bus[159:128];
    assign result5 = result_bus[191:160];
    assign result6 = result_bus[223:192];
    assign result7 = result_bus[255:224];

    always @(posedge clk or negedge rst_n) begin
        if (!rst_n) begin
            read_valid       <= 1'b0;
            read_first       <= 1'b0;
            read_last        <= 1'b0;
            read_addr        <= {ADDR_WIDTH{1'b0}};
            last_write_valid <= 1'b0;
            last_write_addr  <= {ADDR_WIDTH{1'b0}};
            result_valid     <= 1'b0;
            result_addr      <= {ADDR_WIDTH{1'b0}};
        end else begin
            read_valid       <= partial_valid;
            last_write_valid <= read_valid;
            result_valid     <= read_valid && read_last;

            if (partial_valid) begin
                read_first <= first_group;
                read_last  <= last_group;
                read_addr  <= partial_addr;
            end
            if (read_valid) begin
                last_write_addr <= read_addr;
                if (read_last)
                    result_addr <= read_addr;
            end
        end
    end

    genvar co;
    generate
        for (co = 0; co < 8; co = co + 1) begin : channel
            // 不复位 RAM 内容，以便综合工具推断片上存储器。
            // 每个地址在首次使用时必须带 first_group。
            reg signed [31:0] mem [0:DEPTH-1];
            reg signed [31:0] read_data;
            reg signed [31:0] read_partial;
            reg signed [31:0] last_write_data;
            reg signed [31:0] result_data;

            wire signed [31:0] previous =
                use_bypass ? last_write_data : read_data;
            wire signed [31:0] sum_next =
                read_first ? read_partial : previous + read_partial;

            assign result_bus[co*32 +: 32] = result_data;

            always @(posedge clk) begin
                if (rst_n && partial_valid) begin
                    read_data    <= mem[partial_addr];
                    read_partial <= partial_bus[co*32 +: 32];
                end
                if (rst_n && read_valid)
                    mem[read_addr] <= sum_next;
            end

            always @(posedge clk or negedge rst_n) begin
                if (!rst_n) begin
                    last_write_data <= 32'sd0;
                    result_data     <= 32'sd0;
                end else if (read_valid) begin
                    last_write_data <= sum_next;
                    if (read_last)
                        result_data <= sum_next;
                end
            end
        end
    endgenerate

endmodule
