`timescale 1ns/1ps
// 驻留应答与 DDR 应答的四项归属队列。保存每个已接受请求的来源及原地址。
// DDR 客户自身按逻辑请求顺序返回；本地可以更早返回，但只能按共同队列顺序交给原 DMA。
// enable=0 且队列排空时原样旁路。Clear 禁止新请求，继续排空已接受的两种应答。
module feature_forward_read_mux(
    input wire clk,rst_n,clear,enable,
    input wire request_valid,output wire request_ready,input wire [31:0] request_address,
    output wire response_valid,input wire response_ready,
    output wire [31:0] response_address,response_data,output wire response_error,
    input wire local_hit,
    output wire local_request_valid,input wire local_request_ready,
    output wire [31:0] local_request_address,
    input wire local_response_valid,output wire local_response_ready,
    input wire [31:0] local_response_address,local_response_data,input wire local_response_error,
    output wire ddr_request_valid,input wire ddr_request_ready,
    output wire [31:0] ddr_request_address,
    input wire ddr_response_valid,output wire ddr_response_ready,
    input wire [31:0] ddr_response_address,ddr_response_data,input wire ddr_response_error,
    output wire busy,output reg protocol_fault,
    output wire [2:0] pending_count
);
    reg [1:0] head,tail;
    reg [2:0] count;
    reg [3:0] from_local;
    reg [31:0] addresses[0:3];
    wire routed=enable || count!=0;
    wire local_head=count!=0 && from_local[head];
    wire room=count<4 && !clear && !protocol_fault;
    assign busy=count!=0;
    assign pending_count=count;
    assign local_request_valid=routed && request_valid && local_hit && room;
    assign local_request_address=request_address;
    assign ddr_request_valid=routed?(request_valid && !local_hit && room):request_valid;
    assign ddr_request_address=request_address;
    assign request_ready=routed?(room && (local_hit?local_request_ready:ddr_request_ready)):ddr_request_ready;
    assign response_valid=routed?(count!=0 && (local_head?local_response_valid:ddr_response_valid)):ddr_response_valid;
    assign response_address=routed && local_head?local_response_address:ddr_response_address;
    assign response_data=routed && local_head?local_response_data:ddr_response_data;
    assign response_error=(routed && local_head?local_response_error:ddr_response_error) ||
        (routed && response_valid && response_address!=addresses[head]);
    assign local_response_ready=routed && local_head && response_ready;
    assign ddr_response_ready=routed?(count!=0 && !local_head && response_ready):response_ready;
    wire push=routed && request_valid && request_ready;
    wire pop=routed && response_valid && response_ready;
    integer k;
    always @(posedge clk or negedge rst_n)begin
        if(!rst_n)begin head<=0;tail<=0;count<=0;from_local<=0;protocol_fault<=0;
            for(k=0;k<4;k=k+1)addresses[k]<=0;
        end else begin
            case({push,pop})2'b10:count<=count+1'b1;2'b01:count<=count-1'b1;default:begin end endcase
            if(push)begin addresses[tail]<=request_address;from_local[tail]<=local_hit;tail<=tail+1'b1;end
            if(pop)begin
                head<=head+1'b1;
                if(response_error)protocol_fault<=1;
            end
            // 错误锁存。新网络在 CONFIG 复位此小队列，运行中不得丢弃已接受请求。
        end
    end
endmodule
