// Sixteen-pixel cells with 5x7 glyphs, doubled in both axes.
module overlay_object_label(
 input wire clk,rst_n,show,
 input wire [15:0] x,y,
 input wire [11:0] left,top,
 input wire [15:0] class_id,
 input wire [6:0] pct,
 output reg bg,ink
);
 reg [111:0] name_text;
 reg [3:0] name_length;
 always @* begin
  case(class_id)
   16'd0: begin name_text="PERSON        "; name_length=4'd6; end
   16'd1: begin name_text="BICYCLE       "; name_length=4'd7; end
   16'd2: begin name_text="CAR           "; name_length=4'd3; end
   16'd3: begin name_text="MOTORCYCLE    "; name_length=4'd10; end
   16'd4: begin name_text="AIRPLANE      "; name_length=4'd8; end
   16'd5: begin name_text="BUS           "; name_length=4'd3; end
   16'd6: begin name_text="TRAIN         "; name_length=4'd5; end
   16'd7: begin name_text="TRUCK         "; name_length=4'd5; end
   16'd8: begin name_text="BOAT          "; name_length=4'd4; end
   16'd9: begin name_text="TRAFFIC LIGHT "; name_length=4'd13; end
   16'd10: begin name_text="FIRE HYDRANT  "; name_length=4'd12; end
   16'd11: begin name_text="STOP SIGN     "; name_length=4'd9; end
   16'd12: begin name_text="PARKING METER "; name_length=4'd13; end
   16'd13: begin name_text="BENCH         "; name_length=4'd5; end
   16'd14: begin name_text="BIRD          "; name_length=4'd4; end
   16'd15: begin name_text="CAT           "; name_length=4'd3; end
   16'd16: begin name_text="DOG           "; name_length=4'd3; end
   16'd17: begin name_text="HORSE         "; name_length=4'd5; end
   16'd18: begin name_text="SHEEP         "; name_length=4'd5; end
   16'd19: begin name_text="COW           "; name_length=4'd3; end
   16'd20: begin name_text="ELEPHANT      "; name_length=4'd8; end
   16'd21: begin name_text="BEAR          "; name_length=4'd4; end
   16'd22: begin name_text="ZEBRA         "; name_length=4'd5; end
   16'd23: begin name_text="GIRAFFE       "; name_length=4'd7; end
   16'd24: begin name_text="BACKPACK      "; name_length=4'd8; end
   16'd25: begin name_text="UMBRELLA      "; name_length=4'd8; end
   16'd26: begin name_text="HANDBAG       "; name_length=4'd7; end
   16'd27: begin name_text="TIE           "; name_length=4'd3; end
   16'd28: begin name_text="SUITCASE      "; name_length=4'd8; end
   16'd29: begin name_text="FRISBEE       "; name_length=4'd7; end
   16'd30: begin name_text="SKIS          "; name_length=4'd4; end
   16'd31: begin name_text="SNOWBOARD     "; name_length=4'd9; end
   16'd32: begin name_text="SPORTS BALL   "; name_length=4'd11; end
   16'd33: begin name_text="KITE          "; name_length=4'd4; end
   16'd34: begin name_text="BASEBALL BAT  "; name_length=4'd12; end
   16'd35: begin name_text="BASEBALL GLOVE"; name_length=4'd14; end
   16'd36: begin name_text="SKATEBOARD    "; name_length=4'd10; end
   16'd37: begin name_text="SURFBOARD     "; name_length=4'd9; end
   16'd38: begin name_text="TENNIS RACKET "; name_length=4'd13; end
   16'd39: begin name_text="BOTTLE        "; name_length=4'd6; end
   16'd40: begin name_text="WINE GLASS    "; name_length=4'd10; end
   16'd41: begin name_text="CUP           "; name_length=4'd3; end
   16'd42: begin name_text="FORK          "; name_length=4'd4; end
   16'd43: begin name_text="KNIFE         "; name_length=4'd5; end
   16'd44: begin name_text="SPOON         "; name_length=4'd5; end
   16'd45: begin name_text="BOWL          "; name_length=4'd4; end
   16'd46: begin name_text="BANANA        "; name_length=4'd6; end
   16'd47: begin name_text="APPLE         "; name_length=4'd5; end
   16'd48: begin name_text="SANDWICH      "; name_length=4'd8; end
   16'd49: begin name_text="ORANGE        "; name_length=4'd6; end
   16'd50: begin name_text="BROCCOLI      "; name_length=4'd8; end
   16'd51: begin name_text="CARROT        "; name_length=4'd6; end
   16'd52: begin name_text="HOT DOG       "; name_length=4'd7; end
   16'd53: begin name_text="PIZZA         "; name_length=4'd5; end
   16'd54: begin name_text="DONUT         "; name_length=4'd5; end
   16'd55: begin name_text="CAKE          "; name_length=4'd4; end
   16'd56: begin name_text="CHAIR         "; name_length=4'd5; end
   16'd57: begin name_text="COUCH         "; name_length=4'd5; end
   16'd58: begin name_text="POTTED PLANT  "; name_length=4'd12; end
   16'd59: begin name_text="BED           "; name_length=4'd3; end
   16'd60: begin name_text="DINING TABLE  "; name_length=4'd12; end
   16'd61: begin name_text="TOILET        "; name_length=4'd6; end
   16'd62: begin name_text="TV            "; name_length=4'd2; end
   16'd63: begin name_text="LAPTOP        "; name_length=4'd6; end
   16'd64: begin name_text="MOUSE         "; name_length=4'd5; end
   16'd65: begin name_text="REMOTE        "; name_length=4'd6; end
   16'd66: begin name_text="KEYBOARD      "; name_length=4'd8; end
   16'd67: begin name_text="CELL PHONE    "; name_length=4'd10; end
   16'd68: begin name_text="MICROWAVE     "; name_length=4'd9; end
   16'd69: begin name_text="OVEN          "; name_length=4'd4; end
   16'd70: begin name_text="TOASTER       "; name_length=4'd7; end
   16'd71: begin name_text="SINK          "; name_length=4'd4; end
   16'd72: begin name_text="REFRIGERATOR  "; name_length=4'd12; end
   16'd73: begin name_text="BOOK          "; name_length=4'd4; end
   16'd74: begin name_text="CLOCK         "; name_length=4'd5; end
   16'd75: begin name_text="VASE          "; name_length=4'd4; end
   16'd76: begin name_text="SCISSORS      "; name_length=4'd8; end
   16'd77: begin name_text="TEDDY BEAR    "; name_length=4'd10; end
   16'd78: begin name_text="HAIR DRIER    "; name_length=4'd10; end
   16'd79: begin name_text="TOOTHBRUSH    "; name_length=4'd10; end
   default: begin name_text="OBJECT        "; name_length=4'd6; end
  endcase
 end
 wire [4:0] cells={1'b0,name_length}+5'd5;
 wire [15:0] width={7'd0,cells,4'b0};
 wire [15:0] left_edge={4'd0,left};
 wire [15:0] top_edge={4'd0,top};
 wire [15:0] origin_x=left_edge+width>16'd1280 ? 16'd1280-width:left_edge;
 wire [15:0] origin_y=top_edge>=16?top_edge-16:top_edge;
 wire [15:0] dx=x-origin_x;
 wire [15:0] dy=y-origin_y;
 wire [4:0] cell_index=dx[8:4];
 wire [4:0] suffix=cell_index-{1'b0,name_length};
 wire [6:0] tens=pct/7'd10;
 wire [6:0] ones=pct%7'd10;
 reg [7:0] character;
 always @* begin
  character=8'h20;
  if(cell_index<{1'b0,name_length})
   character=name_text[111-8*cell_index-:8];
  else case(suffix)
   1:if(pct==100)character=8'h31;
   2:if(pct>=10)character=8'h30+(pct==100?8'd0:{1'b0,tens});
   3:character=8'h30+{1'b0,ones};
   4:character=8'h25;
   default:begin end
  endcase
 end
 reg [7:0] char_q;
 reg [2:0] row_q,col_q;
 reg bg_q,cell_ink_q;
 reg [34:0] glyph;
 always @* begin
  case(char_q)
   8'h41: glyph=35'b01110100011000111111100011000110001;
   8'h42: glyph=35'b11110100011000111110100011000111110;
   8'h43: glyph=35'b01110100011000010000100001000101110;
   8'h44: glyph=35'b11110100011000110001100011000111110;
   8'h45: glyph=35'b11111100001000011110100001000011111;
   8'h46: glyph=35'b11111100001000011110100001000010000;
   8'h47: glyph=35'b01110100011000010111100011000101111;
   8'h48: glyph=35'b10001100011000111111100011000110001;
   8'h49: glyph=35'b01110001000010000100001000010001110;
   8'h4a: glyph=35'b00111000100001000010100101001001100;
   8'h4b: glyph=35'b10001100101010011000101001001010001;
   8'h4c: glyph=35'b10000100001000010000100001000011111;
   8'h4d: glyph=35'b10001110111010110101100011000110001;
   8'h4e: glyph=35'b10001110011010110011100011000110001;
   8'h4f: glyph=35'b01110100011000110001100011000101110;
   8'h50: glyph=35'b11110100011000111110100001000010000;
   8'h51: glyph=35'b01110100011000110001101011001001101;
   8'h52: glyph=35'b11110100011000111110101001001010001;
   8'h53: glyph=35'b01111100001000001110000010000111110;
   8'h54: glyph=35'b11111001000010000100001000010000100;
   8'h55: glyph=35'b10001100011000110001100011000101110;
   8'h56: glyph=35'b10001100011000110001100010101000100;
   8'h57: glyph=35'b10001100011000110101101011010101010;
   8'h58: glyph=35'b10001100010101000100010101000110001;
   8'h59: glyph=35'b10001100010101000100001000010000100;
   8'h5a: glyph=35'b11111000010001000100010001000011111;
   8'h30: glyph=35'b01110100011001110101110011000101110;
   8'h31: glyph=35'b00100011000010000100001000010001110;
   8'h32: glyph=35'b01110100010000100010001000100011111;
   8'h33: glyph=35'b11110000010000101110000010000111110;
   8'h34: glyph=35'b00010001100101010010111110001000010;
   8'h35: glyph=35'b11111100001000011110000010000111110;
   8'h36: glyph=35'b01110100001000011110100011000101110;
   8'h37: glyph=35'b11111000010001000100010000100001000;
   8'h38: glyph=35'b01110100011000101110100011000101110;
   8'h39: glyph=35'b01110100011000101111000010000101110;
   8'h25: glyph=35'b11001110100001000100010000101110011;
   default:glyph=0;
  endcase
 end
 always @(posedge clk or negedge rst_n)begin
  if(!rst_n)begin
   char_q<=0;row_q<=0;col_q<=0;bg_q<=0;cell_ink_q<=0;bg<=0;ink<=0;
  end else begin
   char_q<=character;row_q<=dy[3:1];col_q<=dx[3:1];
   bg_q<=show && x>=origin_x && y>=origin_y && dx<width && dy<16;
   cell_ink_q<=dx[3:1]<5 && dy[3:1]<7;
   bg<=bg_q;ink<=bg_q && cell_ink_q && glyph[34-5*row_q-col_q];
  end
 end
endmodule
