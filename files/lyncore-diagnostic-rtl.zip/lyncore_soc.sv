`timescale 1ns/1ps
module lyncore_soc #(
    parameter ROM_INIT_FILE = "",
    parameter integer ROM_WORDS = 4096,
    parameter integer CLOCK_HZ = 27000000,
    parameter integer BAUD = 115200,
    parameter bit LINE_BUFFER = 1,
    parameter bit HALT_ON_TRAP = 0,
    parameter bit ENABLE_M = 0,
    parameter bit ENABLE_ZBA = 0,
    parameter bit ENABLE_ZBB = 0,
    parameter bit ENABLE_CACHE = 0,
    parameter bit ENABLE_BP = 0,
    parameter integer BP_INDEX_BITS = 4,
    parameter integer BP_HISTORY_BITS = 0,
    parameter bit BP_HASH_INDEX = 0,
    parameter bit LOAD_USE_INTERLOCK = 1,
    parameter bit PIPELINED_MUL = 0,
    parameter bit ENABLE_RAS = 0,
    parameter bit DECOUPLED_FETCH = 0,
    parameter bit DUAL_ISSUE = 0,
    parameter integer CACHE_SET_BITS = 6,
    parameter integer ICACHE_SET_BITS = CACHE_SET_BITS,
    parameter integer DCACHE_SET_BITS = CACHE_SET_BITS,
    parameter bit ENABLE_ACCEL = 0,
    parameter logic [31:0] ACCEL_BASE = 32'h30000000
) (
    input logic clk, rst, uart_rx,
    input logic [4:0] keys,
    output logic uart_tx,
    output logic [7:0] leds,
    output logic halted,
    output logic [63:0] cycle_count, instret_count,
    output logic accel_valid, accel_write,
    output logic [31:0] accel_addr, accel_wdata,
    output logic [3:0] accel_wstrb,
    input logic accel_ready, accel_error,
    input logic [31:0] accel_rdata,
    input logic [31:0] camera_frame_id,
    output logic camera_frame_done
);
    logic imem_valid, imem_ready, imem_error;
    logic [31:0] imem_addr, imem_rdata;
    logic imem_second_valid;
    logic [31:0] imem_second_data;
    logic dmem_valid, dmem_write, dmem_ready, dmem_error;
    logic [31:0] dmem_addr, dmem_wdata, dmem_rdata;
    logic [31:0] dmem_preview_addr;
    logic dmem_preview_stall;
    logic [3:0] dmem_wstrb;
    logic irq_timer, irq_software, irq_gpio, irq_uart;
    logic irq_timer_sampled;
    always_ff @(posedge clk) begin
        if(rst) irq_timer_sampled <= 1'b0;
        else irq_timer_sampled <= irq_timer;
    end
    logic ram_ready, uart_ready, uart_error, peripheral_ready, peripheral_error;
    logic [31:0] ram_data, uart_data, peripheral_data;
    logic rom_data_ready, rom_data_error;
    logic [31:0] rom_data;
    logic bus_imem_valid, bus_imem_ready, bus_imem_error;
    logic [31:0] bus_imem_addr, bus_imem_rdata;
    logic bus_dmem_valid, bus_dmem_write, bus_dmem_ready, bus_dmem_error;
    logic [31:0] bus_dmem_addr, bus_dmem_wdata, bus_dmem_rdata;
    logic [3:0] bus_dmem_wstrb;
    logic cache_invalidate, predictor_invalidate, cache_control_error;
    logic [31:0] bp_branches,bp_mispredictions;
    logic [31:0] cache_control_data, i_cache_hits, i_cache_misses, d_cache_hits, d_cache_misses;
    localparam logic [31:0] ROM_BYTES=ROM_WORDS*4;
    localparam integer I_ADDRESS_BITS=($clog2(ROM_BYTES)>ICACHE_SET_BITS+4) ? $clog2(ROM_BYTES) : ICACHE_SET_BITS+5;
    localparam integer D_ADDRESS_BITS=(14>DCACHE_SET_BITS+4) ? 14 : DCACHE_SET_BITS+5;
    wire rom_sel = bus_dmem_addr < ROM_BYTES;
    wire ram_sel = bus_dmem_addr >= 32'h00010000 && bus_dmem_addr < 32'h00014000;
    wire uart_sel = bus_dmem_addr[31:8] == 24'h200010;
    wire peripheral_sel = bus_dmem_addr[31:8] == 24'h200000 || bus_dmem_addr[31:8] == 24'h200020;
    wire cache_control_sel = bus_dmem_addr[31:8] == 24'h200030;
    wire uart_offset_valid = bus_dmem_addr[7:4] == 0 && bus_dmem_addr[1:0] == 0;
    wire accel_sel = ENABLE_ACCEL && bus_dmem_addr[31:12] == ACCEL_BASE[31:12];
    assign accel_valid = bus_dmem_valid && accel_sel;
    assign accel_write = bus_dmem_write;
    assign accel_addr = bus_dmem_addr - ACCEL_BASE;
    assign accel_wdata = bus_dmem_wdata;
    assign accel_wstrb = bus_dmem_wstrb;
    always_comb begin
        cache_control_error=0; cache_control_data=0;
        case(bus_dmem_addr[7:2])
            0: begin
                cache_control_data=(ENABLE_CACHE ? 1 : 0) | (ENABLE_BP ? 2 : 0);
                if(bus_dmem_write && bus_dmem_wstrb[0] && |bus_dmem_wdata[7:2]) cache_control_error=1;
            end
            1: cache_control_data=i_cache_hits;
            2: cache_control_data=i_cache_misses;
            3: cache_control_data=d_cache_hits;
            4: cache_control_data=d_cache_misses;
            5: cache_control_data=bp_branches;
            6: cache_control_data=bp_mispredictions;
            default: cache_control_error=1;
        endcase
        if(bus_dmem_write && bus_dmem_addr[7:2]!=0) cache_control_error=1;
        if(bus_dmem_addr[1:0]!=0) cache_control_error=1;
    end
    always_ff @(posedge clk) begin
        if(rst) begin cache_invalidate<=0; predictor_invalidate<=0; end
        else begin
            cache_invalidate<=bus_dmem_valid && bus_dmem_ready && !bus_dmem_error &&
                bus_dmem_write && cache_control_sel && bus_dmem_wstrb[0] && bus_dmem_wdata[0];
            predictor_invalidate<=bus_dmem_valid && bus_dmem_ready && !bus_dmem_error &&
                bus_dmem_write && cache_control_sel && bus_dmem_wstrb[0] && bus_dmem_wdata[1];
        end
    end
    generate if(ENABLE_CACHE) begin : caches
        logic i_line_valid,i_line_ready,i_line_error,i_word_valid,i_word_ready;
        logic i_refill_valid,i_refill_ready;
        logic [31:0] i_line_addr,i_word_addr,i_refill_addr;
        logic [127:0] i_line_data;
        logic d_line_valid,d_line_ready,d_line_error,d_word_valid,d_word_write,d_word_ready,d_word_error;
        logic d_refill_valid,d_refill_ready;
        logic [31:0] d_line_addr,d_word_addr,d_word_wdata,d_refill_addr;
        logic [3:0] d_word_wstrb;
        logic [127:0] d_line_data;
        logic d_read_valid,d_read_error;
        logic d_write_valid,d_write_error;
        logic [31:0] d_read_data;
        logic d_cacheable;
        // The same preview edge already selects D-cache tags and data. Decode
        // the private SRAM window there too, before the MEM-to-EX load bypass.
        always_ff @(posedge clk) if(!dmem_preview_stall)
            d_cacheable<=dmem_preview_addr>=32'h10000 && dmem_preview_addr<32'h14000;
        lyncore_cache #(.SET_BITS(ICACHE_SET_BITS),.FETCH_PAIR(DUAL_ISSUE),.ADDRESS_BITS(I_ADDRESS_BITS)) instruction_cache(.clk(clk),.rst(rst),.invalidate(cache_invalidate),
            .cpu_valid(imem_valid),.cpu_write(1'b0),.cpu_cacheable(imem_addr<ROM_BYTES && imem_addr[1:0]==0),
            .cpu_addr(imem_addr),.preview_addr(32'b0),.preview_stall(1'b0),.cpu_wdata(32'b0),.cpu_wstrb(4'b0),
            .cpu_ready(imem_ready),.cpu_error(imem_error),.cpu_rdata(imem_rdata),
            .cpu_second_valid(imem_second_valid),.cpu_second_data(imem_second_data),
            .line_valid(i_line_valid),.line_addr(i_line_addr),.line_ready(i_line_ready),.line_error(i_line_error),.line_rdata(i_line_data),
            .word_valid(i_word_valid),.word_write(),.word_addr(i_word_addr),.word_wdata(),.word_wstrb(),
            .word_ready(i_word_ready),.word_error(bus_imem_error),.word_rdata(bus_imem_rdata),
            .hit_count(i_cache_hits),.miss_count(i_cache_misses));
        lyncore_cache_refill instruction_refill(.clk(clk),.rst(rst),.line_valid(i_line_valid),.line_addr(i_line_addr),
            .line_ready(i_line_ready),.line_error(i_line_error),.line_rdata(i_line_data),
            .word_valid(i_refill_valid),.word_addr(i_refill_addr),.word_ready(i_refill_ready),
            .word_error(bus_imem_error),.word_rdata(bus_imem_rdata));
        assign bus_imem_valid=i_refill_valid || i_word_valid;
        assign bus_imem_addr=i_refill_valid ? i_refill_addr : i_word_addr;
        assign i_refill_ready=bus_imem_ready && i_refill_valid;
        assign i_word_ready=bus_imem_ready && i_word_valid;
        lyncore_cache #(.SET_BITS(DCACHE_SET_BITS),.ADDRESS_BITS(D_ADDRESS_BITS),.LOOKAHEAD(1),.HOLD_PREVIEW(1)) data_cache(.clk(clk),.rst(rst),.invalidate(cache_invalidate),
            .cpu_valid(dmem_valid),.cpu_write(dmem_write),
            .cpu_cacheable(d_cacheable),
            .cpu_addr(dmem_addr),.preview_addr(dmem_preview_addr),.preview_stall(dmem_preview_stall),.cpu_wdata(dmem_wdata),.cpu_wstrb(dmem_wstrb),
            .cpu_ready(dmem_ready),.cpu_error(dmem_error),.cpu_rdata(dmem_rdata),
            .line_valid(d_line_valid),.line_addr(d_line_addr),.line_ready(d_line_ready),.line_error(d_line_error),.line_rdata(d_line_data),
            .word_valid(d_word_valid),.word_write(d_word_write),.word_addr(d_word_addr),.word_wdata(d_word_wdata),.word_wstrb(d_word_wstrb),
            .word_ready(d_word_ready),.word_error(d_word_write ? d_write_error : d_read_error),.word_rdata(d_read_data),
            .hit_count(d_cache_hits),.miss_count(d_cache_misses));
        lyncore_cache_refill data_refill(.clk(clk),.rst(rst),.line_valid(d_line_valid),.line_addr(d_line_addr),
            .line_ready(d_line_ready),.line_error(d_line_error),.line_rdata(d_line_data),
            .word_valid(d_refill_valid),.word_addr(d_refill_addr),.word_ready(d_refill_ready),
            .word_error(d_read_error),.word_rdata(d_read_data));
        // Register backend reads before they enter load forwarding. Cache hits
        // remain unchanged; stores still commit at the original handshake.
        // Suppress the backend request while delivering its saved response,
        // including read-to-clear MMIO, so no transaction executes twice.
        always_ff @(posedge clk) begin
            if(rst) begin d_read_valid<=0; d_read_error<=0; d_read_data<=0; end
            else if(d_read_valid)begin
                if(d_refill_valid || (d_word_valid && !d_word_write))d_read_valid<=0;
            end
            else if(bus_dmem_valid && !bus_dmem_write && bus_dmem_ready) begin
                d_read_valid<=1;
                d_read_error<=bus_dmem_error;
                d_read_data<=bus_dmem_rdata;
            end
        end
        // Complete backend writes through a register too. Suppress a second
        // backend issue while the held CPU request consumes its response.
        always_ff @(posedge clk) begin
            if(rst) begin d_write_valid<=0;d_write_error<=0;end
            else if(d_write_valid)begin
                if(d_word_valid && d_word_write)d_write_valid<=0;
            end
            else if(bus_dmem_valid && bus_dmem_write && bus_dmem_ready)begin
                d_write_valid<=1;d_write_error<=bus_dmem_error;
            end
        end
        assign bus_dmem_valid=(d_refill_valid || d_word_valid) && !d_read_valid && !d_write_valid;
        assign bus_dmem_addr=d_refill_valid ? d_refill_addr : d_word_addr;
        assign bus_dmem_write=d_word_valid && d_word_write;
        assign bus_dmem_wdata=d_word_wdata;
        assign bus_dmem_wstrb=d_word_valid ? d_word_wstrb : 0;
        assign d_refill_ready=d_read_valid && d_refill_valid;
        assign d_word_ready=d_word_valid && (d_word_write ? d_write_valid : d_read_valid);
    end else begin : no_caches
        assign imem_second_valid=0; assign imem_second_data=0;
        assign bus_imem_valid=imem_valid; assign bus_imem_addr=imem_addr;
        assign imem_ready=bus_imem_ready; assign imem_error=bus_imem_error; assign imem_rdata=bus_imem_rdata;
        assign bus_dmem_valid=dmem_valid; assign bus_dmem_write=dmem_write;
        assign bus_dmem_addr=dmem_addr; assign bus_dmem_wdata=dmem_wdata; assign bus_dmem_wstrb=dmem_wstrb;
        assign dmem_ready=bus_dmem_ready; assign dmem_error=bus_dmem_error; assign dmem_rdata=bus_dmem_rdata;
        assign i_cache_hits=0; assign i_cache_misses=0; assign d_cache_hits=0; assign d_cache_misses=0;
    end endgenerate
    lyncore_cpu #(.HALT_ON_TRAP(HALT_ON_TRAP), .ENABLE_M(ENABLE_M), .ENABLE_ZBA(ENABLE_ZBA), .ENABLE_ZBB(ENABLE_ZBB), .ENABLE_BP(ENABLE_BP),
                  .BP_INDEX_BITS(BP_INDEX_BITS),.BP_HISTORY_BITS(BP_HISTORY_BITS),.BP_HASH_INDEX(BP_HASH_INDEX), .LOAD_USE_INTERLOCK(LOAD_USE_INTERLOCK),.PIPELINED_MUL(PIPELINED_MUL),.ENABLE_RAS(ENABLE_RAS),.DECOUPLED_FETCH(DECOUPLED_FETCH),.DUAL_ISSUE(DUAL_ISSUE)) cpu(
        .clk(clk), .rst(rst), .irq_software(irq_software), .irq_timer(irq_timer_sampled),
        .predictor_flush(predictor_invalidate),.branch_count(bp_branches),.mispredict_count(bp_mispredictions),
        .irq_external(irq_gpio | irq_uart),
        .imem_valid(imem_valid), .imem_ready(imem_ready), .imem_error(imem_error),
        .imem_addr(imem_addr), .imem_rdata(imem_rdata),
        .imem_second_valid(imem_second_valid),.imem_second_data(imem_second_data),
        .dmem_valid(dmem_valid), .dmem_write(dmem_write), .dmem_ready(dmem_ready),
        .dmem_error(dmem_error), .dmem_addr(dmem_addr), .dmem_wdata(dmem_wdata),
        .dmem_preview_addr(dmem_preview_addr),.dmem_preview_stall(dmem_preview_stall),
        .dmem_rdata(dmem_rdata), .dmem_wstrb(dmem_wstrb), .halted(halted),
        .cycle_count(cycle_count), .instret_count(instret_count)
    );
    lyncore_boot_rom #(.WORDS(ROM_WORDS),.INIT_FILE(ROM_INIT_FILE), .LINE_BUFFER(LINE_BUFFER)) rom(
        .clk(clk), .rst(rst), .valid(bus_imem_valid), .addr(bus_imem_addr),
        .ready(bus_imem_ready), .error(bus_imem_error), .rdata(bus_imem_rdata),
        .data_valid(bus_dmem_valid && rom_sel), .data_write(bus_dmem_write), .data_addr(bus_dmem_addr),
        .data_ready(rom_data_ready), .data_error(rom_data_error), .data_rdata(rom_data)
    );
    lyncore_sram ram(.clk(clk), .rst(rst), .valid(bus_dmem_valid && ram_sel),
        .write(bus_dmem_write), .addr(bus_dmem_addr), .wdata(bus_dmem_wdata), .wstrb(bus_dmem_wstrb),
        .ready(ram_ready), .rdata(ram_data));
    lyncore_uart #(.CLOCK_HZ(CLOCK_HZ), .BAUD(BAUD)) uart(
        .clk(clk), .rst(rst), .rx(uart_rx), .tx(uart_tx), .irq(irq_uart),
        .valid(bus_dmem_valid && uart_sel && uart_offset_valid), .write(bus_dmem_write),
        .word_addr(bus_dmem_addr[5:2]), .wdata(bus_dmem_wdata), .wstrb(bus_dmem_wstrb),
        .ready(uart_ready), .error(uart_error), .rdata(uart_data));
    lyncore_peripherals peripherals(.clk(clk), .rst(rst),
        .valid(bus_dmem_valid && peripheral_sel), .write(bus_dmem_write), .addr(bus_dmem_addr),
        .wdata(bus_dmem_wdata), .wstrb(bus_dmem_wstrb), .keys(keys), .leds(leds),
        .irq_timer(irq_timer), .irq_software(irq_software), .irq_gpio(irq_gpio),
        .ready(peripheral_ready), .error(peripheral_error), .rdata(peripheral_data));
    wire camera_frame_sel = bus_dmem_addr == 32'h20004000;
    always_ff @(posedge clk) begin
        if (rst) camera_frame_done <= 1'b0;
        else if (bus_dmem_valid && bus_dmem_write && camera_frame_sel && bus_dmem_wstrb[0])
            camera_frame_done <= bus_dmem_wdata[0];
    end
    always_comb begin
        bus_dmem_ready = bus_dmem_valid;
        bus_dmem_error = bus_dmem_valid;
        bus_dmem_rdata = 0;
        if (rom_sel) begin
            bus_dmem_ready = rom_data_ready; bus_dmem_error = rom_data_error; bus_dmem_rdata = rom_data;
        end else if (ram_sel) begin
            bus_dmem_ready = ram_ready; bus_dmem_error = 0; bus_dmem_rdata = ram_data;
        end else if (uart_sel && uart_offset_valid) begin
            bus_dmem_ready = uart_ready; bus_dmem_error = uart_error; bus_dmem_rdata = uart_data;
        end else if (peripheral_sel) begin
            bus_dmem_ready = peripheral_ready; bus_dmem_error = peripheral_error;
            bus_dmem_rdata = peripheral_data;
        end else if(cache_control_sel) begin
            bus_dmem_ready=bus_dmem_valid; bus_dmem_error=bus_dmem_valid && cache_control_error;
            bus_dmem_rdata=cache_control_data;
        end else if (camera_frame_sel) begin
            bus_dmem_error = 1'b0;
            bus_dmem_rdata = camera_frame_id;
        end else if (accel_sel) begin
            bus_dmem_ready = accel_ready; bus_dmem_error = accel_error; bus_dmem_rdata = accel_rdata;
        end
    end
endmodule
