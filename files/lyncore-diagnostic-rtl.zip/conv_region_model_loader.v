`timescale 1ns/1ps
// 官方镜像供数：参数、SiLU表与权重全部经 model_memory_adapter 读取。
// 只使用全局 co/ci；局部 group8 缓存编号不参与模型地址计算。
module conv_region_model_loader #(
    parameter integer WEIGHT_PREFETCH_ENABLE=0
) (
    input wire clk, rst_n, clear, start,
    output wire ready, busy,
    output reg done, error, cancelled,
    input wire [15:0] model_task, cin_groups, cout_groups,
    input wire kernel_1x1, silu_enable,
    output wire region_start, region_clear,
    input wire region_ready, region_busy, region_done, region_error, region_cancelled, region_result_valid,
    output wire cfg_we,
    input wire cfg_ready,
    output wire [15:0] cfg_co_group,
    output wire [255:0] cfg_bias_bus,
    output wire [247:0] cfg_multiplier_bus, cfg_grid_multiplier_bus,
    output wire [47:0] cfg_shift_bus, cfg_grid_shift_bus,
    output wire lut_load_start, lut_load_valid,
    input wire lut_load_ready,
    output wire [7:0] lut_load_data,
    input wire weight_request, weight_ready,
    output wire weight_valid,
    output wire [31:0] weight_word,
    input wire [15:0] current_ci_group, current_co_group,
    input wire prefetch_enable, future_weight_valid,
    input wire [15:0] future_weight_ci, future_weight_co,
    output wire [15:0] memory_request_co_group, memory_request_ci_group,
    output wire memory_request_valid,
    input wire memory_request_ready,
    output wire [1:0] memory_request_kind,
    output wire [15:0] memory_request_task,
    output wire [31:0] memory_request_address,
    input wire memory_response_valid,
    output wire memory_response_ready,
    input wire [1:0] memory_response_kind,
    input wire [15:0] memory_response_task,
    input wire [31:0] memory_response_address,
    input wire [847:0] memory_response_data,
    input wire memory_response_error
);
    localparam IDLE=0, PARAM_REQ=1, PARAM_WAIT=2, LUT_START=3,
        LUT_REQ=4,LUT_WAIT=5,START=6,RUN=7,WEIGHT_REQ=8,WEIGHT_WAIT=9,ABORT=10,FINISH=11,WEIGHT_BASE=12;
    reg [3:0] state;
    reg [15:0] task_id,cig,cog,param_group;
    reg [31:0] lut_index,weight_address;
    reg [31:0] weight_block_index;
    reg [15:0] weight_co_group,weight_ci_group;
    reg [6:0] weight_position,weight_last;
    reg activation,pending,failed,aborted;
    reg [1:0] expected_kind;
    reg [31:0] expected_address;
    reg pf_active;
    reg [15:0] generation, response_generation;
    wire pf_rq, pf_rr, pf_wv, pf_busy, pf_error;
    wire [31:0] pf_address,pf_word;
    wire [15:0] pf_co,pf_ci,pf_generation;
    wire pf_owner=pf_active && state==RUN;
    generate if(WEIGHT_PREFETCH_ENABLE!=0) begin:g_weight_prefetch
        weight_tile_prefetch stage(
            .clk(clk),.rst_n(rst_n),.clear(clear || state==ABORT),.enable(pf_owner),
            .generation(generation),.task_id(task_id),.cin_groups(cig),.kernel_1x1(weight_last==7),
            .demand(pf_owner && weight_request),.weight_ready(weight_ready),
            .current_co(current_co_group),.current_ci(current_ci_group),
            .future_valid(pf_owner && future_weight_valid),.future_co(future_weight_co),.future_ci(future_weight_ci),
            .weight_valid(pf_wv),.weight_word(pf_word),
            .request_valid(pf_rq),.request_ready(memory_request_ready && pf_owner),
            .request_address(pf_address),.request_co(pf_co),.request_ci(pf_ci),.request_generation(pf_generation),
            .response_valid(memory_response_valid && (pf_owner || state==ABORT)),.response_ready(pf_rr),
            .response_task(memory_response_task),.response_kind(memory_response_kind),
            .response_generation(response_generation),.response_address(memory_response_address),
            .response_data(memory_response_data[31:0]),.response_error(memory_response_error),
            .busy(pf_busy),.error(pf_error),.cancelled());
    end else begin:g_no_weight_prefetch
        assign pf_rq=1'b0;assign pf_rr=1'b0;assign pf_wv=1'b0;assign pf_busy=1'b0;assign pf_error=1'b0;
        assign pf_address=32'd0;assign pf_word=32'd0;assign pf_co=16'd0;assign pf_ci=16'd0;assign pf_generation=16'd0;
    end endgenerate
    assign ready=state==IDLE && !clear && region_ready;
    assign busy=state!=IDLE;
    assign memory_request_valid=!clear && (state==PARAM_REQ || state==LUT_REQ || state==WEIGHT_REQ || (pf_owner && pf_rq));
    assign memory_request_kind=state==PARAM_REQ?2'd0:state==LUT_REQ?2'd1:2'd2;
    assign memory_request_task=task_id;
    assign memory_request_address=pf_owner?pf_address:state==PARAM_REQ?{16'd0,param_group}:state==LUT_REQ?lut_index:weight_address;
    // Cache 标签来自实际请求组；预取时不能误用仍在计算的 active co/ci。
    assign memory_request_co_group=pf_owner?pf_co:state==WEIGHT_REQ?weight_co_group:current_co_group;
    assign memory_request_ci_group=pf_owner?pf_ci:state==WEIGHT_REQ?weight_ci_group:current_ci_group;
    wire response_bad=memory_response_error || memory_response_task!=task_id ||
        memory_response_kind!=expected_kind || memory_response_address!=expected_address;
    assign memory_response_ready=state==ABORT || (pending && response_bad) || (state==PARAM_WAIT && cfg_ready) ||
        (state==LUT_WAIT && lut_load_ready) || (state==WEIGHT_WAIT && weight_ready) || (pf_owner && pf_rr);
    assign cfg_we=state==PARAM_WAIT && memory_response_valid && !response_bad && !clear && cfg_ready;
    assign cfg_co_group=param_group;
    assign cfg_bias_bus=memory_response_data[255:0];
    assign cfg_multiplier_bus=memory_response_data[503:256];
    assign cfg_shift_bus=memory_response_data[551:504];
    assign cfg_grid_multiplier_bus=memory_response_data[799:552];
    assign cfg_grid_shift_bus=memory_response_data[847:800];
    assign lut_load_start=state==LUT_START && region_ready && !clear;
    assign lut_load_valid=state==LUT_WAIT && memory_response_valid && !response_bad && !clear;
    assign lut_load_data=memory_response_data[7:0];
    assign weight_valid=pf_active?pf_wv:(state==WEIGHT_WAIT && memory_response_valid && !response_bad && !clear);
    assign weight_word=pf_active?pf_word:memory_response_data[31:0];
    assign region_start=state==START && region_ready && !clear;
    assign region_clear=clear || state==ABORT;
    always @(posedge clk or negedge rst_n) begin
        if(!rst_n) begin
            state<=IDLE;task_id<=0;cig<=0;cog<=0;param_group<=0;lut_index<=0;
            weight_address<=0;weight_position<=0;weight_last<=0;activation<=0;
            weight_block_index<=0;weight_co_group<=0;weight_ci_group<=0;
            pending<=0;failed<=0;aborted<=0;expected_kind<=0;expected_address<=0;
            done<=0;error<=0;cancelled<=0;
            pf_active<=0;generation<=0;response_generation<=0;
        end else begin
            done<=0;error<=0;cancelled<=0;
            if(memory_request_valid && memory_request_ready) begin
                pending<=1;expected_kind<=memory_request_kind;expected_address<=memory_request_address;
                response_generation<=pf_generation;
            end
            if(memory_response_valid && memory_response_ready) pending<=0;
            case(state)
                IDLE: if(start && ready) begin
                    task_id<=model_task;cig<=cin_groups;cog<=cout_groups;activation<=silu_enable;
                    pf_active<=WEIGHT_PREFETCH_ENABLE!=0 && prefetch_enable;
                    generation<=generation+1'b1;
                    weight_last<=kernel_1x1?7:71;param_group<=0;lut_index<=0;failed<=0;aborted<=0;
                    if(cin_groups==0 || cout_groups==0) begin failed<=1;state<=FINISH;end
                    else state<=PARAM_REQ;
                end
                PARAM_REQ: if(memory_request_ready) state<=PARAM_WAIT;
                PARAM_WAIT: if(memory_response_valid && memory_response_ready) begin
                    if(response_bad) begin failed<=1;state<=ABORT;end
                    else if(param_group+1==cog) state<=activation?LUT_START:START;
                    else begin param_group<=param_group+1'b1;state<=PARAM_REQ;end
                end
                LUT_START: if(region_ready) state<=LUT_REQ;
                LUT_REQ: if(memory_request_ready) state<=LUT_WAIT;
                LUT_WAIT: if(memory_response_valid && memory_response_ready) begin
                    if(response_bad) begin failed<=1;state<=ABORT;end
                    else if(lut_index==1023) state<=START;
                    else begin lut_index<=lut_index+1'b1;state<=LUT_REQ;end
                end
                START: if(region_ready) state<=RUN;
                RUN: if(region_error || region_cancelled || pf_error) begin
                    failed<=region_error || pf_error;aborted<=region_cancelled;state<=ABORT;
                end else if(region_done) begin
                    failed<=!region_result_valid || pf_busy;state<=pf_busy?ABORT:FINISH;
                end else if(weight_request && !pf_active) begin
                    weight_position<=0;
                    weight_block_index<=current_co_group*cig+current_ci_group;
                    weight_co_group<=current_co_group;weight_ci_group<=current_ci_group;
                    state<=WEIGHT_BASE;
                end
                WEIGHT_BASE: begin
                    // 8 words for 1x1, 72 (64+8) for 3x3.
                    weight_address<=(weight_block_index<<3)+
                        (weight_last==7?32'd0:(weight_block_index<<6));
                    state<=WEIGHT_REQ;
                end
                WEIGHT_REQ: if(memory_request_ready) state<=WEIGHT_WAIT;
                WEIGHT_WAIT: if(memory_response_valid && memory_response_ready) begin
                    if(response_bad) begin failed<=1;state<=ABORT;end
                    else if(weight_position==weight_last) state<=RUN;
                    else begin weight_address<=weight_address+1'b1;weight_position<=weight_position+1'b1;state<=WEIGHT_REQ;end
                end
                // 即使 Clear 已到，仍接收原请求应答；目标完整有效位由区域引擎撤销。
                ABORT: if(!pending && !region_busy && !pf_busy) state<=FINISH;
                FINISH: begin done<=!failed && !aborted;error<=failed;cancelled<=aborted;state<=IDLE;end
                default: begin failed<=1;state<=ABORT;end
            endcase
            if(clear && state!=IDLE && state!=FINISH) begin aborted<=1;failed<=0;state<=ABORT;end
            else if(state!=IDLE && state!=ABORT && state!=FINISH && (region_error || region_cancelled)) begin
                failed<=region_error;aborted<=region_cancelled;state<=ABORT;
            end
        end
    end
endmodule
