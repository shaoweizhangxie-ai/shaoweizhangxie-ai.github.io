`timescale 1ns/1ps
// Phase9拟议扩展页的独立实现。请求/响应总线在同一clk域，LynCore AXI适配另行连接。
// CAPABILITIES只声明本模块实际实现的mailbox；不谎称已连接CPU DDR读通道。
module network_mailbox #(parameter [31:0] ACCEL_BASE=32'h30000000,CAPABILITY_BITS=32'd1)(
 input wire clk,rst_n,clear,
 input wire bus_valid,output wire bus_ready,input wire bus_write,
 input wire [11:0] bus_address,input wire [31:0] bus_wdata,input wire [3:0] bus_wstrb,
 output reg response_valid,input wire response_ready,output reg [31:0] response_data,output reg response_error,
 output wire engine_start,input wire engine_ready,output wire engine_cancel,
 input wire engine_idle,engine_done,engine_error,writes_drained,
 input wire [31:0] engine_error_detail,
 input wire [767:0] engine_result_desc,output reg result_ack,
 output wire [319:0] engine_config,output wire [191:0] engine_geometry,output wire result_valid,
 output reg [31:0] publish_seq,output wire [31:0] active_session,active_frame
);
 localparam [2:0] IDLE=0,START=1,RUN=2,FINISH=3,RESULT=4,CANCEL=5,ERROR=6;
 reg [2:0] state;reg [31:0] cfg[0:9],locked[0:9],ack_session,ack_seq,error_code;
 reg [31:0] geometry[0:5],locked_geometry[0:5];
 reg [31:0] error_detail;
 reg [767:0] descriptor;reg fail;integer i,ci;reg [31:0] merged;
 assign bus_ready=rst_n&&!response_valid&&!clear;
 assign engine_start=rst_n&&state==START&&!clear;
 assign engine_cancel=rst_n&&state==CANCEL;
 assign result_valid=state==RESULT;
 assign active_session=locked[0];assign active_frame=locked[1];
 genvar g;generate for(g=0;g<10;g=g+1)begin:configuration assign engine_config[g*32+:32]=locked[g];end endgenerate
 generate for(g=0;g<6;g=g+1)begin:geometry_output assign engine_geometry[g*32+:32]=locked_geometry[g];end endgenerate
 always @(posedge clk or negedge rst_n)begin
  if(!rst_n)begin state<=IDLE;response_valid<=0;response_data<=0;response_error<=0;
   ack_session<=0;ack_seq<=0;publish_seq<=0;descriptor<=0;error_code<=0;error_detail<=0;fail<=0;result_ack<=0;
   for(i=0;i<10;i=i+1)begin cfg[i]<=0;locked[i]<=0;end
   for(i=0;i<6;i=i+1)begin geometry[i]<=0;locked_geometry[i]<=0;end
  end else begin result_ack<=0;
   if(response_valid&&response_ready)response_valid<=0;
   if(clear)begin
    if(state==START||state==RUN||state==FINISH||state==CANCEL)begin state<=CANCEL;fail<=0;end
    else begin if(state==RESULT)result_ack<=1;state<=IDLE;error_code<=0;error_detail<=0;end
   end else begin
    case(state)
     START:if(engine_ready)state<=RUN;
     RUN:if(engine_error)begin fail<=1;error_code<=4;error_detail<=engine_error_detail;state<=CANCEL;end
         else if(engine_done)begin descriptor<=engine_result_desc;state<=FINISH;end
     FINISH:if(engine_error)begin fail<=1;error_code<=4;error_detail<=engine_error_detail;state<=CANCEL;end
            else if(engine_idle&&writes_drained)begin publish_seq<=publish_seq+1'b1;state<=RESULT;end
     CANCEL:if(engine_idle&&writes_drained)begin state<=fail?ERROR:IDLE;end
     default:begin end
    endcase
    if(bus_valid&&bus_ready)begin
     response_valid<=1;response_data<=0;response_error<=0;
     if(bus_address[1:0]!=0)response_error<=1;
     else if(bus_write)begin
      if(bus_address>=12'h110&&bus_address<=12'h134)begin
       if(state!=IDLE)response_error<=1;
       else begin ci=(bus_address-12'h110)/4;merged=cfg[ci];
        for(i=0;i<4;i=i+1)if(bus_wstrb[i])merged[i*8+:8]=bus_wdata[i*8+:8];cfg[ci]<=merged;
       end
      end else if(bus_address>=12'h14c&&bus_address<=12'h160)begin
       if(state!=IDLE)response_error<=1;
       else begin ci=(bus_address-12'h14c)/4;merged=geometry[ci];
        for(i=0;i<4;i=i+1)if(bus_wstrb[i])merged[i*8+:8]=bus_wdata[i*8+:8];geometry[ci]<=merged;
       end
      end else if(bus_address==12'h140||bus_address==12'h144)begin
       if(bus_wstrb!=4'hf)response_error<=1;else if(bus_address==12'h140)ack_session<=bus_wdata;else ack_seq<=bus_wdata;
      end else if(bus_address==12'h108&&bus_wstrb==4'hf)begin
       case(bus_wdata)
        1:if(state!=IDLE||cfg[9]==0||cfg[9]>87||cfg[6][2:0]!=0||cfg[7]!=819200||cfg[4][4:0]!=0||cfg[5][5:0]!=0||
             geometry[0][15:0]==0||geometry[0][31:16]==0||geometry[1]!=32'h01400140||geometry[2]==0||geometry[3]==0)response_error<=1;
          else begin for(i=0;i<10;i=i+1)locked[i]<=cfg[i];for(i=0;i<6;i=i+1)locked_geometry[i]<=geometry[i];state<=START;error_code<=0;error_detail<=0;fail<=0;end
        2:if(state==START||state==RUN||state==FINISH)begin state<=CANCEL;fail<=0;end else response_error<=1;
        4:if(state==RESULT&&ack_session==locked[0]&&ack_seq==publish_seq)begin result_ack<=1;state<=IDLE;end
          else if(state==ERROR)begin state<=IDLE;error_code<=0;error_detail<=0;end else response_error<=1;
        default:response_error<=1;
       endcase
      end else response_error<=1;
     end else if(bus_address>=12'h110&&bus_address<=12'h134)response_data<=cfg[(bus_address-12'h110)/4];
     else if(bus_address>=12'h14c&&bus_address<=12'h160)response_data<=geometry[(bus_address-12'h14c)/4];
     else if(bus_address>=12'h180&&bus_address<12'h1e0)begin
      if(state!=RESULT)response_error<=1;else response_data<=descriptor[((bus_address-12'h180)/4)*32+:32];
     end else case(bus_address)
      12'h100:response_data<=32'h594f0100;
      12'h104:response_data<=CAPABILITY_BITS;
      12'h10c:response_data<=state==IDLE?1:(state==RESULT?4:(state==CANCEL?10:(state==ERROR?16:2)));
      12'h138:response_data<=ACCEL_BASE+32'h180;
      12'h13c:response_data<=publish_seq;
      12'h140:response_data<=ack_session;
      12'h144:response_data<=ack_seq;
      12'h148:response_data<=error_code;
      12'h164:response_data<=error_detail;
      default:response_error<=1;
     endcase
    end
   end
  end
 end
endmodule
