`timescale 1ns/1ps

// 把程序/参数/LUT/权重的逻辑请求转换为小端、四字节对齐的外存读取。
// 全部字节地址由镜像基址和目录生成；每次仅一笔物理读取在途。
// clear 不丢弃已接受请求：先收回在途读取，再把错误响应交还原请求者。
module model_memory_adapter #(
    parameter integer MAX_TASKS=256
) (
    input wire clk, rst_n, clear,
    input wire cfg_valid,
    output wire cfg_ready,
    input wire [31:0] cfg_image_base, cfg_image_bytes,
    input wire [31:0] cfg_program_offset, cfg_directory_offset,
    input wire [15:0] cfg_task_count,
    output reg cfg_error,
    output reg configured,
    output reg [15:0] configured_task_count,
    output wire busy,
    input wire program_request_valid,
    output wire program_request_ready,
    input wire [15:0] program_request_index,
    output wire program_response_valid,
    input wire program_response_ready,
    output wire [15:0] program_response_index,
    output wire [255:0] program_response_data,
    output wire program_response_error,
    input wire memory_request_valid,
    output wire memory_request_ready,
    input wire [1:0] memory_request_kind,
    input wire [15:0] memory_request_task,
    input wire [31:0] memory_request_address,
    output wire memory_response_valid,
    input wire memory_response_ready,
    output wire [1:0] memory_response_kind,
    output wire [15:0] memory_response_task,
    output wire [31:0] memory_response_address,
    output wire [847:0] memory_response_data,
    output wire memory_response_error,
    output wire read_request_valid,
    input wire read_request_ready,
    output wire [31:0] read_request_address,
    input wire read_response_valid,
    output wire read_response_ready,
    input wire [31:0] read_response_address, read_response_data,
    input wire read_response_error
);
    localparam [2:0] IDLE=0, DIR_REQUEST=1, DIR_WAIT=2, CHECK=3,
        DATA_REQUEST=4, DATA_WAIT=5, RESPONSE=6, DATA_ADDRESS=7;
    reg [2:0] state;
    reg [31:0] image_base, image_bytes, program_offset, directory_offset;
    reg owner_program, prefer_memory, aborted, response_error;
    reg [15:0] active_task;
    reg [1:0] active_kind, byte_lane;
    reg [31:0] active_address, bus_address;
    reg [31:0] aligned_element_start;
    reg [5:0] beat, beats;
    reg [2:0] directory_word;
    reg [31:0] directory [0:7];
    reg directory_valid;
    reg [15:0] directory_task;
    reg [863:0] payload;
    integer i;

    // 配置计算扩展到 64 位，拒绝基址、尺寸相加或目录长度产生的回绕。
    wire [63:0] cfg_end={32'd0,cfg_image_base}+{32'd0,cfg_image_bytes};
    wire [63:0] cfg_program_end={32'd0,cfg_program_offset}+({48'd0,cfg_task_count}<<5);
    wire [63:0] cfg_directory_end={32'd0,cfg_directory_offset}+({48'd0,cfg_task_count}<<5);
    wire bad_config=cfg_task_count==0 || cfg_task_count>MAX_TASKS ||
        cfg_image_base[1:0]!=0 || cfg_image_bytes[1:0]!=0 ||
        cfg_program_offset[1:0]!=0 || cfg_directory_offset[1:0]!=0 ||
        cfg_program_offset<32 || cfg_directory_offset<32 ||
        cfg_program_end>{32'd0,cfg_image_bytes} || cfg_directory_end>{32'd0,cfg_image_bytes} ||
        cfg_end>64'h100000000 ||
        !((cfg_program_end<={32'd0,cfg_directory_offset}) ||
          (cfg_directory_end<={32'd0,cfg_program_offset}));
    assign cfg_ready=rst_n && !clear && state==IDLE;
    assign busy=state!=IDLE;
    wire accepting=rst_n && !clear && configured && !cfg_valid && state==IDLE;
    // 两类请求同时有效时交替优先，响应始终归还锁存的所有者。
    assign program_request_ready=accepting && (!memory_request_valid || !prefer_memory);
    assign memory_request_ready=accepting && (!program_request_valid || prefer_memory);
    assign program_response_valid=state==RESPONSE && owner_program;
    assign memory_response_valid=state==RESPONSE && !owner_program;
    assign program_response_index=active_task;
    assign program_response_data=response_error ? 256'd0 : payload[255:0];
    assign program_response_error=response_error;
    assign memory_response_kind=active_kind;
    assign memory_response_task=active_task;
    assign memory_response_address=active_address;
    assign memory_response_data=response_error ? 848'd0 : payload[847:0];
    assign memory_response_error=response_error;
    assign read_request_valid=rst_n && !clear && (state==DIR_REQUEST || state==DATA_REQUEST);
    assign read_request_address=bus_address;
    assign read_response_ready=state==DIR_WAIT || state==DATA_WAIT;
    wire bad_read=read_response_error || read_response_address!=bus_address;

    reg [31:0] selected_offset, selected_count;
    reg [63:0] segment_bytes, element_offset;
    reg [5:0] selected_beats;
    always @* begin
        selected_offset=0; selected_count=0; segment_bytes=0; element_offset=0; selected_beats=1;
        case (active_kind)
            0: begin
                selected_offset=directory[0]; selected_count=directory[1];
                segment_bytes={32'd0,directory[1]}*64'd108;
                element_offset={32'd0,active_address}*64'd108; selected_beats=27;
            end
            1: begin
                selected_offset=directory[2]; selected_count=directory[3];
                segment_bytes=({32'd0,directory[3]}+64'd3)&64'hfffffffffffffffc;
                element_offset={32'd0,active_address};
            end
            2: begin
                selected_offset=directory[4]; selected_count=directory[5];
                segment_bytes={32'd0,directory[5]}<<2;
                element_offset={32'd0,active_address}<<2;
            end
            default: begin end
        endcase
    end
    wire [63:0] element_start={32'd0,selected_offset}+element_offset;
    wire bad_directory=active_kind==3 || active_address>=selected_count ||
        selected_offset<32 || selected_offset[1:0]!=0 || directory[6]!=0 || directory[7]!=0 ||
        ({32'd0,selected_offset}+segment_bytes)>{32'd0,image_bytes};

    always @(posedge clk or negedge rst_n) begin
        if (!rst_n) begin
            state<=IDLE; configured<=0; cfg_error<=0; configured_task_count<=0;
            image_base<=0; image_bytes<=0; program_offset<=0; directory_offset<=0;
            owner_program<=0; prefer_memory<=0; aborted<=0; response_error<=0;
            active_task<=0; active_kind<=0; active_address<=0; bus_address<=0;
            beat<=0; beats<=0; byte_lane<=0; payload<=0; aligned_element_start<=0;
            directory_valid<=0; directory_task<=0; directory_word<=0;
            for(i=0;i<8;i=i+1) directory[i]<=0;
        end else begin
            cfg_error<=0;
            if (clear) begin
                directory_valid<=0;
                if (state!=IDLE && state!=RESPONSE) aborted<=1;
            end
            case (state)
                IDLE: if (!clear) begin
                    if (cfg_valid) begin
                        if (bad_config) cfg_error<=1;
                        else begin
                            image_base<=cfg_image_base; image_bytes<=cfg_image_bytes;
                            program_offset<=cfg_program_offset; directory_offset<=cfg_directory_offset;
                            configured_task_count<=cfg_task_count; configured<=1; directory_valid<=0;
                        end
                    end else if (program_request_valid && program_request_ready) begin
                        owner_program<=1; active_task<=program_request_index;
                        active_address<=0; active_kind<=0; payload<=0; response_error<=0; aborted<=0;
                        prefer_memory<=1; beat<=0; beats<=8;
                        if (program_request_index>=configured_task_count) begin response_error<=1; state<=RESPONSE; end
                        else begin
                            bus_address<=image_base+program_offset+({16'd0,program_request_index}<<5);
                            state<=DATA_REQUEST;
                        end
                    end else if (memory_request_valid && memory_request_ready) begin
                        owner_program<=0; active_task<=memory_request_task; active_kind<=memory_request_kind;
                        active_address<=memory_request_address; payload<=0; response_error<=0; aborted<=0;
                        prefer_memory<=0; beat<=0;
                        if (memory_request_task>=configured_task_count || memory_request_kind==3) begin
                            response_error<=1; state<=RESPONSE;
                        end else if (directory_valid && directory_task==memory_request_task) state<=CHECK;
                        else begin
                            directory_valid<=0; directory_task<=memory_request_task; directory_word<=0;
                            bus_address<=image_base+directory_offset+({16'd0,memory_request_task}<<5);
                            state<=DIR_REQUEST;
                        end
                    end
                end
                DIR_REQUEST: begin
                    if (clear || aborted) begin response_error<=1; state<=RESPONSE; end
                    else if (read_request_ready) state<=DIR_WAIT;
                end
                DIR_WAIT: if (read_response_valid) begin
                    if (clear || aborted || bad_read) begin response_error<=1; state<=RESPONSE; end
                    else begin
                        directory[directory_word]<=read_response_data;
                        if (directory_word==7) begin directory_valid<=1; state<=CHECK; end
                        else begin directory_word<=directory_word+1'b1; bus_address<=bus_address+4; state<=DIR_REQUEST; end
                    end
                end
                CHECK: begin
                    if (clear || aborted || bad_directory) begin response_error<=1; state<=RESPONSE; end
                    else begin
                        // LUT 按一个字节编号，物理地址向下对齐，响应时选择对应 byte lane。
                        byte_lane<=element_start[1:0]; beats<=selected_beats; beat<=0;
                        aligned_element_start<={element_start[31:2],2'b00};
                        state<=DATA_ADDRESS;
                    end
                end
                DATA_ADDRESS: begin
                    if (clear || aborted) begin response_error<=1; state<=RESPONSE; end
                    else begin
                        bus_address<=image_base+aligned_element_start; state<=DATA_REQUEST;
                    end
                end
                DATA_REQUEST: begin
                    if (clear || aborted) begin response_error<=1; state<=RESPONSE; end
                    else if (read_request_ready) state<=DATA_WAIT;
                end
                DATA_WAIT: if (read_response_valid) begin
                    if (clear || aborted || bad_read ||
                        (!owner_program && active_kind==0 && beat==26 && read_response_data[31:16]!=0)) begin
                        response_error<=1; state<=RESPONSE;
                    end else begin
                        if (!owner_program && active_kind==1)
                            payload<={856'd0,read_response_data[byte_lane*8 +: 8]};
                        else payload[beat*32 +: 32]<=read_response_data;
                        if (beat+1==beats) state<=RESPONSE;
                        else begin beat<=beat+1'b1; bus_address<=bus_address+4; state<=DATA_REQUEST; end
                    end
                end
                // 已呈现的响应在反压期间保持；clear 不能改变它的 payload 或 error。
                RESPONSE: if (owner_program ? program_response_ready : memory_response_ready) begin
                    state<=IDLE; aborted<=0;
                end
                default: state<=IDLE;
            endcase
        end
    end
endmodule
