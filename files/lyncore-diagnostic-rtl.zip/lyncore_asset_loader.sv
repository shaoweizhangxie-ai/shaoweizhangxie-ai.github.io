`timescale 1ns/1ps
// Fixed three-object boot stream: LC26, ID, LE32 length, LE32 CRC, payload.
// Each object is written, FENCE-drained and read back before its ACK (A0..A2).
// A failed session requires common reset; no object can release CPU on failure.
module lyncore_asset_loader #(
    parameter [31:0] MODEL_BYTES=2000824, MODEL_CRC=32'hcae3a77e,
    parameter [31:0] TABLE_BYTES=5568, TABLE_CRC=32'h72ada019,
    parameter [31:0] INPUT_BYTES=819200, INPUT_CRC=32'haddf1dd7
)(
    input wire clk,rst_n,transport_error,
    input wire byte_valid,input wire [7:0] byte_data,output wire byte_ready,
    output wire ack_valid,output wire [7:0] ack_data,input wire ack_ready,
    output wire done,output reg failed,output reg [3:0] error_code,
    output reg [2:0] committed,
    output wire read_request_valid,input wire read_request_ready,
    output wire [31:0] read_request_address,
    input wire read_response_valid,output wire read_response_ready,
    input wire [31:0] read_response_address,read_response_data,input wire read_response_error,
    output wire write_request_valid,input wire write_request_ready,
    output wire [31:0] write_request_address,write_request_data,output wire [3:0] write_request_strobe,
    input wire write_response_valid,output wire write_response_ready,
    input wire [31:0] write_response_address,input wire write_response_error
);
    localparam [3:0] MAGIC=0,OBJECT_ID=1,LENGTH=2,HEADER_CRC=3,PAYLOAD=4,
        WRITE_ISSUE=5,WRITE_WAIT=6,FENCE_ISSUE=7,FENCE_WAIT=8,
        READ_ISSUE=9,READ_WAIT=10,READ_CRC=11,REPORT=12,FINISHED=13,FAIL_REPORT=14,FAULT=15;
    reg [3:0] state;
    reg [1:0] object_id,byte_index;
    reg [31:0] magic_word,header_length,header_crc,word_data,offset,crc,read_word;
    wire [31:0] object_base=object_id==0?32'h20000000:object_id==1?32'h201e87c0:32'h20400000;
    wire [31:0] object_bytes=object_id==0?MODEL_BYTES:object_id==1?TABLE_BYTES:INPUT_BYTES;
    wire [31:0] object_crc=object_id==0?MODEL_CRC:object_id==1?TABLE_CRC:INPUT_CRC;
    function automatic [31:0] crc_byte(input [31:0] old_crc,input [7:0] data);
        reg [31:0] v;
        begin
            v=old_crc^{24'd0,data};
            for(integer b=0;b<8;b++)v=v[0]?(v>>1)^32'hedb88320:(v>>1);
            crc_byte=v;
        end
    endfunction
    task reject(input [3:0] code);
        begin failed<=1;error_code<=code;committed<=0;state<=FAIL_REPORT;end
    endtask
    assign byte_ready=rst_n && !failed && (state<=PAYLOAD);
    assign ack_valid=rst_n && (state==REPORT || state==FAIL_REPORT);
    assign ack_data=state==FAIL_REPORT?{4'he,error_code}:8'ha0+{6'd0,object_id};
    assign done=rst_n && state==FINISHED && !failed && committed==3'b111;
    assign write_request_valid=rst_n && !failed && (state==WRITE_ISSUE || state==FENCE_ISSUE);
    assign write_request_address=state==FENCE_ISSUE?object_base:object_base+offset;
    assign write_request_data=word_data;
    assign write_request_strobe=state==FENCE_ISSUE?4'b0:4'hf;
    assign read_request_valid=rst_n && !failed && state==READ_ISSUE;
    assign read_request_address=object_base+offset;
    // Drain a response even after a transport failure; ownership stays loader
    // until common reset, so no stale reply can be reassigned to the CPU.
    assign read_response_ready=rst_n;
    assign write_response_ready=rst_n;
    always @(posedge clk or negedge rst_n)begin
        if(!rst_n)begin
            state<=MAGIC;object_id<=0;byte_index<=0;magic_word<=0;
            header_length<=0;header_crc<=0;word_data<=0;offset<=0;crc<=32'hffffffff;read_word<=0;
            committed<=0;failed<=0;error_code<=0;
        end else if(transport_error && !failed)reject(5);
        else if(!failed && ((read_response_valid && state!=READ_WAIT) ||
                            (write_response_valid && state!=WRITE_WAIT && state!=FENCE_WAIT)))reject(4);
        else case(state)
            MAGIC: if(byte_valid && byte_ready)begin
                magic_word<={byte_data,magic_word[31:8]};byte_index<=byte_index+1'b1;
                if(byte_index==3)begin
                    if({byte_data,magic_word[31:8]}!=32'h3632434c)reject(1);
                    else state<=OBJECT_ID;
                end
            end
            OBJECT_ID: if(byte_valid && byte_ready)begin
                if(byte_data!={6'd0,object_id})reject(1);
                else begin state<=LENGTH;byte_index<=0;end
            end
            LENGTH: if(byte_valid && byte_ready)begin
                header_length<={byte_data,header_length[31:8]};byte_index<=byte_index+1'b1;
                if(byte_index==3)begin
                    if({byte_data,header_length[31:8]}!=object_bytes || object_bytes==0 || object_bytes[1:0]!=0)reject(2);
                    else state<=HEADER_CRC;
                end
            end
            HEADER_CRC: if(byte_valid && byte_ready)begin
                header_crc<={byte_data,header_crc[31:8]};byte_index<=byte_index+1'b1;
                if(byte_index==3)begin
                    if({byte_data,header_crc[31:8]}!=object_crc)reject(3);
                    else begin state<=PAYLOAD;offset<=0;word_data<=0;end
                end
            end
            PAYLOAD: if(byte_valid && byte_ready)begin
                word_data[byte_index*8+:8]<=byte_data;byte_index<=byte_index+1'b1;
                if(byte_index==3)state<=WRITE_ISSUE;
            end
            WRITE_ISSUE: if(write_request_ready)state<=WRITE_WAIT;
            WRITE_WAIT: if(write_response_valid)begin
                if(write_response_error || write_response_address!=object_base+offset)reject(4);
                else if(offset+4==object_bytes)state<=FENCE_ISSUE;
                else begin offset<=offset+4;state<=PAYLOAD;end
            end
            FENCE_ISSUE: if(write_request_ready)state<=FENCE_WAIT;
            FENCE_WAIT: if(write_response_valid)begin
                if(write_response_error || write_response_address!=object_base)reject(4);
                else begin offset<=0;crc<=32'hffffffff;state<=READ_ISSUE;end
            end
            READ_ISSUE: if(read_request_ready)state<=READ_WAIT;
            READ_WAIT: if(read_response_valid)begin
                if(read_response_error || read_response_address!=object_base+offset)reject(4);
                else begin read_word<=read_response_data;byte_index<=0;state<=READ_CRC;end
            end
            READ_CRC: begin
                crc<=crc_byte(crc,read_word[7:0]);read_word<=read_word>>8;byte_index<=byte_index+1'b1;
                if(byte_index==3)begin
                    if(offset+4==object_bytes)begin
                        if(~crc_byte(crc,read_word[7:0])!=object_crc)reject(3);
                        else begin committed[object_id]<=1;state<=REPORT;end
                    end else begin offset<=offset+4;state<=READ_ISSUE;end
                end
            end
            REPORT: if(ack_ready)begin
                if(object_id==2)state<=FINISHED;
                else begin object_id<=object_id+1'b1;byte_index<=0;state<=MAGIC;end
            end
            FAIL_REPORT: if(ack_ready)state<=FAULT;
            default:begin end
        endcase
    end
endmodule
