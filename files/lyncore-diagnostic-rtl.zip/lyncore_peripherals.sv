`timescale 1ns/1ps
// GPIO and machine-level timer/software interrupt registers.
module lyncore_peripherals (
    input logic clk, rst, valid, write,
    input logic [31:0] addr, wdata,
    input logic [3:0] wstrb,
    input logic [4:0] keys,
    output logic [7:0] leds,
    output logic irq_timer, irq_software, irq_gpio,
    output logic ready, error,
    output logic [31:0] rdata
);
    (* ASYNC_REG = "TRUE", syn_preserve = 1, syn_keep = 1, syn_srlstyle = "registers" *) logic [4:0] key_meta, key_sync;
    logic [4:0] key_prev, key_pending, key_enable;
    logic [63:0] mtime, mtimecmp;
    logic msip;
    wire gpio_sel = addr[31:8] == 24'h200000;
    wire timer_sel = addr[31:8] == 24'h200020;
    wire [5:0] reg_index = addr[7:2];
    wire fire = valid && ready && !error && write;
    function automatic [31:0] merge_bytes(input [31:0] old_value, new_value,
                                           input [3:0] mask);
        for (integer b = 0; b < 4; b = b + 1)
            merge_bytes[b*8 +: 8] = mask[b] ? new_value[b*8 +: 8] : old_value[b*8 +: 8];
    endfunction
    assign ready = valid;
    assign irq_timer = mtime >= mtimecmp;
    assign irq_software = msip;
    assign irq_gpio = |(key_pending & key_enable);
    always_comb begin
        rdata = 0;
        error = 0;
        if (gpio_sel) case (reg_index)
            0: rdata = {24'b0, leds};
            1: begin rdata = {27'b0, key_sync}; if (write) error = valid; end
            2: rdata = {27'b0, key_enable};
            3: rdata = {27'b0, key_pending};
            default: error = valid;
        endcase
        else if (timer_sel) case (reg_index)
            0: rdata = mtime[31:0];
            1: rdata = mtime[63:32];
            2: rdata = mtimecmp[31:0];
            3: rdata = mtimecmp[63:32];
            4: rdata = {31'b0, msip};
            default: error = valid;
        endcase
        else error = valid;
    end
    always_ff @(posedge clk) begin
        if (rst) begin
            key_meta <= 5'h1f; key_sync <= 5'h1f; key_prev <= 5'h1f;
            key_pending <= 0; key_enable <= 0; leds <= 0;
            mtime <= 0; mtimecmp <= 64'hffffffffffffffff; msip <= 0;
        end else begin
            key_meta <= keys; key_sync <= key_meta; key_prev <= key_sync;
            key_pending <= (key_pending & ~((fire && gpio_sel && reg_index == 3 && wstrb[0]) ? wdata[4:0] : 5'b0)) |
                           (key_prev & ~key_sync);
            mtime <= mtime + 1'b1;
            if (fire && gpio_sel && wstrb[0]) case (reg_index)
                0: leds <= wdata[7:0];
                2: key_enable <= wdata[4:0];
                default: begin end
            endcase
            if (fire && timer_sel) case (reg_index)
                0: mtime[31:0] <= merge_bytes(mtime[31:0], wdata, wstrb);
                1: mtime[63:32] <= merge_bytes(mtime[63:32], wdata, wstrb);
                2: mtimecmp[31:0] <= merge_bytes(mtimecmp[31:0], wdata, wstrb);
                3: mtimecmp[63:32] <= merge_bytes(mtimecmp[63:32], wdata, wstrb);
                4: if (wstrb[0]) msip <= wdata[0];
                default: begin end
            endcase
        end
    end
endmodule
