`timescale 1ns/1ps
// Exclusive capture-phase DDR client. grant must be held until settled;
// common reset is required before capturing a new frame or after DDR fault.
module video_camera_rgb565(
 input wire clk,pclk,rst_n,sensor_configured,memory_grant,ddr_ready,bridge_busy,bridge_fault,
 input wire vsync,href,input wire [7:0] data,
 output wire overlay_pixel_valid,output wire [15:0] overlay_pixel_data,
 output wire committed,capture_failed,store_failed,settled,
 output wire write_request_valid,input wire write_request_ready,
 output wire [31:0] write_request_address,write_request_data,
 output wire [3:0] write_request_strobe,
 input wire write_response_valid,output wire write_response_ready,
 input wire [31:0] write_response_address,input wire write_response_error
);
 assign overlay_pixel_valid=qv && qr;
 assign overlay_pixel_data=qd;
 wire pv,pr,qv,qr,finished;wire [15:0] pd,qd;
 video_dvp_rgb565 capture(.pclk(pclk),.rst_n(rst_n),
  .enable(sensor_configured && memory_grant && ddr_ready && !bridge_fault),
  .vsync(vsync),.href(href),.data(data),.pixel_valid(pv),.pixel_data(pd),
  .pixel_ready(pr),.finished(finished),.failed(capture_failed));
 lyncore_video_fifo fifo(.wr_clk(pclk),.rd_clk(clk),.rst_n(rst_n),
  .wr_valid(pv),.wr_data(pd),.wr_ready(pr),.rd_valid(qv),.rd_data(qd),.rd_ready(qr));
 video_rgb565_store store(.capture_finished(finished),.capture_failed(capture_failed),
  .pixel_valid(qv),.pixel_data(qd),.pixel_ready(qr),.failed(store_failed),.*);
endmodule
