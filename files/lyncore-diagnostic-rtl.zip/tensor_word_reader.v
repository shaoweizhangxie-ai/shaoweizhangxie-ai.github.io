`timescale 1ns/1ps

// 从带 Slot/ci/index 标签的四通道缓存读出一个八通道字。
// 尾组只读实际存在的半字，未使用 lane 补零；clear 排空已接受的读请求。
module tensor_word_reader (
    input wire clk, rst_n, clear, start,
    output wire ready,
    input wire [2:0] source_slot,
    input wire [15:0] source_channels, source_co_group,    //必须说清楚的是，这里的co_group是在8通道视角下的，虽然我们给出的是4通道的输入。
    input wire [31:0] source_index,         //从slot x保存的那个x通道的特征图中，读取空间位置为x的第x个8通道组。
    output wire busy,
    output reg error,
    output wire request_valid,
    input wire request_ready,
    output wire [2:0] request_slot,
    output wire [15:0] request_ci_group,
    output wire [31:0] request_index,
    input wire response_valid,
    output wire response_ready,
    input wire [2:0] response_slot,
    input wire [15:0] response_ci_group,
    input wire [31:0] response_index, response_pixel,
    input wire response_error,
    output wire out_valid,
    input wire out_ready,
    output reg [63:0] out_data
);
    localparam [2:0] IDLE=0, REQ_LOW=1, WAIT_LOW=2, REQ_HIGH=3,  //所以这就是一个小的状态机     
        WAIT_HIGH=4, EMIT=5, CANCEL=6;               //一个状态机，idle(start)    req_low(请求4通道)   wait_Low(等返回)   （如果还需要高4通道）   reg_high    wiat_high   emit（输出64bit）
    reg [2:0] state, slot;
    reg [15:0] channels, co;
    reg [31:0] index, low;
    wire high_phase = state==REQ_HIGH || state==WAIT_HIGH;
    wire [18:0] base = {co,3'b000};       //base=co x 8 是这个意思（左移表示放大，在右边添零） base表示的是输出64bit word的第一个全局通道编号 比如co=1,那么base=8，全局通道编号为8
    wire has_high = base+19'd4 < channels;    //在判断有没有必要再去读取高四通道。比如我现在的通道数刚好是21，那就已经是有高得了，不用读。
    assign ready = rst_n && !clear && state==IDLE;
    assign busy = state!=IDLE;
    assign request_valid = rst_n && !clear && (state==REQ_LOW || state==REQ_HIGH);
    assign request_slot = slot;
    assign request_ci_group = (co<<1) + (high_phase ? 16'd1 : 16'd0);
    assign request_index = index;
    assign response_ready = rst_n && !clear && (state==WAIT_LOW || state==WAIT_HIGH || state==CANCEL);
    assign out_valid = rst_n && !clear && state==EMIT;
    wire bad_response = response_error || response_slot!=slot ||
        response_ci_group!=request_ci_group || response_index!=index;
    function [63:0] mask_tail;
        input [63:0] data;
        input [18:0] first;
        input [15:0] count;
        integer lane;
        begin
            for (lane=0; lane<8; lane=lane+1)
                mask_tail[lane*8 +: 8] = first+lane<count ? data[lane*8 +: 8] : 8'd0;
        end
    endfunction
    always @(posedge clk or negedge rst_n) begin
        if (!rst_n) begin
            state<=IDLE; slot<=0; channels<=0; co<=0; index<=0; low<=0; out_data<=0; error<=0;
        end else begin
            error<=0;
            if (clear) begin
                if (state==WAIT_LOW || state==WAIT_HIGH || state==CANCEL) state<=CANCEL;
                else state<=IDLE;
            end else begin
                if (start && !ready) error<=1;
                case (state)
                    IDLE: if (start && ready) begin
                        if (source_channels==0 || {source_co_group,3'b000}>=source_channels) error<=1;
                        else begin
                            slot<=source_slot; channels<=source_channels; co<=source_co_group;
                            index<=source_index; state<=REQ_LOW;
                        end
                    end
                    REQ_LOW: if (request_valid && request_ready) state<=WAIT_LOW;
                    REQ_HIGH: if (request_valid && request_ready) state<=WAIT_HIGH;
                    WAIT_LOW: if (response_valid && response_ready) begin
                        if (bad_response) begin error<=1; state<=IDLE; end
                        else if (has_high) begin low<=response_pixel; state<=REQ_HIGH; end
                        else begin out_data<=mask_tail({32'd0,response_pixel},base,channels); state<=EMIT; end
                    end
                    WAIT_HIGH: if (response_valid && response_ready) begin
                        if (bad_response) begin error<=1; state<=IDLE; end
                        else begin out_data<=mask_tail({response_pixel,low},base,channels); state<=EMIT; end
                    end
                    EMIT: if (out_valid && out_ready) state<=IDLE;
                    CANCEL: if (response_valid && response_ready) state<=IDLE;
                    default: state<=IDLE;
                endcase
            end
        end
    end
endmodule
