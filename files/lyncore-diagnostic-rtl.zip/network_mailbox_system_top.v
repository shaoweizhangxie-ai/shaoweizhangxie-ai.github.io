`timescale 1ns/1ps
// A2可综合系统核心：真实Mailbox/Adapter/Full87/CPU单字补口。
// 原生DDR桥/PHY在外部，只允许一个物理桥；本模块不包含仿真模型或软件后处理。
module network_mailbox_system_top #(
 parameter [31:0] ACCEL_BASE=32'h30000000,DDR_BASE=32'h20000000,PACKET_BASE=32'h20300000,
 parameter [63:0] DDR_BYTES=64'h01000000,
 parameter integer CPU_OFFSET_ADDRESS=0,AUX_PIPELINE_ENABLE=0,K1_WIDE_ENABLE=0
)(
 input wire clk,rst_n,clear,ddr_ready,memory_idle,input wire input_allow,input_write_allow,
 input wire [31:0] s_awaddr,input wire s_awvalid,output wire s_awready,
 input wire [31:0] s_wdata,input wire [3:0] s_wstrb,input wire s_wvalid,output wire s_wready,
 output wire [1:0] s_bresp,output wire s_bvalid,input wire s_bready,
 input wire [31:0] s_araddr,input wire s_arvalid,output wire s_arready,
 output wire [31:0] s_rdata,output wire [1:0] s_rresp,output wire s_rvalid,input wire s_rready,
 output wire read_request_valid,input wire read_request_ready,output wire [31:0] read_request_address,
 input wire read_response_valid,output wire read_response_ready,
 input wire [31:0] read_response_address,read_response_data,input wire read_response_error,
 output wire write_request_valid,input wire write_request_ready,
 output wire [31:0] write_request_address,write_request_data,output wire [3:0] write_request_strobe,
 input wire write_response_valid,output wire write_response_ready,
 input wire [31:0] write_response_address,input wire write_response_error,
 output wire job_started,job_finished,output wire [15:0] task_id,output wire [511:0] active_descriptor,
 output wire raw_valid,output wire [15:0] raw_co_group,output wire [31:0] raw_index,output wire [255:0] raw_data,
 output wire out_valid,output wire [15:0] out_co_group,output wire [31:0] out_index,output wire [63:0] out_data,
 output wire executor_start,executor_busy,executor_done,executor_error,executor_cancelled,
 output wire result_valid,output wire [31:0] publish_seq,output wire [4:0] adapter_state,
 output wire [1:0] memory_owner,output wire packet_valid,output wire [31:0] packet_bytes
);
 wire engine_start,engine_ready,engine_cancel,engine_idle,engine_done,engine_error,result_ack;
 wire [319:0] engine_config;wire [191:0] engine_geometry,locked_geometry;
 wire [767:0] result_descriptor;
 wire [31:0] active_session,active_frame,adapter_error;
 wire ext_valid,ext_ready,ext_write,ext_resp_valid,ext_resp_ready,ext_resp_error;
 wire [11:0] ext_address;wire [31:0] ext_wdata,ext_resp_data;wire [3:0] ext_strobe;
 wire retire_result,cpu_idle,result_read_enable,executor_ready,executor_clear;
 wire [31:0] image_base,image_bytes,program_offset,directory_offset,descriptor_base,seed_base,seed_capacity;
 wire [15:0] execute_task_count;
 wire [2:0] inspect_slot;wire inspect_valid;
 wire [31:0] inspect_base;wire [15:0] inspect_generation,inspect_consumers;
 wire arq,arr,ars,asr,are;wire [31:0] ara,asa,asd;
 wire erq,err,ers,esr,ere,ewq,ewr,ews,ewsr,ewse;
 wire [31:0] era,esa,esd,ewa,ewd,ewsa;wire [3:0] ewst;
 wire crq,crr,crs,csr,cre,cwq,cwr,cws,cwsr,cwse;
 wire [31:0] cra,csa,csd,cwa,cwd,cwsa;wire [3:0] cwst;
 network_mailbox_axil #(.ACCEL_BASE(ACCEL_BASE),.CAPABILITY_BITS(32'd15),.EXTENSION_ENABLE(1)) control(
  .clk(clk),.rst_n(rst_n),.clear(clear),
  .s_awaddr(CPU_OFFSET_ADDRESS!=0?s_awaddr+ACCEL_BASE:s_awaddr),.s_awvalid(s_awvalid),.s_awready(s_awready),
  .s_wdata(s_wdata),.s_wstrb(s_wstrb),.s_wvalid(s_wvalid),.s_wready(s_wready),.s_bresp(s_bresp),.s_bvalid(s_bvalid),.s_bready(s_bready),
  .s_araddr(CPU_OFFSET_ADDRESS!=0?s_araddr+ACCEL_BASE:s_araddr),.s_arvalid(s_arvalid),.s_arready(s_arready),
  .s_rdata(s_rdata),.s_rresp(s_rresp),.s_rvalid(s_rvalid),.s_rready(s_rready),
  .engine_start(engine_start),.engine_ready(engine_ready),.engine_cancel(engine_cancel),.engine_idle(engine_idle),
  .engine_done(engine_done),.engine_error(engine_error),
  .engine_error_detail({task_id,8'd0,adapter_error[7:0]}),.writes_drained(memory_idle),.engine_result_desc(result_descriptor),
  .result_ack(result_ack),.result_valid(result_valid),.engine_config(engine_config),.engine_geometry(engine_geometry),
  .publish_seq(publish_seq),.active_session(active_session),.active_frame(active_frame),
  .extension_valid(ext_valid),.extension_ready(ext_ready),.extension_write(ext_write),.extension_address(ext_address),
  .extension_wdata(ext_wdata),.extension_wstrb(ext_strobe),.extension_response_valid(ext_resp_valid),
  .extension_response_ready(ext_resp_ready),.extension_response_data(ext_resp_data),.extension_response_error(ext_resp_error));
 network_mailbox_executor_adapter #(.DDR_BASE(DDR_BASE),.DDR_BYTES(DDR_BYTES)) adapter(
  .clk(clk),.rst_n(rst_n),.clear(clear),.engine_start(engine_start),.engine_cancel(engine_cancel),.result_ack(result_ack),
  .engine_config(engine_config),.engine_geometry(engine_geometry),.engine_ready(engine_ready),.engine_idle(engine_idle),
  .engine_done(engine_done),.engine_error(engine_error),.engine_result_desc(result_descriptor),
  .ddr_ready(ddr_ready),.memory_idle(memory_idle),.cpu_idle(cpu_idle),.memory_owner(memory_owner),
  .result_read_enable(result_read_enable),.retire_result(retire_result),.executor_start(executor_start),.executor_clear(executor_clear),
  .executor_ready(executor_ready),.executor_busy(executor_busy),.executor_done(executor_done),
  .executor_error(executor_error),.executor_cancelled(executor_cancelled),
  .image_base(image_base),.image_bytes(image_bytes),.program_offset(program_offset),.directory_offset(directory_offset),
  .descriptor_base(descriptor_base),.seed_base(seed_base),.seed_capacity(seed_capacity),.execute_task_count(execute_task_count),
  .geometry(locked_geometry),.inspect_slot(inspect_slot),.inspect_valid(inspect_valid),.inspect_base(inspect_base),
  .inspect_generation(inspect_generation),.inspect_consumers(inspect_consumers),
  .read_request_valid(arq),.read_request_ready(arr),.read_request_address(ara),.read_response_valid(ars),
  .read_response_ready(asr),.read_response_address(asa),.read_response_data(asd),.read_response_error(are),
  .error_code(adapter_error),.debug_state(adapter_state));
 cpu_ddr_word_regs #(.PACKET_BASE(PACKET_BASE)) cpu_words(
  .clk(clk),.rst_n(rst_n),.clear(clear||retire_result),.enable(result_valid&&result_read_enable),.head_descriptor(result_descriptor),
  .bus_valid(ext_valid),.bus_ready(ext_ready),.bus_write(ext_write),.bus_address(ext_address),.bus_wdata(ext_wdata),.bus_wstrb(ext_strobe),
  .response_valid(ext_resp_valid),.response_ready(ext_resp_ready),.response_data(ext_resp_data),.response_error(ext_resp_error),
  .idle(cpu_idle),.packet_valid(packet_valid),.packet_bytes(packet_bytes),
  .read_request_valid(crq),.read_request_ready(crr),.read_request_address(cra),.read_response_valid(crs),.read_response_ready(csr),
  .read_response_address(csa),.read_response_data(csd),.read_response_error(cre),
  .write_request_valid(cwq),.write_request_ready(cwr),.write_request_address(cwa),.write_request_data(cwd),.write_request_strobe(cwst),
  .write_response_valid(cws),.write_response_ready(cwsr),.write_response_address(cwsa),.write_response_error(cwse));
  network_task_executor #(.K1_WIDE_ENABLE(K1_WIDE_ENABLE),.AUX_PIPELINE_ENABLE(AUX_PIPELINE_ENABLE),.UPLOAD_PIPELINE_TASK_MASK(87'h7bdbdbcde606beb6fadf5f),
  .FEATURE_FORWARD_P1(0),.FEATURE_FORWARD_P2(0),.FEATURE_FORWARD_P3(0),.FORWARD_CACHE_WORDS(6400),
  .WEIGHT_PREFETCH_ENABLE(0),.WEIGHT_PREFETCH_TASK_MASK(87'h7bdbdbcde606beb6fadf5f),
  .FEATURE_RESIDENCY(1),.FEATURE_CACHE_WORDS(8192),.WEIGHT_RESIDENCY(0),.WEIGHT_CACHE_WORDS(16384),
  .WRITE_COMBINE(1),.DDR_READ_PIPELINE(1),.INPUT_PING_PONG(1)) executor(
  .clk(clk),.rst_n(rst_n),.clear(executor_clear),.start(executor_start),.ddr_ready(ddr_ready),.ready(executor_ready),
  .busy(executor_busy),.done(executor_done),.error(executor_error),.cancelled(executor_cancelled),
  .descriptor_base(descriptor_base),.image_base(image_base),.image_bytes(image_bytes),.program_offset(program_offset),.directory_offset(directory_offset),
  .model_task_count(execute_task_count),.execute_task_count(execute_task_count),.seed_base(seed_base),.seed_capacity(seed_capacity),
  .seed_width(16'd320),.seed_height(16'd320),.seed_channels(16'd3),.seed_consumers(16'd1),
  .input_allow(input_allow),.input_write_allow(input_write_allow),.job_started(job_started),.job_finished(job_finished),
  .task_id(task_id),.active_descriptor(active_descriptor),.raw_valid(raw_valid),.raw_co_group(raw_co_group),.raw_index(raw_index),.raw_data(raw_data),
  .out_valid(out_valid),.out_co_group(out_co_group),.out_index(out_index),.out_data(out_data),
  .inspect_slot(inspect_slot),.inspect_valid(inspect_valid),.inspect_base(inspect_base),.inspect_generation(inspect_generation),.inspect_consumers(inspect_consumers),
  .read_request_valid(erq),.read_request_ready(err),.read_request_address(era),.read_response_valid(ers),.read_response_ready(esr),
  .read_response_address(esa),.read_response_data(esd),.read_response_error(ere),
  .write_request_valid(ewq),.write_request_ready(ewr),.write_request_address(ewa),.write_request_data(ewd),.write_request_strobe(ewst),
  .write_response_valid(ews),.write_response_ready(ewsr),.write_response_address(ewsa),.write_response_error(ewse));
 // owner仅在旧来源已经排空的状态切换；请求/应答都使用同一owner。
 assign read_request_valid=memory_owner==1?erq:(memory_owner==2?crq:arq);
 assign read_request_address=memory_owner==1?era:(memory_owner==2?cra:ara);
 assign read_response_ready=memory_owner==1?esr:(memory_owner==2?csr:asr);
 assign arr=memory_owner==0&&read_request_ready;assign ars=memory_owner==0&&read_response_valid;
 assign asa=read_response_address;assign asd=read_response_data;assign are=read_response_error;
 assign err=memory_owner==1&&read_request_ready;assign ers=memory_owner==1&&read_response_valid;
 assign esa=read_response_address;assign esd=read_response_data;assign ere=read_response_error;
 assign crr=memory_owner==2&&read_request_ready;assign crs=memory_owner==2&&read_response_valid;
 assign csa=read_response_address;assign csd=read_response_data;assign cre=read_response_error;
 assign write_request_valid=memory_owner==1?ewq:(memory_owner==2?cwq:1'b0);
 assign write_request_address=memory_owner==1?ewa:cwa;
 assign write_request_data=memory_owner==1?ewd:cwd;assign write_request_strobe=memory_owner==1?ewst:cwst;
 assign write_response_ready=memory_owner==1?ewsr:(memory_owner==2?cwsr:1'b0);
 assign ewr=memory_owner==1&&write_request_ready;assign ews=memory_owner==1&&write_response_valid;
 assign ewsa=write_response_address;assign ewse=write_response_error;
 assign cwr=memory_owner==2&&write_request_ready;assign cws=memory_owner==2&&write_response_valid;
 assign cwsa=write_response_address;assign cwse=write_response_error;
endmodule
