`timescale 1ns/1ps
// Both producer streams come from the inference core in the DDR user domain.
module preview_detection_frame(
 input wire clk,rst_n,capture,pixel_valid,
 input wire [15:0] pixel_data,
 input wire [31:0] frame_id,
 input wire packet_write,packet_valid,
 input wire [31:0] packet_addr,packet_data,packet_bytes,
 input wire pixel_clk,pixel_reset_n,de,
 input wire [15:0] x,y,
 output reg [15:0] rgb,
 output wire capture_ready,
 output reg border,visible,
 output wire label_bg,label_ink
);
 localparam [31:0] PACKET_BASE=32'h20300000;
 reg [15:0] frames[0:32767];
 reg [10:0] sx;
 reg [9:0] sy;
 reg [13:0] index;
 reg was_capture,eligible,published,acknowledged;
 (* syn_preserve=1 *) reg [1:0] ack_sync,publish_sync;
 reg [31:0] capture_id,packet_id,bx,by,bw,bh;
 reg header_ok,geometry_ok,object_valid,seen_packet;
 reg [15:0] count,object_class,confidence_q16,pub_class,class_id;
 reg [6:0] confidence_pct,pub_pct,pct;
 wire [22:0] percent_product={7'd0,confidence_q16}*23'd100+23'd32767;
 wire [22:0] percent_round=percent_product+{16'd0,percent_product[22:16]}+23'd1;
 overlay_object_label label(.clk(pixel_clk),.rst_n(pixel_reset_n),.show(de && visible && box),
  .x(x),.y(y),.left(left),.top(top),.class_id(class_id),.pct(pct),.bg(label_bg),.ink(label_ink));
 reg [11:0] pub_left,pub_top,pub_right,pub_bottom;
 reg pub_box;
 reg [11:0] left,top,right,bottom;
 reg box;
 wire [32:0] end_x={1'b0,bx}+{1'b0,bw};
 wire [32:0] end_y={1'b0,by}+{1'b0,bh};
 wire valid_box=count!=0 && object_valid && bw!=0 && bh!=0 &&
  end_x<=33'd83886080 && end_y<=33'd47185920;
 wire [13:0] read_row={7'b0,y[9:3]};
 wire [13:0] read_col={6'b0,x[10:3]};
 wire [13:0] read_index=(read_row<<7)+(read_row<<5)+read_col;
 assign capture_ready=ack_sync[1]==published;
 wire sample_pixel=capture && pixel_valid && eligible && sy<720 &&
  sx[2:0]==0 && sy[2:0]==0;
 always @(posedge clk)
  if(rst_n && sample_pixel)frames[{~published,index}]<=pixel_data;
 always @(posedge pixel_clk)
  if(de)rgb<=frames[{acknowledged,read_index}];
 always @(posedge clk or negedge rst_n)begin
  if(!rst_n)begin
   sx<=0;sy<=0;index<=0;was_capture<=0;eligible<=0;published<=0;ack_sync<=0;
   capture_id<=0;packet_id<=0;bx<=0;by<=0;bw<=0;bh<=0;count<=0;
   header_ok<=0;geometry_ok<=0;object_valid<=0;seen_packet<=0;object_class<=0;confidence_q16<=0;confidence_pct<=0;pub_class<=0;pub_pct<=0;
   pub_left<=0;pub_top<=0;pub_right<=0;pub_bottom<=0;pub_box<=0;
  end else begin
   was_capture<=capture;
   confidence_pct<=percent_round[22:16];
   ack_sync<={ack_sync[0],acknowledged};
   if(capture && !was_capture)begin
    sx<=0;sy<=0;index<=0;eligible<=capture_ready;capture_id<=frame_id;
    header_ok<=0;geometry_ok<=0;object_valid<=0;seen_packet<=0;count<=0;
    packet_id<=0;bx<=0;by<=0;bw<=0;bh<=0;
   end else if(capture && pixel_valid && sy<720)begin
    if(sx==1279)begin sx<=0;sy<=sy+1'b1;end
    else sx<=sx+1'b1;
    if(sample_pixel)index<=index+1'b1;
   end
   if(packet_write)case(packet_addr)
    PACKET_BASE:header_ok<=packet_data==32'h31304459;
    PACKET_BASE+12:packet_id<=packet_data;
    PACKET_BASE+24:geometry_ok<=packet_data=={16'd720,16'd1280};
    PACKET_BASE+28:count<=packet_data[15:0];
    PACKET_BASE+48:begin object_valid<=packet_data[31:16]==16'd1;object_class<=packet_data[15:0];end
    PACKET_BASE+52:confidence_q16<=packet_data[15:0];
    PACKET_BASE+56:bx<=packet_data;
    PACKET_BASE+60:by<=packet_data;
    PACKET_BASE+64:bw<=packet_data;
    PACKET_BASE+68:bh<=packet_data;
    default:begin end
   endcase
   if(packet_valid && !seen_packet)begin
    seen_packet<=1;
    if(eligible && sy==720 && index==14400 && header_ok && geometry_ok &&
       packet_id==capture_id && count<=100 && packet_bytes==32'd48+({16'b0,count}<<5))begin
     pub_left<=bx[27:16];pub_top<=by[27:16];
     pub_right<=end_x[27:16];pub_bottom<=end_y[27:16];
     pub_box<=valid_box;pub_class<=object_class;pub_pct<=confidence_pct;published<=~published;
    end
   end
  end
 end
 always @(posedge pixel_clk or negedge pixel_reset_n)begin
  if(!pixel_reset_n)begin
   publish_sync<=0;acknowledged<=0;visible<=0;
   left<=0;top<=0;right<=0;bottom<=0;box<=0;border<=0;class_id<=0;pct<=0;
  end else begin
   publish_sync<={publish_sync[0],published};
   if(x==0 && y==720 && publish_sync[1]!=acknowledged)begin
    acknowledged<=publish_sync[1];visible<=1;
    left<=pub_left;top<=pub_top;right<=pub_right;bottom<=pub_bottom;box<=pub_box;class_id<=pub_class;pct<=pub_pct;
   end
   border<=de && visible && box && x>=left && x<right && y>=top && y<bottom &&
    (x<left+2 || x+2>=right || y<top+2 || y+2>=bottom);
  end
 end
endmodule
