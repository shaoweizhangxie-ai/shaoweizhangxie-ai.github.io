`timescale 1ns/1ps
// Frame-phase ownership, not per-transaction serialization. The system keeps
// its existing four-slot read pipeline during inference. Switch only after
// outgoing client quiescence, final FENCE and all bridge responses drain.
module video_ddr_phase_mux(
 input wire clk,rst_n,camera_phase,system_quiescent,camera_settled,bridge_busy,
 output wire camera_grant,system_grant,
 input wire system_read_request_valid,output wire system_read_request_ready,
 input wire [31:0] system_read_request_address,
 output wire system_read_response_valid,input wire system_read_response_ready,
 output wire [31:0] system_read_response_address,system_read_response_data,
 output wire system_read_response_error,
 input wire system_write_request_valid,output wire system_write_request_ready,
 input wire [31:0] system_write_request_address,system_write_request_data,
 input wire [3:0] system_write_request_strobe,
 output wire system_write_response_valid,input wire system_write_response_ready,
 output wire [31:0] system_write_response_address,output wire system_write_response_error,
 input wire camera_write_request_valid,output wire camera_write_request_ready,
 input wire [31:0] camera_write_request_address,camera_write_request_data,
 input wire [3:0] camera_write_request_strobe,
 output wire camera_write_response_valid,input wire camera_write_response_ready,
 output wire [31:0] camera_write_response_address,output wire camera_write_response_error,
 output wire read_request_valid,input wire read_request_ready,output wire [31:0] read_request_address,
 input wire read_response_valid,output wire read_response_ready,
 input wire [31:0] read_response_address,read_response_data,input wire read_response_error,
 output wire write_request_valid,input wire write_request_ready,
 output wire [31:0] write_request_address,write_request_data,output wire [3:0] write_request_strobe,
 input wire write_response_valid,output wire write_response_ready,
 input wire [31:0] write_response_address,input wire write_response_error
);
 reg owner_camera;
 assign camera_grant=rst_n && owner_camera;
 assign system_grant=rst_n && !owner_camera;
 wire response_pending=read_response_valid || write_response_valid;
 always @(posedge clk or negedge rst_n)begin
  if(!rst_n)owner_camera<=0;
  else if(!bridge_busy && !response_pending)begin
   if(!owner_camera && camera_phase && system_quiescent &&
     !system_read_request_valid && !system_write_request_valid)owner_camera<=1;
   else if(owner_camera && !camera_phase && camera_settled &&
     !camera_write_request_valid)owner_camera<=0;
  end
 end
 assign read_request_valid=system_grant && system_read_request_valid;
 assign read_request_address=system_read_request_address;
 assign system_read_request_ready=system_grant && read_request_ready;
 assign system_read_response_valid=system_grant && read_response_valid;
 assign read_response_ready=system_grant && system_read_response_ready;
 assign system_read_response_address=read_response_address;
 assign system_read_response_data=read_response_data;
 assign system_read_response_error=read_response_error;
 assign write_request_valid=camera_grant?camera_write_request_valid:(system_grant && system_write_request_valid);
 assign write_request_address=owner_camera?camera_write_request_address:system_write_request_address;
 assign write_request_data=owner_camera?camera_write_request_data:system_write_request_data;
 assign write_request_strobe=owner_camera?camera_write_request_strobe:system_write_request_strobe;
 assign camera_write_request_ready=camera_grant && write_request_ready;
 assign system_write_request_ready=system_grant && write_request_ready;
 assign camera_write_response_valid=camera_grant && write_response_valid;
 assign system_write_response_valid=system_grant && write_response_valid;
 assign write_response_ready=owner_camera?camera_write_response_ready:system_write_response_ready;
 assign camera_write_response_address=write_response_address;
 assign system_write_response_address=write_response_address;
 assign camera_write_response_error=write_response_error;
 assign system_write_response_error=write_response_error;
endmodule
