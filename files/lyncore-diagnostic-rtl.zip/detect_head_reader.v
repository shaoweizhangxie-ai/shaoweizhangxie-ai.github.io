`timescale 1ns/1ps

// 按 head -> 八通道组 -> 空间位置读出三个原始检测头。
// 复用特征图缓存的四通道读接口，将两笔响应合为一个 64 位结果字。
// 输出带有效通道掩码，支持反压；不执行 sigmoid、decode 或 NMS。
module detect_head_reader #(
    parameter integer MAX_SLOTS = 6
) (
    input wire clk,
    input wire rst_n,
    input wire clear,
    input wire start,
    output wire ready,
    input wire [8:0] head_slot_bus,
    input wire [47:0] head_width_bus,
    input wire [47:0] head_height_bus,
    input wire [15:0] head_channels,
    output reg busy,
    output reg done,
    output reg error,
    output wire request_valid,
    input wire request_ready,
    output wire [2:0] request_slot,
    output wire [15:0] request_ci_group,
    output wire [31:0] request_index,
    input wire response_valid,
    output wire response_ready,
    input wire [2:0] response_slot,
    input wire [15:0] response_ci_group,
    input wire [31:0] response_index,
    input wire [31:0] response_pixel,
    input wire response_error,
    output wire out_valid,
    input wire out_ready,
    output reg [63:0] out_data,
    output wire [1:0] out_head,
    output wire [15:0] out_co_group,
    output wire [31:0] out_index,
    output wire [7:0] out_lane_mask
);
    localparam [2:0] IDLE=0, REQ_LOW=1, WAIT_LOW=2, REQ_HIGH=3,
                     WAIT_HIGH=4, EMIT=5, CANCEL=6;
    reg [2:0] state;
    reg [2:0] cfg_slot [0:2];
    reg [31:0] cfg_pixels [0:2];
    reg [15:0] cfg_channels;
    reg [16:0] cfg_groups;
    reg [1:0] head;
    reg [15:0] co_group;
    reg [31:0] index;
    reg [31:0] low_pixel;
    reg [7:0] lane_mask;
    reg bad_config;
    integer config_number, mask_lane, latch_number;
    wire [18:0] channel_base = {co_group,3'b000};
    wire has_high = channel_base+19'd4 < {3'd0,cfg_channels};
    wire high_request = state == REQ_HIGH || state == WAIT_HIGH;
    assign ready = rst_n && !clear && !busy;
    assign request_valid = rst_n && !clear && busy && (state == REQ_LOW || state == REQ_HIGH);
    assign request_slot = cfg_slot[head];
    assign request_ci_group = (co_group << 1) + (high_request ? 16'd1 : 16'd0);
    assign request_index = index;
    assign response_ready = rst_n && !clear && (state == WAIT_LOW || state == WAIT_HIGH || state == CANCEL);
    wire bad_response = response_error || response_slot != request_slot ||
        response_ci_group != request_ci_group || response_index != request_index;
    assign out_valid = rst_n && !clear && busy && state == EMIT;
    assign out_head = head;
    assign out_co_group = co_group;
    assign out_index = index;
    assign out_lane_mask = lane_mask;

    always @* begin
        bad_config = head_channels == 0 ||
            head_slot_bus[2:0] == head_slot_bus[5:3] ||
            head_slot_bus[2:0] == head_slot_bus[8:6] ||
            head_slot_bus[5:3] == head_slot_bus[8:6];
        for (config_number=0; config_number<3; config_number=config_number+1) begin
            if (head_slot_bus[config_number*3 +: 3] >= MAX_SLOTS ||
                head_width_bus[config_number*16 +: 16] == 0 ||
                head_height_bus[config_number*16 +: 16] == 0) bad_config = 1;
        end
        for (mask_lane=0; mask_lane<8; mask_lane=mask_lane+1)
            lane_mask[mask_lane] = channel_base+mask_lane < cfg_channels;
    end

    function [63:0] mask_word;
        input [63:0] data;
        input [7:0] mask;
        integer lane;
        begin
            for (lane=0; lane<8; lane=lane+1)
                mask_word[lane*8 +: 8] = mask[lane] ? data[lane*8 +: 8] : 8'd0;
        end
    endfunction

    always @(posedge clk or negedge rst_n) begin
        if (!rst_n) begin
            state <= IDLE; busy <= 0; done <= 0; error <= 0;
            head <= 0; co_group <= 0; index <= 0; cfg_channels <= 0; cfg_groups <= 0;
            for (latch_number=0; latch_number<3; latch_number=latch_number+1) begin
                cfg_slot[latch_number] <= 0; cfg_pixels[latch_number] <= 0;
            end
        end else begin
            done <= 0; error <= 0;
            if (clear) begin
                // 已接受的缓存读不能消失。取消时先接收并丢弃在途响应，才重新 ready。
                if (state == WAIT_LOW || state == WAIT_HIGH || state == CANCEL) begin
                    state <= CANCEL; busy <= 1;
                end else begin state <= IDLE; busy <= 0; end
            end else begin
                if (start && !ready) error <= 1;
                if (start && ready) begin
                    if (bad_config) error <= 1;
                    else begin
                        for (latch_number=0; latch_number<3; latch_number=latch_number+1) begin
                            cfg_slot[latch_number] <= head_slot_bus[latch_number*3 +: 3];
                            cfg_pixels[latch_number] <= {16'd0,head_width_bus[latch_number*16 +: 16]} *
                                                         {16'd0,head_height_bus[latch_number*16 +: 16]};
                        end
                        cfg_channels <= head_channels;
                        cfg_groups <= ({1'b0,head_channels}+17'd7) >> 3;
                        head <= 0; co_group <= 0; index <= 0;
                        busy <= 1; state <= REQ_LOW;
                    end
                end else begin
                    case (state)
                        REQ_LOW: if (request_valid && request_ready) state <= WAIT_LOW;
                        REQ_HIGH: if (request_valid && request_ready) state <= WAIT_HIGH;
                        WAIT_LOW: if (response_valid && response_ready) begin
                            if (bad_response) begin error <= 1; busy <= 0; state <= IDLE; end
                            else if (has_high) begin low_pixel <= response_pixel; state <= REQ_HIGH; end
                            else begin out_data <= mask_word({32'd0,response_pixel},lane_mask); state <= EMIT; end
                        end
                        WAIT_HIGH: if (response_valid && response_ready) begin
                            if (bad_response) begin error <= 1; busy <= 0; state <= IDLE; end
                            else begin out_data <= mask_word({response_pixel,low_pixel},lane_mask); state <= EMIT; end
                        end
                        EMIT: if (out_valid && out_ready) begin
                            if (index != cfg_pixels[head]-1'b1) begin index <= index+1'b1; state <= REQ_LOW; end
                            else begin
                                index <= 0;
                                if ({1'b0,co_group} != cfg_groups-1'b1) begin co_group <= co_group+1'b1; state <= REQ_LOW; end
                                else if (head != 2) begin head <= head+1'b1; co_group <= 0; state <= REQ_LOW; end
                                else begin busy <= 0; done <= 1; state <= IDLE; end
                            end
                        end
                        CANCEL: if (response_valid && response_ready) begin busy <= 0; state <= IDLE; end
                        default: begin state <= IDLE; busy <= 0; end
                    endcase
                end
            end
        end
    end
    // synthesis translate_off
    initial begin
        if (MAX_SLOTS < 1 || MAX_SLOTS > 8) begin
            $display("ERROR: detect_head_reader MAX_SLOTS must be 1..8");
            $finish;
        end
    end
    // synthesis translate_on
endmodule
