`timescale 1ns/1ps
// 1,843,200-byte raw frame at 0x20840000. Two RGB565 pixels per logical
// word; the existing DDR bridge combines eight words per native write.
// Aborted captures drain an exposed request, then FENCE before settling.
module video_rgb565_store(
 input wire clk,rst_n,ddr_ready,bridge_busy,bridge_fault,
 input wire capture_finished,capture_failed,
 input wire pixel_valid,input wire [15:0] pixel_data,output wire pixel_ready,
 output wire write_request_valid,input wire write_request_ready,
 output wire [31:0] write_request_address,write_request_data,
 output wire [3:0] write_request_strobe,
 input wire write_response_valid,output wire write_response_ready,
 input wire [31:0] write_response_address,input wire write_response_error,
 output reg committed,failed,output wire settled
);
 localparam [31:0] BASE=32'h20840000;
 localparam [3:0] LO=0,HI=1,SEND=2,REPLY=3,END_FRAME=4,FENCE=5,FENCE_REPLY=6,DRAIN=7,STOP=8;
 (* ASYNC_REG="TRUE" *) reg [1:0] done_sync,error_sync;
 reg [3:0] state;reg [18:0] words;reg [31:0] packed_data;reg started;
 wire aborting=failed || error_sync[1] || (started && !ddr_ready);
 assign pixel_ready=ddr_ready && !aborting && (state==LO || state==HI);
 // Do not withdraw a request already exposed under backpressure.
 assign write_request_valid=rst_n && !bridge_fault && (state==SEND || state==FENCE);
 assign write_request_address=BASE+{11'd0,words,2'b00};
 assign write_request_data=packed_data;
 assign write_request_strobe=state==FENCE?4'b0000:4'b1111;
 assign write_response_ready=state==REPLY || state==FENCE_REPLY;
 assign settled=state==STOP && !bridge_busy && ddr_ready && !bridge_fault;
 always @(posedge clk or negedge rst_n)begin
  if(!rst_n)begin
   done_sync<=0;error_sync<=0;state<=LO;words<=0;packed_data<=0;
   started<=0;committed<=0;failed<=0;
  end else begin
   done_sync<={done_sync[0],capture_finished};error_sync<={error_sync[0],capture_failed};
   if(aborting)begin failed<=1;committed<=0;end
   if(bridge_fault)begin failed<=1;committed<=0;state<=STOP;end
   else case(state)
    LO:if(aborting)state<=FENCE;
     else if(pixel_valid && pixel_ready)begin started<=1;packed_data[15:0]<=pixel_data;state<=HI;end
    HI:if(aborting)state<=FENCE;
     else if(pixel_valid && pixel_ready)begin packed_data[31:16]<=pixel_data;state<=SEND;end
    SEND:if(write_request_ready)state<=REPLY;
    REPLY:if(write_response_valid)begin
     if(write_response_error || write_response_address!=write_request_address)begin failed<=1;state<=FENCE;end
     else begin
      words<=words+1'b1;
      state<=aborting?FENCE:(words==19'd460799 ? END_FRAME:LO);
     end
    end
    END_FRAME:if(aborting || pixel_valid)begin failed<=1;state<=FENCE;end
     else if(done_sync[1])state<=FENCE;
    FENCE:if(write_request_ready)state<=FENCE_REPLY;
    FENCE_REPLY:if(write_response_valid)begin
     if(write_response_error || write_response_address!=write_request_address)failed<=1;
     state<=DRAIN;
    end
    DRAIN:if(!bridge_busy && ddr_ready)begin committed<=!aborting;state<=STOP;end
    default:begin end
   endcase
  end
 end
endmodule
