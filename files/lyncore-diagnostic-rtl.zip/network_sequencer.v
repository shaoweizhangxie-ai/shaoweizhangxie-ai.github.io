`timescale 1ns/1ps

// 按程序存储器的描述顺序下发整网任务，计算完成和缓存提交必须都到齐。
// 算子内部循环、参数/权重搬运由执行端负责；此模块不假定它们的固定延迟。
module network_sequencer #(
    parameter integer MAX_TASKS = 256,
    parameter integer MAX_SLOTS = 8             //目前一个task descriper相当于一条“神经网络指令”，内部包含了需要的参数 位置等信息。
) (                                             //sequencer这个文件的作用是按顺序取task，task会交给下一步的executer去执行，等执行完成后task+1继续取新的任务。
    input wire clk, rst_n, clear,               // eg.src = Slot2   dst = Slot5    input = 40×40×128    output = 40×40×256   kernel = 3×3   stride = 1 ...等信息，一条指令的长度是256bit
    input wire start,
    input wire [15:0] task_count,
    input wire executor_idle,
    output wire ready,
    output reg busy, done, error,
    output reg task_cancel,
    output wire program_request_valid,
    input wire program_request_ready,
    output wire [15:0] program_request_index,  
    input wire program_response_valid,
    output wire program_response_ready,
    input wire [15:0] program_response_index,
    input wire [255:0] program_response_data,
    input wire program_response_error,    //这里的信号是  向外部程序存储器申请指令的具体内容。
    output wire task_valid,
    input wire task_ready,
    output wire [15:0] task_index,
    output reg [255:0] task_descriptor,
    input wire compute_done,
    input wire commit_done,
    input wire task_error,
    input wire [15:0] completion_index
);
    localparam [2:0] IDLE=0, FETCH_REQ=1, FETCH_WAIT=2, ISSUE=3, ACTIVE=4, CANCEL=5;   //状态机的五个状态，FETCH_REQ表示我正在发出请求，FETCH_WAIT表示请求已被接受，正在被处理。
    reg [2:0] state;
    reg [15:0] cfg_count, index;
    reg compute_seen, commit_seen;
    assign ready = rst_n && !clear && state==IDLE && executor_idle;
    assign program_request_valid = rst_n && !clear && state==FETCH_REQ;
    assign program_request_index = index;
    assign program_response_ready = rst_n && !clear && (state==FETCH_WAIT || state==CANCEL);
    assign task_valid = rst_n && !clear && state==ISSUE;    //如果符合这些条件，取出来的task有效，并且我即将把这个valid信号传给executor去执行，准备好接收后,executor本身会返回ready信号回来
    assign task_index = index;
    wire issue_take = task_valid && task_ready;            //这里是真正的交付，task被真正的交给了executor
    wire execution = state==ACTIVE || issue_take;     //Executor 在接收任务的同一拍就产生完成信号  这种情况是允许的，虽然听起来很夸张。
    wire completion = compute_done || commit_done || task_error;

    // 256 位描述的定义见 docs/network_rtl.md。这里检查通用连线和算子形状约束。
    wire [255:0] p = program_response_data;                              //刚好有8个slot
    wire [2:0] op = p[2:0], lhs = p[5:3], rhs = p[8:6], dst = p[11:9];  //这是描述左源头slot和右源头slot，以及目标slot，op则是在说操作类型。
    wire [15:0] iw=p[31:16], ih=p[47:32], ow=p[63:48], oh=p[79:64];    //尺寸，包括输入和输出
    wire [15:0] lc=p[95:80], rc=p[111:96], oc=p[127:112];              //左源头通道数，右源头通道数和目标结果通道数
    wire [16:0] cat_channels={1'b0,lc}+{1'b0,rc};                      //concat后的通道数
    wire bad_descriptor = op>5 || lhs>=MAX_SLOTS || rhs>=MAX_SLOTS || dst>=MAX_SLOTS ||
        dst==lhs || dst==rhs || iw==0 || ih==0 || ow==0 || oh==0 || lc==0 || rc==0 || oc==0 ||
        p[159] || p[191] || p[199:198]!=0 || p[207:206]!=0 || p[255:208]!=0 ||
        (op==1 && (lc!=rc || oc!=lc || ow!=iw || oh!=ih)) ||
        (op==2 && (cat_channels!={1'b0,oc} || ow!=iw || oh!=ih)) ||
        (op==3 && (oc!=lc || ow!=iw || oh!=ih)) ||
        (op==4 && (oc!=lc || {1'b0,ow}!={iw,1'b0} || {1'b0,oh}!={ih,1'b0})) ||
        (op==5 && (lc!=3 || iw[0] || ih[0] || ow!=(iw>>1) || oh!=(ih>>1) || p[12] || !p[13])) ||
        (op!=0 && op!=5 && p[15:12]!=0);             //在这里把256位指令拆解了。    //这里描述的是bad_descriptor里，什么样的错误发生了，这条指令不会拿去取task，而是会报错等待。

    always @(posedge clk or negedge rst_n) begin
        if (!rst_n) begin
            state<=IDLE; cfg_count<=0; index<=0; task_descriptor<=0;
            compute_seen<=0; commit_seen<=0;
            busy<=0; done<=0; error<=0; task_cancel<=0;
        end else begin
            done<=0; error<=0; task_cancel<=0;
            if (clear) begin
                compute_seen<=0; commit_seen<=0;
                // 接收过的程序读必须排空；执行端还需响应 cancel 并报告 idle。
                if (state==FETCH_WAIT || state==CANCEL) begin state<=CANCEL; busy<=1; end
                else begin
                    if (state==ACTIVE) task_cancel<=1;
                    state<=IDLE; busy<=0;
                end
            end else begin
                case (state)
                    IDLE: if (start && ready) begin
                        if (task_count==0 || task_count>MAX_TASKS)
                            error<=1;
                        else begin
                            cfg_count<=task_count; index<=0; busy<=1;
                            compute_seen<=0; commit_seen<=0; state<=FETCH_REQ;
                        end
                    end
                    FETCH_REQ: if (program_request_valid && program_request_ready) state<=FETCH_WAIT;
                    FETCH_WAIT: if (program_response_valid && program_response_ready) begin
                        if (program_response_error || program_response_index!=index || bad_descriptor) begin
                            state<=IDLE; busy<=0; error<=1;                                                       //这是说明标签内容不一致，只能保持当前状态等待下一步
                        end else begin task_descriptor<=program_response_data; state<=ISSUE; end             //指令内容没有错误，从wait状态进入issue状态
                    end
                    ISSUE: if (issue_take) begin
                        compute_seen<=0; commit_seen<=0; state<=ACTIVE;  //一旦当前的issue被take，就会清空这个任务的seen记录，然后状态跳转到active中
                    end                                                   //必须知道的是compute_done不是commit_done，commit_done在计算完成并且整个任务正式载入slot中，才可以产生commit_done
                    CANCEL: if (program_response_valid && program_response_ready) begin state<=IDLE; busy<=0; end
                    default: begin end
                endcase
                // 接收任务的同一拍也允许完成；只接受带当前 task_index 的完成事件。
                if (execution) begin
                    if (completion && (completion_index!=index || task_error)) begin    //如果网络错误接收到了done信号，那么现在会把状态回到idle直接停下
                        state<=IDLE; busy<=0; error<=1; task_cancel<=1;
                        compute_seen<=0; commit_seen<=0;
                    end else begin
                        compute_seen<=(issue_take ? 1'b0 : compute_seen) || compute_done;      //seen信号的含义：我是否已经见过了done信号？因为done信号通常是一个脉冲并且compute和coommit的脉冲通常是不重合的。
                        commit_seen<=(issue_take ? 1'b0 : commit_seen) || commit_done;
                        if (((issue_take ? 1'b0 : compute_seen) || compute_done) &&
                            ((issue_take ? 1'b0 : commit_seen) || commit_done)) begin
                            compute_seen<=0; commit_seen<=0;                                 //这里通过时序逻辑完成了对任务完成的判断
                            if (index==cfg_count-1) begin state<=IDLE; busy<=0; done<=1; end     //如果执行到了最后一个任务，那么状态回到idle，现在整个网络的计算都完成了。
                            else begin index<=index+1'b1; state<=FETCH_REQ; end           //如果没有计算到最后一个任务，那么状态回到req，继续取下一个任务进行执行
                        end
                    end
                end
            end
        end
    end
    // synthesis translate_off
    initial begin
        if (MAX_TASKS<1 || MAX_TASKS>65535 || MAX_SLOTS<1 || MAX_SLOTS>8) begin
            $display("ERROR: invalid network_sequencer parameters");
            $finish;
        end
    end
    // synthesis translate_on
endmodule
