`timescale 1ns/1ps
// CPU and real job-control RTL. The engine ports are internal FPGA connections.
module lyncore_job_system #(
    parameter ROM_INIT_FILE = "job_boot128.hex",
    parameter integer ROM_WORDS = 4096,
    parameter integer CLOCK_HZ = 27000000,
    parameter integer BAUD = 115200,
    parameter bit LINE_BUFFER = 1,
    parameter bit ENABLE_M = 0,
    parameter bit ENABLE_ZBA = 0,
    parameter bit ENABLE_ZBB = 0,
    parameter bit ENABLE_CACHE = 0,
    parameter integer CACHE_SET_BITS = 6,
    parameter integer ICACHE_SET_BITS = CACHE_SET_BITS,
    parameter integer DCACHE_SET_BITS = CACHE_SET_BITS,
    parameter bit ENABLE_BP = 0,
    parameter integer BP_INDEX_BITS = 4,
    parameter integer BP_HISTORY_BITS = 0,
    parameter bit BP_HASH_INDEX = 0,
    parameter bit LOAD_USE_INTERLOCK = 1,
    parameter bit PIPELINED_MUL = 0,
    parameter bit ENABLE_RAS = 0,
    parameter bit DECOUPLED_FETCH = 0
) (
    input logic clk, rst, uart_rx,
    input logic [4:0] keys,
    output logic uart_tx,
    output logic [7:0] leds,
    output logic halted,
    output logic [63:0] cycle_count, instret_count,
    output logic job_start, job_reset, job_busy,
    output logic [703:0] job_config,
    input logic engine_done, engine_error
);
    logic accel_valid, accel_write, accel_ready, accel_error;
    logic [31:0] accel_addr, accel_wdata, accel_rdata;
    logic [3:0] accel_wstrb;
    logic [31:0] awaddr, wdata, araddr, rdata;
    logic [2:0] awprot, arprot;
    logic [3:0] wstrb;
    logic awvalid, awready, wvalid, wready, bvalid, bready, arvalid, arready, rvalid, rready;
    logic [1:0] bresp, rresp;
    lyncore_soc #(.ROM_INIT_FILE(ROM_INIT_FILE), .ROM_WORDS(ROM_WORDS),.CLOCK_HZ(CLOCK_HZ), .BAUD(BAUD),
                  .LINE_BUFFER(LINE_BUFFER), .ENABLE_M(ENABLE_M), .ENABLE_ZBA(ENABLE_ZBA), .ENABLE_ZBB(ENABLE_ZBB), .ENABLE_CACHE(ENABLE_CACHE), .CACHE_SET_BITS(CACHE_SET_BITS),.ENABLE_BP(ENABLE_BP),
                  .ICACHE_SET_BITS(ICACHE_SET_BITS), .DCACHE_SET_BITS(DCACHE_SET_BITS),
                  .BP_INDEX_BITS(BP_INDEX_BITS),.BP_HISTORY_BITS(BP_HISTORY_BITS),.BP_HASH_INDEX(BP_HASH_INDEX), .LOAD_USE_INTERLOCK(LOAD_USE_INTERLOCK),.PIPELINED_MUL(PIPELINED_MUL),.ENABLE_RAS(ENABLE_RAS),.DECOUPLED_FETCH(DECOUPLED_FETCH), .ENABLE_ACCEL(1)) soc(.*);
    lyncore_axi_lite_bridge bridge(
        .clk(clk), .rst(rst), .valid(accel_valid), .write(accel_write),
        .addr(accel_addr), .wdata(accel_wdata), .wstrb(accel_wstrb),
        .ready(accel_ready), .error(accel_error), .rdata(accel_rdata),
        .m_awaddr(awaddr), .m_awprot(awprot), .m_awvalid(awvalid), .m_awready(awready),
        .m_wdata(wdata), .m_wstrb(wstrb), .m_wvalid(wvalid), .m_wready(wready),
        .m_bresp(bresp), .m_bvalid(bvalid), .m_bready(bready),
        .m_araddr(araddr), .m_arprot(arprot), .m_arvalid(arvalid), .m_arready(arready),
        .m_rdata(rdata), .m_rresp(rresp), .m_rvalid(rvalid), .m_rready(rready)
    );
    lyncore_job_regs control(
        .clk(clk), .rst(rst), .s_awaddr(awaddr), .s_awprot(awprot), .s_awvalid(awvalid), .s_awready(awready),
        .s_wdata(wdata), .s_wstrb(wstrb), .s_wvalid(wvalid), .s_wready(wready),
        .s_bresp(bresp), .s_bvalid(bvalid), .s_bready(bready),
        .s_araddr(araddr), .s_arprot(arprot), .s_arvalid(arvalid), .s_arready(arready),
        .s_rdata(rdata), .s_rresp(rresp), .s_rvalid(rvalid), .s_rready(rready),
        .job_start(job_start), .job_reset(job_reset), .job_busy(job_busy),
        .job_config(job_config), .engine_done(engine_done), .engine_error(engine_error)
    );
endmodule
