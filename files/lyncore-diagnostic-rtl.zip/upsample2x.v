`timescale 1ns/1ps

// nearest 2 倍上采样：每个八通道像素在横、纵方向各复制两次。
// 输入和输出均为通道组内的 y -> x 顺序；frame_done 在最后结果被接收后产生。
// 一行 RAM 保存当前输入行，再按原顺序输出两遍。预读下一像素支持连续输出。
module upsample2x #(
    parameter MAX_WIDTH = 640
) (
    input wire clk,
    input wire rst_n,
    input wire clear,
    input wire frame_start,
    output wire frame_ready,
    input wire [15:0] frame_width,
    input wire [15:0] frame_height,
    input wire [15:0] frame_co_group,
    output reg busy,
    output reg frame_done,
    output reg error,
    input wire in_valid,
    output wire in_ready,
    input wire [63:0] in_data,
    output wire out_valid,
    input wire out_ready,
    output wire [63:0] out_data,
    output wire [15:0] out_co_group,
    output reg [31:0] out_index
);
    localparam [1:0] IDLE = 0, LOAD_ROW = 1, PRIME = 2, EMIT = 3;
    reg [1:0] state;
    reg [15:0] cfg_width, cfg_height, cfg_co;
    reg [15:0] input_column, input_row, read_column;
    reg row_copy, column_copy;
    reg [63:0] row_mem [0:MAX_WIDTH-1];
    reg [63:0] pixel, next_pixel;
    wire [15:0] next_column = read_column == cfg_width-1'b1 ? 16'd0 : read_column+1'b1;
    // 配置计算使用 34 位，拒绝超过 32 位空间 index 能描述的输出。
    wire [33:0] output_pixels = {18'd0,frame_width} * {18'd0,frame_height} * 34'd4;
    assign frame_ready = rst_n && !clear && !busy;
    assign in_ready = rst_n && !clear && busy && state == LOAD_ROW;
    assign out_valid = rst_n && !clear && busy && state == EMIT;
    assign out_data = pixel;
    assign out_co_group = cfg_co;

    // 数据 RAM 和预读寄存器不复位。整行写完后才进入 PRIME，旧帧不会泄漏。
    always @(posedge clk) begin
        if (rst_n && !clear) begin
            if (in_valid && in_ready) row_mem[input_column] <= in_data;
            if (state == PRIME) pixel <= row_mem[0];
            if (out_valid && out_ready) begin
                // 接收第一个横向副本时预读；接收第二个副本时切换像素。
                // 第二个副本若被阻塞，pixel/index 与 next_pixel 都保持不变。
                if (!column_copy) next_pixel <= row_mem[next_column];
                else pixel <= next_pixel;
            end
        end
    end

    always @(posedge clk or negedge rst_n) begin
        if (!rst_n) begin
            state <= IDLE; busy <= 0; frame_done <= 0; error <= 0;
            cfg_width <= 0; cfg_height <= 0; cfg_co <= 0;
            input_column <= 0; input_row <= 0; read_column <= 0;
            row_copy <= 0; column_copy <= 0; out_index <= 0;
        end else begin
            frame_done <= 0; error <= 0;
            if (clear) begin
                state <= IDLE; busy <= 0; row_copy <= 0; column_copy <= 0;
            end else begin
                if (frame_start && !frame_ready) error <= 1;
                if (frame_start && frame_ready) begin
                    if (frame_width == 0 || frame_height == 0 || frame_width > MAX_WIDTH || output_pixels[33:32] != 0)
                        error <= 1;
                    else begin
                        cfg_width <= frame_width; cfg_height <= frame_height; cfg_co <= frame_co_group;
                        input_column <= 0; input_row <= 0; read_column <= 0;
                        row_copy <= 0; column_copy <= 0; out_index <= 0;
                        state <= LOAD_ROW; busy <= 1;
                    end
                end else begin
                    case (state)
                        LOAD_ROW: if (in_valid && in_ready) begin
                            if (input_column == cfg_width-1'b1) begin
                                input_column <= 0; read_column <= 0;
                                row_copy <= 0; column_copy <= 0; state <= PRIME;
                            end else input_column <= input_column+1'b1;
                        end
                        PRIME: state <= EMIT;
                        EMIT: if (out_valid && out_ready) begin
                            out_index <= out_index+1'b1;
                            if (!column_copy) column_copy <= 1;
                            else begin
                                column_copy <= 0;
                                if (read_column != cfg_width-1'b1) read_column <= read_column+1'b1;
                                else begin
                                    read_column <= 0;
                                    if (!row_copy) row_copy <= 1;
                                    else if (input_row == cfg_height-1'b1) begin
                                        state <= IDLE; busy <= 0; frame_done <= 1;
                                    end else begin
                                        input_row <= input_row+1'b1; state <= LOAD_ROW;
                                    end
                                end
                            end
                        end
                        default: state <= IDLE;
                    endcase
                end
            end
        end
    end
endmodule
