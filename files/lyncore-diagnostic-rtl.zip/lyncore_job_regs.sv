`timescale 1ns/1ps
// Team v0.1 offsets, 22 opaque configuration words. No DDR or arithmetic engine.
// Idle START clears old flags and snapshots config. Busy writes/reset are refused.
module lyncore_job_regs (
    input logic clk, rst,
    input logic [31:0] s_awaddr, s_wdata, s_araddr,
    input logic [2:0] s_awprot, s_arprot,
    input logic [3:0] s_wstrb,
    input logic s_awvalid, s_wvalid, s_bready, s_arvalid, s_rready,
    output logic s_awready, s_wready, s_bvalid, s_arready, s_rvalid,
    output logic [1:0] s_bresp, s_rresp,
    output logic [31:0] s_rdata,
    output logic job_start, job_reset, job_busy,
    output logic [703:0] job_config,
    input logic engine_done, engine_error
);
    logic aw_held, w_held;
    logic [31:0] write_addr, write_data;
    logic [3:0] write_mask;
    logic [31:0] config_words[0:21], active_words[0:21];
    logic done_flag, error_flag;
    wire aw_fire = s_awvalid && s_awready;
    wire w_fire = s_wvalid && s_wready;
    wire write_fire = aw_held && w_held && !s_bvalid;
    wire [29:0] write_index = write_addr[31:2];
    wire [29:0] read_index = s_araddr[31:2];
    assign s_awready = !rst && !aw_held && !s_bvalid;
    assign s_wready = !rst && !w_held && !s_bvalid;
    assign s_arready = !rst && !s_rvalid;
    for (genvar i=0; i<22; i=i+1) assign job_config[i*32 +: 32] = active_words[i];
    always_ff @(posedge clk) begin
        if (rst) begin
            aw_held <= 0; w_held <= 0; write_addr <= 0; write_data <= 0; write_mask <= 0;
            s_bvalid <= 0; s_bresp <= 0; s_rvalid <= 0; s_rresp <= 0; s_rdata <= 0;
            job_start <= 0; job_reset <= 0; job_busy <= 0; done_flag <= 0; error_flag <= 0;
            for(integer i=0; i<22; i=i+1) begin config_words[i] <= 0; active_words[i] <= 0; end
        end else begin
            job_start <= 0; job_reset <= 0;
            if (job_busy && (engine_done || engine_error)) begin
                job_busy <= 0; done_flag <= !engine_error; error_flag <= engine_error;
            end
            if (aw_fire) begin write_addr <= s_awaddr; aw_held <= 1; end
            if (w_fire) begin write_data <= s_wdata; write_mask <= s_wstrb; w_held <= 1; end
            if (s_bvalid && s_bready) s_bvalid <= 0;
            if (s_rvalid && s_rready) s_rvalid <= 0;
            if (write_fire) begin
                aw_held <= 0; w_held <= 0; s_bvalid <= 1; s_bresp <= 0;
                if (write_addr[1:0] != 0 || write_index >= 24 || write_index == 1) s_bresp <= 2;
                else if (write_index == 0) begin
                    if (write_mask[0] && |write_data[1:0]) begin
                        if (job_busy || write_data[1:0] == 3) s_bresp <= 2;
                        else if (write_data[1]) begin
                            job_reset <= 1; done_flag <= 0; error_flag <= 0;
                            for(integer i=0; i<22; i=i+1) begin config_words[i] <= 0; active_words[i] <= 0; end
                        end else begin
                            done_flag <= 0; error_flag <= config_words[0] > 4;
                            if(config_words[0] <= 4) begin
                                job_busy <= 1; job_start <= 1;
                                for(integer i=0; i<22; i=i+1) active_words[i] <= config_words[i];
                            end
                        end
                    end
                end else if (job_busy) s_bresp <= 2;
                else for(integer b=0; b<4; b=b+1)
                    if(write_mask[b]) config_words[write_index-2][b*8 +: 8] <= write_data[b*8 +: 8];
            end
            if (s_arvalid && s_arready) begin
                s_rvalid <= 1; s_rresp <= 0; s_rdata <= 0;
                if(s_araddr[1:0] != 0 || read_index >= 24) s_rresp <= 2;
                else if(read_index == 1) s_rdata <= {29'b0, error_flag, done_flag, job_busy};
                else if(read_index >= 2) s_rdata <= config_words[read_index-2];
            end
        end
    end
    // AxPROT is accepted but not an access-control policy in this M-mode system.
endmodule
