`timescale 1ns/1ps
// One ordered native MMIO transaction. Bundled payload stays stable until the
// synchronized response returns; only request/response toggles cross sync FFs.
// reset_n aborts BOTH domains and their attached master/slave together.
module lyncore_mmio_cdc (
    input logic cpu_clk, accel_clk, reset_n,
    output wire cpu_reset, accel_reset,
    input logic s_valid, s_write,
    input logic [31:0] s_addr, s_wdata,
    input logic [3:0] s_wstrb,
    output wire s_ready, s_error,
    output wire [31:0] s_rdata,
    output wire m_valid, m_write,
    output wire [31:0] m_addr, m_wdata,
    output wire [3:0] m_wstrb,
    input logic m_ready, m_error,
    input logic [31:0] m_rdata
);
    (* ASYNC_REG = "TRUE" *) logic [1:0] cpu_release, accel_release;
    always_ff @(posedge cpu_clk or negedge reset_n)
        if (!reset_n) cpu_release <= 0;
        else cpu_release <= {cpu_release[0],1'b1};
    always_ff @(posedge accel_clk or negedge reset_n)
        if (!reset_n) accel_release <= 0;
        else accel_release <= {accel_release[0],1'b1};
    assign cpu_reset = !cpu_release[1];
    assign accel_reset = !accel_release[1];

    typedef enum logic [1:0] {CPU_IDLE, CPU_WAIT, CPU_RESPONSE} cpu_state_t;
    cpu_state_t cpu_state;
    logic request_toggle, response_toggle;
    logic [68:0] request_payload;
    logic [32:0] response_payload, cpu_response;
    (* ASYNC_REG = "TRUE" *) logic request_meta, request_sync;
    (* ASYNC_REG = "TRUE" *) logic response_meta, response_sync;
    logic request_seen, response_seen, accel_active;
    logic [68:0] accel_request;

    always_ff @(posedge cpu_clk or posedge cpu_reset)
        if (cpu_reset) begin response_meta <= 0; response_sync <= 0; end
        else begin response_meta <= response_toggle; response_sync <= response_meta; end
    always_ff @(posedge accel_clk or posedge accel_reset)
        if (accel_reset) begin request_meta <= 0; request_sync <= 0; end
        else begin request_meta <= request_toggle; request_sync <= request_meta; end

    assign s_ready = !cpu_reset && s_valid && cpu_state == CPU_RESPONSE;
    assign s_error = s_ready && cpu_response[32];
    assign s_rdata = cpu_response[31:0];
    assign m_valid = !accel_reset && accel_active;
    assign {m_write,m_addr,m_wdata,m_wstrb} = accel_request;

    always_ff @(posedge cpu_clk or posedge cpu_reset) begin
        if (cpu_reset) begin
            cpu_state <= CPU_IDLE; request_toggle <= 0;
            request_payload <= 0; response_seen <= 0; cpu_response <= 0;
        end else case (cpu_state)
            CPU_IDLE: if (s_valid) begin
                request_payload <= {s_write,s_addr,s_wdata,s_wstrb};
                request_toggle <= !request_toggle;
                cpu_state <= CPU_WAIT;
            end
            CPU_WAIT: if (response_sync != response_seen) begin
                cpu_response <= response_payload;
                response_seen <= response_sync;
                cpu_state <= CPU_RESPONSE;
            end
            CPU_RESPONSE: if (s_valid) cpu_state <= CPU_IDLE;
            default: cpu_state <= CPU_IDLE;
        endcase
    end

    always_ff @(posedge accel_clk or posedge accel_reset) begin
        if (accel_reset) begin
            request_seen <= 0; accel_active <= 0; accel_request <= 0;
            response_toggle <= 0; response_payload <= 0;
        end else if (!accel_active) begin
            if (request_sync != request_seen) begin
                accel_request <= request_payload;
                request_seen <= request_sync;
                accel_active <= 1;
            end
        end else if (m_ready) begin
            response_payload <= {m_error,m_rdata};
            response_toggle <= !response_toggle;
            accel_active <= 0;
        end
    end
endmodule
