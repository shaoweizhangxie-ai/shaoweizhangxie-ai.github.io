`timescale 1ns/1ps
package lyncore_pkg;
    typedef enum logic [4:0] {
        ALU_ADD, ALU_SUB, ALU_SLL, ALU_SLT, ALU_SLTU,
        ALU_XOR, ALU_SRL, ALU_SRA, ALU_OR, ALU_AND,
        ALU_SH1ADD, ALU_SH2ADD, ALU_SH3ADD,
        ALU_ANDN, ALU_ORN, ALU_XNOR, ALU_CLZ, ALU_CTZ, ALU_CPOP,
        ALU_MIN, ALU_MINU, ALU_MAX, ALU_MAXU, ALU_SEXTB, ALU_SEXTH,
        ALU_ZEXTH, ALU_ROL, ALU_ROR, ALU_ORCB, ALU_REV8
    } alu_op_t;

    typedef struct packed {
        logic [4:0] rs1, rs2, rd;
        logic use_rs1, use_rs2, reg_write;
        logic [31:0] imm;
        alu_op_t alu_op;
        logic a_pc, a_zero, b_imm;
        logic load, store, branch, jal, jalr;
        logic csr, mret, muldiv;
        logic [11:0] csr_addr;
        logic [2:0] funct3;
        logic trap;
        logic [31:0] cause, tval;
    } decode_t;

    typedef struct packed {
        logic valid;
        logic [31:0] pc, insn, predicted_pc;
        logic fetch_error;
    } if_id_t;

    typedef struct packed {
        logic valid;
        logic [31:0] pc, insn, rs1_value, rs2_value, predicted_pc;
        decode_t ctrl;
    } id_ex_t;

    typedef struct packed {
        logic valid;
        logic [31:0] pc, insn, next_pc, result, store_value;
        logic [4:0] rd;
        logic reg_write, load, store, multiply;
        logic csr_write, mret;
        logic [11:0] csr_addr;
        logic [31:0] csr_value;
        logic [2:0] funct3;
        logic trap;
        logic [31:0] cause, tval;
    } ex_mem_t;

    typedef struct packed {
        logic valid;
        logic [31:0] pc, insn, next_pc, result;
        logic [4:0] rd;
        logic reg_write, trap;
        logic csr_write, mret;
        logic [11:0] csr_addr;
        logic [31:0] csr_value;
        logic [31:0] cause, tval, mem_addr, mem_rdata, mem_wdata;
        logic [3:0] mem_rmask, mem_wmask;
    } mem_wb_t;
endpackage
