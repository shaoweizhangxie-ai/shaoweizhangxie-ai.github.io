`timescale 1ns/1ps
module lyncore_regfile #(parameter bit DUAL_ISSUE=0) (
    input logic clk, rst,
    input logic write_en,
    input logic [4:0] write_addr, rs1, rs2,
    input logic [31:0] write_data,
    output logic [31:0] rs1_data, rs2_data,
    input logic write2_en,
    input logic [4:0] write2_addr, rs3, rs4,
    input logic [31:0] write2_data,
    output logic [31:0] rs3_data, rs4_data
);
    logic [31:0] regs [0:31];
    integer i;
    always_ff @(posedge clk) begin
        if (rst) begin
            for (i = 0; i < 32; i = i + 1) regs[i] <= 0;
        end else begin
            if (write_en && write_addr != 0) regs[write_addr] <= write_data;
            if (DUAL_ISSUE && write2_en && write2_addr != 0) regs[write2_addr] <= write2_data;
        end
    end
    // WB-to-ID bypass gives deterministic same-cycle write/read semantics.
    always_comb begin
        rs1_data = (rs1 == 0) ? 0 : regs[rs1];
        rs2_data = (rs2 == 0) ? 0 : regs[rs2];
        rs3_data = !DUAL_ISSUE || rs3 == 0 ? 0 : regs[rs3];
        rs4_data = !DUAL_ISSUE || rs4 == 0 ? 0 : regs[rs4];
        if (write_en && write_addr != 0) begin
            if (rs1 == write_addr) rs1_data = write_data;
            if (rs2 == write_addr) rs2_data = write_data;
            if (DUAL_ISSUE && rs3 == write_addr) rs3_data = write_data;
            if (DUAL_ISSUE && rs4 == write_addr) rs4_data = write_data;
        end
        if (DUAL_ISSUE && write2_en && write2_addr != 0) begin
            if (rs1 == write2_addr) rs1_data = write2_data;
            if (rs2 == write2_addr) rs2_data = write2_data;
            if (rs3 == write2_addr) rs3_data = write2_data;
            if (rs4 == write2_addr) rs4_data = write2_data;
        end
    end
endmodule
