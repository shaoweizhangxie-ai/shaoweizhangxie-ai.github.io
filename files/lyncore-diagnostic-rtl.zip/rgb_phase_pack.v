`timescale 1ns/1ps

// 将 RGB 图像的一个通道拆成四种像素奇偶位置，供首层复用四通道 PE。
// 输入低字节依次为 R/G/B；输出低字节依次为左上/右上/左下/右下。
// 只接收偶数宽高，与官方 YOLOv5 按 32 倍数预处理的输入一致。
module rgb_phase_pack #(
    parameter integer MAX_WIDTH = 640
) (
    input wire clk,
    input wire rst_n,
    input wire frame_start,
    input wire [15:0] frame_width,
    input wire [15:0] frame_height,
    input wire [1:0] rgb_channel,
    output wire frame_ready,
    output wire busy,
    output reg frame_done,
    output reg frame_error,
    input wire in_valid,
    output wire in_ready,
    input wire [23:0] in_pixel,
    output reg out_valid,
    input wire out_ready,
    output reg [31:0] out_pixel
);
    reg active;
    reg [15:0] cfg_width, cfg_height;
    reg [1:0] cfg_channel;
    reg [15:0] x, y;
    reg a_valid, a_odd_x, a_last;
    reg [7:0] a_top, a_bottom;
    reg [7:0] top_left, bottom_left;
    reg out_last;

    // 同步读行 RAM，不复位内容；每个偶数行写满后才读取对应奇数行。
    reg [7:0] even_row [0:MAX_WIDTH-1];
    wire step = !out_valid || out_ready;
    assign in_ready = active && step;
    wire take = in_valid && in_ready;
    wire [7:0] selected = in_pixel[cfg_channel*8 +: 8];
    assign busy = active || a_valid || out_valid;
    assign frame_ready = !busy;
    wire bad_config = (frame_width < 2) || (frame_height < 2) ||
        frame_width[0] || frame_height[0] || (frame_width > MAX_WIDTH) ||
        (rgb_channel >= 3);

    always @(posedge clk) begin
        if (rst_n && take) begin
            if (!y[0])
                even_row[x] <= selected;
            else
                a_top <= even_row[x];
        end
    end

    always @(posedge clk or negedge rst_n) begin
        if (!rst_n) begin
            active <= 0;
            cfg_width <= 0; cfg_height <= 0; cfg_channel <= 0;
            x <= 0; y <= 0;
            a_valid <= 0; a_odd_x <= 0; a_last <= 0; a_bottom <= 0;
            top_left <= 0; bottom_left <= 0;
            out_valid <= 0; out_pixel <= 0; out_last <= 0;
            frame_done <= 0; frame_error <= 0;
        end else begin
            frame_done <= out_valid && out_ready && out_last;
            frame_error <= 0;
            // 输出阻塞时冻结读地址、读响应及左右像素寄存器。
            // 因此即使输入持续 valid，也不会覆盖尚未接收的输出字。
            if (step) begin
                out_valid <= 0;
                a_valid <= take && y[0];
                if (take) begin
                    a_bottom <= selected;
                    a_odd_x <= x[0];
                    a_last <= (x == cfg_width-1) && (y == cfg_height-1);
                    if (x == cfg_width-1) begin
                        x <= 0;
                        if (y == cfg_height-1)
                            active <= 0;
                        else
                            y <= y+1'b1;
                    end else
                        x <= x+1'b1;
                end
                if (a_valid) begin
                    if (!a_odd_x) begin
                        top_left <= a_top;
                        bottom_left <= a_bottom;
                    end else begin
                        out_valid <= 1;
                        out_pixel <= {a_bottom, bottom_left, a_top, top_left};
                        out_last <= a_last;
                    end
                end
            end
            if (frame_start && frame_ready) begin
                if (bad_config)
                    frame_error <= 1;
                else begin
                    cfg_width <= frame_width; cfg_height <= frame_height;
                    cfg_channel <= rgb_channel;
                    x <= 0; y <= 0;
                    active <= 1;
                end
            end
        end
    end
    // synthesis translate_off
    initial begin
        if (MAX_WIDTH < 2 || MAX_WIDTH > 65534) begin
            $display("ERROR: invalid rgb_phase_pack MAX_WIDTH");
            $finish;
        end
    end
    // synthesis translate_on
endmodule
