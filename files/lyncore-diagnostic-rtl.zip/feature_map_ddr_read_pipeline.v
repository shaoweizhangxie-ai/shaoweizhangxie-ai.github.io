`timescale 1ns/1ps

// 专用区域下载 DMA：group8 -> y -> x，每个缓存字包含八个 INT8。
// 最多四项32位读取在途，按请求顺序拼合低/高半字，输出可停顿64位流。
// 配置在 start 时锁存；Halo 不读 DDR，通道尾 lane 补零。上传仍用旧 DMA。
module feature_map_ddr_read_pipeline #(
    parameter [31:0] DDR_WINDOW_BASE=32'h20000000,
    parameter [63:0] DDR_BYTES=64'h40000000
) (
    input wire clk, rst_n, clear, start,
    output wire ready, busy,
    output wire done, error, cancelled,
    // download=0 上传，=1 下载；以下配置仅在 start && ready 时锁存。
    input wire download,
    input wire [31:0] frame_base,
    input wire [15:0] frame_width, frame_height, frame_channels,
    input wire signed [31:0] region_x, region_y,
    input wire [15:0] region_width, region_height, co_base, co_groups,
    input wire [2:0] source_slot,
    // 上传源是局部区域，通道数为所选 group8 的实际有效通道数。
    output wire [2:0] source_config_slot,
    input wire source_config_valid,
    input wire [15:0] source_width, source_height, source_channels,
    output wire source_request_valid,
    input wire source_request_ready,
    output wire [2:0] source_request_slot,
    output wire [15:0] source_request_ci_group,
    output wire [31:0] source_request_index,
    input wire source_response_valid,
    output wire source_response_ready,
    input wire [2:0] source_response_slot,
    input wire [15:0] source_response_ci_group,
    input wire [31:0] source_response_index, source_response_pixel,
    input wire source_response_error,
    // 下载元数据为局部区域配置；输出组从 0 编号，index=row*区域宽度+列。
    output wire [15:0] transfer_width, transfer_height, transfer_channels,
    output wire out_valid,
    input wire out_ready,
    output wire [63:0] out_data,
    output wire [15:0] out_co_group,
    output wire [31:0] out_index,
    output wire out_last,
    // 与已有 pango_ddr_bridge 的 32 位系统字节地址端口直接连接。
    output wire read_request_valid,
    input wire read_request_ready,
    output wire [31:0] read_request_address,
    input wire read_response_valid,
    output wire read_response_ready,
    input wire [31:0] read_response_address, read_response_data,
    input wire read_response_error,
    output wire write_request_valid,
    input wire write_request_ready,
    output wire [31:0] write_request_address, write_request_data,
    output wire [3:0] write_request_strobe,
    input wire write_response_valid,
    output wire write_response_ready,
    input wire [31:0] write_response_address,
    input wire write_response_error
);
    // 仅下载路径：四个32位请求槽。地址/局部索引/通道组/半字均随槽保留。
    // 仲裁器和桥按逻辑顺序退休；本模块同时检查返回地址，不猜响应延迟。
    localparam [63:0] WINDOW_END={32'd0,DDR_WINDOW_BASE}+DDR_BYTES;
    reg running,stopped,stop_error,stop_cancel,allocation_done;
    reg [2:0] config_phase;
    reg config_download;
    reg [63:0] config_bytes,config_end;
    reg done_reg,error_reg,cancel_reg;
    reg [2:0] count;
    reg [1:0] head,tail;
    reg [3:0] issued,complete,half_word;
    reg [31:0] address[0:3],local_index[0:3],data[0:3];
    reg [15:0] local_group[0:3];
    reg [31:0] base,pixels,low_data;
    reg [15:0] fw,fh,fc,rw,rh,first,groups,column,row,group;
    reg signed [31:0] rx,ry;
    reg half;
    reg ov,last_reg;
    reg [63:0] od;
    reg [31:0] oi;
    reg [15:0] og,tw,th,tc;
    integer offset,slot,issue,response,k,lane;
    wire [16:0] held_frame_groups=({1'b0,fc}+17'd7)>>3;
    wire [16:0] selected_end={1'b0,first}+{1'b0,groups};
    wire bad_config=!config_download || DDR_WINDOW_BASE[4:0]!=0 || DDR_BYTES==0 || DDR_BYTES[4:0]!=0 ||
        DDR_BYTES>64'h40000000 || WINDOW_END>64'h100000000 || base[2:0]!=0 ||
        base<DDR_WINDOW_BASE || config_end>WINDOW_END || fw==0 || fh==0 ||
        fc==0 || rw==0 || rh==0 || groups==0 || selected_end>held_frame_groups;
    wire signed [32:0] x=$signed({rx[31],rx})+$signed({17'd0,column});
    reg signed [32:0] y;
    wire allocate_outside=x<0 || y<0 || x>=$signed({17'd0,fw}) || y>=$signed({17'd0,fh});
    wire [16:0] absolute_group={1'b0,first}+{1'b0,group};
    wire [63:0] global_word={47'd0,absolute_group}*{32'd0,pixels}+{31'd0,y}*{48'd0,fw}+{31'd0,x};
    wire [31:0] next_address=base+(global_word<<3)+(half?32'd4:32'd0);
    wire push=running && config_phase==0 && !stopped && !clear && !allocation_done && count<4;
    wire pop=running && count!=0 && complete[head] &&
        (stopped || !half_word[head] || !ov || out_ready);
    always @*begin
        issue=-1;response=-1;
        for(offset=0;offset<4;offset=offset+1)begin
            slot=(head+offset)%4;
            if(offset<count && !issued[slot] && !complete[slot] && issue<0)issue=slot;
            if(offset<count && issued[slot] && !complete[slot] && response<0)response=slot;
        end
    end
    assign ready=rst_n && !clear && !running;
    assign busy=running;
    assign done=done_reg;assign error=error_reg;assign cancelled=cancel_reg;
    assign transfer_width=tw;assign transfer_height=th;assign transfer_channels=tc;
    assign out_valid=ov;assign out_data=od;assign out_index=oi;assign out_co_group=og;assign out_last=last_reg;
    assign read_request_valid=running && !stopped && !clear && issue>=0;
    assign read_request_address=issue>=0?address[issue]:32'd0;
    assign read_response_ready=running && response>=0;
    assign source_config_slot=source_slot;assign source_request_valid=0;assign source_request_slot=0;
    assign source_request_ci_group=0;assign source_request_index=0;assign source_response_ready=0;
    assign write_request_valid=0;assign write_request_address=0;assign write_request_data=0;
    assign write_request_strobe=0;assign write_response_ready=0;
    // 旧区域 TB 的 Halo 监测对应正在输出的局部位置。
    wire signed [32:0] out_x=$signed({rx[31],rx})+$signed({1'b0,(rw==0?32'd0:oi%rw)});
    wire signed [32:0] out_y=$signed({ry[31],ry})+$signed({1'b0,(rw==0?32'd0:oi/rw)});
    wire outside=out_x<0 || out_y<0 || out_x>=$signed({17'd0,fw}) || out_y>=$signed({17'd0,fh});
    wire [3:0] state=running?4'd9:4'd0;
    function [63:0] mask_tail;
        input [63:0] value;input [15:0] local_co;
        integer b;
        begin for(b=0;b<8;b=b+1)mask_tail[b*8 +: 8]=((first+local_co)*8+b<fc)?value[b*8 +: 8]:8'd0;end
    endfunction
    always @(posedge clk or negedge rst_n)begin
        if(!rst_n)begin
            running<=0;stopped<=0;stop_error<=0;stop_cancel<=0;allocation_done<=0;
            config_phase<=0;config_download<=0;config_bytes<=0;config_end<=0;
            done_reg<=0;error_reg<=0;cancel_reg<=0;count<=0;head<=0;tail<=0;issued<=0;complete<=0;half_word<=0;
            base<=0;pixels<=0;low_data<=0;fw<=0;fh<=0;fc<=0;rw<=0;rh<=0;first<=0;groups<=0;
            column<=0;row<=0;group<=0;rx<=0;ry<=0;y<=0;half<=0;ov<=0;od<=0;oi<=0;og<=0;tw<=0;th<=0;tc<=0;last_reg<=0;
            for(k=0;k<4;k=k+1)begin address[k]<=0;local_index[k]<=0;local_group[k]<=0;data[k]<=0;end
        end else begin
            done_reg<=0;error_reg<=0;cancel_reg<=0;
            if(ov && out_ready)ov<=0;
            if(start && ready)begin
                running<=1;stopped<=0;stop_error<=0;stop_cancel<=0;allocation_done<=0;
                config_phase<=1;config_download<=download;
                count<=0;head<=0;tail<=0;issued<=0;complete<=0;
                base<=frame_base;pixels<=0;fw<=frame_width;fh<=frame_height;fc<=frame_channels;
                rw<=region_width;rh<=region_height;first<=co_base;groups<=co_groups;rx<=region_x;ry<=region_y;y<={region_y[31],region_y};
                column<=0;row<=0;group<=0;half<=0;tw<=region_width;th<=region_height;
                tc<=((frame_channels-co_base*8)<co_groups*8)?(frame_channels-co_base*8):co_groups*8;
            end else if(running)begin
                // Validate a captured configuration before allocating requests.
                // Keep the two products, end-address addition and comparison
                // on separate cycles instead of driving stopped through them.
                if(config_phase!=0 && !clear && !stopped)begin
                    case(config_phase)
                        1:begin pixels<={16'd0,fw}*{16'd0,fh};config_phase<=2;end
                        2:begin config_bytes<=({32'd0,pixels}*{47'd0,held_frame_groups})<<3;config_phase<=3;end
                        3:begin config_end<={32'd0,base}+config_bytes;config_phase<=4;end
                        4:begin stopped<=bad_config;stop_error<=bad_config;allocation_done<=bad_config;config_phase<=0;end
                        default:begin stopped<=1;stop_error<=1;allocation_done<=1;config_phase<=0;end
                    endcase
                end
                case({push,pop})2'b10:count<=count+1;2'b01:count<=count-1;default:begin end endcase
                if(push)begin
                    address[tail]<=next_address;local_index[tail]<=row*rw+column;local_group[tail]<=group;
                    half_word[tail]<=half;issued[tail]<=0;complete[tail]<=allocate_outside;data[tail]<=0;tail<=tail+1'b1;
                    if(!half)half<=1;
                    else begin
                        half<=0;
                        if(column==rw-1)begin column<=0;
                            if(row==rh-1)begin row<=0;y<={ry[31],ry};
                                if(group==groups-1)allocation_done<=1;else group<=group+1'b1;
                            end else begin row<=row+1'b1;y<=y+33'sd1;end
                        end else column<=column+1'b1;
                    end
                end
                if(read_request_valid && read_request_ready)issued[issue]<=1;
                if(read_response_valid && read_response_ready)begin
                    data[response]<=read_response_data;complete[response]<=1;
                    if(read_response_error || read_response_address!=address[response])begin stop_error<=1;stopped<=1;end
                end
                if(pop)begin
                    head<=head+1'b1;
                    if(!stopped && !clear)begin
                        if(!half_word[head])low_data<=data[head];
                        else begin ov<=1;od<=mask_tail({data[head],low_data},local_group[head]);
                            oi<=local_index[head];og<=local_group[head];
                            last_reg<=local_index[head]==rw*rh-1 && local_group[head]==groups-1;
                        end
                    end
                end
                if(clear)begin stopped<=1;stop_cancel<=1;config_phase<=0;end
                // 已接受的请求必须收回响应；未发请求可直接退休。输出 valid 必须仍握手。
                if(stopped || clear)for(k=0;k<4;k=k+1)if(!issued[k])complete[k]<=1;
                if((allocation_done || stopped) && count==0 && !ov)begin
                    running<=0;done_reg<=!stop_error && !stop_cancel && !clear;
                    error_reg<=stop_error && !stop_cancel && !clear;cancel_reg<=stop_cancel || clear;
                end
            end
        end
    end
endmodule
