`timescale 1ns/1ps
module lyncore_alu #(parameter bit COMPACT=0) (
    input lyncore_pkg::alu_op_t op,
    input logic [31:0] a, b,
    output logic [31:0] result
);
    import lyncore_pkg::*;
    logic [31:0] add_a;
    logic [5:0] clz_value,ctz_value,pop_value;
    logic [1:0] pop2[0:15];
    logic [2:0] pop4[0:7];
    logic [3:0] pop8[0:3];
    logic [4:0] pop16[0:1];
    logic [31:0] ordinary_result;
    wire [31:0] count_result=(!COMPACT && op==ALU_CPOP) ? {26'b0,pop_value} : 32'b0;
    // Keep the narrow population-count sum out of the ordinary arithmetic
    // result selector, where synthesis can otherwise share a wide carry cone.
    // Reverse bits to reuse one right-shift network for left shifts too.
    // Rotates reuse its fill half; no architectural cycle is added.
    wire shift_left=(op==ALU_SLL || op==ALU_ROL);
    wire shift_rotate=(op==ALU_ROL || op==ALU_ROR);
    wire shift_active=(op==ALU_SLL || op==ALU_SRL || op==ALU_SRA || shift_rotate);
    wire [31:0] reversed_a,shift_input,shift_fill,shift_right,shift_output;
    wire [63:0] shifted;
    for(genvar i=0;i<32;i++)begin : shift_reverse
        assign reversed_a[i]=a[31-i];
        assign shift_output[i]=shift_left ? shift_right[31-i] : shift_right[i];
    end
    assign shift_input=shift_left ? reversed_a : a;
    assign shift_fill=shift_rotate ? shift_input : {32{op==ALU_SRA && a[31]}};
    assign shifted={shift_fill,shift_input} >> b[4:0];
    assign shift_right=shifted[31:0];
    assign result=ordinary_result | count_result | ({32{shift_active}} & shift_output);
    always_comb begin
        // Fixed shifts are wiring; Zba shares the ordinary ADD datapath.
        case (op)
            ALU_SH1ADD: add_a = {a[30:0], 1'b0};
            ALU_SH2ADD: add_a = {a[29:0], 2'b0};
            ALU_SH3ADD: add_a = {a[28:0], 3'b0};
            default: add_a = a;
        endcase
        clz_value=32;
        ctz_value=32;
        for(integer i=0;i<32;i++) begin
            if(a[i]) clz_value=6'(31-i);
            if(a[31-i]) ctz_value=6'(31-i);
        end
        for(integer i=0;i<16;i++) pop2[i]={1'b0,a[2*i]}+{1'b0,a[2*i+1]};
        for(integer i=0;i<8;i++) pop4[i]={1'b0,pop2[2*i]}+{1'b0,pop2[2*i+1]};
        for(integer i=0;i<4;i++) pop8[i]={1'b0,pop4[2*i]}+{1'b0,pop4[2*i+1]};
        for(integer i=0;i<2;i++) pop16[i]={1'b0,pop8[2*i]}+{1'b0,pop8[2*i+1]};
        pop_value={1'b0,pop16[0]}+{1'b0,pop16[1]};
        case (op)
            ALU_ADD, ALU_SH1ADD, ALU_SH2ADD, ALU_SH3ADD: ordinary_result = add_a + b;
            ALU_SUB: ordinary_result = a - b;
            ALU_SLL: ordinary_result = 0;
            ALU_SLT: ordinary_result = {31'b0, ($signed(a) < $signed(b))};
            ALU_SLTU: ordinary_result = {31'b0, (a < b)};
            ALU_XOR: ordinary_result = a ^ b;
            ALU_SRL: ordinary_result = 0;
            ALU_SRA: ordinary_result = 0;
            ALU_OR: ordinary_result = a | b;
            ALU_AND: ordinary_result = a & b;
            ALU_ANDN: ordinary_result = a & ~b;
            ALU_ORN: ordinary_result = a | ~b;
            ALU_XNOR: ordinary_result = ~(a ^ b);
            ALU_CLZ: ordinary_result = COMPACT ? 32'b0 : {26'b0,clz_value};
            ALU_CTZ: ordinary_result = COMPACT ? 32'b0 : {26'b0,ctz_value};
            ALU_CPOP: ordinary_result = 0;
            ALU_MIN: ordinary_result = COMPACT ? 32'b0 : (($signed(a)<$signed(b)) ? a : b);
            ALU_MINU: ordinary_result = COMPACT ? 32'b0 : ((a<b) ? a : b);
            ALU_MAX: ordinary_result = COMPACT ? 32'b0 : (($signed(a)>$signed(b)) ? a : b);
            ALU_MAXU: ordinary_result = COMPACT ? 32'b0 : ((a>b) ? a : b);
            ALU_SEXTB: ordinary_result = {{24{a[7]}},a[7:0]};
            ALU_SEXTH: ordinary_result = {{16{a[15]}},a[15:0]};
            ALU_ZEXTH: ordinary_result = {16'b0,a[15:0]};
            ALU_ROL: ordinary_result = 0;
            ALU_ROR: ordinary_result = 0;
            ALU_ORCB: ordinary_result = {{8{|a[31:24]}},{8{|a[23:16]}},{8{|a[15:8]}},{8{|a[7:0]}}};
            ALU_REV8: ordinary_result = {a[7:0],a[15:8],a[23:16],a[31:24]};
            default: ordinary_result = 0;
        endcase
    end
endmodule
