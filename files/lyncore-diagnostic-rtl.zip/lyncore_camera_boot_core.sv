`timescale 1ns/1ps
// Single frame per common reset. Frozen model/table are loaded and CRC-verified
// through LC26 object0/object1. There is one shared bridge and no preloaded tensor.
// Video and CPU ownership change only after requests, responses and writes drain.
module lyncore_camera_boot_core #(parameter integer CPU_CLOCK_HZ=120000000,BAUD=115200,
 parameter [31:0] MODEL_BYTES=2000824,MODEL_CRC=32'hcae3a77e,TABLE_BYTES=5568,TABLE_CRC=32'h72ada019)( 
input wire clk,cpu_clk,pclk,rst_n,ddr_init_done,sensor_configured,vsync,href,
 input wire [7:0] camera_data,
 input wire load_byte_valid,load_ack_ready,transport_idle,transport_error,
 input wire [7:0] load_byte_data,
 output wire load_byte_ready,load_ack_valid,load_failed,assets_ready,
 output wire [7:0] load_ack_data,output wire [3:0] load_error,
 output wire [2:0] load_committed,
 input wire [31:0] frame_id,
 input wire overlay_ready,
 input wire uart_rx,
 input wire [4:0] keys,
 output wire uart_tx,halted,
 output wire [7:0] leds,
 output reg [2:0] phase,
 output reg failed,
 output wire cpu_run_enable,raw_committed,tensor_committed,
 output wire [31:0] input_crc32,verified_bytes,committed_frame_id,
 output wire overlay_capture,overlay_pixel_valid,overlay_packet_write,overlay_packet_valid,
 output wire [15:0] overlay_pixel_data,
 output wire [31:0] overlay_frame_id,overlay_packet_addr,overlay_packet_data,overlay_packet_bytes,
 output wire [27:0] axi_araddr,
 output wire axi_aruser_ap,
 output wire [3:0] axi_aruser_id,
 output wire [3:0] axi_arlen,
 output wire axi_arvalid,
 input wire axi_arready,
 input wire [255:0] axi_rdata,
 input wire [3:0] axi_rid,
 input wire axi_rlast,
 input wire axi_rvalid,
 output wire [27:0] axi_awaddr,
 output wire axi_awuser_ap,
 output wire [3:0] axi_awuser_id,
 output wire [3:0] axi_awlen,
 output wire axi_awvalid,
 input wire axi_awready,
 output wire [255:0] axi_wdata,
 output wire [31:0] axi_wstrb,
 input wire axi_wready,
 input wire [3:0] axi_wusero_id,
 input wire axi_wusero_last
);
 localparam [2:0] WAIT_ASSETS=0,CAPTURE=1,PREPARE=2,VERIFY=3,DRAIN=4,RUN=5,REARM=6;
 reg [31:0] frame_context;
 reg [3:0] rearm_count;
 wire frame_reset_n=rst_n && phase!=REARM;
 wire cpu_frame_done;
 (* syn_preserve=1 *) reg [1:0] frame_done_sync;
 always @(posedge clk or negedge rst_n)
  if(!rst_n) frame_done_sync<=0;
  else if(phase!=RUN) frame_done_sync<=0;
  else frame_done_sync<={frame_done_sync[0],cpu_frame_done};
 (* syn_preserve=1 *) reg [1:0] sensor_sync;
 wire ddr_ready,bridge_busy,bridge_fault,raw_failed,store_failed,raw_settled,render_ready,render_failed,verify_active;
 wire loader_selected=phase==WAIT_ASSETS;
 wire camera_selected=phase==CAPTURE;
 wire assets_committed=load_committed[1:0]==2'b11 && !load_failed;
 assign assets_ready=rst_n && assets_committed;
 wire loader_byte_ready;
 assign load_byte_ready=loader_selected && !assets_committed && loader_byte_ready;
 wire boot_idle=assets_committed && !load_ack_valid && transport_idle && !bridge_busy && !pending;
 wire cpu_selected=phase==RUN;
 wire render_start=phase==PREPARE && render_ready && !failed;
 assign cpu_run_enable=rst_n && cpu_selected && !failed && ddr_init_done && assets_ready;
 wire pending;
 always @(posedge clk or negedge rst_n)begin
  if(!rst_n)begin phase<=WAIT_ASSETS;failed<=0;frame_context<=0;sensor_sync<=0;rearm_count<=0;end
  else begin
   sensor_sync<={sensor_sync[0],sensor_configured};
   if(bridge_fault || load_failed || store_failed || render_failed ||
     (phase!=WAIT_ASSETS && (!ddr_init_done || !assets_ready)))failed<=1;
   else if(!failed)case(phase)
    WAIT_ASSETS:if(ddr_ready && boot_idle && sensor_sync[1] && overlay_ready)begin frame_context<=frame_id;phase<=CAPTURE;end
    CAPTURE:if(raw_committed && raw_settled && !bridge_busy && !pending)phase<=PREPARE;
    PREPARE:if(render_ready)phase<=VERIFY;
    VERIFY:if(tensor_committed)begin
     if(verified_bytes!=819200 || committed_frame_id!=frame_context)failed<=1;
     else phase<=DRAIN;
    end
    DRAIN:if(!bridge_busy && !pending)phase<=RUN;
    RUN:if(frame_done_sync[1] && !bridge_busy && !pending)begin
     rearm_count<=0;phase<=REARM;
    end
    REARM:if((&rearm_count) && overlay_ready)begin
     frame_context<=frame_context+32'd1;phase<=CAPTURE;
    end else if(!(&rearm_count))rearm_count<=rearm_count+1'b1;
    default:begin end
   endcase
  end
 end
 wire cpu_read_request_valid;
 wire cpu_read_request_ready;
 wire [31:0] cpu_read_request_address;
 wire cpu_read_response_valid;
 wire cpu_read_response_ready;
 wire [31:0] cpu_read_response_address;
 wire [31:0] cpu_read_response_data;
 wire cpu_read_response_error;
 wire cpu_write_request_valid;
 wire cpu_write_request_ready;
 wire [31:0] cpu_write_request_address;
 wire [31:0] cpu_write_request_data;
 wire [3:0] cpu_write_request_strobe;
 wire cpu_write_response_valid;
 wire cpu_write_response_ready;
 wire [31:0] cpu_write_response_address;
 wire cpu_write_response_error;
 wire render_read_request_valid;
 wire render_read_request_ready;
 wire [31:0] render_read_request_address;
 wire render_read_response_valid;
 wire render_read_response_ready;
 wire [31:0] render_read_response_address;
 wire [31:0] render_read_response_data;
 wire render_read_response_error;
 wire render_write_request_valid;
 wire render_write_request_ready;
 wire [31:0] render_write_request_address;
 wire [31:0] render_write_request_data;
 wire [3:0] render_write_request_strobe;
 wire render_write_response_valid;
 wire render_write_response_ready;
 wire [31:0] render_write_response_address;
 wire render_write_response_error;
 wire shared_read_request_valid;
 wire shared_read_request_ready;
 wire [31:0] shared_read_request_address;
 wire shared_read_response_valid;
 wire shared_read_response_ready;
 wire [31:0] shared_read_response_address;
 wire [31:0] shared_read_response_data;
 wire shared_read_response_error;
 wire shared_write_request_valid;
 wire shared_write_request_ready;
 wire [31:0] shared_write_request_address;
 wire [31:0] shared_write_request_data;
 wire [3:0] shared_write_request_strobe;
 wire shared_write_response_valid;
 wire shared_write_response_ready;
 wire [31:0] shared_write_response_address;
 wire shared_write_response_error;
 wire camera_write_request_valid;
 wire camera_write_request_ready;
 wire [31:0] camera_write_request_address;
 wire [31:0] camera_write_request_data;
 wire [3:0] camera_write_request_strobe;
 wire camera_write_response_valid;
 wire camera_write_response_ready;
 wire [31:0] camera_write_response_address;
 wire camera_write_response_error;
 wire loader_read_request_valid;
 wire loader_read_request_ready;
 wire [31:0] loader_read_request_address;
 wire loader_read_response_valid;
 wire loader_read_response_ready;
 wire [31:0] loader_read_response_address;
 wire [31:0] loader_read_response_data;
 wire loader_read_response_error;
 wire loader_write_request_valid;
 wire loader_write_request_ready;
 wire [31:0] loader_write_request_address;
 wire [31:0] loader_write_request_data;
 wire [3:0] loader_write_request_strobe;
 wire loader_write_response_valid;
 wire loader_write_response_ready;
 wire [31:0] loader_write_response_address;
 wire loader_write_response_error;
 assign pending=shared_read_request_valid || shared_write_request_valid || shared_read_response_valid || shared_write_response_valid;
 assign shared_read_request_valid=loader_selected?loader_read_request_valid:(camera_selected?1'd0:(cpu_selected?cpu_read_request_valid:render_read_request_valid));
 assign loader_read_request_ready=loader_selected && shared_read_request_ready;
 assign cpu_read_request_ready=cpu_selected && shared_read_request_ready;
 assign render_read_request_ready=!loader_selected && !camera_selected && !cpu_selected && shared_read_request_ready;
 assign shared_read_request_address=loader_selected?loader_read_request_address:(camera_selected?32'd0:(cpu_selected?cpu_read_request_address:render_read_request_address));
 assign loader_read_response_valid=loader_selected && shared_read_response_valid;
 assign cpu_read_response_valid=cpu_selected && shared_read_response_valid;
 assign render_read_response_valid=!loader_selected && !camera_selected && !cpu_selected && shared_read_response_valid;
 assign shared_read_response_ready=loader_selected?loader_read_response_ready:(camera_selected?1'd0:(cpu_selected?cpu_read_response_ready:render_read_response_ready));
 assign loader_read_response_address=shared_read_response_address;
 assign cpu_read_response_address=shared_read_response_address;
 assign render_read_response_address=shared_read_response_address;
 assign loader_read_response_data=shared_read_response_data;
 assign cpu_read_response_data=shared_read_response_data;
 assign render_read_response_data=shared_read_response_data;
 assign loader_read_response_error=shared_read_response_error;
 assign cpu_read_response_error=shared_read_response_error;
 assign render_read_response_error=shared_read_response_error;
 assign shared_write_request_valid=loader_selected?loader_write_request_valid:(camera_selected?camera_write_request_valid:(cpu_selected?cpu_write_request_valid:render_write_request_valid));
 assign loader_write_request_ready=loader_selected && shared_write_request_ready;
 assign cpu_write_request_ready=cpu_selected && shared_write_request_ready;
 assign render_write_request_ready=!loader_selected && !camera_selected && !cpu_selected && shared_write_request_ready;
 assign camera_write_request_ready=camera_selected && shared_write_request_ready;
 assign shared_write_request_address=loader_selected?loader_write_request_address:(camera_selected?camera_write_request_address:(cpu_selected?cpu_write_request_address:render_write_request_address));
 assign shared_write_request_data=loader_selected?loader_write_request_data:(camera_selected?camera_write_request_data:(cpu_selected?cpu_write_request_data:render_write_request_data));
 assign shared_write_request_strobe=loader_selected?loader_write_request_strobe:(camera_selected?camera_write_request_strobe:(cpu_selected?cpu_write_request_strobe:render_write_request_strobe));
 assign loader_write_response_valid=loader_selected && shared_write_response_valid;
 assign cpu_write_response_valid=cpu_selected && shared_write_response_valid;
 assign render_write_response_valid=!loader_selected && !camera_selected && !cpu_selected && shared_write_response_valid;
 assign camera_write_response_valid=camera_selected && shared_write_response_valid;
 assign shared_write_response_ready=loader_selected?loader_write_response_ready:(camera_selected?camera_write_response_ready:(cpu_selected?cpu_write_response_ready:render_write_response_ready));
 assign loader_write_response_address=shared_write_response_address;
 assign cpu_write_response_address=shared_write_response_address;
 assign render_write_response_address=shared_write_response_address;
 assign camera_write_response_address=shared_write_response_address;
 assign loader_write_response_error=shared_write_response_error;
 assign cpu_write_response_error=shared_write_response_error;
 assign render_write_response_error=shared_write_response_error;
 assign camera_write_response_error=shared_write_response_error;
 // The frozen three-object loader is stopped after A1. Object2 comes
 // from the camera path, not from the host. ACK transmission must drain first.
 lyncore_asset_loader #(.MODEL_BYTES(MODEL_BYTES),.MODEL_CRC(MODEL_CRC),.TABLE_BYTES(TABLE_BYTES),.TABLE_CRC(TABLE_CRC)) loader(
  .clk(clk),.rst_n(rst_n && ddr_init_done),.transport_error((transport_error && loader_selected) || bridge_fault),
  .byte_valid(load_byte_valid && loader_selected && !assets_committed),.byte_data(load_byte_data),.byte_ready(loader_byte_ready),
  .ack_valid(load_ack_valid),.ack_data(load_ack_data),.ack_ready(load_ack_ready),.done(),.failed(load_failed),.error_code(load_error),.committed(load_committed),
  .read_request_valid(loader_read_request_valid),
  .read_request_ready(loader_read_request_ready),
  .read_request_address(loader_read_request_address),
  .read_response_valid(loader_read_response_valid),
  .read_response_ready(loader_read_response_ready),
  .read_response_address(loader_read_response_address),
  .read_response_data(loader_read_response_data),
  .read_response_error(loader_read_response_error),
  .write_request_valid(loader_write_request_valid),
  .write_request_ready(loader_write_request_ready),
  .write_request_address(loader_write_request_address),
  .write_request_data(loader_write_request_data),
  .write_request_strobe(loader_write_request_strobe),
  .write_response_valid(loader_write_response_valid),
  .write_response_ready(loader_write_response_ready),
  .write_response_address(loader_write_response_address),
  .write_response_error(loader_write_response_error));
 assign overlay_capture=phase==CAPTURE && !failed;
 assign overlay_frame_id=frame_context;
 assign overlay_packet_write=cpu_write_request_valid && cpu_write_request_ready && (&cpu_write_request_strobe);
 assign overlay_packet_addr=cpu_write_request_address;
 assign overlay_packet_data=cpu_write_request_data;
 assign overlay_packet_valid=packet_valid && !failed;
 assign overlay_packet_bytes=packet_bytes;
 video_camera_rgb565 camera(.overlay_pixel_valid(overlay_pixel_valid),.overlay_pixel_data(overlay_pixel_data),
  .clk(clk),.pclk(pclk),.rst_n(frame_reset_n),.sensor_configured(sensor_sync[1]),.memory_grant(phase==CAPTURE),
  .ddr_ready(ddr_ready),.bridge_busy(bridge_busy),.bridge_fault(bridge_fault),.vsync(vsync),.href(href),.data(camera_data),
  .committed(raw_committed),.capture_failed(raw_failed),.store_failed(store_failed),.settled(raw_settled),
  .write_request_valid(camera_write_request_valid),
  .write_request_ready(camera_write_request_ready),
  .write_request_address(camera_write_request_address),
  .write_request_data(camera_write_request_data),
  .write_request_strobe(camera_write_request_strobe),
  .write_response_valid(camera_write_response_valid),
  .write_response_ready(camera_write_response_ready),
  .write_response_address(camera_write_response_address),
  .write_response_error(camera_write_response_error));
 video_frame_to_input render(
  .clk(clk),.rst_n(frame_reset_n),.start(render_start),.source_committed(raw_committed),.slot_available(1'b1),.release_frame(1'b0),
  .ddr_ready(ddr_ready),.bridge_busy(bridge_busy),.bridge_fault(bridge_fault),.frame_id(frame_context),
  .ready(render_ready),.busy(),.committed(tensor_committed),.failed(render_failed),.verify_active(verify_active),
  .committed_frame_id(committed_frame_id),.verified_bytes(verified_bytes),.tensor_crc32(input_crc32),
  .read_request_valid(render_read_request_valid),
  .read_request_ready(render_read_request_ready),
  .read_request_address(render_read_request_address),
  .read_response_valid(render_read_response_valid),
  .read_response_ready(render_read_response_ready),
  .read_response_address(render_read_response_address),
  .read_response_data(render_read_response_data),
  .read_response_error(render_read_response_error),
  .write_request_valid(render_write_request_valid),
  .write_request_ready(render_write_request_ready),
  .write_request_address(render_write_request_address),
  .write_request_data(render_write_request_data),
  .write_request_strobe(render_write_request_strobe),
  .write_response_valid(render_write_response_valid),
  .write_response_ready(render_write_response_ready),
  .write_response_address(render_write_response_address),
  .write_response_error(render_write_response_error));
 wire job_started;
 wire job_finished;
 wire [15:0] task_id;
 wire [511:0] active_descriptor;
 wire raw_valid;
 wire [15:0] raw_co_group;
 wire [31:0] raw_index;
 wire [255:0] raw_data;
 wire out_valid;
 wire [15:0] out_co_group;
 wire [31:0] out_index;
 wire [63:0] out_data;
 wire executor_start;
 wire executor_busy;
 wire executor_done;
 wire executor_error;
 wire executor_cancelled;
 wire result_valid;
 wire [31:0] publish_seq;
 wire [4:0] adapter_state;
 wire [1:0] memory_owner;
 wire packet_valid;
 wire [31:0] packet_bytes;
 wire [63:0] cycle_count;
 wire [63:0] instret_count;
 lyncore_yolo_soc #(.CLOCK_HZ(CPU_CLOCK_HZ),.BAUD(BAUD),.K1_WIDE_ENABLE(1),.AUX_PIPELINE_ENABLE(2)) cpu_system(
  .clk(clk),.cpu_clk(cpu_clk),.rst_n(cpu_run_enable),.clear(1'b0),.uart_rx(uart_rx),.keys(keys),
  .uart_tx(uart_tx),.leds(leds),.halted(halted),
  .camera_frame_id(frame_context),.camera_frame_done(cpu_frame_done),.ddr_ready(ddr_ready),.memory_idle(!bridge_busy),.input_allow(1'b1),.input_write_allow(1'b1),
  .read_request_valid(cpu_read_request_valid),
  .read_request_ready(cpu_read_request_ready),
  .read_request_address(cpu_read_request_address),
  .read_response_valid(cpu_read_response_valid),
  .read_response_ready(cpu_read_response_ready),
  .read_response_address(cpu_read_response_address),
  .read_response_data(cpu_read_response_data),
  .read_response_error(cpu_read_response_error),
  .write_request_valid(cpu_write_request_valid),
  .write_request_ready(cpu_write_request_ready),
  .write_request_address(cpu_write_request_address),
  .write_request_data(cpu_write_request_data),
  .write_request_strobe(cpu_write_request_strobe),
  .write_response_valid(cpu_write_response_valid),
  .write_response_ready(cpu_write_response_ready),
  .write_response_address(cpu_write_response_address),
  .write_response_error(cpu_write_response_error),
  .job_started(job_started),
  .job_finished(job_finished),
  .task_id(task_id),
  .active_descriptor(active_descriptor),
  .raw_valid(raw_valid),
  .raw_co_group(raw_co_group),
  .raw_index(raw_index),
  .raw_data(raw_data),
  .out_valid(out_valid),
  .out_co_group(out_co_group),
  .out_index(out_index),
  .out_data(out_data),
  .executor_start(executor_start),
  .executor_busy(executor_busy),
  .executor_done(executor_done),
  .executor_error(executor_error),
  .executor_cancelled(executor_cancelled),
  .result_valid(result_valid),
  .publish_seq(publish_seq),
  .adapter_state(adapter_state),
  .memory_owner(memory_owner),
  .packet_valid(packet_valid),
  .packet_bytes(packet_bytes),
  .cycle_count(cycle_count),
  .instret_count(instret_count));
 pango_ddr_read_pipeline #(.WRITE_COMBINE(1),.READ_BEAT_CACHE(1),.DDR_BYTES(64'h02000000)) bridge(
  .clk(clk),.rst_n(rst_n),.clear(1'b0),.ddr_init_done(ddr_init_done),.ddr_ready(ddr_ready),.busy(bridge_busy),.protocol_fault(bridge_fault),
  .read_request_valid(shared_read_request_valid),
  .read_request_ready(shared_read_request_ready),
  .read_request_address(shared_read_request_address),
  .read_response_valid(shared_read_response_valid),
  .read_response_ready(shared_read_response_ready),
  .read_response_address(shared_read_response_address),
  .read_response_data(shared_read_response_data),
  .read_response_error(shared_read_response_error),
  .write_request_valid(shared_write_request_valid),
  .write_request_ready(shared_write_request_ready),
  .write_request_address(shared_write_request_address),
  .write_request_data(shared_write_request_data),
  .write_request_strobe(shared_write_request_strobe),
  .write_response_valid(shared_write_response_valid),
  .write_response_ready(shared_write_response_ready),
  .write_response_address(shared_write_response_address),
  .write_response_error(shared_write_response_error),
  .axi_araddr(axi_araddr),
  .axi_aruser_ap(axi_aruser_ap),
  .axi_aruser_id(axi_aruser_id),
  .axi_arlen(axi_arlen),
  .axi_arvalid(axi_arvalid),
  .axi_arready(axi_arready),
  .axi_rdata(axi_rdata),
  .axi_rid(axi_rid),
  .axi_rlast(axi_rlast),
  .axi_rvalid(axi_rvalid),
  .axi_awaddr(axi_awaddr),
  .axi_awuser_ap(axi_awuser_ap),
  .axi_awuser_id(axi_awuser_id),
  .axi_awlen(axi_awlen),
  .axi_awvalid(axi_awvalid),
  .axi_awready(axi_awready),
  .axi_wdata(axi_wdata),
  .axi_wstrb(axi_wstrb),
  .axi_wready(axi_wready),
  .axi_wusero_id(axi_wusero_id),
  .axi_wusero_last(axi_wusero_last));
endmodule
