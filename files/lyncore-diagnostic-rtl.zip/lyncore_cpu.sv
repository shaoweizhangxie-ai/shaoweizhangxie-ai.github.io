`timescale 1ns/1ps
module lyncore_cpu #(
    parameter logic [31:0] RESET_PC = 32'h00000000,
    parameter bit HALT_ON_TRAP = 0, // Legacy diagnostic test mode only
    parameter bit ENABLE_M = 0,
    parameter bit ENABLE_ZBA = 0,
    parameter bit ENABLE_ZBB = 0,
    parameter bit ENABLE_BP = 0,
    parameter integer BP_INDEX_BITS = 4,
    parameter integer BP_HISTORY_BITS = 0,
    parameter bit BP_HASH_INDEX = 0,
    parameter bit LOAD_USE_INTERLOCK = 1,
    parameter bit PIPELINED_MUL = 0,
    parameter bit ENABLE_RAS = 0,
    parameter bit DECOUPLED_FETCH = 0,
    parameter bit DUAL_ISSUE = 0
) (
    input logic clk, rst, predictor_flush,
    // Synchronous, level-held requests. The source clears its pending condition.
    input logic irq_software, irq_timer, irq_external,
    output logic irq_taken,
    output logic [31:0] irq_pc, irq_cause,
    // Blocking transaction: valid/address stay stable until ready completes it.
    // Data and error are sampled on that same completion edge.
    output logic imem_valid,
    output logic [31:0] imem_addr,
    input logic imem_ready,
    input logic [31:0] imem_rdata,
    input logic imem_error,
    // Optional adjacent word from the SAME successful transaction/16-byte line.
    // A false valid never faults: fetch that PC in a subsequent transaction.
    input logic imem_second_valid,
    input logic [31:0] imem_second_data,
    output logic dmem_valid, dmem_write,
    output logic [31:0] dmem_addr, dmem_wdata,
    // Address that the MEM register will expose after the next edge. Used only
    // for side-effect-free cache RAM lookahead, never for issuing a bus access.
    output logic [31:0] dmem_preview_addr,
    output logic dmem_preview_stall,
    output logic [3:0] dmem_wstrb,
    input logic dmem_ready,
    input logic [31:0] dmem_rdata,
    input logic dmem_error,
    output logic halted,
    output logic [31:0] halt_pc, halt_cause, halt_tval,
    // Retirement observation for differential tests, not a claim of RVFI compliance.
    output logic retire_valid, retire_trap,
    output logic [31:0] retire_pc, retire_insn, retire_next_pc,
    output logic [4:0] retire_rd,
    output logic [31:0] retire_data, retire_cause, retire_tval,
    output logic [31:0] retire_mem_addr, retire_mem_rdata, retire_mem_wdata,
    output logic [3:0] retire_mem_rmask, retire_mem_wmask,
    output logic [63:0] cycle_count, instret_count,
    output logic [31:0] load_stall_count, mem_stall_count, redirect_count,
    output logic [31:0] branch_count, mispredict_count,
    output logic retire2_valid,
    output logic [31:0] retire2_pc, retire2_insn, retire2_data, retire2_next_pc,
    output logic [4:0] retire2_rd
);
    import lyncore_pkg::*;
    if_id_t if_id;
    id_ex_t id_ex;
    ex_mem_t ex_mem;
    mem_wb_t mem_wb;
    decode_t decoded;
    logic [31:0] rs1_data, rs2_data, ex_rs1, ex_rs2;
    logic [31:0] alu_a, alu_b, alu_result, ex_result, ex_target;
    wire [31:0] ex_address=ex_rs1+id_ex.ctrl.imm;
    logic branch_taken, jump_taken, redirect, ex_fault, mem_fault, fault_event;
    logic [31:0] ex_cause, ex_tval;
    logic [31:0] load_shifted, load_value, mem_result;
    logic [3:0] mem_mask;
    logic mem_ready, ex_ready, load_use, mem_load_use, fetch_ready, writeback;
    // Capture the qualified request with MEM metadata, before the cache/load
    // forwarding path. It is held and flushed exactly like ex_mem.valid.
    logic mem_access;
    logic [31:0] fetch_pc, request_pc;
    logic request_active, request_killed, stop_fetch;
    logic instruction_done;
    logic fetch_available;
    if_id_t fetch_head;
    logic [31:0] csr_data, csr_operand, csr_value, trap_vector, return_pc;
    logic csr_legal, csr_read_only, csr_write_intent;
    logic system_wait, system_inflight, irq_pending, trap_commit, return_commit;
    logic control_redirect;
    logic [31:0] architectural_pc, control_target, entry_cause;
    logic md_start, md_busy, md_done, md_wait;
    logic [31:0] md_result;
    logic [31:0] multiply_result, multiply_low_result;
    logic [31:0] predicted_fetch_pc, resolved_pc;
    logic [31:0] predicted_second_pc;
    logic predictor_update;
    logic redirect_stat_q,predictor_stat_q;
    if_id_t if_id2;
    id_ex_t id_ex2;
    ex_mem_t ex_mem2;
    mem_wb_t mem_wb2;
    decode_t decoded2;
    logic [31:0] rs3_data, rs4_data, ex2_rs1, ex2_rs2, alu2_result;
    logic [31:0] branch1_a,branch1_b,branch2_a,branch2_b;
    logic writeback2, pair_issue, issue_fire, fetch_second;
    logic late_pair_mem, late_pair_rs1, late_pair_rs2;
    logic [31:0] late_pair_a, late_pair_b, late_pair_result;
    alu_op_t late_pair_op;
    wire pair_raw_ex=id_ex.ctrl.reg_write && id_ex.ctrl.rd!=0 &&
        ((id_ex2.ctrl.use_rs1 && id_ex2.ctrl.rs1==id_ex.ctrl.rd) ||
         (id_ex2.ctrl.use_rs2 && id_ex2.ctrl.rs2==id_ex.ctrl.rd));
    // Never chain a producing EX ALU into its companion's comparator. A RAW
    // branch resolves from the registered primary result in MEM instead.
    wire late_branch_ex=DUAL_ISSUE && id_ex2.valid && id_ex2.ctrl.branch &&
        pair_raw_ex;
    wire branch2_ex=DUAL_ISSUE && id_ex2.valid && id_ex2.ctrl.branch && !late_branch_ex;
    logic late_branch_mem;
    logic [31:0] late_branch_predicted;
    // Paired branches follow an ordinary ALU, never a load/multiply/CSR.
    // Keep the cache and multiplier trees off this comparison path.
    wire [31:0] late_branch_primary=ex_mem.result;
    wire [31:0] late_branch_a=late_pair_rs1 ? late_branch_primary : late_pair_a;
    wire [31:0] late_branch_b=late_pair_rs2 ? late_branch_primary : late_pair_b;
    wire [31:0] late_pair_primary=ex_mem.load ? load_value : ex_mem.result;
    logic late_branch_taken;
    wire [31:0] late_branch_next=late_branch_taken ? ex_mem2.next_pc : ex_mem2.pc+4;
    wire late_branch_update=late_branch_mem && ex_mem.valid && ex_mem2.valid && mem_ready &&
        !rst && !halted && !stop_fetch && !control_redirect && !mem_fault && !ex_mem.trap;
    // Compare PC metadata in parallel with the data-dependent branch condition.
    wire late_redirect=late_branch_update && (late_branch_taken ?
        late_branch_predicted!=ex_mem2.next_pc : late_branch_predicted!=ex_mem2.pc+4);
    // One predictor training port: an EX control-flow instruction waits only
    // when the older MEM branch owns that port. Ordinary EX may still advance.
    wire branch_port_wait=id_ex.valid && late_branch_mem && ex_mem2.valid &&
        (id_ex.ctrl.branch || id_ex.ctrl.jal || id_ex.ctrl.jalr || branch2_ex);
    wire [31:0] early_resolved_pc=branch2_ex ? branch2_next : (jump_taken ? ex_target : id_ex.pc+4);
    wire early_update=id_ex.valid && ex_ready && !rst && !halted && !stop_fetch &&
        !control_redirect && !mem_fault && !ex_fault && !late_branch_update &&
        (id_ex.ctrl.branch || id_ex.ctrl.jal || id_ex.ctrl.jalr || branch2_ex);
    wire primary_writes=id_ex.ctrl.reg_write && id_ex.ctrl.rd!=0;
    logic branch2_taken;
    wire [31:0] branch2_target=id_ex2.pc+id_ex2.ctrl.imm;
    wire [31:0] branch2_next=branch2_taken ? branch2_target : id_ex2.pc+4;
    // JALR clears sum bit 0. For an even prediction P, the only matching
    // operands are P-imm and (P|1)-imm, modulo 2^32. The target adder still
    // supplies the real redirect PC, but no longer precedes its enable test.
    wire [31:0] jalr_expected0=id_ex.predicted_pc-id_ex.ctrl.imm;
    wire [31:0] jalr_expected1={id_ex.predicted_pc[31:1],1'b1}-id_ex.ctrl.imm;
    wire jalr_prediction_wrong=id_ex.predicted_pc[0] ||
        (branch1_a!=jalr_expected0 && branch1_a!=jalr_expected1);
    // Outside JALR, the target is PC-relative. Do not send the selected JALR
    // address adder back through the non-JALR prediction comparison.
    wire [31:0] pc_relative_target=id_ex.pc+id_ex.ctrl.imm;
    wire primary_prediction_wrong=id_ex.ctrl.jalr ? jalr_prediction_wrong :
        (jump_taken ? id_ex.predicted_pc!=pc_relative_target : id_ex.predicted_pc!=id_ex.pc+4);
    wire early_prediction_wrong=branch2_ex ?
        (branch2_taken ? id_ex2.predicted_pc!=branch2_target : id_ex2.predicted_pc!=id_ex2.pc+4) :
        primary_prediction_wrong;
    always_comb begin
        case(ex_mem2.funct3)
            0: late_branch_taken=late_branch_a==late_branch_b;
            1: late_branch_taken=late_branch_a!=late_branch_b;
            4: late_branch_taken=$signed(late_branch_a)<$signed(late_branch_b);
            5: late_branch_taken=$signed(late_branch_a)>=$signed(late_branch_b);
            6: late_branch_taken=late_branch_a<late_branch_b;
            7: late_branch_taken=late_branch_a>=late_branch_b;
            default: late_branch_taken=0;
        endcase
    end
    always_comb begin
        case(id_ex2.ctrl.funct3)
            0: branch2_taken=branch2_a==branch2_b;
            1: branch2_taken=branch2_a!=branch2_b;
            4: branch2_taken=$signed(branch2_a)<$signed(branch2_b);
            5: branch2_taken=$signed(branch2_a)>=$signed(branch2_b);
            6: branch2_taken=branch2_a<branch2_b;
            7: branch2_taken=branch2_a>=branch2_b;
            default: branch2_taken=0;
        endcase
    end
    // High-half multiplication has a longer result tree. Let its dependent
    // consumer use registered WB data instead of chaining that tree into EX.
    wire late_multiply=ENABLE_M && PIPELINED_MUL && ex_mem.multiply && |ex_mem.insn[13:12];

    // Pair along the predicted path, including a taken branch/jump target.
    // A wrong prediction cancels the companion before any architectural effect.
    assign pair_issue = DUAL_ISSUE && if_id.valid && if_id2.valid &&
        if_id2.pc == ((decoded.branch || decoded.jal || decoded.jalr) ? if_id.predicted_pc : if_id.pc+4) &&
        !if_id.fetch_error && !if_id2.fetch_error &&
        (decoded2.branch || if_id2.predicted_pc == if_id2.pc+4) &&
        !decoded.trap &&
        !decoded.csr && !decoded.mret && if_id.insn[6:0] != 7'h0f &&
        (!decoded.muldiv || (PIPELINED_MUL && !decoded.funct3[2])) &&
        !decoded2.trap && !decoded2.load && !decoded2.store && !decoded2.muldiv &&
        // The aligned branch cannot fault. Loads and RAW ALU dependencies
        // resolve in MEM; an independent integer/branch pair resolves in EX.
        (!decoded2.branch || (!decoded.branch && !decoded.jal && !decoded.jalr && !decoded.load && !decoded.store && !decoded.muldiv &&
                             decoded2.imm[1:0]==0)) &&
        !decoded2.jal && !decoded2.jalr && !decoded2.csr &&
        !decoded2.mret && if_id2.insn[6:0] != 7'h0f &&
        // Expensive bit counts/min-max remain fully supported by lane 0.
        // A compact integer companion avoids duplicating these long datapaths.
        !(decoded2.alu_op==ALU_CLZ || decoded2.alu_op==ALU_CTZ || decoded2.alu_op==ALU_CPOP ||
          decoded2.alu_op==ALU_MIN || decoded2.alu_op==ALU_MINU ||
          decoded2.alu_op==ALU_MAX || decoded2.alu_op==ALU_MAXU) &&
        !(decoded.reg_write && decoded.rd != 0 && decoded2.reg_write && decoded2.rd == decoded.rd) &&
        // Do not chain either multiplier result through the companion ALU.
        !(decoded.muldiv && decoded.rd!=0 &&
          ((decoded2.use_rs1 && decoded2.rs1==decoded.rd) ||
           (decoded2.use_rs2 && decoded2.rs2==decoded.rd))) &&
        !(LOAD_USE_INTERLOCK && id_ex.valid && id_ex.ctrl.load && id_ex.ctrl.rd != 0 &&
          ((decoded2.use_rs1 && decoded2.rs1 == id_ex.ctrl.rd) ||
           (decoded2.use_rs2 && decoded2.rs2 == id_ex.ctrl.rd)));
    assign issue_fire = if_id.valid && ex_ready && !load_use && !system_inflight &&
                        !redirect && !fault_event && !control_redirect && !halted && !stop_fetch;
    assign fetch_second = DUAL_ISSUE && imem_second_valid && !imem_error &&
                          predicted_fetch_pc == imem_addr+4;

    lyncore_decode #(.ENABLE_M(ENABLE_M),.ENABLE_ZBA(ENABLE_ZBA),.ENABLE_ZBB(ENABLE_ZBB)) decoder(.insn(if_id.insn), .ctrl(decoded));
    lyncore_decode #(.ENABLE_M(ENABLE_M),.ENABLE_ZBA(ENABLE_ZBA),.ENABLE_ZBB(ENABLE_ZBB)) decoder2(.insn(if_id2.insn), .ctrl(decoded2));
    lyncore_regfile #(.DUAL_ISSUE(DUAL_ISSUE)) rf(
        .clk(clk), .rst(rst), .write_en(writeback), .write_addr(mem_wb.rd),
        .write_data(mem_wb.result), .rs1(decoded.rs1), .rs2(decoded.rs2),
        .rs1_data(rs1_data), .rs2_data(rs2_data),
        .write2_en(writeback2),.write2_addr(mem_wb2.rd),.write2_data(mem_wb2.result),
        .rs3(decoded2.rs1),.rs4(decoded2.rs2),.rs3_data(rs3_data),.rs4_data(rs4_data)
    );
    lyncore_alu alu(.op(id_ex.ctrl.alu_op), .a(alu_a), .b(alu_b), .result(alu_result));
    lyncore_alu #(.COMPACT(1)) alu2(.op(id_ex2.ctrl.alu_op),
        .a(id_ex2.ctrl.a_zero ? 32'b0 : (id_ex2.ctrl.a_pc ? id_ex2.pc : ex2_rs1)),
        .b(id_ex2.ctrl.b_imm ? id_ex2.ctrl.imm : ex2_rs2),.result(alu2_result));
    // Only dependent companions use this later ALU. Its inputs are registered
    // EX operands or the completed older instruction in MEM. A consumer waits
    // for WB instead of chaining this result through the next EX ALU.
    lyncore_alu #(.COMPACT(1)) late_alu(.op(late_pair_op),
        .a(late_pair_rs1 ? late_pair_primary : late_pair_a),
        .b(late_pair_rs2 ? late_pair_primary : late_pair_b),.result(late_pair_result));
    lyncore_csr #(.ENABLE_M(ENABLE_M),.DUAL_ISSUE(DUAL_ISSUE)) csrs(
        .clk(clk), .rst(rst), .read_addr(id_ex.ctrl.csr_addr),
        .read_data(csr_data), .read_legal(csr_legal), .read_only(csr_read_only),
        .write_en(retire_valid && !retire_trap && mem_wb.csr_write),
        .write_addr(mem_wb.csr_addr), .write_data(mem_wb.csr_value),
        .retire_en(retire_valid && !retire_trap),
        .retire2_en(retire2_valid),
        .trap_enter(trap_commit || irq_taken), .trap_return(return_commit),
        .trap_pc(irq_taken ? architectural_pc : mem_wb.pc),
        .trap_cause(entry_cause), .trap_value(irq_taken ? 0 : mem_wb.tval),
        .irq_software(irq_software), .irq_timer(irq_timer), .irq_external(irq_external),
        .irq_pending(irq_pending), .irq_cause(irq_cause),
        .trap_vector(trap_vector), .return_pc(return_pc),
        .cycle_count(cycle_count), .instret_count(instret_count)
    );
    generate if (ENABLE_M) begin : multiply_divide
        lyncore_muldiv #(.ENABLE_MULTIPLY(!PIPELINED_MUL)) unit(.clk(clk), .rst(rst),
            // A younger iterative operation cannot start before the older
            // blocking load completes; md_start already excludes late_redirect.
            .cancel(halted || stop_fetch || fault_event || control_redirect),
            .start(md_start), .accept(ex_ready && id_ex.valid && id_ex.ctrl.muldiv),
            .op(id_ex.ctrl.funct3), .a(ex_rs1), .b(ex_rs2),
            .busy(md_busy), .done(md_done), .result(md_result));
    end else begin : no_multiply_divide
        assign md_busy = 0;
        assign md_done = 0;
        assign md_result = 0;
    end endgenerate
    generate if (ENABLE_M && PIPELINED_MUL) begin : pipeline_multiply
        lyncore_multiplier unit(.clk(clk),.rst(rst),
            .enable(id_ex.valid && id_ex.ctrl.muldiv && !id_ex.ctrl.funct3[2] &&
                    ex_ready && !halted && !stop_fetch && !fault_event && !control_redirect && !late_redirect),
            .op(id_ex.ctrl.funct3[1:0]),.a(ex_rs1),.b(ex_rs2),.result(multiply_result),.low_result(multiply_low_result));
    end else begin : no_pipeline_multiply
        assign multiply_result=0;
        assign multiply_low_result=0;
    end endgenerate
    // Start only after older memory completes, so a forwarded load is valid.
    assign md_start = ENABLE_M && id_ex.valid && id_ex.ctrl.muldiv &&
                      (!PIPELINED_MUL || id_ex.ctrl.funct3[2]) && mem_ready &&
                      !md_busy && !md_done && !halted && !stop_fetch && !mem_fault && !mem_load_use && !control_redirect && !late_redirect;
    assign md_wait = id_ex.valid && id_ex.ctrl.muldiv &&
                     (!PIPELINED_MUL || id_ex.ctrl.funct3[2]) && !md_done;
    assign resolved_pc = late_redirect ? late_branch_next : early_resolved_pc;
    assign predictor_update = late_branch_update || early_update;
    generate if(ENABLE_BP) begin : prediction
        lyncore_branch_predictor #(.INDEX_BITS(BP_INDEX_BITS),.ENABLE_RAS(ENABLE_RAS),.LOCAL_HISTORY_BITS(BP_HISTORY_BITS),.HASH_INDEX(BP_HASH_INDEX),.SECOND_LOOKUP(DUAL_ISSUE)) predictor(.clk(clk),.rst(rst),.invalidate(predictor_flush),
            .fetch_pc(imem_addr),.predicted_pc(predicted_fetch_pc),.update(predictor_update),
            .predicted_second_pc(predicted_second_pc),
            .conditional_branch(late_branch_update || id_ex.ctrl.branch || branch2_ex),
            .taken(late_branch_update ? late_branch_taken : (branch2_ex ? branch2_taken : jump_taken)),
            .update_pc(late_branch_update ? ex_mem2.pc : (branch2_ex ? id_ex2.pc : id_ex.pc)),
            .target(late_branch_update ? ex_mem2.next_pc : (branch2_ex ? branch2_target : ex_target)),
            .update_call(!late_branch_update && !branch2_ex && (id_ex.ctrl.jal || id_ex.ctrl.jalr) && (id_ex.ctrl.rd==1 || id_ex.ctrl.rd==5)),
            .update_return(!late_branch_update && !branch2_ex && id_ex.ctrl.jalr && (id_ex.ctrl.rs1==1 || id_ex.ctrl.rs1==5) &&
                           (!(id_ex.ctrl.rd==1 || id_ex.ctrl.rd==5) || id_ex.ctrl.rd!=id_ex.ctrl.rs1)));
    end else begin : no_prediction
        assign predicted_fetch_pc=imem_addr+4;
        assign predicted_second_pc=imem_addr+8;
    end endgenerate
    // System operations are uncommon: drain older instructions before reading
    // CSR state, and hold younger instructions until the WB update is complete.
    assign system_wait = id_ex.valid && (id_ex.ctrl.csr || id_ex.ctrl.mret) &&
                         (ex_mem.valid || mem_wb.valid);
    assign system_inflight = (id_ex.valid && (id_ex.ctrl.csr || id_ex.ctrl.mret)) ||
                             (ex_mem.valid && (ex_mem.csr_write || ex_mem.mret || ex_mem.insn[6:0] == 7'h73)) ||
                             (mem_wb.valid && (mem_wb.csr_write || mem_wb.mret || mem_wb.insn[6:0] == 7'h73));
    assign trap_commit = retire_valid && retire_trap && !HALT_ON_TRAP;
    assign return_commit = retire_valid && !retire_trap && mem_wb.mret;
    assign irq_taken = !HALT_ON_TRAP && !rst && !halted && !stop_fetch && irq_pending &&
                       !if_id.valid && !id_ex.valid && !ex_mem.valid && !mem_wb.valid;
    assign irq_pc = architectural_pc;
    assign entry_cause = irq_taken ? irq_cause : mem_wb.cause;
    assign control_redirect = trap_commit || return_commit || irq_taken;
    assign control_target = return_commit ? return_pc : trap_vector;

    assign writeback = mem_wb.valid && mem_wb.reg_write && !mem_wb.trap && !halted;
    assign writeback2 = retire2_valid && mem_wb2.reg_write;
    assign mem_ready = !mem_access || dmem_ready;
    assign mem_fault = dmem_valid && dmem_ready && dmem_error;
    wire late_pair_use=id_ex.valid && ex_mem2.valid && late_pair_mem && ex_mem2.reg_write && ex_mem2.rd!=0 &&
        ((id_ex.ctrl.use_rs1 && id_ex.ctrl.rs1==ex_mem2.rd) ||
         (id_ex.ctrl.use_rs2 && id_ex.ctrl.rs2==ex_mem2.rd) ||
         (id_ex2.valid && ((id_ex2.ctrl.use_rs1 && id_ex2.ctrl.rs1==ex_mem2.rd) ||
                          (id_ex2.ctrl.use_rs2 && id_ex2.ctrl.rs2==ex_mem2.rd))));
    // Keep ordinary MUL-to-ALU bypassing, but branch/JALR consumers wait for WB
    // so the partial-product carry tree cannot feed a same-cycle redirect.
    wire multiply_branch_use=id_ex.valid && ex_mem.valid && ex_mem.multiply &&
        !ex_mem.trap && ex_mem.reg_write && ex_mem.rd!=0 &&
        (((id_ex.ctrl.branch || id_ex.ctrl.jalr) &&
          ((id_ex.ctrl.use_rs1 && id_ex.ctrl.rs1==ex_mem.rd) ||
           (id_ex.ctrl.use_rs2 && id_ex.ctrl.rs2==ex_mem.rd))) ||
         (id_ex2.valid && id_ex2.ctrl.branch &&
          ((id_ex2.ctrl.use_rs1 && id_ex2.ctrl.rs1==ex_mem.rd) ||
           (id_ex2.ctrl.use_rs2 && id_ex2.ctrl.rs2==ex_mem.rd))));
    wire load_branch_use=id_ex.valid && ex_mem.valid && ex_mem.load &&
        !ex_mem.trap && ex_mem.reg_write && ex_mem.rd!=0 &&
        (((id_ex.ctrl.branch || id_ex.ctrl.jalr) &&
          ((id_ex.ctrl.use_rs1 && id_ex.ctrl.rs1==ex_mem.rd) ||
           (id_ex.ctrl.use_rs2 && id_ex.ctrl.rs2==ex_mem.rd))) ||
         (id_ex2.valid && id_ex2.ctrl.branch &&
          ((id_ex2.ctrl.use_rs1 && id_ex2.ctrl.rs1==ex_mem.rd) ||
           (id_ex2.ctrl.use_rs2 && id_ex2.ctrl.rs2==ex_mem.rd))));
    assign mem_load_use = branch_port_wait || late_pair_use || multiply_branch_use || load_branch_use || (id_ex.valid && ex_mem.valid &&
                          ((LOAD_USE_INTERLOCK && ex_mem.load) || late_multiply) &&
                          !ex_mem.trap && ex_mem.rd != 0 &&
                          ((id_ex.ctrl.use_rs1 && id_ex.ctrl.rs1 == ex_mem.rd) ||
                           (id_ex.ctrl.use_rs2 && id_ex.ctrl.rs2 == ex_mem.rd) ||
                           (DUAL_ISSUE && id_ex2.valid &&
                            ((id_ex2.ctrl.use_rs1 && id_ex2.ctrl.rs1 == ex_mem.rd) ||
                             (id_ex2.ctrl.use_rs2 && id_ex2.ctrl.rs2 == ex_mem.rd)))));
    assign ex_ready = !id_ex.valid || (mem_ready && !system_wait && !md_wait && !mem_load_use);
    // With the interlock disabled, dependent EX waits for blocking MEM, then
    // takes the existing MEM-to-EX forwarding path on the completion edge.
    assign load_use = LOAD_USE_INTERLOCK && if_id.valid && id_ex.valid && id_ex.ctrl.load &&
                      id_ex.ctrl.rd != 0 &&
                      ((decoded.use_rs1 && decoded.rs1 == id_ex.ctrl.rd) ||
                       (decoded.use_rs2 && decoded.rs2 == id_ex.ctrl.rd));
    assign fetch_ready = !if_id.valid || (ex_ready && !load_use && !system_inflight);

    // Decode mutually exclusive sources before the late load data arrives.
    // MEM2 wins over MEM, then WB2, WB, and the saved operand; x0 stays zero.
    // Waiting/faulting MEM may change operands, but existing advance/flush
    // guards still block all younger architectural effects.
    function automatic logic [31:0] forward_operand(input logic [4:0] source,input logic [31:0] saved,input bit allow_multiply,input bit allow_load);
        logic take_pair,take_load,take_mem,take_wb2,take_wb,take_saved;
        take_pair=source!=0 && DUAL_ISSUE && ex_mem2.valid && !late_pair_mem && ex_mem2.reg_write &&
            ex_mem2.rd!=0 && source==ex_mem2.rd;
        take_load=allow_load && source!=0 && !take_pair && !LOAD_USE_INTERLOCK && ex_mem.valid &&
            ex_mem.reg_write && !ex_mem.trap && ex_mem.rd!=0 && ex_mem.load && source==ex_mem.rd;
        take_mem=source!=0 && !take_pair && ex_mem.valid && ex_mem.reg_write &&
            !ex_mem.trap && ex_mem.rd!=0 && !ex_mem.load && !late_multiply &&
            (allow_multiply || !ex_mem.multiply) && source==ex_mem.rd;
        take_wb2=source!=0 && !take_pair && !take_load && !take_mem && writeback2 &&
            mem_wb2.rd!=0 && source==mem_wb2.rd;
        take_wb=source!=0 && !take_pair && !take_load && !take_mem && !take_wb2 &&
            writeback && mem_wb.rd!=0 && source==mem_wb.rd;
        take_saved=source!=0 && !(take_pair || take_load || take_mem || take_wb2 || take_wb);
        forward_operand=({32{take_pair}} & ex_mem2.result) |
               ({32{take_load}} & load_value) |
               ({32{take_mem}} & (allow_multiply && ex_mem.multiply ? multiply_low_result : ex_mem.result)) |
               ({32{take_wb2}} & mem_wb2.result) |
               ({32{take_wb}} & mem_wb.result) |
               ({32{take_saved}} & saved);
    endfunction
    always_comb begin
        ex_rs1=forward_operand(id_ex.ctrl.rs1,id_ex.rs1_value,1,1);
        ex_rs2=forward_operand(id_ex.ctrl.rs2,id_ex.rs2_value,1,1);
        ex2_rs1=forward_operand(id_ex2.ctrl.rs1,id_ex2.rs1_value,1,1);
        ex2_rs2=forward_operand(id_ex2.ctrl.rs2,id_ex2.rs2_value,1,1);
        // Control-flow consumers wait for registered WB load/multiply data.
        branch1_a=forward_operand(id_ex.ctrl.rs1,id_ex.rs1_value,0,0);
        branch1_b=forward_operand(id_ex.ctrl.rs2,id_ex.rs2_value,0,0);
        branch2_a=forward_operand(id_ex2.ctrl.rs1,id_ex2.rs1_value,0,0);
        branch2_b=forward_operand(id_ex2.ctrl.rs2,id_ex2.rs2_value,0,0);
        alu_a = id_ex.ctrl.a_zero ? 0 : (id_ex.ctrl.a_pc ? id_ex.pc : ex_rs1);
        alu_b = id_ex.ctrl.b_imm ? id_ex.ctrl.imm : ex_rs2;
    end

    always_comb begin
        branch_taken = 0;
        case (id_ex.ctrl.funct3)
            0: branch_taken = (branch1_a == branch1_b);
            1: branch_taken = (branch1_a != branch1_b);
            4: branch_taken = ($signed(branch1_a) < $signed(branch1_b));
            5: branch_taken = ($signed(branch1_a) >= $signed(branch1_b));
            6: branch_taken = (branch1_a < branch1_b);
            7: branch_taken = (branch1_a >= branch1_b);
            default: branch_taken = 0;
        endcase
        jump_taken = id_ex.ctrl.jal || id_ex.ctrl.jalr ||
                     (id_ex.ctrl.branch && branch_taken);
        ex_target = id_ex.ctrl.jalr ? ((branch1_a + id_ex.ctrl.imm) & 32'hfffffffe) :
                                     (id_ex.pc + id_ex.ctrl.imm);
        ex_result = (id_ex.ctrl.jal || id_ex.ctrl.jalr) ? id_ex.pc + 4 : alu_result;
        if (id_ex.ctrl.load || id_ex.ctrl.store) ex_result = ex_address;
        csr_operand = id_ex.ctrl.funct3[2] ? {27'b0, id_ex.ctrl.rs1} : ex_rs1;
        csr_write_intent = id_ex.ctrl.csr &&
                           (id_ex.ctrl.funct3[1:0] == 1 || id_ex.ctrl.rs1 != 0);
        case (id_ex.ctrl.funct3[1:0])
            1: csr_value = csr_operand;
            2: csr_value = csr_data | csr_operand;
            3: csr_value = csr_data & ~csr_operand;
            default: csr_value = csr_data;
        endcase
        if (id_ex.ctrl.csr) ex_result = csr_data;
        if (id_ex.ctrl.muldiv) ex_result = md_result;
        ex_fault = id_ex.ctrl.trap;
        ex_cause = id_ex.ctrl.cause;
        ex_tval = id_ex.ctrl.tval;
        if (!ex_fault && id_ex.ctrl.csr &&
            (!csr_legal || (csr_read_only && csr_write_intent))) begin
            ex_fault = 1;
            ex_cause = 2;
            ex_tval = id_ex.insn;
        end
        if (!ex_fault && jump_taken && ex_target[1:0] != 0) begin
            ex_fault = 1;
            ex_cause = 0;
            ex_tval = ex_target;
        end
        if (!ex_fault && (id_ex.ctrl.load || id_ex.ctrl.store) &&
            ((id_ex.ctrl.funct3[1:0] == 1 && ex_address[0]) ||
             (id_ex.ctrl.funct3[1:0] == 2 && ex_address[1:0] != 0))) begin
            ex_fault = 1;
            ex_cause = id_ex.ctrl.store ? 6 : 4;
            ex_tval = ex_address;
        end
    end
    assign redirect = late_redirect || (id_ex.valid && ex_ready && !mem_fault && !ex_fault &&
                      (ENABLE_BP ? early_prediction_wrong :
                       (jump_taken || (branch2_ex && branch2_taken))));
    assign fault_event = mem_fault || (!late_redirect && id_ex.valid && mem_ready && !system_wait && !mem_load_use && ex_fault);

    always_comb begin
        case (ex_mem.funct3[1:0])
            0: mem_mask = 4'b0001 << ex_mem.result[1:0];
            1: mem_mask = 4'b0011 << ex_mem.result[1:0];
            2: mem_mask = 4'b1111;
            default: mem_mask = 0;
        endcase
        load_shifted = dmem_rdata >> (8 * ex_mem.result[1:0]);
        case (ex_mem.funct3)
            0: load_value = {{24{load_shifted[7]}}, load_shifted[7:0]};
            1: load_value = {{16{load_shifted[15]}}, load_shifted[15:0]};
            2: load_value = load_shifted;
            4: load_value = {24'b0, load_shifted[7:0]};
            5: load_value = {16'b0, load_shifted[15:0]};
            default: load_value = 0;
        endcase
        mem_result = ex_mem.result;
        if (ex_mem.multiply) mem_result=multiply_result;
        if (ex_mem.load) mem_result=load_value;
    end
    assign dmem_valid = !rst && !halted && mem_access;
    assign dmem_write = ex_mem.store;
    assign dmem_addr = ex_mem.result;
    // Only loads/stores will consume this read. Do not route unrelated Zbb,
    // CSR or multiply result trees through the cache RAM address inputs.
    assign dmem_preview_stall = !mem_ready;
    assign dmem_preview_addr = rst ? 32'b0 :
        ((id_ex.ctrl.load || id_ex.ctrl.store) ? ex_address : 32'b0);
    assign dmem_wdata = ex_mem.store_value << (8 * ex_mem.result[1:0]);
    assign dmem_wstrb = ex_mem.store ? mem_mask : 0;

    // If a jump/exception arrives while fetch is waiting, drain the old read
    // without changing its address; discard its result, then fetch the target.
    assign imem_addr = request_active ? request_pc : fetch_pc;
    assign instruction_done = imem_valid && imem_ready;
    generate if (DUAL_ISSUE) begin : dual_fetch
        if_id_t entries[0:7];
        logic [2:0] read_pointer,write_pointer;
        logic [3:0] count;
        wire [2:0] read_next=read_pointer+3'd1,write_next=write_pointer+3'd1;
        wire flush=redirect || fault_event || control_redirect || halted || stop_fetch;
        wire response_data=instruction_done && !request_killed && !irq_pending;
        wire response=response_data && !flush;
        wire [3:0] push_count=response ? (fetch_second ? 4'd2 : 4'd1) : 4'd0;
        wire [3:0] pop_count=issue_fire ? (pair_issue ? 4'd2 : 4'd1) : 4'd0;
        assign if_id=count!=0 ? entries[read_pointer] : '0;
        assign if_id2=count>1 ? entries[read_next] : '0;
        assign fetch_available=count!=0;
        assign fetch_head=if_id;
        // Reserve two slots BEFORE launching, independent of EX ready paths.
        assign imem_valid=!rst && (request_active ||
            (!halted && !stop_fetch && !irq_pending && count<=4'd6));
        always_ff @(posedge clk) begin
            if (rst || flush) begin
                read_pointer<=0; write_pointer<=0; count<=0;
            end else begin
                count<=count+push_count-pop_count;
                write_pointer<=write_pointer+push_count[2:0];
                read_pointer<=read_pointer+pop_count[2:0];
            end
        end
        // Flush resets occupancy/pointers, so data written on that edge stays
        // unreachable. Keep the late EX flush off the wide payload write enable.
        always_ff @(posedge clk) begin
            if (!rst && response_data) begin
                entries[write_pointer]<='{valid:1'b1,pc:imem_addr,insn:imem_rdata,
                    predicted_pc:predicted_fetch_pc,fetch_error:imem_error};
                if (fetch_second)
                    entries[write_next]<='{valid:1'b1,pc:imem_addr+4,
                        insn:imem_second_data,predicted_pc:predicted_second_pc,fetch_error:1'b0};
            end
        end
    end else if (DECOUPLED_FETCH) begin : fetch_queue
        // Two registered entries reserve space before starting a blocking read.
        // No EX/MEM decision or consumer-ready bypass is in the request path.
        if_id_t entries[0:1];
        logic read_pointer,write_pointer;
        logic [1:0] count;
        wire flush=redirect || fault_event || control_redirect || halted || stop_fetch;
        wire queued=count!=2'd0;
        wire response=instruction_done && !request_killed && !irq_pending && !flush;
        wire consume=fetch_ready && fetch_available && !irq_pending && !flush;
        wire push=response && !(consume && !queued);
        wire pop=consume && queued;
        // Empty-queue bypass avoids another bubble after every corrected branch.
        // Requests still use only registered occupancy, never consumer readiness.
        assign fetch_available=queued || response;
        assign fetch_head=queued ? entries[read_pointer] :
                          '{valid:response,pc:imem_addr,insn:imem_rdata,
                            predicted_pc:predicted_fetch_pc,fetch_error:imem_error};
        assign imem_valid=!rst && (request_active ||
                          (!halted && !stop_fetch && !irq_pending && count<2'd2));
        always_ff @(posedge clk) begin
            if (rst || flush) begin
                read_pointer<=0;
                write_pointer<=0;
                count<=0;
            end else begin
                case ({push,pop})
                    2'b10: count<=count+1'b1;
                    2'b01: count<=count-1'b1;
                    default: ;
                endcase
                if (push) begin
                    entries[write_pointer].valid<=1;
                    entries[write_pointer].pc<=imem_addr;
                    entries[write_pointer].insn<=imem_rdata;
                    entries[write_pointer].predicted_pc<=predicted_fetch_pc;
                    entries[write_pointer].fetch_error<=imem_error;
                    write_pointer<=!write_pointer;
                end
                if (pop) read_pointer<=!read_pointer;
            end
        end
    end else begin : coupled_fetch
        assign imem_valid = !rst && (request_active ||
                            (!halted && !stop_fetch && !irq_pending && fetch_ready &&
                             !redirect && !fault_event && !control_redirect));
        assign fetch_available=instruction_done && !request_killed;
        assign fetch_head='{valid:fetch_available,pc:imem_addr,insn:imem_rdata,
                            predicted_pc:predicted_fetch_pc,fetch_error:imem_error};
    end endgenerate

    // The integer companion moves with its older lane, never past a blocking
    // load/store. A lane-0 fault cancels it before architectural writeback.
    always_ff @(posedge clk) begin
        if (rst || !DUAL_ISSUE) begin
            id_ex2<='0; ex_mem2<='0; mem_wb2<='0;
            late_pair_mem<=0; late_pair_rs1<=0; late_pair_rs2<=0;
            late_pair_a<=0; late_pair_b<=0; late_pair_op<=ALU_ADD;
            late_branch_mem<=0; late_branch_predicted<=0;
        end else begin
            if (fault_event || late_redirect || halted || stop_fetch || control_redirect) id_ex2.valid<=0;
            else if (ex_ready) begin
                id_ex2.valid<=issue_fire && pair_issue;
                id_ex2.pc<=if_id2.pc; id_ex2.insn<=if_id2.insn;
                id_ex2.predicted_pc<=if_id2.predicted_pc;
                id_ex2.ctrl<=decoded2;
                id_ex2.rs1_value<=rs3_data; id_ex2.rs2_value<=rs4_data;
            end else begin
                id_ex2.rs1_value<=ex2_rs1; id_ex2.rs2_value<=ex2_rs2;
            end
            if (halted || mem_fault || control_redirect) ex_mem2.valid<=0;
            else if (mem_ready) begin
                ex_mem2.valid<=id_ex2.valid && ex_ready && !ex_fault && !stop_fetch && !late_redirect &&
                    !((id_ex.ctrl.branch || id_ex.ctrl.jal || id_ex.ctrl.jalr) &&
                      (jump_taken ? ex_target : id_ex.pc+4) != id_ex2.pc);
                ex_mem2.pc<=id_ex2.pc; ex_mem2.insn<=id_ex2.insn;
                ex_mem2.rd<=id_ex2.ctrl.rd; ex_mem2.reg_write<=id_ex2.ctrl.reg_write;
                ex_mem2.result<=alu2_result;
                ex_mem2.next_pc<=late_branch_ex ? branch2_target : (branch2_ex ? branch2_next : id_ex2.pc+4);
                ex_mem2.funct3<=id_ex2.ctrl.funct3;
                late_branch_mem<=late_branch_ex;
                late_branch_predicted<=id_ex2.predicted_pc;
                late_pair_mem<=pair_raw_ex && !id_ex2.ctrl.branch;
                late_pair_rs1<=primary_writes && id_ex2.ctrl.use_rs1 && id_ex2.ctrl.rs1==id_ex.ctrl.rd;
                late_pair_rs2<=primary_writes && id_ex2.ctrl.use_rs2 && id_ex2.ctrl.rs2==id_ex.ctrl.rd;
                late_pair_a<=id_ex2.ctrl.a_zero ? 32'b0 : (id_ex2.ctrl.a_pc ? id_ex2.pc : ex2_rs1);
                late_pair_b<=id_ex2.ctrl.b_imm ? id_ex2.ctrl.imm : ex2_rs2;
                late_pair_op<=id_ex2.ctrl.alu_op;
            end
            mem_wb2.valid<=ex_mem2.valid && mem_ready && !mem_fault && !ex_mem.trap &&
                           !halted && !control_redirect;
            if (ex_mem2.valid && mem_ready) begin
                mem_wb2.pc<=ex_mem2.pc; mem_wb2.insn<=ex_mem2.insn;
                mem_wb2.next_pc<=late_branch_mem ? late_branch_next : ex_mem2.next_pc;
                mem_wb2.rd<=ex_mem2.rd; mem_wb2.reg_write<=ex_mem2.reg_write;
                mem_wb2.result<=late_pair_mem ? late_pair_result : ex_mem2.result;
            end
        end
    end

    always_ff @(posedge clk) begin
        if (rst) begin
            id_ex <= '0;
            ex_mem <= '0;
            mem_access <= 0;
            mem_wb <= '0;
            fetch_pc <= RESET_PC;
            architectural_pc <= RESET_PC;
            request_pc <= RESET_PC;
            request_active <= 0;
            request_killed <= 0;
            stop_fetch <= 0;
            halted <= 0;
            halt_pc <= 0;
            halt_cause <= 0;
            halt_tval <= 0;
            load_stall_count <= 0;
            mem_stall_count <= 0;
            redirect_count <= 0;
            branch_count <= 0;
            mispredict_count <= 0;
            redirect_stat_q<=0;predictor_stat_q<=0;
        end else begin
            if (retire_valid && !retire_trap)
                architectural_pc <= retire2_valid ? retire2_next_pc : retire_next_pc;
            if (!halted && load_use && ex_ready && !fault_event && !redirect)
                load_stall_count <= load_stall_count + 1;
            if (dmem_valid && !dmem_ready) mem_stall_count <= mem_stall_count + 1;
            // Observe statistics one cycle after the execution event; branch
            // resolution and predictor updates retain their original timing.
            redirect_stat_q<=redirect;predictor_stat_q<=predictor_update;
            if (redirect_stat_q) redirect_count <= redirect_count + 1;
            if(ENABLE_BP && predictor_stat_q) branch_count<=branch_count+1;
            if(ENABLE_BP && redirect_stat_q) mispredict_count<=mispredict_count+1;
            if (mem_wb.valid && mem_wb.trap && !halted && HALT_ON_TRAP) begin
                halted <= 1;
                halt_pc <= mem_wb.pc;
                halt_cause <= mem_wb.cause;
                halt_tval <= mem_wb.tval;
            end
            if (fault_event) stop_fetch <= 1;

            if (imem_valid && !imem_ready && !request_active) begin
                request_active <= 1;
                request_pc <= imem_addr;
                request_killed <= 0;
            end
            if (instruction_done) begin
                request_active <= 0;
                request_killed <= 0;
                if (!request_killed && !stop_fetch && !halted && !irq_pending)
                    fetch_pc <= fetch_second ? predicted_second_pc : predicted_fetch_pc;
            end
            if (redirect) fetch_pc <= resolved_pc;
            if ((redirect || fault_event) &&
                (request_active || ((DECOUPLED_FETCH || DUAL_ISSUE) && imem_valid)) && !instruction_done)
                request_killed <= 1;

            if (fault_event || late_redirect || halted || stop_fetch) begin
                id_ex.valid <= 0;
            end else if (ex_ready) begin
                id_ex.valid <= if_id.valid && !load_use && !redirect && !system_inflight;
                id_ex.pc <= if_id.pc;
                id_ex.insn <= if_id.insn;
                id_ex.predicted_pc <= if_id.predicted_pc;
                id_ex.rs1_value <= rs1_data;
                id_ex.rs2_value <= rs2_data;
                id_ex.ctrl <= decoded;
                if (if_id.fetch_error) begin
                    id_ex.ctrl <= '0;
                    id_ex.ctrl.trap <= 1;
                    id_ex.ctrl.cause <= 1;
                    id_ex.ctrl.tval <= if_id.pc;
                end
            end else begin
                id_ex.rs1_value <= ex_rs1;
                id_ex.rs2_value <= ex_rs2;
            end

            // A MEM access fault is older than the EX instruction and cancels it.
            if (halted || mem_fault) begin
                ex_mem.valid <= 0;
                mem_access <= 0;
            end else if (mem_ready) begin
                ex_mem.valid <= id_ex.valid && !stop_fetch && !system_wait && !md_wait && !mem_load_use && !late_redirect;
                mem_access <= id_ex.valid && !stop_fetch && !system_wait && !md_wait && !mem_load_use && !late_redirect &&
                              !ex_fault && (id_ex.ctrl.load || id_ex.ctrl.store);
                ex_mem.pc <= id_ex.pc;
                ex_mem.insn <= id_ex.insn;
                ex_mem.next_pc <= id_ex.ctrl.mret ? return_pc : (jump_taken ? ex_target : id_ex.pc + 4);
                ex_mem.result <= ex_result;
                ex_mem.store_value <= ex_rs2;
                ex_mem.rd <= id_ex.ctrl.rd;
                ex_mem.reg_write <= id_ex.ctrl.reg_write;
                ex_mem.csr_write <= csr_write_intent;
                ex_mem.csr_addr <= id_ex.ctrl.csr_addr;
                ex_mem.csr_value <= csr_value;
                ex_mem.mret <= id_ex.ctrl.mret;
                ex_mem.load <= id_ex.ctrl.load;
                ex_mem.store <= id_ex.ctrl.store;
                ex_mem.multiply <= ENABLE_M && PIPELINED_MUL && id_ex.ctrl.muldiv && !id_ex.ctrl.funct3[2];
                ex_mem.funct3 <= id_ex.ctrl.funct3;
                ex_mem.trap <= ex_fault;
                ex_mem.cause <= ex_cause;
                ex_mem.tval <= ex_tval;
            end

            // WB drains every cycle even while MEM is waiting: no duplicate commit.
            mem_wb.valid <= ex_mem.valid && mem_ready && !halted;
            if (ex_mem.valid && mem_ready) begin
                mem_wb.pc <= ex_mem.pc;
                mem_wb.insn <= ex_mem.insn;
                mem_wb.next_pc <= ex_mem.next_pc;
                mem_wb.rd <= ex_mem.rd;
                mem_wb.reg_write <= ex_mem.reg_write;
                mem_wb.csr_write <= ex_mem.csr_write;
                mem_wb.csr_addr <= ex_mem.csr_addr;
                mem_wb.csr_value <= ex_mem.csr_value;
                mem_wb.mret <= ex_mem.mret;
                mem_wb.result <= mem_result;
                mem_wb.trap <= ex_mem.trap || mem_fault;
                mem_wb.cause <= mem_fault ? (ex_mem.store ? 7 : 5) : ex_mem.cause;
                mem_wb.tval <= mem_fault ? ex_mem.result : ex_mem.tval;
                mem_wb.mem_addr <= (ex_mem.load || ex_mem.store) ? ex_mem.result : 0;
                mem_wb.mem_rdata <= ex_mem.load ? dmem_rdata : 0;
                mem_wb.mem_wdata <= ex_mem.store ? dmem_wdata : 0;
                mem_wb.mem_rmask <= (ex_mem.load && !ex_mem.trap && !mem_fault) ? mem_mask : 0;
                mem_wb.mem_wmask <= (ex_mem.store && !ex_mem.trap && !mem_fault) ? mem_mask : 0;
            end
            // Entry/return is committed at WB; nothing on a discarded path can
            // change CSR state. Outstanding fetches still obey the bus contract.
            if (control_redirect) begin
                fetch_pc <= control_target;
                architectural_pc <= control_target;
                stop_fetch <= 0;
                id_ex.valid <= 0;
                ex_mem.valid <= 0;
                mem_access <= 0;
                mem_wb.valid <= 0;
                if ((request_active || ((DECOUPLED_FETCH || DUAL_ISSUE) && imem_valid)) && !instruction_done) request_killed <= 1;
            end
        end
    end

    generate if (!DUAL_ISSUE) begin : single_decode_register
        assign if_id2='0;
        always_ff @(posedge clk) begin
            if (rst) if_id<='0;
            else if (redirect || fault_event || halted || stop_fetch || control_redirect)
                if_id.valid<=0;
            else if (fetch_ready) begin
                if_id.valid<=fetch_available && !irq_pending;
                if (fetch_available && !irq_pending) if_id<=fetch_head;
            end
        end
    end endgenerate

    assign retire_valid = mem_wb.valid && !halted && !rst;
    assign retire_pc = mem_wb.pc;
    assign retire_insn = mem_wb.insn;
    assign retire_next_pc = mem_wb.next_pc;
    assign retire_trap = mem_wb.trap;
    assign retire_rd = (mem_wb.reg_write && !mem_wb.trap) ? mem_wb.rd : 0;
    assign retire_data = (retire_rd != 0) ? mem_wb.result : 0;
    assign retire_cause = mem_wb.trap ? mem_wb.cause : 0;
    assign retire_tval = mem_wb.trap ? mem_wb.tval : 0;
    assign retire_mem_addr = mem_wb.mem_addr;
    assign retire_mem_rmask = mem_wb.mem_rmask;
    assign retire_mem_wmask = mem_wb.mem_wmask;
    assign retire_mem_rdata = mem_wb.mem_rdata;
    assign retire_mem_wdata = mem_wb.mem_wdata;
    assign retire2_valid = DUAL_ISSUE && retire_valid && !retire_trap && mem_wb2.valid;
    assign retire2_pc=mem_wb2.pc;
    assign retire2_insn=mem_wb2.insn;
    assign retire2_next_pc=mem_wb2.next_pc;
    assign retire2_rd=mem_wb2.reg_write ? mem_wb2.rd : 5'b0;
    assign retire2_data=retire2_rd!=0 ? mem_wb2.result : 32'b0;
endmodule
