`timescale 1ns/1ps
// Source 100K PLL VCO: 27*2*19.25=1039.5 MHz. Change only pixel divide
// from 28 to 14: 74.25 MHz. Config outputs preserve source ratios.
module lyncore_video_camera_clock(input wire clk_27m,reset_n,
 output wire pixel_clk,cfg_clk,camera_cfg_clk,locked);
 GTP_GPLL #(.CLKIN_FREQ(27.0),.STATIC_RATIOI(1),.STATIC_RATIOM(2),
  .STATIC_RATIOF(19.25),.STATIC_RATIO0(14.0),.STATIC_RATIO1(104),
  .STATIC_RATIO2(42),.STATIC_RATIO3(21),.STATIC_RATIO4(21),.STATIC_RATIO5(21),.STATIC_RATIO6(21),
  .STATIC_DUTYF(19),.STATIC_DUTY0(14),.STATIC_DUTY1(104),.STATIC_DUTY2(42),
  .STATIC_DUTY3(21),.STATIC_DUTY4(21),.STATIC_DUTY5(21),.STATIC_DUTY6(21),
  .INTERNAL_FB("CLKOUTF"),.EXTERNAL_FB("DISABLE"),.BANDWIDTH("OPTIMIZED")) pll(
  .CLKIN1(clk_27m),.CLKIN2(1'b0),.CLKIN_SEL(1'b0),.CLKFB(1'b0),
  .CLKOUT0(pixel_clk),.CLKOUT1(cfg_clk),.CLKOUT2(camera_cfg_clk),.LOCK(locked),.RST(!reset_n),.PLL_PWD(1'b0),
  .DPS_CLK(1'b0),.DPS_EN(1'b0),.DPS_DIR(1'b0),
  .CLKOUT0_SYN(1'b0),.CLKOUT1_SYN(1'b0),.CLKOUT2_SYN(1'b0),.CLKOUT3_SYN(1'b0),
  .CLKOUT4_SYN(1'b0),.CLKOUT5_SYN(1'b0),.CLKOUT6_SYN(1'b0),.CLKOUTF_SYN(1'b0),
  .APB_CLK(1'b0),.APB_RST_N(1'b0),.APB_ADDR(5'b0),.APB_SEL(1'b0),
  .APB_EN(1'b0),.APB_WRITE(1'b0),.APB_WDATA(16'b0));
endmodule
