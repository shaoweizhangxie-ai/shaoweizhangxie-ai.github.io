`timescale 1ns/1ps

// 同一套 4×8 PE 轮流执行普通 K1/K3 卷积与官方 RGB K6/S2/P2 首层。
// source_ci_group 是缓存读取组；weight_ci_group 是当前权重 tile 的输入组。
// RGB 模式下前者固定为 0，后者依次为 R/G/B 对应的三个派生通道组。
module conv_task_top #(
    parameter integer MAX_WIDTH = 640,
    parameter integer PSUM_DEPTH = 256,
    parameter integer MAX_CO_GROUPS = 128,
    parameter integer PE_LATENCY = 7
) (
    input wire clk, rst_n,
    input wire layer_start,
    input wire [15:0] frame_width, frame_height, cin_groups, cout_groups,
    input wire kernel_6x6, kernel_1x1, stride_2, padding_1, silu_enable,
    output wire layer_ready, layer_busy, layer_done, layer_error,
    input wire cfg_we,
    output wire cfg_ready,
    input wire [15:0] cfg_co_group,
    input wire [255:0] cfg_bias_bus,
    input wire [247:0] cfg_linear_multiplier_bus,
    input wire [47:0] cfg_linear_shift_bus,
    input wire [247:0] cfg_grid_multiplier_bus,
    input wire [47:0] cfg_grid_shift_bus,
    input wire lut_load_start, lut_load_valid,
    output wire lut_load_ready,
    input wire [7:0] lut_load_data,
    output wire lut_valid,
    output wire weight_request, weight_ready,
    input wire weight_valid,
    input wire [31:0] weight_word,
    output wire ifm_request, ifm_ready,
    input wire ifm_valid,
    input wire [31:0] ifm_pixel,
    output wire [15:0] source_ci_group, weight_ci_group, current_co_group,
    output wire [31:0] current_tile_base,
    output wire raw_valid,
    output wire [15:0] raw_co_group,
    output wire [31:0] raw_index,
    output wire [255:0] raw_data,
    output wire out_valid,
    output wire [15:0] out_co_group,
    output wire [31:0] out_index,
    output wire [63:0] out_data
);
    reg cfg_stem;
    reg [15:0] cfg_width, cfg_height;
    reg shape_error;
    wire core_ready, core_busy, core_done, core_error;
    wire core_ifm_ready, pack_ready, pack_busy, pack_error, pack_valid, pack_input_ready;
    wire [31:0] pack_pixel;
    // 首层的三个原 RGB 通道装在一个四通道缓存组中；模式固定为 K6/S2/P2。
    // padding_1 只描述普通 K1/K3，首层由包装器固定等价 K3/P1。
    wire bad_stem = kernel_6x6 && ((frame_width < 2) || (frame_height < 2) ||
        frame_width[0] || frame_height[0] || frame_width > MAX_WIDTH ||
        cin_groups != 1 || kernel_1x1 || !stride_2);
    assign layer_ready = core_ready && pack_ready;
    assign layer_busy = core_busy || pack_busy;
    assign layer_done = core_done;
    assign layer_error = core_error || pack_error || shape_error;
    assign source_ci_group = cfg_stem ? 16'd0 : weight_ci_group;
    assign ifm_ready = cfg_stem ? pack_input_ready : core_ifm_ready;
    always @(posedge clk or negedge rst_n) begin
        if (!rst_n) begin
            cfg_stem <= 0; cfg_width <= 0; cfg_height <= 0; shape_error <= 0;
        end else begin
            shape_error <= 0;
            if (layer_start && layer_ready && !lut_load_start) begin
                if (bad_stem)
                    shape_error <= 1;
                else begin
                    cfg_stem <= kernel_6x6;
                    cfg_width <= frame_width; cfg_height <= frame_height;
                end
            end
        end
    end
    rgb_phase_pack #(.MAX_WIDTH(MAX_WIDTH)) packer (
        .clk(clk), .rst_n(rst_n), .frame_start(ifm_request && cfg_stem),
        .frame_width(cfg_width), .frame_height(cfg_height), .rgb_channel(weight_ci_group[1:0]),
        .frame_ready(pack_ready), .busy(pack_busy), .frame_done(), .frame_error(pack_error),
        .in_valid(ifm_valid && cfg_stem), .in_ready(pack_input_ready), .in_pixel(ifm_pixel[23:0]),
        .out_valid(pack_valid), .out_ready(core_ifm_ready && cfg_stem), .out_pixel(pack_pixel)
    );
    conv_layer_top #(.MAX_WIDTH(MAX_WIDTH), .PSUM_DEPTH(PSUM_DEPTH),
        .MAX_CO_GROUPS(MAX_CO_GROUPS), .PE_LATENCY(PE_LATENCY)) core (
        .clk(clk), .rst_n(rst_n), .layer_start(layer_start && layer_ready && !bad_stem),
        .frame_width(kernel_6x6 ? (frame_width >> 1) : frame_width),
        .frame_height(kernel_6x6 ? (frame_height >> 1) : frame_height),
        .cin_groups(kernel_6x6 ? 16'd3 : cin_groups), .cout_groups(cout_groups),
        .kernel_1x1(kernel_6x6 ? 1'b0 : kernel_1x1),
        .stride_2(kernel_6x6 ? 1'b0 : stride_2), .padding_1(kernel_6x6 ? 1'b1 : padding_1),
        .silu_enable(silu_enable), .layer_ready(core_ready), .layer_busy(core_busy),
        .layer_done(core_done), .layer_error(core_error),
        .cfg_we(cfg_we), .cfg_ready(cfg_ready), .cfg_co_group(cfg_co_group),
        .cfg_bias_bus(cfg_bias_bus), .cfg_linear_multiplier_bus(cfg_linear_multiplier_bus),
        .cfg_linear_shift_bus(cfg_linear_shift_bus), .cfg_grid_multiplier_bus(cfg_grid_multiplier_bus),
        .cfg_grid_shift_bus(cfg_grid_shift_bus), .lut_load_start(lut_load_start),
        .lut_load_valid(lut_load_valid), .lut_load_ready(lut_load_ready), .lut_load_data(lut_load_data),
        .lut_valid(lut_valid), .weight_request(weight_request), .weight_ready(weight_ready),
        .weight_valid(weight_valid), .weight_word(weight_word), .ifm_request(ifm_request),
        .ifm_ready(core_ifm_ready), .ifm_valid(cfg_stem ? pack_valid : ifm_valid),
        .ifm_pixel(cfg_stem ? pack_pixel : ifm_pixel), .current_ci_group(weight_ci_group),
        .current_co_group(current_co_group), .current_tile_base(current_tile_base),
        .raw_valid(raw_valid), .raw_co_group(raw_co_group), .raw_index(raw_index), .raw_data(raw_data),
        .out_valid(out_valid), .out_co_group(out_co_group), .out_index(out_index), .out_data(out_data)
    );
endmodule
