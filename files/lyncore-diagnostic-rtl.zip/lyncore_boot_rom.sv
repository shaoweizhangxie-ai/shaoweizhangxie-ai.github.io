`timescale 1ns/1ps
// Four-word, read-only instruction line buffer over a synchronous ROM.
// This is not a general cache: there is no refill bus or self-modifying code.
module lyncore_boot_rom #(
    parameter integer WORDS = 4096,
    parameter INIT_FILE = "",
    parameter bit LINE_BUFFER = 1
) (
    input logic clk, rst, valid,
    input logic [31:0] addr,
    output logic ready, error,
    output logic [31:0] rdata,
    input logic data_valid, data_write,
    input logic [31:0] data_addr,
    output logic data_ready, data_error,
    output logic [31:0] data_rdata
);
    localparam integer ROW_BITS = $clog2(WORDS/4);
    (* ram_style = "block" *) logic [127:0] rom [0:WORDS/4-1];
    logic [127:0] line_data;
    logic [31:4] line_tag;
    logic line_valid;
    logic data_pending;
    logic [127:0] data_line;
    wire in_range = addr < WORDS*4 && addr[1:0] == 0;
    integer i;
    initial begin
        for (i = 0; i < WORDS/4; i = i + 1) rom[i] = {4{32'h00000013}};
        if (INIT_FILE != "") $readmemh(INIT_FILE, rom);
    end
    assign ready = valid && (!in_range || (line_valid && line_tag == addr[31:4]));
    assign error = valid && !in_range;
    assign rdata = line_data[addr[3:2]*32 +: 32];
    // Independent read port: constant loads do not evict the instruction line.
    // Byte/halfword selection remains in the CPU, just as for the data SRAM.
    wire data_in_range = data_addr < WORDS*4;
    assign data_ready = data_valid && (data_write || !data_in_range || data_pending);
    assign data_error = data_valid && (data_write || !data_in_range);
    assign data_rdata = data_line[data_addr[3:2]*32 +: 32];
    // Keep reset off the ROM data register so block RAM inference is possible.
    always_ff @(posedge clk) begin
        if (valid && in_range && !ready) line_data <= rom[addr[ROW_BITS+3:4]];
        if (data_valid && !data_write && data_in_range && !data_pending && !rst)
            data_line <= rom[data_addr[ROW_BITS+3:4]];
        if (rst) data_pending <= 0;
        else if (data_pending) data_pending <= 0;
        else if (data_valid && !data_write && data_in_range) data_pending <= 1;
        if (rst) line_valid <= 0;
        else if (valid && in_range && !ready) begin
            line_tag <= addr[31:4];
            line_valid <= 1;
        end else if (!LINE_BUFFER && ready) line_valid <= 0;
    end
endmodule
