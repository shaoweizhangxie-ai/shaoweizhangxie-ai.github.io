`timescale 1ns/1ps
// 面积模式：INT8 只有256种输入，系数改变时由一个共享整数乘法器生成精确表。
// 每条lane有独立同步读端口；不压缩40位Add中间值，不改变舍入或饱和定义。
// 表失配期间反压上游；命中后仍为两级弹性流水。clear/reset使全部表失效。
module int8_requant_table #(
    parameter integer LANES=8,
    parameter integer OUTPUT_WIDTH=8,
    parameter integer META_WIDTH=48
) (
    input wire clk,rst_n,clear,
    input wire in_valid, output wire in_ready,
    input wire [LANES*8-1:0] in_data,
    input wire [LANES*31-1:0] in_multiplier,
    input wire [LANES*6-1:0] in_shift,
    input wire [META_WIDTH-1:0] in_meta,
    output wire out_valid, input wire out_ready,
    output reg [LANES*OUTPUT_WIDTH-1:0] out_data,
    output reg [META_WIDTH-1:0] out_meta
);
    localparam IDLE=0, FILL=1, DRAIN=2;
    reg [1:0] state;
    reg [LANES-1:0] table_valid;
    reg [30:0] table_multiplier[0:LANES-1];
    reg [5:0] table_shift[0:LANES-1];
    wire [LANES-1:0] key_match;
    reg [LANES-1:0] fill_lanes;
    reg [30:0] fill_multiplier;
    reg [5:0] fill_shift;
    reg [7:0] fill_index, write_index;
    reg signed [39:0] fill_product;
    reg fill_valid;
    reg [2:0] quant_valid,quant_negative;
    reg [7:0] quant_index0,quant_index1,quant_index2;
    reg [40:0] fill_magnitude,fill_rounded,fill_shifted,fill_rounding;
    reg [1:0] valid_pipe;
    wire [LANES*OUTPUT_WIDTH-1:0] lookup_data;
    reg [META_WIDTH-1:0] meta_pipe;
    wire advance = rst_n && !clear && (!valid_pipe[1] || out_ready);
    assign in_ready = advance && state==IDLE && (&key_match);
    assign out_valid = valid_pipe[1] && !clear;
    wire accept = in_valid && in_ready;
    // 找到一个失配key，每次填表同时广播给具有相同key的所有lane。
    integer find_lane;
    reg [30:0] next_multiplier;
    reg [5:0] next_shift;
    reg found;
    reg [LANES-1:0] next_lanes;
    always @* begin
        found=0; next_multiplier=0; next_shift=0; next_lanes=0;
        for(find_lane=0;find_lane<LANES;find_lane=find_lane+1)
            if(!key_match[find_lane] && !found) begin
                next_multiplier=in_multiplier[find_lane*31+:31];
                next_shift=in_shift[find_lane*6+:6]; found=1;
            end
        for(find_lane=0;find_lane<LANES;find_lane=find_lane+1)
            next_lanes[find_lane]=
                in_multiplier[find_lane*31+:31]==next_multiplier &&
                in_shift[find_lane*6+:6]==next_shift;
    end
    // Separate magnitude, rounding and variable shift during table generation.
    // Steady-state lookup latency stays unchanged. Only a valid final stage
    // may write a table entry; DRAIN waits for that pipeline to empty.
    localparam [40:0] NEGATIVE_LIMIT=41'd1<<(OUTPUT_WIDTH-1);
    localparam [40:0] POSITIVE_LIMIT=NEGATIVE_LIMIT-41'd1;
    wire [OUTPUT_WIDTH-1:0] fill_value=quant_negative[2] ?
        (fill_shifted>=NEGATIVE_LIMIT ? {1'b1,{(OUTPUT_WIDTH-1){1'b0}}} :
         -fill_shifted[OUTPUT_WIDTH-1:0]) :
        (fill_shifted>POSITIVE_LIMIT ? {1'b0,{(OUTPUT_WIDTH-1){1'b1}}} :
         fill_shifted[OUTPUT_WIDTH-1:0]);
    always @(posedge clk)begin
        quant_negative<={quant_negative[1:0],fill_product[39]};
        quant_index0<=write_index;quant_index1<=quant_index0;quant_index2<=quant_index1;
        fill_magnitude<=fill_product[39] ? -$signed({fill_product[39],fill_product}) : {1'b0,fill_product};
        fill_rounded<=fill_magnitude+fill_rounding;
        fill_shifted<=fill_shift>=41 ? 41'd0 : (fill_rounded>>fill_shift);
        if(rst_n && !clear && state==IDLE && in_valid && !(&key_match))
            fill_rounding<=(next_shift==0 || next_shift>=41) ? 41'd0 : (41'd1<<(next_shift-1'b1));
    end
    genvar lane;
    generate for(lane=0;lane<LANES;lane=lane+1) begin:g_lane
        // PDS默认将256深度表选为LUT RAM；明确使用剩余DRM换取LUT面积。
        reg [OUTPUT_WIDTH-1:0] values[0:255];
        reg [OUTPUT_WIDTH-1:0] table_q /* synthesis syn_ramstyle="block_ram" */;
        assign lookup_data[lane*OUTPUT_WIDTH+:OUTPUT_WIDTH]=table_q;
        assign key_match[lane]=table_valid[lane] &&
            table_multiplier[lane]==in_multiplier[lane*31+:31] &&
            table_shift[lane]==in_shift[lane*6+:6];
        always @(posedge clk) begin
            if(rst_n && !clear && quant_valid[2] && fill_lanes[lane])
                values[quant_index2]<=fill_value;
        end
        always @(posedge clk)
            if(advance && accept) table_q<=values[in_data[lane*8+:8]];
    end endgenerate
    integer j;
    always @(posedge clk or negedge rst_n) begin
        if(!rst_n) begin
            state<=IDLE;table_valid<=0;fill_valid<=0;valid_pipe<=0;
            meta_pipe<=0;out_meta<=0;fill_lanes<=0;fill_multiplier<=0;
            fill_shift<=0;fill_index<=0;write_index<=0;fill_product<=0;
            quant_valid<=0;
            for(j=0;j<LANES;j=j+1) begin table_multiplier[j]<=0;table_shift[j]<=0;end
        end else if(clear) begin
            state<=IDLE;table_valid<=0;fill_valid<=0;valid_pipe<=0;quant_valid<=0;
        end else begin
            quant_valid<={quant_valid[1:0],fill_valid};
            if(advance) begin
                valid_pipe<={valid_pipe[0],accept};
                if(accept) meta_pipe<=in_meta;
                if(valid_pipe[0]) begin out_data<=lookup_data;out_meta<=meta_pipe;end
            end
            case(state)
                IDLE: begin
                    fill_valid<=0;
                    if(in_valid && !(&key_match)) begin
                        fill_multiplier<=next_multiplier;fill_shift<=next_shift;
                        fill_lanes<=next_lanes;fill_index<=0;state<=FILL;
                        table_valid<=table_valid & ~next_lanes;
                        for(j=0;j<LANES;j=j+1) if(next_lanes[j]) begin
                            table_multiplier[j]<=next_multiplier;table_shift[j]<=next_shift;
                        end
                    end
                end
                FILL: begin
                    fill_product<=$signed(fill_index)*$signed({1'b0,fill_multiplier});
                    write_index<=fill_index;fill_valid<=1;
                    if(fill_index==255) state<=DRAIN;
                    else fill_index<=fill_index+1'b1;
                end
                DRAIN: begin
                    fill_valid<=0;
                    if(!fill_valid && quant_valid==0)begin
                        table_valid<=table_valid|fill_lanes;state<=IDLE;
                    end
                end
                default: begin state<=IDLE;table_valid<=0;fill_valid<=0;quant_valid<=0;end
            endcase
        end
    end
endmodule
