`timescale 1ns/1ps
// Common reset only. Gray pointers cross independently; constrain their skew
// and the first synchronizer stage in the eventual physical design.
module lyncore_video_fifo #(parameter AW=9)(
 input wire wr_clk,rd_clk,rst_n,
 input wire wr_valid,input wire [15:0] wr_data,output wire wr_ready,
 output wire rd_valid,output wire [15:0] rd_data,input wire rd_ready
);
 reg [15:0] mem[0:(1<<AW)-1];
 reg [AW:0] wb,wg,rb,rg;
 (* ASYNC_REG="TRUE" *) reg [AW:0] rg1,rg2,wg1,wg2;
 (* ASYNC_REG="TRUE" *) reg [1:0] wr_reset,rd_reset;
 always @(posedge wr_clk or negedge rst_n)
  if(!rst_n)wr_reset<=0;else wr_reset<={wr_reset[0],1'b1};
 always @(posedge rd_clk or negedge rst_n)
  if(!rst_n)rd_reset<=0;else rd_reset<={rd_reset[0],1'b1};
 wire full=wg=={~rg2[AW:AW-1],rg2[AW-2:0]};
 assign wr_ready=wr_reset[1] && !full;
 wire [AW:0] wn=wb+{{AW{1'b0}},wr_valid && wr_ready};
 always @(posedge wr_clk or negedge rst_n)begin
  if(!rst_n)begin wb<=0;wg<=0;rg1<=0;rg2<=0;end
  else if(!wr_reset[1])begin wb<=0;wg<=0;rg1<=0;rg2<=0;end
  else begin
   rg1<=rg;rg2<=rg1;wb<=wn;wg<=(wn>>1)^wn;
   if(wr_valid && wr_ready)mem[wb[AW-1:0]]<=wr_data;
  end
 end
 // Registered read with a one-word output buffer; avoid a large asynchronous
 // memory read mux. The advanced read pointer denotes the buffered word too.
 reg out_valid;reg [15:0] out_data;
 wire fetch=rd_reset[1] && (!out_valid || rd_ready) && rg!=wg2;
 wire [AW:0] rn=rb+{{AW{1'b0}},fetch};
 assign rd_valid=rd_reset[1] && out_valid;
 assign rd_data=out_data;
 always @(posedge rd_clk or negedge rst_n)begin
  if(!rst_n)begin rb<=0;rg<=0;wg1<=0;wg2<=0;out_valid<=0;out_data<=0;end
  else if(!rd_reset[1])begin rb<=0;rg<=0;wg1<=0;wg2<=0;out_valid<=0;end
  else begin
   wg1<=wg;wg2<=wg1;rb<=rn;rg<=(rn>>1)^rn;
   if(!out_valid || rd_ready)out_valid<=fetch;
   if(fetch)out_data<=mem[rb[AW-1:0]];
  end
 end
endmodule
