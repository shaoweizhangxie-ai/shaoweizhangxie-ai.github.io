`timescale 1ns/1ps
module lyncore_decode #(parameter bit ENABLE_M = 0, parameter bit ENABLE_ZBA = 0,
                       parameter bit ENABLE_ZBB = 0) (
    input logic [31:0] insn,
    output lyncore_pkg::decode_t ctrl
);
    import lyncore_pkg::*;
    logic legal;
    always_comb begin
        ctrl = '0;
        ctrl.rs1 = insn[19:15];
        ctrl.rs2 = insn[24:20];
        ctrl.rd = insn[11:7];
        ctrl.funct3 = insn[14:12];
        ctrl.alu_op = ALU_ADD;
        legal = 1'b1;
        case (insn[6:0])
            7'h37, 7'h17: begin // LUI / AUIPC
                ctrl.reg_write = 1;
                ctrl.a_zero = (insn[6:0] == 7'h37);
                ctrl.a_pc = (insn[6:0] == 7'h17);
                ctrl.b_imm = 1;
                ctrl.imm = {insn[31:12], 12'b0};
            end
            7'h6f: begin // JAL
                ctrl.reg_write = 1;
                ctrl.jal = 1;
                ctrl.imm = {{11{insn[31]}}, insn[31], insn[19:12],
                            insn[20], insn[30:21], 1'b0};
            end
            7'h67: begin // JALR
                ctrl.reg_write = 1;
                ctrl.use_rs1 = 1;
                ctrl.jalr = 1;
                ctrl.imm = {{20{insn[31]}}, insn[31:20]};
                legal = (insn[14:12] == 0);
            end
            7'h63: begin
                ctrl.branch = 1;
                ctrl.use_rs1 = 1;
                ctrl.use_rs2 = 1;
                ctrl.imm = {{19{insn[31]}}, insn[31], insn[7],
                            insn[30:25], insn[11:8], 1'b0};
                legal = (insn[14:12] != 3'b010 && insn[14:12] != 3'b011);
            end
            7'h03: begin
                ctrl.load = 1;
                ctrl.reg_write = 1;
                ctrl.use_rs1 = 1;
                ctrl.b_imm = 1;
                ctrl.imm = {{20{insn[31]}}, insn[31:20]};
                legal = (insn[14:12] == 0 || insn[14:12] == 1 ||
                         insn[14:12] == 2 || insn[14:12] == 4 || insn[14:12] == 5);
            end
            7'h23: begin
                ctrl.store = 1;
                ctrl.use_rs1 = 1;
                ctrl.use_rs2 = 1;
                ctrl.b_imm = 1;
                ctrl.imm = {{20{insn[31]}}, insn[31:25], insn[11:7]};
                legal = (insn[14:12] <= 2);
            end
            7'h13, 7'h33: begin
                ctrl.reg_write = 1;
                ctrl.use_rs1 = 1;
                ctrl.use_rs2 = (insn[6:0] == 7'h33);
                ctrl.b_imm = (insn[6:0] == 7'h13);
                ctrl.imm = {{20{insn[31]}}, insn[31:20]};
                case (insn[14:12])
                    0: ctrl.alu_op = (insn[6:0] == 7'h33 && insn[30]) ? ALU_SUB : ALU_ADD;
                    1: ctrl.alu_op = ALU_SLL;
                    2: ctrl.alu_op = ALU_SLT;
                    3: ctrl.alu_op = ALU_SLTU;
                    4: ctrl.alu_op = ALU_XOR;
                    5: ctrl.alu_op = insn[30] ? ALU_SRA : ALU_SRL;
                    6: ctrl.alu_op = ALU_OR;
                    7: ctrl.alu_op = ALU_AND;
                endcase
                if (insn[6:0] == 7'h33) begin
                    if (ENABLE_M && insn[31:25] == 1) begin
                        ctrl.muldiv = 1;
                        legal = 1;
                    end else if (ENABLE_ZBA && insn[31:25] == 7'h10 &&
                                 (insn[14:12] == 2 || insn[14:12] == 4 || insn[14:12] == 6)) begin
                        case (insn[14:12])
                            2: ctrl.alu_op = ALU_SH1ADD;
                            4: ctrl.alu_op = ALU_SH2ADD;
                            6: ctrl.alu_op = ALU_SH3ADD;
                            default: ctrl.alu_op = ALU_ADD;
                        endcase
                    end else if (ENABLE_ZBB && insn[31:25] == 7'h20 &&
                                 (insn[14:12] == 4 || insn[14:12] == 6 || insn[14:12] == 7)) begin
                        case (insn[14:12])
                            4: ctrl.alu_op = ALU_XNOR;
                            6: ctrl.alu_op = ALU_ORN;
                            7: ctrl.alu_op = ALU_ANDN;
                            default: ctrl.alu_op = ALU_ADD;
                        endcase
                    end else if (ENABLE_ZBB && insn[31:25] == 7'h05 && insn[14:12] >= 4) begin
                        case (insn[14:12])
                            4: ctrl.alu_op = ALU_MIN;
                            5: ctrl.alu_op = ALU_MINU;
                            6: ctrl.alu_op = ALU_MAX;
                            7: ctrl.alu_op = ALU_MAXU;
                            default: ctrl.alu_op = ALU_ADD;
                        endcase
                    end else if (ENABLE_ZBB && insn[31:25] == 7'h30 &&
                                 (insn[14:12] == 1 || insn[14:12] == 5)) begin
                        ctrl.alu_op = (insn[14:12] == 1) ? ALU_ROL : ALU_ROR;
                    end else if (ENABLE_ZBB && insn[31:25] == 7'h04 && insn[14:12] == 4 && insn[24:20] == 0) begin
                        ctrl.alu_op = ALU_ZEXTH;
                        ctrl.use_rs2 = 0;
                    end else if (insn[14:12] == 0 || insn[14:12] == 5)
                        legal = (insn[31:25] == 0 || insn[31:25] == 7'h20);
                    else
                        legal = (insn[31:25] == 0);
                end else if (insn[14:12] == 1) begin
                    legal = (insn[31:25] == 0);
                end else if (insn[14:12] == 5) begin
                    legal = (insn[31:25] == 0 || insn[31:25] == 7'h20);
                end
                if (ENABLE_ZBB && insn[6:0] == 7'h13) begin
                    if (insn[14:12] == 1 && (insn[31:20] == 12'h600 || insn[31:20] == 12'h601 ||
                        insn[31:20] == 12'h602 || insn[31:20] == 12'h604 || insn[31:20] == 12'h605)) begin
                        legal = 1;
                        case (insn[31:20])
                            12'h600: ctrl.alu_op = ALU_CLZ;
                            12'h601: ctrl.alu_op = ALU_CTZ;
                            12'h602: ctrl.alu_op = ALU_CPOP;
                            12'h604: ctrl.alu_op = ALU_SEXTB;
                            12'h605: ctrl.alu_op = ALU_SEXTH;
                            default: ctrl.alu_op = ALU_ADD;
                        endcase
                    end else if (insn[14:12] == 5 && insn[31:25] == 7'h30) begin
                        legal = 1;
                        ctrl.alu_op = ALU_ROR;
                    end else if (insn[14:12] == 5 && insn[31:20] == 12'h287) begin
                        legal = 1;
                        ctrl.alu_op = ALU_ORCB;
                    end else if (insn[14:12] == 5 && insn[31:20] == 12'h698) begin
                        legal = 1;
                        ctrl.alu_op = ALU_REV8;
                    end
                end
            end
            7'h0f: legal = (insn[14:12] == 0); // FENCE: blocking, ordered bus
            7'h73: begin
                if (insn[14:12] != 0 && insn[14:12] != 4) begin
                    ctrl.csr = 1;
                    ctrl.csr_addr = insn[31:20];
                    ctrl.reg_write = 1;
                    ctrl.use_rs1 = !insn[14];
                end else if (insn == 32'h30200073) ctrl.mret = 1;
                else if (insn == 32'h10500073) begin end // WFI permitted as NOP
                else begin
                    ctrl.trap = 1;
                    if (insn == 32'h00000073) ctrl.cause = 11;
                    else if (insn == 32'h00100073) ctrl.cause = 3;
                    else legal = 0;
                end
            end
            default: legal = 0;
        endcase
        if (!legal) begin
            ctrl.reg_write = 0;
            ctrl.load = 0;
            ctrl.store = 0;
            ctrl.branch = 0;
            ctrl.jal = 0;
            ctrl.jalr = 0;
            ctrl.csr = 0;
            ctrl.mret = 0;
            ctrl.muldiv = 0;
            ctrl.trap = 1;
            ctrl.cause = 2;
            ctrl.tval = insn;
        end
    end
endmodule
