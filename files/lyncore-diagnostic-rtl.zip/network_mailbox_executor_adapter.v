`timescale 1ns/1ps
// 单帧整网适配。所有头来自真实任务表/Slot；不计算卷积或检测后处理。
module network_mailbox_executor_adapter #(
 parameter [31:0] DDR_BASE=32'h20000000,MODEL_ID=32'h2792d5c5,
 parameter [63:0] DDR_BYTES=64'h01000000
)(
 input wire clk,rst_n,clear,
 input wire engine_start,engine_cancel,result_ack,
 input wire [319:0] engine_config,input wire [191:0] engine_geometry,
 output wire engine_ready,engine_idle,output reg engine_done,engine_error,
 output reg [767:0] engine_result_desc,
 input wire ddr_ready,memory_idle,cpu_idle,
 output wire [1:0] memory_owner,output wire result_read_enable,output reg retire_result,
 output wire executor_start,output reg executor_clear,
 input wire executor_ready,executor_busy,executor_done,executor_error,executor_cancelled,
 output reg [31:0] image_base,image_bytes,program_offset,directory_offset,descriptor_base,seed_base,seed_capacity,
 output reg [15:0] execute_task_count,
 output reg [191:0] geometry,
 output wire [2:0] inspect_slot,input wire inspect_valid,
 input wire [31:0] inspect_base,input wire [15:0] inspect_generation,inspect_consumers,
 output wire read_request_valid,input wire read_request_ready,output wire [31:0] read_request_address,
 input wire read_response_valid,output wire read_response_ready,
 input wire [31:0] read_response_address,read_response_data,input wire read_response_error,
 output reg [31:0] error_code,output wire [4:0] debug_state
);
 localparam IDLE=0,ACCEPT=1,HREQ=2,HWAIT=3,HCHECK=4,LAUNCH=5,EXECUTE=6,
 EXEC_DRAIN=7,DREQ=8,DWAIT=9,DCHECK=10,INSPECT=11,SNAPSHOT=12,
 PUBLISH_RESULT=13,HOLD_RESULT=14,ACK_DRAIN=15,ABORT_DRAIN=16,FAIL_REPORT=17;
 reg [4:0] state;
 reg [319:0] cfg;reg [31:0] header[0:7];reg [511:0] head_task;
 reg [3:0] word_index;reg [1:0] head_index;
 reg aborting,failed,launched;integer i;
 wire cancelling=engine_cancel||clear;
 wire [31:0] head_pixels=head_index==0?1600:(head_index==1?400:100);
 wire [15:0] head_width=head_index==0?40:(head_index==1?20:10);
 wire [31:0] head_bytes=head_pixels*256;
 wire [31:0] request_address=state==HREQ||state==HWAIT?
       image_base+{27'd0,word_index[2:0],2'b00}:
       descriptor_base+(32'd84+{30'd0,head_index})*64+{26'd0,word_index,2'b00};
 wire [63:0] window_end={32'd0,DDR_BASE}+DDR_BYTES;
 function region_ok;
  input [31:0] base,bytes;
  begin region_ok=bytes!=0&&base>=DDR_BASE&&({32'd0,base}+{32'd0,bytes})<=window_end;end
 endfunction
 wire header_bad=header[0]!=32'h504d4659||header[1]!=1||header[2]!=87||header[6]!=0||header[7]!=0||
  header[3]<32||header[3][4:0]!=0||header[4][4:0]!=0||header[5][1:0]!=0||
  {32'd0,header[3]}+64'd2784>{32'd0,header[4]}||
  {32'd0,header[4]}+64'd2784>{32'd0,header[5]}||!region_ok(image_base,header[5]);
 wire head_bad=head_task[2:0]!=0||!head_task[12]||head_task[415:400]!=(16'd84+head_index)||
  head_task[127:112]!=255||head_task[63:48]!=head_width||head_task[79:64]!=head_width||
  head_task[399:384]==0||head_task[383:352]<head_bytes||head_task[322:320]!=0||
  !region_ok(head_task[351:320],head_bytes);
 assign debug_state=state;
 assign engine_ready=rst_n&&state==IDLE&&ddr_ready&&memory_idle&&cpu_idle&&!cancelling;
 // HOLD可被Mailbox发布；engine_ready仍为0，不能重新启动/覆盖三头。
 assign engine_idle=(state==IDLE||state==HOLD_RESULT)&&!executor_busy;
 assign result_read_enable=state==HOLD_RESULT&&!cancelling;
 assign memory_owner=(state==HOLD_RESULT||state==ACK_DRAIN)?2'd2:
   (launched&&(state==LAUNCH||state==EXECUTE||state==EXEC_DRAIN||state==ABORT_DRAIN))?2'd1:2'd0;
 assign executor_start=state==LAUNCH&&executor_ready&&!cancelling&&!aborting;
 assign inspect_slot=head_task[11:9];
 assign read_request_valid=rst_n&&(state==HREQ||state==DREQ);
 assign read_request_address=request_address;
 assign read_response_ready=state==HWAIT||state==DWAIT;
 always @(posedge clk or negedge rst_n)begin
  if(!rst_n)begin state<=IDLE;cfg<=0;geometry<=0;image_base<=0;image_bytes<=0;program_offset<=0;directory_offset<=0;
   descriptor_base<=0;seed_base<=0;seed_capacity<=0;execute_task_count<=0;engine_result_desc<=0;
   word_index<=0;head_index<=0;head_task<=0;aborting<=0;failed<=0;launched<=0;
   engine_done<=0;engine_error<=0;executor_clear<=0;retire_result<=0;error_code<=0;
   for(i=0;i<8;i=i+1)header[i]<=0;
  end else begin
   engine_done<=0;engine_error<=0;executor_clear<=0;retire_result<=0;
   if(cancelling&&state!=IDLE&&state!=HOLD_RESULT&&state!=ACK_DRAIN&&!aborting)begin
    aborting<=1;if(launched)executor_clear<=1;
   end
   case(state)
    IDLE:if(engine_start&&engine_ready)begin
     cfg<=engine_config;geometry<=engine_geometry;
     image_base<=engine_config[159:128];descriptor_base<=engine_config[191:160];
     seed_base<=engine_config[223:192];seed_capacity<=engine_config[255:224];
     execute_task_count<=engine_config[303:288];
     engine_result_desc<=0;error_code<=0;aborting<=0;failed<=0;launched<=0;state<=ACCEPT;
    end
    ACCEPT:if(cancelling||aborting)state<=ABORT_DRAIN;
     else if(cfg[319:288]!=87||cfg[287:256]!=MODEL_ID||image_base[4:0]!=0||descriptor_base[5:0]!=0||
       seed_base[2:0]!=0||seed_capacity!=819200||!region_ok(image_base,32)||
       !region_ok(descriptor_base,5568)||!region_ok(seed_base,seed_capacity)||
       geometry[15:0]==0||geometry[31:16]==0||geometry[63:32]!=32'h01400140||geometry[95:64]==0||geometry[127:96]==0)begin
      failed<=1;error_code<=1;state<=FAIL_REPORT;
     end else begin word_index<=0;state<=HREQ;end
    HREQ:if(read_request_ready)state<=HWAIT;
    HWAIT:if(read_response_valid)begin
     if(aborting||cancelling)state<=ABORT_DRAIN;
     else if(read_response_error||read_response_address!=request_address)begin failed<=1;error_code<=2;state<=FAIL_REPORT;end
     else begin header[word_index[2:0]]<=read_response_data;
      if(word_index==7)state<=HCHECK;else begin word_index<=word_index+1'b1;state<=HREQ;end
     end
    end
    HCHECK:if(aborting||cancelling)state<=ABORT_DRAIN;
     else if(header_bad)begin failed<=1;error_code<=3;state<=FAIL_REPORT;end
     else begin image_bytes<=header[5];program_offset<=header[3];directory_offset<=header[4];state<=LAUNCH;end
    LAUNCH:if(aborting||cancelling)state<=ABORT_DRAIN;
     else if(executor_start)begin launched<=1;state<=EXECUTE;end
    EXECUTE:if(executor_error||executor_cancelled)begin failed<=!executor_cancelled;error_code<=4;state<=ABORT_DRAIN;end
     else if(aborting||cancelling)state<=ABORT_DRAIN;
     else if(executor_done)state<=EXEC_DRAIN;
    EXEC_DRAIN:if(aborting||cancelling)state<=ABORT_DRAIN;
     else if(!executor_busy&&memory_idle)begin
      launched<=0;head_index<=0;word_index<=0;head_task<=0;
      engine_result_desc[191:0]<={32'd3,cfg[287:256],cfg[127:96],cfg[95:64],cfg[63:32],cfg[31:0]};state<=DREQ;
     end
    DREQ:if(read_request_ready)state<=DWAIT;
    DWAIT:if(read_response_valid)begin
     if(aborting||cancelling)state<=ABORT_DRAIN;
     else if(read_response_error||read_response_address!=request_address)begin failed<=1;error_code<=2;state<=FAIL_REPORT;end
     else begin head_task[word_index*32+:32]<=read_response_data;
      if(word_index==15)state<=DCHECK;else begin word_index<=word_index+1'b1;state<=DREQ;end
     end
    end
    DCHECK:if(aborting||cancelling)state<=ABORT_DRAIN;
     else if(head_bad)begin failed<=1;error_code<=5;state<=FAIL_REPORT;end else state<=INSPECT;
    INSPECT:state<=SNAPSHOT; // 给Slot查询端完整一拍稳定选择，无PE延迟猜测。
    SNAPSHOT:if(aborting||cancelling)state<=ABORT_DRAIN;
     else if(!inspect_valid||inspect_base!=head_task[351:320]||inspect_consumers!=1)begin
      failed<=1;error_code<=6;state<=FAIL_REPORT;
     end else begin
      case(head_index)
       2'd0: engine_result_desc[192+:192] <= {32'd409600,16'd0,16'd40,16'd40,16'd255,inspect_generation,13'd0,inspect_slot,inspect_base,32'd84};
       2'd1: engine_result_desc[384+:192] <= {32'd102400,16'd0,16'd20,16'd20,16'd255,inspect_generation,13'd0,inspect_slot,inspect_base,32'd85};
       2'd2: engine_result_desc[576+:192] <= {32'd25600,16'd0,16'd10,16'd10,16'd255,inspect_generation,13'd0,inspect_slot,inspect_base,32'd86};
       default: ;
      endcase
      if(head_index==2)state<=PUBLISH_RESULT;else begin head_index<=head_index+1'b1;word_index<=0;head_task<=0;state<=DREQ;end
     end
    PUBLISH_RESULT:if(aborting||cancelling)state<=ABORT_DRAIN;
     else if(memory_idle&&!executor_busy)begin engine_done<=1;state<=HOLD_RESULT;end
    HOLD_RESULT:if(result_ack||clear)state<=ACK_DRAIN;
    ACK_DRAIN:if(memory_idle&&cpu_idle)begin retire_result<=1;engine_result_desc<=0;state<=IDLE;end
    FAIL_REPORT:begin engine_error<=1;state<=ABORT_DRAIN;end
    ABORT_DRAIN:if(!executor_busy&&memory_idle)begin
      launched<=0;if(failed)begin engine_error<=1;failed<=0;end else state<=IDLE;
    end
    default:begin failed<=1;error_code<=7;state<=FAIL_REPORT;end
   endcase
  end
 end
endmodule
