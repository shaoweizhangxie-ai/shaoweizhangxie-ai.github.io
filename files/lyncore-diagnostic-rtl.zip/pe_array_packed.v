`timescale 1ns/1ps

// 独立实验副本（不替换生产文件）。PE 阵列：PCIN=4、PCOUT=8、K=3、有符号 INT8。
//
// window_bus[(ci*9 + k)*8 +: 8] 对应 X[ci][k]。
// weight_bus[((co*4 + ci)*9 + k)*8 +: 8] 对应 W[co][ci][k]。
// k = ky*3 + kx，3×3 窗口按行优先排列。
// PE_LATENCY 表示包含输入采样级的寄存器级数，默认 7。
// 上升沿 n 采样的事务，在 n+PE_LATENCY-1 后输出；允许增加输出寄存级。
// 流水线每个时钟周期都能接收一组新输入。
module pe_array #(
    parameter integer PE_LATENCY = 10
) (
    input  wire               clk,
    input  wire               rst_n,
    input  wire               in_valid,
    input  wire [287:0]       window_bus,
    input  wire [2303:0]      weight_bus,
    output wire signed [31:0] psum0,
    output wire signed [31:0] psum1,
    output wire signed [31:0] psum2,
    output wire signed [31:0] psum3,
    output wire signed [31:0] psum4,
    output wire signed [31:0] psum5,
    output wire signed [31:0] psum6,
    output wire signed [31:0] psum7,
    output wire               out_valid
);
    localparam integer PCIN  = 4;
    localparam integer PCOUT = 2;
    localparam integer K2    = 9;
    // 乘法、四级核内归并、一级通道对归并、一级最终归并，共七级。
    // 更大 PE_LATENCY 在此计算核之后增加真实数据寄存器，valid 同步延迟。
    localparam integer CORE_LATENCY = 7;
    localparam integer MIN_LATENCY = CORE_LATENCY + 3;

    // 第 0 级：计算 288 个有符号 8×8 乘积。
    reg signed [15:0] product [0:PCOUT-1][0:PCIN-1][0:K2-1];
    // 第 1 级：9 项归并为 5 项，每个和最多包含 2 个乘积。
    // 此处仍只归并同一组 co、ci 内的乘积，不跨输入通道相加。
    reg signed [16:0] sum1 [0:PCOUT-1][0:PCIN-1][0:4];
    // 第 2 级：5 项归并为 3 项，每个和最多包含 4 个乘积。
    reg signed [17:0] sum2 [0:PCOUT-1][0:PCIN-1][0:2];
    // 第 3 级：3 项归并为 2 项，每个和最多包含 8 个乘积。
    reg signed [18:0] sum3 [0:PCOUT-1][0:PCIN-1][0:1];
    // 第 4 级：2 项归并为 1 项，每个点积包含 9 个乘积。
    // dot[co][ci] 精确对应一个输出通道和一个输入通道的 3×3 点积。
    reg signed [18:0] dot  [0:PCOUT-1][0:PCIN-1];

    // dot 只覆盖当前 3×3 窗口；完整输入通道范围仍需后续 Psum Buffer 累加。
    // 第 5 级：四个输入通道的点积先两两相加，缩短单级组合加法路径。
    reg signed [19:0] pair_sum [0:PCOUT-1][0:1];

    // 第 6 级的结果寄存器。八个命名输出便于逐通道查看波形。
    reg signed [31:0] psum [0:7];
    wire [255:0] core_result = {
        psum[7], psum[6], psum[5], psum[4],
        psum[3], psum[2], psum[1], psum[0]
    };
    wire [255:0] output_result;
    assign psum0 = output_result[0 +: 32];
    assign psum1 = output_result[32 +: 32];
    assign psum2 = output_result[64 +: 32];
    assign psum3 = output_result[96 +: 32];
    assign psum4 = output_result[128 +: 32];
    assign psum5 = output_result[160 +: 32];
    assign psum6 = output_result[192 +: 32];
    assign psum7 = output_result[224 +: 32];

    // Two physical output channels serve eight logical channels in four
    // phases. in_valid transactions must be separated by at least three edges.
    reg [1:0] phase;
    reg [287:0] held_window;
    reg [1727:0] held_upper_weights;
    wire [287:0] selected_window=phase!=0?held_window:window_bus;
    wire [575:0] selected_weights=phase!=0?held_upper_weights[(phase-1'b1)*576+:576]:weight_bus[575:0];
    wire [1151:0] packed_products;
    always @(posedge clk or negedge rst_n)
        if(!rst_n)phase<=0;else if(phase!=0)phase<=phase+1'b1;else if(in_valid)phase<=1;
    always @(posedge clk)if(in_valid&&phase==0)begin
        held_window<=window_bus;held_upper_weights<=weight_bus[2303:576];
    end
    genvar pc,pi,pk;
    generate for(pc=0;pc<1;pc=pc+1)begin:pair_co
     for(pi=0;pi<4;pi=pi+1)begin:pair_ci
      for(pk=0;pk<9;pk=pk+1)begin:pair_k
       int8_pair_product pair(.x(selected_window[(pi*9+pk)*8+:8]),
        .w0(selected_weights[(((pc*2)*4+pi)*9+pk)*8+:8]),
        .w1(selected_weights[(((pc*2+1)*4+pi)*9+pk)*8+:8]),
        .p0(packed_products[(((pc*2)*4+pi)*9+pk)*16+:16]),
        .p1(packed_products[(((pc*2+1)*4+pi)*9+pk)*16+:16]));
      end
     end
    end endgenerate
    // synthesis translate_off
    always @(posedge clk)if(rst_n&&in_valid&&phase!=0)
        $fatal(1,"folded PE input overrun");
    // synthesis translate_on

    integer co;
    integer ci;
    integer k;

    // 运算流水寄存器不复位；只有对应的有效位穿过全部七级流水后，
    // 这些寄存器中的结果才会被使用。
    // 三重 for 循环由综合工具展开为并行硬件，不会逐拍遍历 288 次。
    always @(posedge clk) begin
        for (co = 0; co < PCOUT; co = co + 1) begin
            for (ci = 0; ci < PCIN; ci = ci + 1) begin
                for (k = 0; k < K2; k = k + 1) begin
                    product[co][ci][k] <= packed_products[((co*PCIN+ci)*K2+k)*16 +: 16];
                    // 每次选出两个 8 bit 数据并按有符号数相乘；
                    // co、ci、k 是硬件索引，并非运行时逐拍移动的计数器。
                end

                sum1[co][ci][0] <= product[co][ci][0] + product[co][ci][1];
                sum1[co][ci][1] <= product[co][ci][2] + product[co][ci][3];
                sum1[co][ci][2] <= product[co][ci][4] + product[co][ci][5];
                sum1[co][ci][3] <= product[co][ci][6] + product[co][ci][7];
                sum1[co][ci][4] <= product[co][ci][8];

                sum2[co][ci][0] <= sum1[co][ci][0] + sum1[co][ci][1];
                sum2[co][ci][1] <= sum1[co][ci][2] + sum1[co][ci][3];
                sum2[co][ci][2] <= sum1[co][ci][4];

                sum3[co][ci][0] <= sum2[co][ci][0] + sum2[co][ci][1];
                sum3[co][ci][1] <= sum2[co][ci][2];

                dot[co][ci] <= sum3[co][ci][0] + sum3[co][ci][1];
            end

            pair_sum[co][0] <= dot[co][0] + dot[co][1];
            pair_sum[co][1] <= dot[co][2] + dot[co][3];
        end
    end

    // 核内 valid 的级数来自实际计算结构，输出扩展级见文件末尾。
    reg [CORE_LATENCY-1:0] valid_pipe;
    reg [1:0] phase_pipe [0:CORE_LATENCY-1];
    integer phase_stage;
    wire beat_valid = in_valid || phase != 0;
    wire core_valid = valid_pipe[CORE_LATENCY-1] && phase_pipe[CORE_LATENCY-1] == 3;
    integer out_co;

    // Data is observable only with core_valid. Avoid folding a runtime
    // clear into APM output reset; the validity pipeline still resets async.
    always @(posedge clk or negedge rst_n)
        if(!rst_n)begin
            valid_pipe<={CORE_LATENCY{1'b0}};
            for(phase_stage=0;phase_stage<CORE_LATENCY;phase_stage=phase_stage+1)phase_pipe[phase_stage]<=0;
        end else begin
            valid_pipe<={valid_pipe[CORE_LATENCY-2:0],beat_valid};
            phase_pipe[0]<=phase;
            for(phase_stage=1;phase_stage<CORE_LATENCY;phase_stage=phase_stage+1)phase_pipe[phase_stage]<=phase_pipe[phase_stage-1];
        end
    always @(posedge clk)begin
        if(valid_pipe[CORE_LATENCY-2])begin
            for(out_co=0;out_co<PCOUT;out_co=out_co+1)
                psum[{phase_pipe[CORE_LATENCY-2],1'b0}+out_co]<=
                    {{12{pair_sum[out_co][0][19]}},pair_sum[out_co][0]}+
                    {{12{pair_sum[out_co][1][19]}},pair_sum[out_co][1]};
        end
    end

    generate
        if (PE_LATENCY > MIN_LATENCY) begin : g_output_delay
            localparam integer EXTRA_STAGES = PE_LATENCY - MIN_LATENCY;
            reg [EXTRA_STAGES-1:0] delay_valid;
            reg [255:0] delay_data [0:EXTRA_STAGES-1];
            integer delay_stage;
            assign out_valid = delay_valid[EXTRA_STAGES-1];
            assign output_result = delay_data[EXTRA_STAGES-1];
            always @(posedge clk or negedge rst_n) begin
                if (!rst_n) begin
                    delay_valid <= {EXTRA_STAGES{1'b0}};
                    for (delay_stage = 0; delay_stage < EXTRA_STAGES;
                         delay_stage = delay_stage + 1)
                        delay_data[delay_stage] <= 256'd0;
                end else begin
                    delay_valid[0] <= core_valid;
                    if (core_valid)
                        delay_data[0] <= core_result;
                    for (delay_stage = 1; delay_stage < EXTRA_STAGES;
                         delay_stage = delay_stage + 1) begin
                        delay_valid[delay_stage] <= delay_valid[delay_stage-1];
                        if (delay_valid[delay_stage-1])
                            delay_data[delay_stage] <= delay_data[delay_stage-1];
                    end
                end
            end
        end else begin : g_core_output
            assign out_valid = core_valid;
            assign output_result = core_result;
        end
    endgenerate

    // synthesis translate_off
    initial begin
        if (PE_LATENCY < MIN_LATENCY) begin
            $display("ERROR: pe_array requires PE_LATENCY >= %0d", MIN_LATENCY);
            $finish;
        end
    end
    // synthesis translate_on
endmodule
