`timescale 1ns/1ps
// Exclusive single-frame preprocess phase; reuse the existing DDR user bridge.
module video_frame_to_input(
 input wire clk,rst_n,start,source_committed,slot_available,release_frame,ddr_ready,bridge_busy,bridge_fault,
 input wire [31:0] frame_id,
 output wire ready,busy,committed,failed,verify_active,
 output wire [31:0] committed_frame_id,verified_bytes,tensor_crc32,
 output wire read_request_valid,input wire read_request_ready,output wire [31:0] read_request_address,
 input wire read_response_valid,output wire read_response_ready,
 input wire [31:0] read_response_address,read_response_data,input wire read_response_error,
 output wire write_request_valid,input wire write_request_ready,
 output wire [31:0] write_request_address,write_request_data,output wire [3:0] write_request_strobe,
 input wire write_response_valid,output wire write_response_ready,
 input wire [31:0] write_response_address,input wire write_response_error
);
 wire pre_ready,pre_busy,pre_done,pre_error,pre_cancelled,commit_ready,commit_busy;
 wire tensor_valid,tensor_ready,tensor_last;wire [63:0] tensor_data;
 wire [23:0] tensor_rgb;wire [31:0] tensor_index,tensor_frame_id;
 wire p_req,p_ready,p_reply,p_accept,v_req,v_ready,v_reply,v_accept;
 wire [31:0] p_address,v_address;
 assign ready=source_committed && pre_ready && commit_ready;
 wire launch=start && ready;
 assign busy=pre_busy || commit_busy;
 // The bridge uses a read barrier to flush combined writes. Do not present
 // a new source read while the previous tensor word is still being written.
 // This phase-local gate does not change the CPU's four-slot inference path.
 assign read_request_valid=verify_active?v_req:(p_req && tensor_ready);
 assign read_request_address=verify_active?v_address:p_address;
 assign p_ready=!verify_active && tensor_ready && read_request_ready;
 assign v_ready=verify_active && read_request_ready;
 assign p_reply=!verify_active && read_response_valid;
 assign v_reply=verify_active && read_response_valid;
 assign read_response_ready=verify_active?v_accept:p_accept;
 video_letterbox_720p #(.SOURCE_RGB565(1)) preprocess(
  .clk(clk),.rst_n(rst_n),.clear(1'b0),.start(launch),.source_base(32'h20840000),.source_capacity(32'd1843200),
  .frame_id(frame_id),.ready(pre_ready),.busy(pre_busy),.done(pre_done),.error(pre_error),.cancelled(pre_cancelled),
  .read_request_valid(p_req),.read_request_ready(p_ready),.read_request_address(p_address),
  .read_response_valid(p_reply),.read_response_ready(p_accept),.read_response_address(read_response_address),
  .read_response_data(read_response_data),.read_response_error(read_response_error),
  .out_valid(tensor_valid),.out_ready(tensor_ready),.out_data(tensor_data),.out_rgb(tensor_rgb),
  .out_index(tensor_index),.out_frame_id(tensor_frame_id),.out_last(tensor_last),
  .resized_width(),.resized_height(),.pad_left(),.pad_top());
 video_tensor_commit commit(
  .clk(clk),.rst_n(rst_n),.start(launch),.slot_available(slot_available),.release_frame(release_frame),
  .ddr_ready(ddr_ready),.bridge_busy(bridge_busy),.bridge_fault(bridge_fault),.producer_failed(pre_error || pre_cancelled),
  .frame_id(frame_id),.ready(commit_ready),.busy(commit_busy),.verify_active(verify_active),
  .committed(committed),.failed(failed),.committed_frame_id(committed_frame_id),.verified_bytes(verified_bytes),.tensor_crc32(tensor_crc32),
  .in_valid(tensor_valid),.in_ready(tensor_ready),.in_data(tensor_data),.in_index(tensor_index),.in_frame_id(tensor_frame_id),.in_last(tensor_last),
  .write_request_valid(write_request_valid),.write_request_ready(write_request_ready),.write_request_address(write_request_address),
  .write_request_data(write_request_data),.write_request_strobe(write_request_strobe),
  .write_response_valid(write_response_valid),.write_response_ready(write_response_ready),.write_response_address(write_response_address),.write_response_error(write_response_error),
  .read_request_valid(v_req),.read_request_ready(v_ready),.read_request_address(v_address),
  .read_response_valid(v_reply),.read_response_ready(v_accept),.read_response_address(read_response_address),
  .read_response_data(read_response_data),.read_response_error(read_response_error));
endmodule
