`timescale 1ns/1ps
// One outstanding RV32M operation. DONE/result stay stable until accept.
// Four 16x16 registered products; restoring division takes 32 steps.
module lyncore_muldiv #(parameter bit ENABLE_MULTIPLY=1) (
    input logic clk, rst, cancel, start, accept,
    input logic [2:0] op,
    input logic [31:0] a, b,
    output logic busy, done,
    output logic [31:0] result
);
    typedef enum logic [2:0] {IDLE, PREPARE, MUL_SUM, MUL_SIGN, DIV_STEP, DIV_SIGN, DONE} state_t;
    state_t state;
    logic [2:0] operation;
    logic [31:0] operand_a, operand_b, p00, p01, p10, p11;
    logic [63:0] product;
    logic negative_a, negative_b, negative_quotient, negative_remainder;
    logic [31:0] quotient, remainder, divisor;
    logic [5:0] step;
    logic [32:0] shifted_remainder, reduced_remainder;
    logic [31:0] next_quotient;
    logic subtract_divisor;
    assign busy = state != IDLE && state != DONE;
    assign done = state == DONE;
    always_comb begin
        shifted_remainder = {remainder, quotient[31]};
        subtract_divisor = shifted_remainder >= {1'b0, divisor};
        reduced_remainder = subtract_divisor ? shifted_remainder - {1'b0, divisor} : shifted_remainder;
        next_quotient = {quotient[30:0], subtract_divisor};
    end
    always_ff @(posedge clk) begin
        if (rst || cancel) begin
            state <= IDLE;
            result <= 0;
            operation <= 0;
            operand_a <= 0; operand_b <= 0;
            p00 <= 0; p01 <= 0; p10 <= 0; p11 <= 0; product <= 0;
            negative_a <= 0; negative_b <= 0;
            negative_quotient <= 0; negative_remainder <= 0;
            quotient <= 0; remainder <= 0; divisor <= 0; step <= 0;
        end else begin
            case (state)
                IDLE: if (start) begin
                    operation <= op;
                    operand_a <= a; operand_b <= b;
                    state <= PREPARE;
                end
                PREPARE: begin
                    // Prepare private division state at acceptance. Shortcut
                    // results do not read it, so zero/overflow checks need not
                    // gate these wide register controls.
                    quotient <= (!operation[0] && operand_a[31]) ? -operand_a : operand_a;
                    divisor <= (!operation[0] && operand_b[31]) ? -operand_b : operand_b;
                    negative_quotient <= !operation[0] && (operand_a[31] ^ operand_b[31]);
                    negative_remainder <= !operation[0] && operand_a[31];
                    remainder <= 0; step <= 0;
                    if (ENABLE_MULTIPLY && !operation[2]) begin
                        p00 <= operand_a[15:0] * operand_b[15:0];
                        p01 <= operand_a[15:0] * operand_b[31:16];
                        p10 <= operand_a[31:16] * operand_b[15:0];
                        p11 <= operand_a[31:16] * operand_b[31:16];
                        negative_a <= (operation == 1 || operation == 2) && operand_a[31];
                        negative_b <= operation == 1 && operand_b[31];
                        state <= MUL_SUM;
                    end else if (operand_b == 0) begin
                        result <= operation[1] ? operand_a : 32'hffffffff;
                        state <= DONE;
                    end else if (!operation[0] && operand_a == 32'h80000000 && operand_b == 32'hffffffff) begin
                        result <= operation[1] ? 0 : operand_a;
                        state <= DONE;
                    end else begin
                        state <= DIV_STEP;
                    end
                end
                MUL_SUM: begin
                    if (operation == 0) begin
                        // MUL keeps only the low word: high partial products
                        // and signed corrections cannot affect these 32 bits.
                        result <= p00 + {p01[15:0], 16'b0} + {p10[15:0], 16'b0};
                        state <= DONE;
                    end else begin
                        product <= {32'b0, p00} + {16'b0, p01, 16'b0} +
                                   {16'b0, p10, 16'b0} + {p11, 32'b0};
                        state <= MUL_SIGN;
                    end
                end
                MUL_SIGN: begin
                    result <= product[63:32] - (negative_a ? operand_b : 0) -
                              (negative_b ? operand_a : 0);
                    state <= DONE;
                end
                DIV_STEP: begin
                    quotient <= next_quotient;
                    remainder <= reduced_remainder[31:0];
                    step <= step + 1;
                    if (step == 31) state <= DIV_SIGN;
                end
                DIV_SIGN: begin
                    result <= operation[1] ? (negative_remainder ? -remainder : remainder) :
                                            (negative_quotient ? -quotient : quotient);
                    state <= DONE;
                end
                DONE: if (accept) state <= IDLE;
                default: state <= IDLE;
            endcase
        end
    end
endmodule
