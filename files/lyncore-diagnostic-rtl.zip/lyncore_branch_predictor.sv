`timescale 1ns/1ps
// Direct-mapped BTB with two-bit saturating direction counters.
// Optional resolved-path return stack; speculative fetches never modify it.
module lyncore_branch_predictor #(parameter integer INDEX_BITS=4,
                                 parameter bit ENABLE_RAS=0, parameter integer RAS_DEPTH=8,
                                 parameter integer LOCAL_HISTORY_BITS=0,
                                 parameter bit HASH_INDEX=0,
                                 parameter bit SECOND_LOOKUP=0) (
    input logic clk, rst, invalidate,
    input logic [31:0] fetch_pc,
    output logic [31:0] predicted_pc,
    output logic [31:0] predicted_second_pc,
    input logic update, conditional_branch, taken,
    input logic update_call, update_return,
    input logic [31:0] update_pc, target
);
    localparam integer ENTRIES=1<<INDEX_BITS;
    logic [ENTRIES-1:0] valid;
    logic [29-INDEX_BITS:0] tags[0:ENTRIES-1];
    logic [31:0] targets[0:ENTRIES-1];
    logic [1:0] counters[0:ENTRIES-1];
    wire [INDEX_BITS-1:0] fetch_index=fetch_pc[INDEX_BITS+1:2] ^
                                    (HASH_INDEX ? fetch_pc[2*INDEX_BITS+1:INDEX_BITS+2] : {INDEX_BITS{1'b0}});
    wire [INDEX_BITS-1:0] update_index=update_pc[INDEX_BITS+1:2] ^
                                     (HASH_INDEX ? update_pc[2*INDEX_BITS+1:INDEX_BITS+2] : {INDEX_BITS{1'b0}});
    wire fetch_hit=valid[fetch_index] && tags[fetch_index]==fetch_pc[31:INDEX_BITS+2];
    wire [31:0] second_pc=fetch_pc+4;
    wire [INDEX_BITS-1:0] second_index=second_pc[INDEX_BITS+1:2] ^
        (HASH_INDEX ? second_pc[2*INDEX_BITS+1:INDEX_BITS+2] : {INDEX_BITS{1'b0}});
    wire second_hit=valid[second_index] && tags[second_index]==second_pc[31:INDEX_BITS+2];
    wire update_hit=valid[update_index] && tags[update_index]==update_pc[31:INDEX_BITS+2];
    logic [ENTRIES-1:0] returns;
    logic [31:0] return_target;
    logic return_valid;
    logic predict_taken;
    logic second_taken;
    // Resolved-path, per-BTB-entry history: no wrong-path speculative training.
    // This compact two-level candidate is not an implementation of RUNLTS.
    generate if (LOCAL_HISTORY_BITS>0) begin : local_history
        localparam integer PATTERNS=1<<LOCAL_HISTORY_BITS;
        logic [LOCAL_HISTORY_BITS-1:0] histories[0:ENTRIES-1];
        logic [1:0] patterns[0:ENTRIES-1][0:PATTERNS-1];
        logic [1:0] choosers[0:ENTRIES-1];
        logic [ENTRIES-1:0] conditional_entries;
        assign predict_taken=(!conditional_entries[fetch_index] || !choosers[fetch_index][1]) ?
                             counters[fetch_index][1] : patterns[fetch_index][histories[fetch_index]][1];
        assign second_taken=(!conditional_entries[second_index] || !choosers[second_index][1]) ?
                            counters[second_index][1] : patterns[second_index][histories[second_index]][1];
        always_ff @(posedge clk) begin
            if (!rst && !invalidate && update) begin
                conditional_entries[update_index]<=conditional_branch;
                if (!update_hit || !conditional_entries[update_index] || !conditional_branch) begin
                    choosers[update_index]<=0;
                    histories[update_index]<={{(LOCAL_HISTORY_BITS-1){1'b0}},taken && conditional_branch};
                    for (integer i=0;i<PATTERNS;i++)
                        patterns[update_index][i]<=(i==0 && taken) ? 2 : 1;
                end else begin
                    if (counters[update_index][1]!=patterns[update_index][histories[update_index]][1]) begin
                        if (patterns[update_index][histories[update_index]][1]==taken && choosers[update_index]!=3)
                            choosers[update_index]<=choosers[update_index]+1;
                        else if (counters[update_index][1]==taken && choosers[update_index]!=0)
                            choosers[update_index]<=choosers[update_index]-1;
                    end
                    histories[update_index]<=(histories[update_index]<<1) |
                                             {{(LOCAL_HISTORY_BITS-1){1'b0}},taken};
                    if (taken && patterns[update_index][histories[update_index]]!=3)
                        patterns[update_index][histories[update_index]]<=patterns[update_index][histories[update_index]]+1;
                    else if (!taken && patterns[update_index][histories[update_index]]!=0)
                        patterns[update_index][histories[update_index]]<=patterns[update_index][histories[update_index]]-1;
                end
            end
        end
    end else begin : bimodal
        assign predict_taken=counters[fetch_index][1];
        assign second_taken=counters[second_index][1];
    end endgenerate
    generate if (ENABLE_RAS) begin : return_stack
        localparam integer POINTER_BITS=$clog2(RAS_DEPTH);
        localparam integer COUNT_BITS=$clog2(RAS_DEPTH+1);
        logic [31:0] stack[0:RAS_DEPTH-1];
        logic [POINTER_BITS-1:0] top;
        logic [COUNT_BITS-1:0] count;
        wire [POINTER_BITS-1:0] next_top=(top==POINTER_BITS'(RAS_DEPTH-1)) ? '0 : top+1'b1;
        wire [POINTER_BITS-1:0] previous_top=(top==0) ? POINTER_BITS'(RAS_DEPTH-1) : top-1'b1;
        assign return_target=stack[top];
        assign return_valid=count!=0;
        always_ff @(posedge clk) begin
            if (rst || invalidate) begin top<=0;count<=0;end
            else if (update) begin
                if (update_call) begin
                    // Shift-stack semantics, including overflow and replace-top,
                    // without moving every payload on a late training enable.
                    stack[update_return ? top : next_top]<=update_pc+4;
                    if (update_return) begin
                        if (count==0) count<=1;
                    end else begin
                        top<=next_top;
                        if (count<COUNT_BITS'(RAS_DEPTH)) count<=count+1'b1;
                    end
                end else if (update_return && count!=0) begin
                    top<=previous_top;
                    count<=count-1'b1;
                end
            end
        end
    end else begin : no_return_stack
        assign return_target=0;
        assign return_valid=0;
    end endgenerate
    assign predicted_pc=(!rst && !invalidate && fetch_pc[1:0]==0 && fetch_hit && predict_taken) ?
                         ((ENABLE_RAS && returns[fetch_index] && return_valid) ? return_target : targets[fetch_index]) : fetch_pc+4;
    assign predicted_second_pc=(SECOND_LOOKUP && !rst && !invalidate && second_pc[1:0]==0 && second_hit && second_taken) ?
        ((ENABLE_RAS && returns[second_index] && return_valid) ? return_target : targets[second_index]) : second_pc+4;
    always_ff @(posedge clk) begin
        if(rst || invalidate) valid<=0;
        else if(update) begin
            valid[update_index]<=1;
            tags[update_index]<=update_pc[31:INDEX_BITS+2];
            targets[update_index]<=target;
            returns[update_index]<=update_return;
            if(!conditional_branch) counters[update_index]<=3;
            else if(!update_hit) counters[update_index]<=taken ? 2 : 1;
            else if(taken && counters[update_index]!=3) counters[update_index]<=counters[update_index]+1;
            else if(!taken && counters[update_index]!=0) counters[update_index]<=counters[update_index]-1;
        end
    end
endmodule
