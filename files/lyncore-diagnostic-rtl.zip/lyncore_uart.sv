`timescale 1ns/1ps
// 8N1 UART, eight-byte RX/TX queues, fixed baud rate. Interrupts are level held.
module lyncore_uart #(parameter integer CLOCK_HZ = 27000000,
                      parameter integer BAUD = 115200) (
    input logic clk, rst, rx,
    output logic tx, irq,
    input logic valid, write,
    input logic [3:0] word_addr,
    input logic [31:0] wdata,
    input logic [3:0] wstrb,
    output logic ready, error,
    output logic [31:0] rdata
);
    localparam integer DIV = (CLOCK_HZ + BAUD/2)/BAUD;
    localparam integer TIMER_BITS = $clog2(DIV+1);
    logic [7:0] tx_fifo[0:7], rx_fifo[0:7];
    logic [2:0] tx_wptr, tx_rptr, rx_wptr, rx_rptr;
    logic [3:0] tx_count, rx_count;
    logic [9:0] tx_shift;
    logic [3:0] tx_bits;
    logic [TIMER_BITS-1:0] tx_timer, rx_timer;
    // Keep the asynchronous input's two stages as identifiable registers in PDS.
    (* ASYNC_REG = "TRUE", syn_preserve = 1, syn_keep = 1, syn_srlstyle = "registers" *) logic rx_meta, rx_sync;
    logic overrun, framing;
    logic [1:0] irq_enable;
    logic [1:0] rx_state;
    logic [2:0] rx_bit;
    logic [7:0] rx_byte;
    wire tx_busy = tx_bits != 0;
    wire tx_start = !tx_busy && tx_count != 0;
    wire rx_done = rx_state == 3 && rx_timer == 0;
    wire rx_pop = valid && ready && !write && word_addr == 0 && rx_count != 0;
    wire rx_push = rx_done && rx_sync && (rx_count != 8 || rx_pop);
    wire tx_push = valid && ready && !error && write && word_addr == 0 && wstrb[0];
    wire access = valid && ready && !error;
    assign tx = tx_busy ? tx_shift[0] : 1'b1;
    assign irq = (irq_enable[0] && rx_count != 0) ||
                 (irq_enable[1] && tx_count == 0 && !tx_busy);
    assign error = valid && (word_addr > 3 || (write && word_addr == 1));
    assign ready = valid && !(write && word_addr == 0 && wstrb[0] && tx_count == 8);
    always_comb begin
        rdata = 0;
        case (word_addr)
            0: rdata = rx_count == 0 ? 0 : {24'b0, rx_fifo[rx_rptr]};
            1: rdata = {26'b0, (tx_count == 0 && !tx_busy), framing, overrun, tx_busy, (tx_count != 8), (rx_count != 0)};
            2: rdata = {30'b0, irq_enable};
            3: rdata = {30'b0, framing, overrun};
            default: rdata = 0;
        endcase
    end
    always_ff @(posedge clk) begin
        if (rst) begin
            rx_meta <= 1; rx_sync <= 1;
            tx_wptr <= 0; tx_rptr <= 0; tx_count <= 0;
            rx_wptr <= 0; rx_rptr <= 0; rx_count <= 0;
            tx_shift <= 10'h3ff; tx_bits <= 0; tx_timer <= 0;
            rx_state <= 0; rx_timer <= 0; rx_bit <= 0; rx_byte <= 0;
            irq_enable <= 0; overrun <= 0; framing <= 0;
        end else begin
            rx_meta <= rx; rx_sync <= rx_meta;
            if (access && write && word_addr == 2 && wstrb[0]) irq_enable <= wdata[1:0];
            if (access && write && word_addr == 3 && wstrb[0]) begin
                if (wdata[0]) overrun <= 0;
                if (wdata[1]) framing <= 0;
            end
            if (tx_push) begin tx_fifo[tx_wptr] <= wdata[7:0]; tx_wptr <= tx_wptr + 1'b1; end
            if (tx_start) begin
                tx_rptr <= tx_rptr + 1'b1;
                tx_shift <= {1'b1, tx_fifo[tx_rptr], 1'b0};
                tx_bits <= 10; tx_timer <= DIV-1;
            end else if (tx_busy) begin
                if (tx_timer == 0) begin
                    tx_shift <= {1'b1, tx_shift[9:1]};
                    tx_bits <= tx_bits - 1'b1; tx_timer <= DIV-1;
                end else tx_timer <= tx_timer - 1'b1;
            end
            case ({tx_push, tx_start})
                2'b10: tx_count <= tx_count + 1'b1;
                2'b01: tx_count <= tx_count - 1'b1;
                default: begin end
            endcase
            if (rx_pop) rx_rptr <= rx_rptr + 1'b1;
            if (rx_push) begin rx_fifo[rx_wptr] <= rx_byte; rx_wptr <= rx_wptr + 1'b1; end
            case ({rx_push, rx_pop})
                2'b10: rx_count <= rx_count + 1'b1;
                2'b01: rx_count <= rx_count - 1'b1;
                default: begin end
            endcase
            if (rx_done && rx_sync && !rx_push) overrun <= 1;
            if (rx_done && !rx_sync) framing <= 1;
            case (rx_state)
                0: if (!rx_sync) begin rx_state <= 1; rx_timer <= DIV/2-1; end
                1: if (rx_timer != 0) rx_timer <= rx_timer - 1'b1;
                   else if (rx_sync) rx_state <= 0;
                   else begin rx_state <= 2; rx_timer <= DIV-1; rx_bit <= 0; end
                2: if (rx_timer != 0) rx_timer <= rx_timer - 1'b1;
                   else begin
                       rx_byte[rx_bit] <= rx_sync; rx_timer <= DIV-1;
                       if (rx_bit == 7) rx_state <= 3;
                       else rx_bit <= rx_bit + 1'b1;
                   end
                3: if (rx_timer != 0) rx_timer <= rx_timer - 1'b1;
                   else rx_state <= 0;
            endcase
        end
    end
endmodule
