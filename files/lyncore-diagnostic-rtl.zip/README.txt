LynCore / YOLO integration - 160x90 diagnostic RTL snapshot

These 90 RTL files correspond to source hashes listed in the project's 2026-11-04 diagnostic candidate manifest. They include LynCore and selected accelerator and video pipeline modules. This is a source snapshot for inspection, not a complete standalone build: vendor IP, board constraints, firmware, model weights, build tools and other dependencies are not included. No license is granted for omitted third-party components. Preserve applicable notices and check rights before redistribution.

Board test (2026-11-04): the diagnostic bitstream was programmed and ten detection packets passed UART CRC checks. The HDMI display reported no signal or unsupported input; its cause was not established. A separate RTL simulation checked 720p pin timing without camera-frame input. These results do not establish a working HDMI display or accuracy, FPS or full-system benchmark.

Bitstream SHA-256: 14dba98f468fd809f2b6b782d695e40750a3b8ad46d8864db2fc9b582ad76201
